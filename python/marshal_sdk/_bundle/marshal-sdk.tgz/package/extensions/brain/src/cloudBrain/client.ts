import type { CallerCredentialSource } from './googleCredentials.js';
import { CloudBrainError, redactCredentials } from './errors.js';

export const MCP_PROTOCOL_VERSION = '2025-06-18';
export const CALLER_HEADER = 'x-brain-caller';
const STARTING = /\bstarting\b/i;
const UNKNOWN_SESSION = /unknown-session/i;
const BUSY_STATUS = 'busy';
/** Statuses and error codes of a request the cloud refused as malformed or unanswerable, not a cloud outage. */
const REJECTED_STATUSES = new Set([
  'invalid-request', 'invalid_request', 'rejected', 'invalid_filter', 'ambiguous_ref', 'not_found',
  'cursor_expired', 'limit_exceeded',
]);
const MAX_ERROR_TEXT = 600;
const MAX_RESPONSE_BYTES = 8 * 1024 * 1024;
const CLIENT_INFO = { name: 'marshal-cloud-brain', version: '0.1.0' } as const;
/** The cloud service's own retry hint for a starting index. */
export const STARTING_RETRY_AFTER_SECONDS = 30;

export interface CloudToolAnswer {
  readonly output: unknown;
  readonly caller: string;
}

export interface CloudBrainClient {
  callTool(
    tool: string,
    args: Readonly<Record<string, unknown>>,
    signal: AbortSignal,
    callerEmail?: string,
  ): Promise<CloudToolAnswer>;
  /** Opens the connection to the proxy ahead of a call when it has been idle; never throws, never blocks. */
  warm?(): void;
}

export const CLOUD_KEEPALIVE_ENV = 'MARSHAL_BRAIN_CLOUD_KEEPALIVE';
const CLOUD_KEEPALIVE_OFF = '0';
/** How long an idle connection to the proxy stays open (fetch's own default is 4 s, shorter than a person's pause). */
export const CLOUD_KEEPALIVE_MS = 110_000;
const CLOUD_WARM_PATH = '/health';
const CLOUD_WARM_TIMEOUT_MS = 5_000;
const UNDICI_GLOBAL_DISPATCHER = Symbol.for('undici.globalDispatcher.1');

type UndiciAgentClass = new (options: { keepAliveTimeout: number; keepAliveMaxTimeout: number }) => object;

/**
 * The runtime's own undici Agent class, found through the global dispatcher fetch uses: the extension
 * cannot import undici, and an agent built from another copy would not be accepted by this fetch.
 */
function undiciAgentClass(): UndiciAgentClass | undefined {
  void globalThis.Response;
  const agent = (globalThis as { [UNDICI_GLOBAL_DISPATCHER]?: { constructor?: unknown; dispatch?: unknown } })[UNDICI_GLOBAL_DISPATCHER];
  return typeof agent?.constructor === 'function' && typeof agent.dispatch === 'function'
    ? agent.constructor as UndiciAgentClass
    : undefined;
}

export interface CloudConnection {
  /** Extra fetch options for a request: the dispatcher that keeps the connection open. */
  init(): { dispatcher?: object };
  /** A request is about to go out. */
  used(): void;
  /** Sends one unauthenticated GET /health when the connection has been idle, so the next call finds it open. */
  warm(): void;
}

/**
 * The cloud client posts through its own Agent that keeps an idle connection to the proxy 110 s
 * instead of fetch's 4 s, so a call after a pause skips the connection setup. `warm` opens that
 * connection ahead of a call. MARSHAL_BRAIN_CLOUD_KEEPALIVE=0 turns it off; requests and answers
 * are unchanged either way.
 */
export function createCloudConnection(
  origin: string,
  fetcher: typeof fetch,
  deps: { readonly env?: NodeJS.ProcessEnv; readonly now?: () => number; readonly agentClass?: UndiciAgentClass } = {},
): CloudConnection {
  const env = deps.env ?? process.env;
  const now = deps.now ?? Date.now;
  const off = env[CLOUD_KEEPALIVE_ENV]?.trim() === CLOUD_KEEPALIVE_OFF;
  let dispatcher: object | undefined;
  if (!off) {
    try {
      const Agent = deps.agentClass ?? undiciAgentClass();
      dispatcher = Agent ? new Agent({ keepAliveTimeout: CLOUD_KEEPALIVE_MS, keepAliveMaxTimeout: CLOUD_KEEPALIVE_MS }) : undefined;
    } catch {
      dispatcher = undefined;
    }
  }
  let usedAt = Number.NEGATIVE_INFINITY;
  return {
    init: () => (dispatcher ? { dispatcher } : {}),
    used() {
      usedAt = now();
    },
    warm() {
      if (!dispatcher || now() - usedAt < CLOUD_KEEPALIVE_MS) return;
      usedAt = now();
      void fetcher(`${origin}${CLOUD_WARM_PATH}`, {
        method: 'GET',
        dispatcher,
        signal: AbortSignal.timeout(CLOUD_WARM_TIMEOUT_MS),
      } as RequestInit)
        .then((response) => discard(response))
        .catch(() => undefined);
    },
  };
}

/**
 * A minimal streamable-HTTP MCP client for the cloud Brain: one stateless JSON-RPC `tools/call` per request, with the
 * service-account ID token and the signed-in person as the viewer. Each failure becomes a `CloudBrainError` whose code
 * says what happened (auth, unavailable, starting, busy, timeout, rejected), never an empty success.
 */
export function createCloudBrainClient(
  options: {
    readonly url: string;
    readonly credentials: CallerCredentialSource;
    readonly sendCaller?: boolean;
    /** Full MCP endpoint, when it is not `<url origin>/mcp` (the org broker's `<apiBase>/v1/broker/brain/mcp`). */
    readonly endpoint?: string;
  },
  deps: {
    readonly fetch?: typeof fetch;
    readonly connection?: CloudConnection;
    readonly env?: NodeJS.ProcessEnv;
    readonly now?: () => number;
    readonly agentClass?: UndiciAgentClass;
  } = {},
): CloudBrainClient {
  const fetcher = deps.fetch ?? fetch;
  const endpoint = options.endpoint ?? `${new URL(options.url).origin}/mcp`;
  const connection = deps.connection ?? createCloudConnection(new URL(options.url).origin, fetcher, deps);
  let nextId = 1;
  let initialized = false;
  let sessionId: string | undefined;

  const post = async (
    body: Record<string, unknown>,
    signal: AbortSignal,
    allowRefresh: boolean,
    callerEmail?: string,
  ): Promise<{ response: Response; caller: string }> => {
    const credentials = await options.credentials.credentials(signal, callerEmail);
    const caller = callerEmail ?? credentials.caller;
    if (!caller) {
      throw new CloudBrainError('cloud_brain_auth_failed', 'cloud brain auth failed: no authenticated caller is available.');
    }
    let response: Response;
    connection.used();
    try {
      response = await fetcher(endpoint, {
        method: 'POST',
        headers: {
          authorization: `Bearer ${credentials.idToken}`,
          ...(options.sendCaller === false ? {} : { [CALLER_HEADER]: caller }),
          'content-type': 'application/json',
          accept: 'application/json, text/event-stream',
          'mcp-protocol-version': MCP_PROTOCOL_VERSION,
          ...(sessionId ? { 'mcp-session-id': sessionId } : {}),
        },
        body: JSON.stringify(body),
        signal,
        ...connection.init(),
      } as RequestInit);
    } catch (error) {
      if (signal.aborted) throw signal.reason ?? error;
      throw new CloudBrainError(
        'cloud_brain_unavailable',
        `cloud brain unavailable: could not reach ${endpoint} (${describeNetworkError(error)}).`,
      );
    }
    if (response.status === 401 && allowRefresh) {
      await discard(response);
      options.credentials.reset();
      return post(body, signal, false, callerEmail);
    }
    const issued = response.headers.get('mcp-session-id');
    if (issued) sessionId = issued;
    return { response, caller };
  };

  const rpc = async (
    method: string,
    params: Record<string, unknown>,
    signal: AbortSignal,
    callerEmail?: string,
  ) => {
    const id = nextId++;
    const { response, caller } = await post({ jsonrpc: '2.0', id, method, params }, signal, true, callerEmail);
    await assertHttpOk(response);
    const message = await readJsonRpc(response, id, signal);
    return { message, caller };
  };

  const initialize = async (signal: AbortSignal, callerEmail?: string) => {
    const { message } = await rpc('initialize', {
      protocolVersion: MCP_PROTOCOL_VERSION,
      capabilities: {},
      clientInfo: CLIENT_INFO,
    }, signal, callerEmail);
    if (message.error) throw rpcFailure(message.error);
    const { response } = await post({ jsonrpc: '2.0', method: 'notifications/initialized' }, signal, true, callerEmail);
    await discard(response);
    initialized = true;
  };

  return {
    async callTool(tool, args, signal, callerEmail) {
      let message: JsonRpcMessage;
      let caller: string;
      try {
        ({ message, caller } = await rpc('tools/call', { name: tool, arguments: args }, signal, callerEmail));
      } catch (error) {
        // The broker pins a session to the person and answers 404 `unknown-session` for one it no longer knows: start a new one.
        if (!sessionId || !(error instanceof CloudBrainError) || error.httpStatus !== 404 || !UNKNOWN_SESSION.test(error.message)) throw error;
        sessionId = undefined;
        initialized = false;
        await initialize(signal, callerEmail);
        ({ message, caller } = await rpc('tools/call', { name: tool, arguments: args }, signal, callerEmail));
      }
      if (message.error && !initialized && isNotInitialized(message.error)) {
        await initialize(signal, callerEmail);
        ({ message, caller } = await rpc('tools/call', { name: tool, arguments: args }, signal, callerEmail));
      }
      if (message.error) throw rpcFailure(message.error);
      return { output: readToolResult(message.result, tool), caller };
    },
    warm() {
      connection.warm();
    },
  };
}

interface JsonRpcMessage {
  readonly id?: unknown;
  readonly result?: unknown;
  readonly error?: { readonly code?: unknown; readonly message?: unknown };
}

async function assertHttpOk(response: Response): Promise<void> {
  if (response.ok) return;
  const detail = redactCredentials((await safeText(response)).slice(0, MAX_ERROR_TEXT));
  const status = response.status;
  if (status === 401 || status === 403) {
    throw new CloudBrainError(
      'cloud_brain_auth_failed',
      `cloud brain auth failed: the cloud Brain refused the caller (HTTP ${status}${detail ? `: ${detail}` : ''}).`,
      { httpStatus: status },
    );
  }
  if (status === 429) {
    throw new CloudBrainError(
      'cloud_brain_busy',
      `cloud brain busy: the proxy is rate limiting (HTTP 429); retry in a few seconds.`,
      { httpStatus: status, retryAfterSeconds: retryAfter(response) ?? 5 },
    );
  }
  if (status === 502 || status === 503 || status === 504) {
    throw new CloudBrainError(
      'cloud_brain_unavailable',
      `cloud brain unavailable: the proxy answered HTTP ${status}; the Brain service behind it is down, restarting or starting up. Retry in a minute; local knowledge.* is unaffected.`,
      { httpStatus: status, retryAfterSeconds: retryAfter(response) ?? 60 },
    );
  }
  if (status === 400 || status === 404 || status === 405 || status === 406 || status === 415) {
    throw new CloudBrainError(
      'cloud_brain_rejected',
      `cloud brain rejected the request (HTTP ${status}${detail ? `: ${detail}` : ''}).`,
      { httpStatus: status },
    );
  }
  throw new CloudBrainError(
    'cloud_brain_failed',
    `cloud brain failed with HTTP ${status}${detail ? `: ${detail}` : ''}.`,
    { httpStatus: status },
  );
}

async function readJsonRpc(response: Response, id: number, signal: AbortSignal): Promise<JsonRpcMessage> {
  const text = await boundedText(response, signal);
  const contentType = response.headers.get('content-type') ?? '';
  const candidates = contentType.includes('text/event-stream')
    ? sseMessages(text)
    : [text];
  for (const candidate of candidates) {
    let parsed: unknown;
    try {
      parsed = JSON.parse(candidate);
    } catch {
      continue;
    }
    for (const message of Array.isArray(parsed) ? parsed : [parsed]) {
      if (message && typeof message === 'object' && (message as JsonRpcMessage).id === id) {
        return message as JsonRpcMessage;
      }
    }
  }
  throw new CloudBrainError('cloud_brain_failed', 'cloud brain failed: the answer was not a JSON-RPC response to this call.');
}

function sseMessages(text: string): string[] {
  const messages: string[] = [];
  for (const block of text.split(/\r?\n\r?\n/)) {
    const data = block
      .split(/\r?\n/)
      .filter((line) => line.startsWith('data:'))
      .map((line) => line.slice(5).trimStart())
      .join('\n');
    if (data) messages.push(data);
  }
  return messages;
}

/**
 * Reads the text a cloud tool answers: the body itself (`{ok: true, status, ...}`; a legacy `output` wrapper is
 * unwrapped), or `{ok: false, error: {code, message, details}}`, which throws the matching error.
 */
export function readToolResult(raw: unknown, tool: string): unknown {
  const result = raw as { content?: Array<{ type?: string; text?: string }>; isError?: boolean } | undefined;
  const text = result?.content?.find((part) => part.type === 'text')?.text;
  if (typeof text !== 'string') {
    throw new CloudBrainError('cloud_brain_failed', `cloud brain failed: ${tool} answered without a text result.`);
  }
  let body: { ok?: unknown; status?: unknown; output?: unknown; error?: unknown };
  try {
    body = JSON.parse(text) as typeof body;
  } catch {
    if (result?.isError === true) throw toolFailure(tool, 'failed', text);
    return text;
  }
  if (body.ok === true) return body.output ?? body;
  const error = failureDetail(body.error, tool);
  const status = typeof body.status === 'string' ? body.status : error.code ?? 'failed';
  throw toolFailure(tool, status, error.message);
}

function failureDetail(error: unknown, tool: string): { message: string; code?: string } {
  if (typeof error === 'string') return { message: error };
  if (error && typeof error === 'object') {
    const record = error as { code?: unknown; message?: unknown };
    const message = typeof record.message === 'string' ? record.message : `${tool} failed`;
    return typeof record.code === 'string' ? { message, code: record.code } : { message };
  }
  return { message: `${tool} failed` };
}

function toolFailure(tool: string, status: string, error: string): CloudBrainError {
  const detail = redactCredentials(error).slice(0, MAX_ERROR_TEXT);
  if (status === 'timeout') {
    return new CloudBrainError('cloud_brain_timeout', `cloud brain timeout: ${tool}: ${detail}`, { retryAfterSeconds: 30, toolStatus: status });
  }
  if (status === 'unavailable' && STARTING.test(error)) {
    return new CloudBrainError(
      'cloud_brain_starting',
      `cloud brain starting: ${detail}`,
      { retryAfterSeconds: STARTING_RETRY_AFTER_SECONDS, toolStatus: status },
    );
  }
  if (status === 'unavailable') {
    return new CloudBrainError('cloud_brain_unavailable', `cloud brain unavailable: ${detail}`, { retryAfterSeconds: 60, toolStatus: status });
  }
  if (status === BUSY_STATUS) {
    return new CloudBrainError('cloud_brain_busy', `cloud brain busy: ${detail}`, { retryAfterSeconds: 5, toolStatus: status });
  }
  if (REJECTED_STATUSES.has(status)) {
    return new CloudBrainError('cloud_brain_rejected', `cloud brain rejected ${tool}: ${detail}`, { toolStatus: status });
  }
  if (status === 'permission-denied') {
    return new CloudBrainError('cloud_brain_auth_failed', `cloud brain auth failed: ${tool} was refused: ${detail}`, { toolStatus: status });
  }
  return new CloudBrainError('cloud_brain_failed', `cloud brain failed: ${tool} (${status}): ${detail}`, { toolStatus: status });
}

function rpcFailure(error: JsonRpcMessage['error']): CloudBrainError {
  const message = typeof error?.message === 'string' ? redactCredentials(error.message).slice(0, MAX_ERROR_TEXT) : 'unknown error';
  if (error?.code === -32601 || error?.code === -32602) {
    return new CloudBrainError('cloud_brain_rejected', `cloud brain rejected the call: ${message}`);
  }
  return new CloudBrainError('cloud_brain_failed', `cloud brain failed: ${message}`);
}

function isNotInitialized(error: JsonRpcMessage['error']): boolean {
  return typeof error?.message === 'string' && /not initialized/i.test(error.message);
}

function retryAfter(response: Response): number | undefined {
  const value = Number(response.headers.get('retry-after'));
  return Number.isFinite(value) && value > 0 ? value : undefined;
}

async function boundedText(response: Response, signal: AbortSignal): Promise<string> {
  const length = Number(response.headers.get('content-length'));
  if (Number.isFinite(length) && length > MAX_RESPONSE_BYTES) {
    await discard(response);
    throw new CloudBrainError('cloud_brain_failed', `cloud brain failed: the answer is larger than ${MAX_RESPONSE_BYTES} bytes; narrow the request.`);
  }
  let text: string;
  try {
    text = await response.text();
  } catch (error) {
    if (signal.aborted) throw signal.reason ?? error;
    throw new CloudBrainError('cloud_brain_unavailable', 'cloud brain unavailable: the connection closed before the answer was read.');
  }
  if (text.length > MAX_RESPONSE_BYTES) {
    throw new CloudBrainError('cloud_brain_failed', `cloud brain failed: the answer is larger than ${MAX_RESPONSE_BYTES} bytes; narrow the request.`);
  }
  return text;
}

async function safeText(response: Response): Promise<string> {
  try {
    return await response.text();
  } catch {
    return '';
  }
}

async function discard(response: Response): Promise<void> {
  try {
    await response.body?.cancel();
  } catch {
    // The body is not needed.
  }
}

function describeNetworkError(error: unknown): string {
  const cause = (error as { cause?: { code?: unknown; message?: unknown } } | null)?.cause;
  if (typeof cause?.code === 'string') return cause.code;
  if (error instanceof Error && error.message) return redactCredentials(error.message).slice(0, 200);
  return 'network error';
}
