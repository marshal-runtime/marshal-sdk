import type { InvocationContext } from '@marshal/agent-runtime-core';
import type { LegacyProjectTargetOptions, PortableMemoryRuntime } from '@marshal/agent-runtime-provider-memory';
import { stableId } from './lifecycleScopeIds.js';
import type { HealLog } from './userDailyHeal.js';

const consoleLog: HealLog = {
  info: (message, metadata) => console.info(message, metadata),
  warn: (message, metadata) => console.warn(message, metadata),
};

/**
 * Moves the opened project's principal-keyed (pre-sharing) workspace/project memories
 * into its shared project scope: those projected under its projection root, and those
 * recorded sessions prove belong to it. Only the opened project: the copies are written
 * under this bundle's projection root, which is where this project's bundle imports them
 * from. Another project's copies written here would be missing from its own root when it
 * opens, and its import would drop them, so other proven projects are only counted
 * (`deferredProjects`) and migrate when they are opened. It never rejects: failures are
 * logged (metadata only) and the ledger stays open, so the next start retries.
 */
export async function runProjectScopeMigration(
  runtime: PortableMemoryRuntime,
  hostContext: InvocationContext,
  projectionRoot: string,
  log: HealLog = consoleLog,
): Promise<void> {
  const startedAt = Date.now();
  try {
    const ownProjectId = hostContext.scope?.projectId;
    // Wave-1 lifecycles recorded a hash of the host project id: never proof of a project.
    const options: LegacyProjectTargetOptions = {
      phantomProjectId: (projectId) => stableId('project', projectId),
      ...(ownProjectId ? { hostProjectIds: [ownProjectId] } : {}),
    };
    const { targets } = runtime.recordedLegacyProjectTargets(options);
    const ownProven = targets.find(({ projectId }) => projectId === ownProjectId)?.sourceScopeIds ?? [];
    // Scopes proven for another project stay out, even if their files sit under this root.
    const provenElsewhere = targets.filter(({ projectId }) => projectId !== ownProjectId)
      .flatMap(({ sourceScopeIds }) => sourceScopeIds);
    const project = runtime.scopes.ensureBuiltInScopes(hostContext).find(({ kind }) => kind === 'project');
    let promoted = 0;
    if (project) {
      const result = await runtime.migrateLegacyProjectScopes({
        targetHandle: { scopeId: project.scopeId, policyVersion: project.policyVersion },
        projectionRoot,
        sourceScopeIds: ownProven,
        excludedScopeIds: provenElsewhere,
      }, hostContext);
      if (result.status === 'completed') promoted = result.promoted.length;
    }
    const pending = runtime.recordedLegacyProjectTargets(options);
    log.info('[brain] project-scope migration', {
      status: 'completed',
      promoted,
      deferredProjects: pending.targets.filter(({ projectId }) => projectId !== ownProjectId).length,
      pendingLegacyScopes: pending.unidentifiedScopeIds.length
        + pending.targets.reduce((sum, { sourceScopeIds }) => sum + sourceScopeIds.length, 0),
      durationMs: Date.now() - startedAt,
    });
  } catch (error) {
    log.warn('[brain] project-scope migration failed; it will retry at next start', {
      errorName: error instanceof Error ? error.name : typeof error,
      errorCode: typeof (error as { code?: unknown })?.code === 'string' ? (error as { code: string }).code : undefined,
      durationMs: Date.now() - startedAt,
    });
  }
}
