import { createCloudBrainClient, type CloudBrainClient } from './client.js';
import type { CloudRouteConfiguration } from './config.js';
import { CloudBrainError, isCloudBrainError } from './errors.js';
import { isServiceCallerMode } from './config.js';
import {
  createCallerCredentialSource,
  createMetadataCallerCredentialSource,
  createServiceKeyCallerCredentialSource,
  type CallerCredentialSource,
  type GoogleCredentialDeps,
} from './googleCredentials.js';
import { createOrgBrokerBrainClient, type BrokerFetchSource } from './orgBroker.js';
import type { InvocationContext } from '@marshal/agent-runtime-core';
import { RuntimeIdentityError, trustedRuntimeCaller } from '../runtimeIdentity.js';

export interface CloudCallAnswer {
  readonly output: unknown;
  readonly caller: string;
  readonly elapsedMs: number;
}

/** The cloud Brain as Brain's knowledge provider calls it: one read tool per call, under one deadline. */
export interface CloudBrainRoute {
  readonly origin: string;
  /**
   * Calls one cloud tool. `deadlineMs` covers token minting, waiting for a free slot and the call; `reason` names the
   * deadline in the timeout message. Every failure is a coded `CloudBrainError`, never an empty answer.
   */
  call(
    tool: string,
    args: Readonly<Record<string, unknown>>,
    options: {
      readonly deadlineMs: number;
      readonly signal?: AbortSignal;
      readonly reason?: string;
      readonly context?: InvocationContext;
    },
  ): Promise<CloudCallAnswer>;
  /** Desktop ADC warms credentials; delegated mode does not prewarm or cache a viewer identity. */
  prewarm(): void;
  /**
   * Mints the credentials and makes one cheap `schema` call in the background, so the first real search after
   * activation does not pay for the token mint, the connection and a cold cloud path. Returns at once and never
   * throws or rejects; delegated mode does nothing (it has no caller identity yet).
   */
  warmUp(): void;
  /** Stops the keep-warm calls. Safe to call more than once. */
  dispose(): void;
  /** Opens the connection to the proxy when it has been idle, so the next call does not pay for it. */
  warm(): void;
}

export interface CloudBrainRouteDeps extends GoogleCredentialDeps {
  /** Replaces the HTTP client, for tests. */
  readonly client?: CloudBrainClient;
  /** Replaces the credential source, for tests. */
  readonly credentials?: CallerCredentialSource;
  /** Org mode: the host's broker fetch (it adds the org bearer itself). Without one, org mode uses the gcloud fallback. */
  readonly brokerFetch?: BrokerFetchSource;
}

const PREWARM_DEADLINE_MS = 15_000;
const WARM_UP_DEADLINE_MS = 20_000;
const KEEP_WARM_DEADLINE_MS = 15_000;
/** Keep-warm calls stop once no real call has come for this long, so an idle Marshal sends nothing. */
const KEEP_WARM_ACTIVE_MS = 10 * 60_000;
const CREDENTIAL_MINT_DEADLINE_MS = 30_000;
const DELEGATED_IDENTITY_TTL_MS = 24 * 60 * 60 * 1_000;
const MAX_DELEGATED_CONVERSATIONS = 512;

export function createCloudBrainRoute(
  configuration: CloudRouteConfiguration,
  deps: CloudBrainRouteDeps = {},
): CloudBrainRoute {
  const org = configuration.callerMode === 'org';
  if (!configuration.enabled
    || (!org && !configuration.url)
    || (configuration.callerMode === 'desktop' && !configuration.callerServiceAccount)) {
    throw new CloudBrainError('cloud_brain_disabled', 'The cloud route is off.');
  }
  // Org mode reaches the Brain through the org broker; cloudUrl with a service account, when both are set, is the gcloud fallback.
  const gcloudFallback = configuration.url && (!org || configuration.callerServiceAccount);
  const origin = configuration.url ? new URL(configuration.url).origin : 'org-broker';
  const audience = configuration.audience ?? origin;
  const asService = isServiceCallerMode(configuration.callerMode);
  const credentials = shareInFlightMint(deps.credentials ?? (configuration.callerMode === 'delegated'
    ? createMetadataCallerCredentialSource(audience, deps)
    : configuration.callerMode === 'service-key'
      ? createServiceKeyCallerCredentialSource(
        audience,
        configuration.credentialsFile ? { credentialsFile: configuration.credentialsFile } : {},
        deps,
      )
      : gcloudFallback
      ? createCallerCredentialSource({
        serviceAccount: configuration.callerServiceAccount!,
        audience,
        ...(configuration.credentialsFile ? { credentialsFile: configuration.credentialsFile } : {}),
        ...(configuration.expectedCaller ? { expectedCaller: configuration.expectedCaller } : {}),
      }, deps)
      : noGcloudCredentials()));
  const gcloudClient = gcloudFallback
    ? createCloudBrainClient({ url: origin, credentials }, deps.fetch ? { fetch: deps.fetch } : {})
    : undefined;
  const client = deps.client ?? (org
    ? createOrgBrokerBrainClient(
      { source: deps.brokerFetch ?? (() => undefined), ...(gcloudClient ? { fallback: gcloudClient } : {}) },
      deps.now ? { now: deps.now } : {},
    )
    : gcloudClient!);
  const gate = new ConcurrencyGate(configuration.maxConcurrent);
  const now = deps.now ?? Date.now;
  const delegatedIdentities = new Map<string, { readonly callerEmail: string; lastSeenAt: number }>();
  let lastCallAt = 0;
  let lastRealCallAt = 0;
  let keepWarmTimer: ReturnType<typeof setInterval> | undefined;

  const route: CloudBrainRoute = {
    origin,
    async call(tool, args, options) {
      const started = now();
      lastCallAt = started;
      if (options.reason !== 'warm-up' && options.reason !== 'keep-warm') lastRealCallAt = started;
      let release: (() => void) | undefined;
      try {
        const answer = await withCloudDeadline(options.deadlineMs, options.signal, options.reason, async (signal) => {
          const acquired = await gate.acquire(signal);
          if (signal.aborted) {
            acquired();
            throw signal.reason;
          }
          release = acquired;
          const caller = asService
            ? pinTrustedRuntimeCaller(options.context, delegatedIdentities, now())
            : undefined;
          return await client.callTool(tool, args, signal, caller);
        });
        return { output: answer.output, caller: answer.caller, elapsedMs: Math.max(0, now() - started) };
      } finally {
        lastCallAt = now();
        release?.();
      }
    },
    warm() {
      client.warm?.();
    },
    prewarm() {
      client.warm?.();
      if (asService) return;
      const controller = new AbortController();
      const timer = setTimeout(() => controller.abort(), PREWARM_DEADLINE_MS);
      void credentials.credentials(controller.signal)
        .catch(() => undefined)
        .finally(() => clearTimeout(timer));
    },
    warmUp() {
      if (asService) return;
      const started = now();
      try {
        void route.call('schema', {}, { deadlineMs: WARM_UP_DEADLINE_MS, reason: 'warm-up' }).then(
          () => console.info('[brain] cloud warm-up', { status: 'ok', ms: Math.max(0, now() - started) }),
          (error: unknown) => console.info('[brain] cloud warm-up', {
            status: 'failed',
            code: isCloudBrainError(error) ? error.code : 'error',
            ms: Math.max(0, now() - started),
          }),
        );
      } catch {
        // A warm-up never fails the activation.
      }
      if (configuration.keepWarmMs > 0 && !keepWarmTimer) {
        keepWarmTimer = setInterval(() => {
          const at = now();
          if (at - lastRealCallAt > KEEP_WARM_ACTIVE_MS || at - lastCallAt < configuration.keepWarmMs || gate.busy) return;
          try {
            void route.call('schema', {}, { deadlineMs: KEEP_WARM_DEADLINE_MS, reason: 'keep-warm' }).catch(() => undefined);
          } catch {
            // A keep-warm call never throws.
          }
        }, configuration.keepWarmMs);
        keepWarmTimer.unref?.();
      }
    },
    dispose() {
      if (keepWarmTimer) clearInterval(keepWarmTimer);
      keepWarmTimer = undefined;
    },
  };
  return route;
}

/**
 * One token mint in flight per caller, shared by every request that arrives meanwhile: the activation warm-up and the
 * first searches would otherwise each mint their own (a mint takes seconds). The mint outlives any one caller's
 * cancellation, bounded by its own deadline; each caller still stops waiting when its own signal aborts.
 */
function shareInFlightMint(source: CallerCredentialSource): CallerCredentialSource {
  type Minted = Awaited<ReturnType<CallerCredentialSource['credentials']>>;
  const pending = new Map<string, Promise<Minted>>();
  return {
    credentials(signal, callerEmail) {
      const key = callerEmail ?? '';
      let minting = pending.get(key);
      if (!minting) {
        const own = new AbortController();
        const timer = setTimeout(() => own.abort(new CloudBrainError(
          'cloud_brain_timeout',
          `cloud brain timeout: the ID token was not minted within ${CREDENTIAL_MINT_DEADLINE_MS} ms.`,
        )), CREDENTIAL_MINT_DEADLINE_MS);
        const started = source.credentials(own.signal, callerEmail).finally(() => {
          clearTimeout(timer);
          if (pending.get(key) === started) pending.delete(key);
        });
        started.catch(() => undefined);
        pending.set(key, started);
        minting = started;
      }
      return waitFor(minting, signal);
    },
    reset() {
      pending.clear();
      source.reset();
    },
  };
}

function noGcloudCredentials(): CallerCredentialSource {
  return {
    async credentials() {
      throw new CloudBrainError('cloud_brain_auth_failed', 'cloud brain auth failed: the org broker is the only route configured and it is not available.');
    },
    reset() { /* Nothing cached. */ },
  };
}

function waitFor<T>(work: Promise<T>, signal: AbortSignal): Promise<T> {
  if (signal.aborted) return Promise.reject(signal.reason);
  return new Promise<T>((resolve, reject) => {
    const abort = () => reject(signal.reason);
    signal.addEventListener('abort', abort, { once: true });
    work.then(
      (value) => { signal.removeEventListener('abort', abort); resolve(value); },
      (error: unknown) => { signal.removeEventListener('abort', abort); reject(error); },
    );
  });
}

function pinTrustedRuntimeCaller(
  context: InvocationContext | undefined,
  identities: Map<string, { readonly callerEmail: string; lastSeenAt: number }>,
  now: number,
): string {
  let identity: ReturnType<typeof trustedRuntimeCaller>;
  try {
    identity = trustedRuntimeCaller(context);
  } catch (error) {
    if (!(error instanceof RuntimeIdentityError)) throw error;
    throw new CloudBrainError(
      'cloud_brain_auth_failed',
      'cloud brain auth failed: delegated calls require a trusted caller email (principal claim callerEmail) and conversation from the runtime host.',
    );
  }
  const { callerEmail, conversationId } = identity;
  for (const [sessionId, pinned] of identities) {
    if (now - pinned.lastSeenAt > DELEGATED_IDENTITY_TTL_MS) identities.delete(sessionId);
  }
  const existing = identities.get(conversationId);
  if (existing && existing.callerEmail !== callerEmail) {
    throw new CloudBrainError(
      'cloud_brain_auth_failed',
      'cloud brain auth failed: the runtime caller identity changed within an established conversation.',
    );
  }
  if (!existing && identities.size >= MAX_DELEGATED_CONVERSATIONS) {
    throw new CloudBrainError(
      'cloud_brain_auth_failed',
      'cloud brain auth failed: the delegated conversation identity registry is full; start a fresh runtime session.',
    );
  }
  identities.set(conversationId, { callerEmail, lastSeenAt: now });
  return callerEmail;
}

export async function withCloudDeadline<T>(
  deadlineMs: number,
  outer: AbortSignal | undefined,
  reason: string | undefined,
  work: (signal: AbortSignal) => Promise<T>,
): Promise<T> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(new CloudBrainError(
    'cloud_brain_timeout',
    `cloud brain timeout: no answer within ${deadlineMs} ms${reason ? ` (${reason})` : ''}. The cloud Brain may be starting, refreshing or loaded; retry later.`,
    { retryAfterSeconds: 30 },
  )), deadlineMs);
  const cancel = () => controller.abort(new CloudBrainError('cloud_brain_cancelled', 'cloud brain call cancelled by the caller.'));
  if (outer?.aborted) cancel();
  outer?.addEventListener?.('abort', cancel, { once: true });
  try {
    return await Promise.race([
      work(controller.signal),
      new Promise<never>((_, reject) => {
        if (controller.signal.aborted) reject(controller.signal.reason);
        controller.signal.addEventListener('abort', () => reject(controller.signal.reason), { once: true });
      }),
    ]);
  } catch (error) {
    if (controller.signal.aborted && isCloudBrainError(controller.signal.reason)) throw controller.signal.reason;
    throw error;
  } finally {
    clearTimeout(timer);
    outer?.removeEventListener?.('abort', cancel);
    controller.abort();
  }
}

/** At most `limit` calls in flight; a released slot passes straight to the next waiter. */
class ConcurrencyGate {
  #running = 0;
  readonly #waiting: Array<() => void> = [];

  constructor(private readonly limit: number) {}

  get busy(): boolean {
    return this.#running > 0;
  }

  async acquire(signal: AbortSignal): Promise<() => void> {
    if (this.#running < this.limit) {
      this.#running += 1;
    } else {
      await new Promise<void>((resolve, reject) => {
        const wake = () => {
          signal.removeEventListener('abort', abort);
          resolve();
        };
        const abort = () => {
          const index = this.#waiting.indexOf(wake);
          if (index >= 0) this.#waiting.splice(index, 1);
          reject(signal.reason);
        };
        this.#waiting.push(wake);
        signal.addEventListener('abort', abort, { once: true });
      });
    }
    let released = false;
    return () => {
      if (released) return;
      released = true;
      const next = this.#waiting.shift();
      if (next) next();
      else this.#running -= 1;
    };
  }
}
