import { createReadStream } from 'node:fs';
import { readFile, stat } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { homedir } from 'node:os';
import { join } from 'node:path';
import { Graph } from './core.js';

export const DEFAULT_COMPANY_GRAPH_DIR = join(homedir(), '.marshal', 'brain', 'company-graph');
export const EXPECTED_FREEZE_SHA = '051d67efc85da3662cc75ebbae8701c6a60000ab1c06a29bcd40132e08f1054b';

export interface GraphManifest {
  readonly bytes: Buffer;
  readonly revision: string;
}

export interface CompanyGraphSource {
  manifest(): Promise<GraphManifest>;
  records(file: 'nodes.jsonl' | 'edges.jsonl', accept: (record: Record<string, unknown>) => void): Promise<string>;
}

export class LocalCompanyGraphSource implements CompanyGraphSource {
  constructor(readonly directory: string = DEFAULT_COMPANY_GRAPH_DIR) {}

  async manifest(): Promise<GraphManifest> {
    const path = join(this.directory, 'FREEZE.json');
    const info = await stat(path, { bigint: true });
    const bytes = await readFile(path);
    return { bytes, revision: `${info.ino}:${info.mtimeNs}:${info.ctimeNs}:${digest(bytes)}` };
  }

  async records(file: 'nodes.jsonl' | 'edges.jsonl', accept: (record: Record<string, unknown>) => void): Promise<string> {
    const hash = createHash('sha256');
    const parse = (line: string) => {
      try {
        return JSON.parse(line) as Record<string, unknown>;
      } catch {
        throw new Error(`Frozen company graph refused: invalid JSONL in ${file}; snapshot integrity could not be verified.`);
      }
    };
    let pending = '';
    for await (const chunk of createReadStream(join(this.directory, file), { encoding: 'utf8' })) {
      hash.update(chunk);
      pending += chunk;
      let start = 0;
      let end: number;
      while ((end = pending.indexOf('\n', start)) !== -1) {
        if (end > start) accept(parse(pending.slice(start, end)));
        start = end + 1;
      }
      pending = pending.slice(start);
    }
    if (pending) accept(parse(pending));
    return hash.digest('hex');
  }
}

export class LazyCompanyGraph {
  private cached?: { revision: string; graph: Graph };
  private loading?: { revision: string; promise: Promise<Graph> };
  private readonly expectedFreezeSha: string;

  constructor(private readonly source: CompanyGraphSource = new LocalCompanyGraphSource(), expectedFreezeSha: unknown = EXPECTED_FREEZE_SHA) {
    if (typeof expectedFreezeSha !== 'string' || !/^[a-f\d]{64}$/i.test(expectedFreezeSha)) {
      throw new TypeError('companyGraphFreezeSha must be a 64-character hexadecimal SHA256.');
    }
    this.expectedFreezeSha = expectedFreezeSha.toLowerCase();
  }

  async get(): Promise<Graph> {
    const manifest = await this.source.manifest();
    if (digest(manifest.bytes) !== this.expectedFreezeSha) {
      this.cached = undefined;
      throw new Error('Frozen company graph refused: FREEZE.json SHA256 does not match the pinned freeze.');
    }
    if (this.cached?.revision === manifest.revision) return this.cached.graph;
    if (this.loading?.revision === manifest.revision) return this.loading.promise;
    this.cached = undefined;
    const pending = { revision: manifest.revision, promise: this.load(manifest) };
    this.loading = pending;
    try {
      const graph = await pending.promise;
      if (this.loading === pending) this.cached = { revision: manifest.revision, graph };
      return graph;
    } finally {
      if (this.loading === pending) this.loading = undefined;
    }
  }

  dispose(): void {
    this.cached = undefined;
    this.loading = undefined;
  }

  private async load(manifest: GraphManifest): Promise<Graph> {
    const freeze = JSON.parse(manifest.bytes.toString('utf8')) as Record<string, unknown>;
    const graph = new Graph();
    for (const [file, key] of [['nodes.jsonl', 'nodes_sha256'], ['edges.jsonl', 'edges_sha256']] as const) {
      const actual = await this.source.records(file, (record) => file === 'nodes.jsonl' ? graph.addNode(record) : graph.addEdge(record));
      if (actual !== freeze[key]) throw new Error(`Frozen company graph refused: ${file} SHA256 does not match FREEZE.json.`);
    }
    const current = await this.source.manifest();
    if (current.revision !== manifest.revision || !current.bytes.equals(manifest.bytes)) {
      throw new Error('Frozen company graph refused: FREEZE.json changed while the graph was loading; retry against a stable snapshot.');
    }
    graph.sourceLabel = this.expectedFreezeSha === EXPECTED_FREEZE_SHA
      ? 'frozen snapshot poc/graph-frozen-v2'
      : `frozen snapshot sha256:${this.expectedFreezeSha}`;
    graph.build();
    return graph;
  }
}

function digest(bytes: Buffer): string {
  return createHash('sha256').update(bytes).digest('hex');
}
