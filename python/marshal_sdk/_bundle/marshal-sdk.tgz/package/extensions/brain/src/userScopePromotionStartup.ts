import type { ForeignAgentPromotionResult } from '@marshal/agent-runtime-provider-memory';

export interface PromotionLog {
  info(message: string, metadata: Readonly<Record<string, unknown>>): void;
  warn(message: string, metadata: Readonly<Record<string, unknown>>): void;
}

const consoleLog: PromotionLog = {
  info: (message, metadata) => console.info(message, metadata),
  warn: (message, metadata) => console.warn(message, metadata),
};

/**
 * Runs the agent-scope promotion (and blessing) at activation. It never rejects: a
 * failure is logged (metadata only, never memory text) and the ledger stays
 * unwritten, so the next start retries.
 */
export async function runStartupPromotion(
  promote: () => Promise<ForeignAgentPromotionResult>,
  log: PromotionLog = consoleLog,
): Promise<ForeignAgentPromotionResult | undefined> {
  const startedAt = Date.now();
  try {
    const result = await promote();
    const blessed = (result as { readonly blessed?: number }).blessed ?? 0;
    // One line per start, also when nothing was left to do.
    log.info('[brain] user-scope promotion completed', {
      status: result.status,
      promoted: result.status === 'completed' ? result.promoted.filter(({ reused }) => !reused).length : 0,
      reused: result.status === 'completed' ? result.promoted.filter(({ reused }) => reused).length : 0,
      blessed,
      durationMs: Date.now() - startedAt,
    });
    return result;
  } catch (error) {
    log.warn('[brain] user-scope promotion failed; it will retry at next start', {
      errorName: error instanceof Error ? error.name : typeof error,
      errorCode: typeof (error as { code?: unknown })?.code === 'string' ? (error as { code: string }).code : undefined,
      durationMs: Date.now() - startedAt,
    });
    return undefined;
  }
}

/**
 * Activation order: promotion (and blessing) settles first, then the host store is
 * registered, so the first prompt already sees promoted memories. A failed
 * promotion still registers the store.
 */
export async function registerAfterStartupPromotion<T>(
  promote: () => Promise<ForeignAgentPromotionResult>,
  register: () => T,
  log: PromotionLog = consoleLog,
): Promise<T> {
  await runStartupPromotion(promote, log);
  return register();
}
