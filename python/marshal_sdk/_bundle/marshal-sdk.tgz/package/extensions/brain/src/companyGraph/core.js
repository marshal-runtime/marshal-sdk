// Ported from poc/walk/graph.mjs; traversal and lexical ranking are unchanged.
// Snapshot IO is owned by loader.ts; vectors, cloud search and text rendering are excluded.
// ---------------------------------------------------------------------------------------------
// Impact direction table. One entry per edge type. The stored edge is  from --TYPE--> to.
//   fwd : a change at `from` affects `to`        (WRITES: a writer change affects the table it writes)
//   rev : a change at `to` affects `from`        (READS: a source change affects the reader)
//   none: the edge does not carry change impact  (attribution, tenancy, classification)
// impact() follows only these directions and excludes the starting table's builders across cycles.
// ---------------------------------------------------------------------------------------------
export const IMPACT_DIRECTION = {
  READS: 'rev',
  WRITES: 'fwd',
  FEEDS: 'fwd',
  RUNS: 'rev', // airflow_dag RUNS sql_file: a change to the file affects the dag that runs it
  REFERENCES: 'rev', // table REFERENCES table (FK): a change to the referenced table affects the referencing one
  LIVES_IN: 'fwd', // column LIVES_IN table: a column change affects its table
  DERIVED_FROM: 'rev',
  COMPUTED_FROM: 'rev',
  MIRRORS: 'rev', // mirror MIRRORS source
  CHANGED_BY: 'rev', // symbol CHANGED_BY commit
  MERGED_AS: 'rev', // commit MERGED_AS pr
  IMPLEMENTS: 'rev', // pr IMPLEMENTS ticket
  DEFINED_IN: 'fwd', // symbol DEFINED_IN service
  CALLS: 'rev', // caller CALLS callee: callee change affects caller
  CREATED_VIA: 'rev',
  ENTERS_VIA: 'rev',
  RESOLVES_TO: 'rev',
  WRITTEN_BY: 'rev', // decision/event WRITTEN_BY code symbol
  PART_OF: 'rev', // ad PART_OF adset PART_OF campaign: parent change affects children
  ABOUT: 'rev', // insight ABOUT ad
  RESPONDS_TO: 'rev', // decision RESPONDS_TO insight
  ACTED_ON: 'fwd', // decision ACTED_ON ad
  CHANGED: 'fwd', // change_event CHANGED ad
  CAUSED: 'fwd', // decision CAUSED change_event
  // non-propagating: attribution, tenancy, classification, bulk instance links
  MADE_BY: 'none',
  CREATED_BY: 'none',
  BELONGS_TO: 'none',
  CLIENT_OF: 'none',
  INSTANCE_OF: 'none',
  SUBCLASS_OF: 'none',
  STORED_IN: 'none',
  STORES: 'none',
  REPORTED_IN: 'none',
  REPORTS_ON: 'none',
  ROLLS_UP_TO: 'none',
  // brand-brain, incident and creative chains in the merged snapshot
  CONTAINS: 'fwd', // account CONTAINS campaign, adset CONTAINS ad: a parent change affects its children
  APPLIES_TO: 'fwd', // rule APPLIES_TO metric
  COMPUTES: 'fwd', // recipe COMPUTES metric
  LANDS_ON: 'rev', // ad LANDS_ON landing_page: a page change affects the ads that land on it
  PROMOTES: 'rev', // ad PROMOTES product
  HAS_PRODUCT: 'fwd',
  HAS_VARIANT: 'fwd',
  FOR_PRODUCT: 'rev',
  AFFECTS: 'fwd', // root_cause AFFECTS service
  FIXES: 'fwd', // pr FIXES root_cause
  TOUCHES: 'fwd', // pr TOUCHES code_file: a PR change reaches the files it edits
  IMPLEMENTED_BY: 'rev', // model/sql_file IMPLEMENTED_BY code_file
  AUTHORED_BY: 'none',
  FIXED_BY: 'rev', // dd_issue FIXED_BY pr
  IMPLICATES: 'rev', // dd_issue IMPLICATES code_file: a change to the file affects the issue
  CITES: 'none',
  FILED: 'none',
  OPENED: 'none',
  CONCLUDED: 'none',
  INVESTIGATED_BY: 'none',
  POINTS_AT: 'none',
  TRACKED_BY: 'none',
  POSTED_IN: 'none',
  HAS_ANGLE: 'none',
  HAS_HOOK: 'none',
  HAS_OFFER: 'none',
  HAS_PERSONA: 'none',
  RELATED_TO: 'none',
  DISTINCT_FROM: 'none',
  CONFLICTS_WITH: 'none',
  // same edge type, different meaning by node kinds: "TYPE:fromKind>toKind" wins over "TYPE"
  'PART_OF:code_file>service': 'fwd', // a file change affects the service it belongs to
  'RUNS:brand>campaign': 'fwd',
  'USES:ad>channel': 'none',
  'MIRRORS:dbt_model>table': 'none', // equivalence between a dbt rewrite and the Airflow table, not a data dependency
  // names W10 may add to the merged snapshot (service/infra/incident edges); overridable via WALK_DIRECTIONS
  CALLS_SERVICE: 'rev',
  DEPENDS_ON: 'rev',
  USES: 'rev',
  CONSUMES: 'rev',
  IMPORTS: 'rev',
  PUBLISHES: 'fwd',
  PRODUCES: 'fwd',
  TRIGGERS: 'fwd',
  DEPLOYED_AS: 'fwd',
  DEPLOYS: 'fwd',
  CAUSED_BY: 'rev',
  OWNS: 'none',
  OWNED_BY: 'none',
  ASSIGNED_TO: 'none',
};

// Edge types skipped by path() unless the caller asks for them: structural links that connect everything to everything.
const STRUCTURAL_TYPES = new Set(['BELONGS_TO', 'CLIENT_OF', 'INSTANCE_OF', 'SUBCLASS_OF', 'ROLLS_UP_TO']);

const DERIVATION_CONF = { source_recorded: 1, recorded: 1, code_derived: 0.9, source_derived: 0.9, doc_derived: 0.7, inferred: 0.5 };
const KIND_PRIOR = {
  table: 1, dbt_model: 1, service: 1, metric: 1, airflow_dag: 0.98, sql_file: 0.95, pr: 0.95, linear_issue: 0.95, concept: 0.92,
  brand: 0.9, entity_class: 0.9, channel: 0.9, column: 0.82, ad: 0.8, adset: 0.8, campaign: 0.8, insight: 0.75, decision: 0.75,
  change_event: 0.75,
};
const STOP = new Set(['the', 'a', 'an', 'of', 'to', 'in', 'for', 'and', 'or', 'is', 'on', 'by', 'with', 'from', 'table', 'tables', 'what', 'which', 'where', 'how', 'does', 'do', 'that', 'it', 'this', 'node', 'entity']);
const ALIAS_TOKEN = { bigquery: 'bq', postgres: 'pg', postgresql: 'pg' };
const SEARCH_KIND_PRIOR = { metric: 1.8, concept: 1.55, recipe: 1.6, table: 1.45, dbt_model: 1.4, service: 1.4, column: 0.3, sql_file: 0.5, code_file: 0.55 };
const SEARCH_STOP = new Set(['can', 'check', 'many', 'should', 'start', 'investigating', 'trace', 'recorded', 'come', 'me', 'connected', 'during', 'find']);
const SEARCH_LINEAGE_TYPES = new Set(['READS', 'WRITES', 'FEEDS', 'DERIVED_FROM', 'COMPUTED_FROM', 'MIRRORS']);

export function tokenize(text) {
  const spaced = String(text)
    .replace(/([a-z0-9])([A-Z])/g, '$1 $2')
    .replace(/#(\d+)/g, ' pr$1 ')
    .toLowerCase();
  const out = [];
  for (let tok of spaced.split(/[^a-z0-9]+/)) {
    if (!tok || STOP.has(tok)) continue;
    tok = ALIAS_TOKEN[tok] ?? tok;
    if (tok.length > 3 && tok.endsWith('s') && !tok.endsWith('ss')) tok = tok.slice(0, -1);
    out.push(tok);
  }
  return out;
}

function normAlias(text) {
  return String(text).toLowerCase().replace(/\s+/g, ' ').trim();
}

function shortForms(id, kind, name, props, nodeAliases) {
  const forms = new Set([id, name]);
  const rest = id.includes(':') ? id.slice(id.indexOf(':') + 1) : id;
  forms.add(rest);
  if (id.startsWith('tbl:pg:')) {
    const t = rest.replace(/^pg:/, '');
    forms.add(t);
    forms.add(t.split('.').pop());
    forms.add('pg ' + t.split('.').pop());
    forms.add('postgres ' + t.split('.').pop());
    forms.add('pg:' + t.split('.').pop());
    forms.add('pg:' + t);
  } else if (id.startsWith('tbl:bq:')) {
    const t = rest.replace(/^bq:/, '').split('.');
    if (t.length >= 3) {
      forms.add(t.join('.'));
      forms.add(t.slice(1).join('.'));
      forms.add('bq:' + t.slice(1).join('.'));
      forms.add(t[2]);
    }
  } else if (id.startsWith('col:')) {
    const t = rest.replace(/^(bq|pg):/, '').split('.');
    if (t.length >= 3) forms.add(t.slice(-3).join('.')), forms.add(t.slice(-2).join('.'));
  } else if (id.startsWith('sql_file:')) {
    forms.add(rest.split('/').pop());
  } else if (id.startsWith('airflow_dag:')) {
    for (const part of rest.split(':')) forms.add(part);
  } else if (id.startsWith('pr:')) {
    forms.add('#' + rest);
    forms.add('pr ' + rest);
    forms.add('pr' + rest);
  } else if (id.startsWith('linear:')) {
    forms.add(rest);
  }
  const extra = props?.alias ?? props?.aliases ?? nodeAliases;
  if (Array.isArray(extra)) extra.forEach((a) => forms.add(a));
  else if (typeof extra === 'string') forms.add(extra);
  return [...forms].filter(Boolean).map(normAlias);
}

function edgeConfidence(e) {
  const c = e.confidence ?? e.prior ?? e.props?.confidence;
  if (typeof c === 'number') return c;
  return DERIVATION_CONF[e.derivation] ?? 0.8;
}

function shortRef(ref) {
  if (!ref) return '';
  return String(ref).replace(/^git:\/\//, '').replace(/@[0-9a-f]{6,}$/, '');
}





export class Graph {
  constructor(opts = {}) {
    this.directions = { ...IMPACT_DIRECTION, ...(opts.directions ?? {}) };
    this.nodes = [];
    this.index = new Map();
    this.edges = [];
    this.edgeKey = new Map();
    this.sourceLabel = '';
  }

  addNode(n) {
    const id = n.node_id ?? n.id;
    if (!id) return;
    const known = this.index.get(id);
    if (known !== undefined) {
      const cur = this.nodes[known];
      if (!cur.name && n.name) cur.name = n.name;
      if (n.aliases?.length) cur.aliases = [...new Set([...cur.aliases, ...n.aliases])];
      if (!cur.source_ref && n.source_ref) cur.source_ref = n.source_ref;
      return;
    }
    this.index.set(id, this.nodes.length);
    this.nodes.push({ id, kind: n.kind ?? '?', name: n.name ?? '', summary: n.summary ?? '', parent_id: n.parent_id, props: n.props ?? {}, aliases: n.aliases ?? [], source_ref: n.source_ref ?? '', record: n });
  }

  addEdge(e) {
    const from = e.from ?? e.source ?? e.src;
    const to = e.to ?? e.target ?? e.dst;
    const type = e.type ?? e.edge_type;
    if (!from || !to || !type) return;
    const a = this.index.get(from);
    const b = this.index.get(to);
    if (a === undefined || b === undefined) {
      this.dangling = (this.dangling ?? 0) + 1;
      return;
    }
    const key = `${type}\u0000${a}\u0000${b}`;
    const conf = edgeConfidence(e);
    const known = this.edgeKey.get(key);
    if (known !== undefined) {
      const cur = this.edges[known];
      if (conf > cur.conf) cur.conf = conf;
      return;
    }
    this.edgeKey.set(key, this.edges.length);
    this.edges.push({ a, b, type, conf, ref: e.source_ref ?? '', derivation: e.derivation ?? '' });
  }

  build() {
    const n = this.nodes.length;
    const outDeg = new Int32Array(n);
    const inDeg = new Int32Array(n);
    for (const e of this.edges) (outDeg[e.a]++, inDeg[e.b]++);
    this.out = Array.from({ length: n }, () => []);
    this.in = Array.from({ length: n }, () => []);
    this.edges.forEach((e, i) => (this.out[e.a].push(i), this.in[e.b].push(i)));
    this.degree = (i) => this.out[i].length + this.in[i].length;
    // alias + token indexes
    this.aliasIndex = new Map();
    this.tokenIndex = new Map();
    this.nodeTokens = new Array(n);
    for (let i = 0; i < n; i++) {
      const node = this.nodes[i];
      for (const a of shortForms(node.id, node.kind, node.name, node.props, node.aliases)) {
        let list = this.aliasIndex.get(a);
        if (!list) this.aliasIndex.set(a, (list = []));
        list.push(i);
      }
      const toks = new Set([...tokenize(node.id.slice(node.id.indexOf(':') + 1)), ...tokenize(node.name)]);
      this.nodeTokens[i] = toks;
      for (const t of toks) {
        let list = this.tokenIndex.get(t);
        if (!list) this.tokenIndex.set(t, (list = []));
        list.push(i);
      }
    }
    this.idf = (t) => Math.log(1 + n / (1 + (this.tokenIndex.get(t)?.length ?? 0)));
    this.columnTable = new Map();
    this.tableColumns = new Map();
    this.lineageDegree = new Int32Array(n);
    for (const edge of this.edges) {
      if (SEARCH_LINEAGE_TYPES.has(edge.type)) { this.lineageDegree[edge.a]++; this.lineageDegree[edge.b]++; }
      if (edge.type !== 'LIVES_IN' || this.nodes[edge.a].kind !== 'column' || this.nodes[edge.b].kind !== 'table') continue;
      this.columnTable.set(edge.a, edge.b);
    }
    for (let index = 0; index < n; index++) {
      if (this.nodes[index].kind !== 'column') continue;
      const parent = this.columnTable.get(index) ?? this.index.get(this.nodes[index].parent_id);
      if (parent === undefined || this.nodes[parent].kind !== 'table') continue;
      this.columnTable.set(index, parent);
      if (!this.tableColumns.has(parent)) this.tableColumns.set(parent, new Set());
      this.tableColumns.get(parent).add(this.nodes[index].id.split('.').pop().toLowerCase());
    }
  }

  search(query, { types, limit = 10 } = {}) {
    const queryTokens = [...new Set(tokenize(query).filter((token) => !SEARCH_STOP.has(token)))];
    const wanted = types?.length ? new Set(types) : null;
    const exact = new Map(this.find(query, { limit: 100 }).filter((hit) => ['id', 'alias'].includes(hit.how)).map((hit) => [hit.id, hit]));
    const queryText = normAlias(query).replace(/`/g, '');
    const explicitlyNames = (node) => {
      if (queryText.includes(node.id.toLowerCase())) return true;
      if (node.kind === 'column') {
        const parts = node.id.split('.');
        const qualified = [node.id.replace(/^col:(?:bq|pg):/, ''), parts.slice(-3).join('.'), parts.slice(-2).join('.'), node.name, ...node.aliases].filter((alias) => typeof alias === 'string' && alias.includes('.'));
        return wanted?.has('column') || qualified.some((alias) => queryText.includes(alias.toLowerCase())) || /\b(column|field)\b/.test(queryText) && queryTokens.includes(tokenize(node.id.split('.').pop()).join(' '));
      }
      if (['sql_file', 'code_file'].includes(node.kind)) {
        const path = node.props.path ?? node.id.slice(node.id.indexOf(':') + 1);
        const basename = path.split('/').pop();
        return wanted?.has(node.kind) || queryText.includes(path.toLowerCase()) || basename?.includes('.') && queryText.includes(basename.toLowerCase());
      }
      return false;
    };
    const ranked = new Map();
    const add = (index, lexicalScore, matchedColumn, exactScore = 0) => {
      const node = this.nodes[index];
      if (wanted && !wanted.has(node.kind)) return;
      const prior = explicitlyNames(node) ? 1.8 : SEARCH_KIND_PRIOR[node.kind] ?? 0.8;
      const score = exactScore + lexicalScore * prior;
      let result = ranked.get(index);
      if (!result) ranked.set(index, result = { ...this.brief(index), summary: node.summary.slice(0, 1200), source_ref: shortRef(node.source_ref), score, kind_prior: prior, matched_columns: [], backend: 'snapshot', ranker: 'lexical', index });
      result.score = Math.max(result.score, score);
      if (matchedColumn && !result.matched_columns.some((column) => column.id === matchedColumn.id)) result.matched_columns.push(matchedColumn);
    };
    for (let index = 0; index < this.nodes.length; index++) {
      const node = this.nodes[index];
      const specific = explicitlyNames(node);
      const parent = node.kind === 'column' && !specific ? this.columnTable.get(index) : undefined;
      if (node.kind === 'column' && !specific && parent === undefined) continue;
      if (wanted && !wanted.has(node.kind) && !(parent !== undefined && wanted.has('table'))) continue;
      const title = new Set(tokenize([node.id, node.name, ...node.aliases, node.props.alias ?? '', ...(Array.isArray(node.props.aliases) ? node.props.aliases : [])].join(' ')));
      const summary = new Set(tokenize(node.summary || node.props.description || ''));
      let lexical = 0;
      let covered = 0;
      for (const token of queryTokens) {
        if (title.has(token) || summary.has(token)) covered++;
        if (title.has(token)) lexical += this.idf(token) * 2;
        else if (summary.has(token)) lexical += this.idf(token);
      }
      const alias = exact.get(node.id);
      const aliasScore = alias?.how === 'id' ? 1000 : alias?.how === 'alias' && (node.kind !== 'column' || specific) ? 500 : 0;
      if (!lexical && !aliasScore) continue;
      const score = lexical / Math.sqrt(1 + title.size + summary.size * 0.2) + covered / Math.max(1, queryTokens.length);
      if (parent !== undefined) add(parent, score, { id: node.id, name: node.name, source_ref: shortRef(node.source_ref), node_source_ref: node.source_ref, lexical_score: Number(score.toFixed(3)) });
      else add(index, score, null, Math.max(aliasScore, specific && ['column', 'sql_file', 'code_file'].includes(node.kind) ? 400 : 0));
    }
    const ordered = [...ranked.values()].sort((left, right) => right.score - left.score || this.lineageDegree[right.index] - this.lineageDegree[left.index] || left.id.localeCompare(right.id));
    return this.groupSearchHits(ordered).slice(0, limit).map((hit) => this.searchCard(hit));
  }

  groupSearchHits(ordered) {
    const groups = [];
    const byFamily = new Map();
    for (const hit of ordered) {
      const family = hit.kind === 'table' ? hit.id.replace(/(_quick|_lifetime)(?=\.)/g, '') : hit.id;
      const schema = this.tableColumns.get(hit.index) ?? new Set(this.nodes[hit.index].props.columns ?? []);
      const candidates = byFamily.get(family) ?? [];
      const duplicate = candidates.find((candidate) => {
        const otherSchema = this.tableColumns.get(candidate.index) ?? new Set(this.nodes[candidate.index].props.columns ?? []);
        if (!schema.size || !otherSchema.size) return false;
        const overlap = [...schema].filter((column) => otherSchema.has(column)).length;
        return overlap / new Set([...schema, ...otherSchema]).size >= 0.8;
      });
      if (duplicate) {
        duplicate.alternatives ??= [];
        duplicate.alternatives.push({ id: hit.id, name: hit.name, score: Number(hit.score.toFixed(3)), source_ref: hit.source_ref, node_source_ref: this.nodes[hit.index].source_ref });
        for (const column of hit.matched_columns) if (!duplicate.matched_columns.some((known) => known.id === column.id)) duplicate.matched_columns.push(column);
      } else {
        candidates.push(hit);
        byFamily.set(family, candidates);
        groups.push(hit);
      }
    }
    return groups;
  }

  searchCard({ index, ...hit }) {
      const lineage = [];
      for (const direction of ['out', 'in']) for (const edgeIndex of this[direction][index]) {
        const edge = this.edges[edgeIndex];
        if (!SEARCH_LINEAGE_TYPES.has(edge.type)) continue;
        const other = direction === 'out' ? edge.b : edge.a;
        lineage.push({ ...this.brief(other), edge: edge.type, direction, prior: edge.conf, source_ref: shortRef(edge.ref), provenance: this.edgeProvenance(edge) });
      }
      lineage.sort((left, right) => right.prior - left.prior || left.id.localeCompare(right.id));
      return { ...hit, score: Number(hit.score.toFixed(6)), matched_columns: (hit.matched_columns ?? []).sort((left, right) => right.lexical_score - left.lexical_score).slice(0, 5), lineage: lineage.slice(0, 3), lineage_total: lineage.length };
  }

  stats() {
    const kinds = {};
    for (const n of this.nodes) kinds[n.kind] = (kinds[n.kind] ?? 0) + 1;
    const types = {};
    for (const e of this.edges) types[e.type] = (types[e.type] ?? 0) + 1;
    return { source: this.sourceLabel, nodes: this.nodes.length, edges: this.edges.length, dangling: this.dangling ?? 0, kinds, edgeTypes: types };
  }

  // -------------------------------------------------------------------------------------------
  // find: exact id, then alias, then name tokens
  // -------------------------------------------------------------------------------------------
  find(text, { types, limit = 10 } = {}) {
    const typeSet = types?.length ? new Set(types) : null;
    const okKind = (i) => !typeSet || typeSet.has(this.nodes[i].kind);
    const results = [];
    const seen = new Set();
    const push = (i, score, how) => {
      if (seen.has(i) || !okKind(i)) return;
      seen.add(i);
      results.push({ i, score, how });
    };
    const q = String(text).trim();
    const exact = this.index.get(q);
    if (exact !== undefined) push(exact, 10, 'id');
    const alias = this.aliasIndex.get(normAlias(q));
    if (alias) for (const i of alias) push(i, 5 + (KIND_PRIOR[this.nodes[i].kind] ?? 0.7), 'alias');
    const qt = [...new Set(tokenize(q))];
    if (qt.length) {
      const idfSum = qt.reduce((s, t) => s + this.idf(t), 0) || 1;
      // candidate set: union of postings of the 3 rarest query tokens, then verify all tokens
      const known = qt.filter((t) => this.tokenIndex.has(t)).sort((x, y) => this.tokenIndex.get(x).length - this.tokenIndex.get(y).length);
      const cands = new Set();
      for (const t of known.slice(0, 3)) for (const i of this.tokenIndex.get(t)) cands.add(i);
      const scored = [];
      for (const i of cands) {
        if (seen.has(i) || !okKind(i)) continue;
        const toks = this.nodeTokens[i];
        let hit = 0;
        for (const t of qt) if (toks.has(t)) hit += this.idf(t);
        if (!hit) continue;
        let nodeIdf = 0;
        for (const t of toks) nodeIdf += this.idf(t);
        const coverage = hit / idfSum;
        const precision = hit / (nodeIdf || 1);
        const score = (0.75 * coverage + 0.25 * precision) * (KIND_PRIOR[this.nodes[i].kind] ?? 0.7);
        scored.push({ i, score, how: coverage >= 0.999 ? 'tokens' : 'partial' });
      }
      scored.sort((x, y) => y.score - x.score || this.nodes[x.i].id.localeCompare(this.nodes[y.i].id));
      for (const s of scored.slice(0, limit * 3)) push(s.i, s.score, s.how);
    }
    results.sort((x, y) => y.score - x.score || this.nodes[x.i].id.localeCompare(this.nodes[y.i].id));
    return results.slice(0, limit).map((r) => ({ ...this.brief(r.i), score: Number(r.score.toFixed(3)), how: r.how }));
  }

  brief(i) {
    const n = this.nodes[i];
    return { id: n.id, kind: n.kind, name: n.name, source_ref: n.source_ref, node_source_ref: n.source_ref };
  }

  record(id) {
    const index = this.index.get(id);
    if (index === undefined) return { error: 'Unknown node ID', truncated: false };
    const node = this.nodes[index];
    const edgeCounts = { in: Object.create(null), out: Object.create(null) };
    for (const direction of ['in', 'out']) for (const edgeIndex of this[direction][index]) {
      const type = this.edges[edgeIndex].type;
      edgeCounts[direction][type] = (edgeCounts[direction][type] ?? 0) + 1;
    }
    return {
      source: this.sourceLabel, id: node.id, kind: node.kind,
      label: node.record.label ?? node.name,
      node: structuredClone(node.record), edgeCounts, truncated: false,
    };
  }

  edgeProvenance(edge) {
    return { from: this.nodes[edge.a].id, to: this.nodes[edge.b].id, type: edge.type, source_ref: edge.ref, derivation: edge.derivation };
  }

  // Accept an id or any text. Returns {idx, note} or {candidates}.
  resolve(ref) {
    const direct = this.index.get(ref);
    if (direct !== undefined) return { idx: direct };
    const hits = this.find(ref, { limit: 5 });
    if (!hits.length) return { error: `no node matches "${ref}"` };
    const best = hits[0];
    const second = hits[1];
    const confident = best.how === 'id' || best.how === 'alias' || (best.how === 'tokens' && (!second || best.score >= second.score * 1.15));
    if (confident) return { idx: this.index.get(best.id), note: `resolved "${ref}" -> ${best.id}` };
    if (best.how === 'partial') return { error: `no confident match for "${ref}" (only partial name matches)`, candidates: hits };
    return { error: `"${ref}" is ambiguous`, candidates: hits };
  }

  // -------------------------------------------------------------------------------------------
  // neighbors
  // -------------------------------------------------------------------------------------------
  neighbors(ref, { edgeTypes, direction = 'both', limit = 25, kinds, perGroup } = {}) {
    const r = this.resolve(ref);
    if (r.idx === undefined) return r;
    const types = edgeTypes?.length ? new Set(edgeTypes.map((t) => t.toUpperCase())) : null;
    const kindSet = kinds?.length ? new Set(kinds) : null;
    // an agent that filters by edge type or kind is drilling in: no per-group cap then
    const groupCap = perGroup ?? (types || kindSet ? limit : 5);
    const rows = [];
    const take = (list, dir) => {
      for (const ei of list) {
        const e = this.edges[ei];
        if (types && !types.has(e.type.toUpperCase())) continue;
        const other = dir === 'out' ? e.b : e.a;
        if (kindSet && !kindSet.has(this.nodes[other].kind)) continue;
        rows.push({ other, dir, type: e.type, conf: e.conf, ref: e.ref, provenance: this.edgeProvenance(e) });
      }
    };
    if (direction === 'out' || direction === 'both') take(this.out[r.idx], 'out');
    if (direction === 'in' || direction === 'both') take(this.in[r.idx], 'in');
    rows.sort((x, y) => y.conf - x.conf || x.type.localeCompare(y.type) || this.nodes[x.other].id.localeCompare(this.nodes[y.other].id));
    // group by (edge type, direction, kind of the other node) so bulk instance edges (2,700 decisions STORED_IN a
    // table) cannot crowd out the few schema-level edges; fill the limit round-robin, rare groups first
    const groups = new Map();
    for (const x of rows) {
      const key = `${x.type}|${x.dir}|${this.nodes[x.other].kind}`;
      let g = groups.get(key);
      if (!g) groups.set(key, (g = { edge: x.type, direction: x.dir, kind: this.nodes[x.other].kind, rows: [] }));
      g.rows.push(x);
    }
    const ordered = [...groups.values()].sort((x, y) => y.rows[0].conf - x.rows[0].conf || x.rows.length - y.rows.length || x.edge.localeCompare(y.edge));
    const cut = [];
    for (let round = 0; round < groupCap && cut.length < limit; round++) {
      for (const g of ordered) {
        if (cut.length >= limit) break;
        if (g.rows[round]) cut.push(g.rows[round]);
      }
    }
    const shown = new Map();
    for (const x of cut) shown.set(`${x.type}|${x.dir}|${this.nodes[x.other].kind}`, (shown.get(`${x.type}|${x.dir}|${this.nodes[x.other].kind}`) ?? 0) + 1);
    const rest = {};
    for (const g of ordered) {
      const key = `${g.edge}|${g.direction}|${g.kind}`;
      const hidden = g.rows.length - (shown.get(key) ?? 0);
      if (hidden > 0) rest[`${g.edge}${g.direction === 'out' ? '->' : '<-'}${g.kind}`] = hidden;
    }
    cut.sort((x, y) => y.conf - x.conf || x.type.localeCompare(y.type) || this.nodes[x.other].id.localeCompare(this.nodes[y.other].id));
    return {
      node: this.brief(r.idx),
      note: r.note,
      total: rows.length,
      results: cut.map((x) => ({ ...this.brief(x.other), edge: x.type, direction: x.dir, confidence: x.conf, source_ref: shortRef(x.ref), provenance: x.provenance })),
      omitted: rows.length - cut.length,
      omittedByType: rest,
    };
  }

  // -------------------------------------------------------------------------------------------
  // path: evidence-weighted shortest paths (undirected walk), hop-limited, up to k distinct paths
  // -------------------------------------------------------------------------------------------
  path(fromRef, toRef, { maxHops = 6, k = 3, edgeTypes, includeStructural = false } = {}) {
    const a = this.resolve(fromRef);
    if (a.idx === undefined) return { error: a.error, candidates: a.candidates, which: 'from' };
    const b = this.resolve(toRef);
    if (b.idx === undefined) return { error: b.error, candidates: b.candidates, which: 'to' };
    const types = edgeTypes?.length ? new Set(edgeTypes.map((t) => t.toUpperCase())) : null;
    const banned = new Set();
    const found = [];
    const seenSig = new Set();
    for (let round = 0; round < k + 4 && found.length < k; round++) {
      const p = this.#shortest(a.idx, b.idx, maxHops, types, includeStructural, banned);
      if (!p) break;
      const sig = p.steps.map((s) => s.ei).join(',');
      if (!seenSig.has(sig)) {
        seenSig.add(sig);
        found.push(p);
      }
      if (!p.steps.length) break;
      // ban the weakest-evidence edge of the path so the next round finds a different route
      let worst = p.steps[0];
      for (const s of p.steps) if (this.edges[s.ei].conf < this.edges[worst.ei].conf || (this.edges[s.ei].conf === this.edges[worst.ei].conf && s.ei > worst.ei)) worst = s;
      banned.add(worst.ei);
      if (p.steps.length === 1) banned.add(p.steps[0].ei);
    }
    return {
      from: this.brief(a.idx),
      to: this.brief(b.idx),
      notes: [a.note, b.note].filter(Boolean),
      paths: found.map((p) => ({
        hops: p.steps.length,
        confidence: Number(p.conf.toFixed(3)),
        nodes: [this.brief(a.idx), ...p.steps.map((s) => this.brief(s.node))],
        steps: p.steps.map((s) => {
          const e = this.edges[s.ei];
          return { edge: e.type, direction: s.dir, confidence: e.conf, source_ref: shortRef(e.ref), provenance: this.edgeProvenance(e) };
        }),
      })),
    };
  }

  #shortest(src, dst, maxHops, types, includeStructural, banned) {
    if (src === dst) return { steps: [], conf: 1 };
    const N = this.nodes.length;
    const H = maxHops + 1;
    const dist = new Float64Array(N * H).fill(Infinity);
    const prev = new Int32Array(N * H).fill(-1); // packed prev state
    const prevEdge = new Int32Array(N * H).fill(-1);
    const prevDir = new Uint8Array(N * H);
    const heap = [[0, src, 0]];
    dist[src * H] = 0;
    const push = (item) => {
      heap.push(item);
      let c = heap.length - 1;
      while (c > 0) {
        const p = (c - 1) >> 1;
        if (heap[p][0] <= heap[c][0]) break;
        [heap[p], heap[c]] = [heap[c], heap[p]];
        c = p;
      }
    };
    const pop = () => {
      const top = heap[0];
      const last = heap.pop();
      if (heap.length) {
        heap[0] = last;
        let c = 0;
        for (;;) {
          const l = 2 * c + 1;
          const r = l + 1;
          let m = c;
          if (l < heap.length && heap[l][0] < heap[m][0]) m = l;
          if (r < heap.length && heap[r][0] < heap[m][0]) m = r;
          if (m === c) break;
          [heap[m], heap[c]] = [heap[c], heap[m]];
          c = m;
        }
      }
      return top;
    };
    let goalState = -1;
    while (heap.length) {
      const [d, u, h] = pop();
      if (d > dist[u * H + h]) continue;
      if (u === dst) {
        goalState = u * H + h;
        break;
      }
      if (h === maxHops) continue;
      const relax = (list, dir) => {
        for (const ei of list) {
          if (banned.has(ei)) continue;
          const e = this.edges[ei];
          if (types ? !types.has(e.type.toUpperCase()) : !includeStructural && STRUCTURAL_TYPES.has(e.type)) continue;
          const v = dir === 0 ? e.b : e.a;
          const cost = 1 + 2 * (1 - e.conf) + 0.25 * Math.log10(1 + this.degree(v));
          const nd = d + cost;
          const s = v * H + h + 1;
          if (nd < dist[s]) {
            dist[s] = nd;
            prev[s] = u * H + h;
            prevEdge[s] = ei;
            prevDir[s] = dir;
            push([nd, v, h + 1]);
          }
        }
      };
      relax(this.out[u], 0);
      relax(this.in[u], 1);
    }
    if (goalState < 0) return null;
    const steps = [];
    let conf = 1;
    for (let s = goalState; prev[s] >= 0; s = prev[s]) {
      const node = Math.floor(s / H);
      steps.push({ ei: prevEdge[s], node, dir: prevDir[s] === 0 ? 'out' : 'in' });
      conf *= this.edges[prevEdge[s]].conf;
    }
    steps.reverse();
    return { steps, conf };
  }

  // -------------------------------------------------------------------------------------------
  // A builder remains upstream of its output even if coarse service read/write edges form a cycle.
  tableBuilders(index) {
    const builders = new Set();
    if (this.nodes[index].kind !== 'table') return builders;
    for (const edgeIndex of this.in[index]) {
      const edge = this.edges[edgeIndex];
      if (['WRITES', 'PRODUCES', 'PUBLISHES', 'RUNS'].includes(edge.type)) builders.add(edge.a);
    }
    const preciseWriterKnown = [...builders].some((builder) => ['sql_file', 'dbt_model', 'code_file'].includes(this.nodes[builder].kind));
    for (const builder of [...builders]) {
      for (const edgeIndex of this.out[builder]) {
        const edge = this.edges[edgeIndex];
        if (edge.type === 'IMPLEMENTED_BY' || edge.type === 'RUNS' && !preciseWriterKnown) builders.add(edge.b);
      }
      for (const edgeIndex of this.in[builder]) {
        const edge = this.edges[edgeIndex];
        if (edge.type === 'RUNS' && ['sql_file', 'code_file', 'dbt_model'].includes(this.nodes[builder].kind)) builders.add(edge.a);
      }
    }
    return builders;
  }

  impactInputs(index, builders = this.tableBuilders(index)) {
    const inputs = new Set(builders);
    for (const edgeIndex of this.in[index]) {
      const edge = this.edges[edgeIndex];
      if (!['WRITES', 'PRODUCES', 'PUBLISHES', 'FEEDS'].includes(edge.type)) continue;
      inputs.add(edge.a);
      const path = edge.ref.replace(/^git:\/\//, '').replace(/:\d+(?:[-:]\d+)?(?:@.*)?$/, '').replace(/@[^@]+$/, '');
      const sql = this.index.get(`sql_file:${path}`);
      if (sql !== undefined) inputs.add(sql);
    }
    const queue = [...inputs];
    for (let cursor = 0; cursor < queue.length; cursor++) {
      const producer = queue[cursor];
      if (!['sql_file', 'code_file', 'dbt_model', 'airflow_task'].includes(this.nodes[producer].kind)) continue;
      for (const edgeIndex of this.in[producer]) {
        const edge = this.edges[edgeIndex];
        if (edge.type !== 'RUNS' || inputs.has(edge.a) || edge.a === index) continue;
        inputs.add(edge.a);
        queue.push(edge.a);
      }
    }
    inputs.delete(index);
    return inputs;
  }

  impactAncestors(index) {
    const ancestors = new Set([index]);
    const queue = [index];
    for (let cursor = 0; cursor < queue.length; cursor++) {
      const current = queue[cursor];
      for (const [list, side] of [[this.in[current], 'in'], [this.out[current], 'out']]) {
        for (const edgeIndex of list) {
          const edge = this.edges[edgeIndex];
          const direction = this.directions[`${edge.type}:${this.nodes[edge.a].kind}>${this.nodes[edge.b].kind}`] ?? this.directions[edge.type];
          if (side === 'in' ? direction !== 'fwd' : direction !== 'rev') continue;
          const upstream = side === 'in' ? edge.a : edge.b;
          if (ancestors.has(upstream)) continue;
          ancestors.add(upstream);
          queue.push(upstream);
        }
      }
    }
    ancestors.delete(index);
    return ancestors;
  }

  // impact: downstream directions, seed-builder output exclusion, cycle flags and a prior floor.
  // -------------------------------------------------------------------------------------------
  impact(ref, { maxHops = 4, stopAtTypes, kinds, limit = 50, minPrior = 0.1, minConfidence, hubThreshold = 25 } = {}) {
    const r = this.resolve(ref);
    if (r.idx === undefined) return r;
    const stop = stopAtTypes?.length ? new Set(stopAtTypes) : null;
    const wantKinds = kinds?.length ? new Set(kinds) : null;
    const floor = minConfidence ?? minPrior;
    if (!Number.isFinite(floor) || floor < 0 || floor > 1) throw new RangeError('minPrior must be between 0 and 1');
    const builders = this.tableBuilders(r.idx);
    const inputs = this.impactInputs(r.idx, builders);
    const ancestors = this.impactAncestors(r.idx);
    const best = new Map(); // node -> {conf, hops, prevNode, ei}
    const start = { node: r.idx, conf: 1, hops: 0, prev: -1, ei: -1, previous: null };
    best.set(r.idx, start);
    let frontier = new Map([[r.idx, start]]);
    const skipped = {};
    for (let hop = 1; hop <= maxHops && frontier.size; hop++) {
      const next = new Map();
      for (const [u, base] of frontier) {
        if (u !== r.idx && stop && stop.has(this.nodes[u].kind)) continue;
        const eligible = [];
        const collect = (list, side) => {
          for (const ei of list) {
            const e = this.edges[ei];
            const dir = this.directions[`${e.type}:${this.nodes[e.a].kind}>${this.nodes[e.b].kind}`] ?? this.directions[e.type];
            if (dir === undefined) {
              skipped[e.type] = (skipped[e.type] ?? 0) + 1;
              continue;
            }
            // side 'out': u is e.a. fwd lets a change at a reach b. side 'in': u is e.b; rev lets a change at b reach a.
            if (dir === 'none' || (side === 'out' && dir !== 'fwd') || (side === 'in' && dir !== 'rev')) continue;
            const v = side === 'out' ? e.b : e.a;
            if (v !== r.idx) eligible.push([ei, v]);
          }
        };
        collect(this.out[u], 'out');
        collect(this.in[u], 'in');
        // a coarse hub (e.g. a gateway service touching 170 tables) is weak evidence for each of its fan-out targets
        const damp = u !== r.idx && eligible.length > hubThreshold ? hubThreshold / eligible.length : 1;
        for (const [ei, v] of eligible) {
          const conf = base.conf * this.edges[ei].conf * damp;
          const state = { node: v, conf, hops: hop, prev: u, ei, damp, previous: base };
          // Keep the best state at this depth even when a longer, stronger route already won globally.
          // Otherwise that longer route consumes the shorter route's remaining hop budget.
          if (!next.has(v) || conf > next.get(v).conf) next.set(v, state);
          const cur = best.get(v);
          if (!cur || conf > cur.conf + 1e-12 || (Math.abs(conf - cur.conf) < 1e-12 && hop < cur.hops)) {
            best.set(v, state);
          }
        }
      }
      frontier = next;
    }
    const rows = [];
    for (const [i, info] of best) {
      if (i === r.idx || inputs.has(i)) continue;
      if (wantKinds && !wantKinds.has(this.nodes[i].kind)) continue;
      rows.push({ i, ...info });
    }
    const belowFloor = rows.filter((row) => row.conf < floor).length;
    const retained = rows.filter((row) => row.conf >= floor);
    // sort by evidence BEFORE capping
    retained.sort((x, y) => y.conf - x.conf || x.hops - y.hops || this.nodes[x.i].id.localeCompare(this.nodes[y.i].id));
    const cut = retained.slice(0, limit);
    const byKind = {};
    for (const x of retained) byKind[this.nodes[x.i].kind] = (byKind[this.nodes[x.i].kind] ?? 0) + 1;
    return {
      node: this.brief(r.idx),
      note: r.note,
      direction: 'downstream-only',
      total: retained.length,
      minPrior: floor,
      omittedBelowPrior: belowFloor,
      excludedBuilders: [...builders].map((index) => this.nodes[index].id),
      excluded_inputs: [...inputs].map((index) => this.nodes[index].id),
      upstreamPolicy: 'direct producers and their evidenced SQL/RUNS executors hidden from output only; other downstream/upstream overlaps remain traversable with cycle=true',
      cycleCount: retained.filter((row) => ancestors.has(row.i)).length,
      returnedCycleCount: cut.filter((row) => ancestors.has(row.i)).length,
      byKind,
      results: cut.map((x) => {
        const e = this.edges[x.ei];
        const chain = [];
        for (let state = x; state.previous; state = state.previous) {
          const edge = this.edges[state.ei];
          chain.unshift({ from: this.nodes[state.prev].id, to: this.nodes[state.node].id, edge: edge.type, direction: edge.a === state.prev ? 'out' : 'in', prior: Number(state.conf.toFixed(3)), source_ref: shortRef(edge.ref), provenance: this.edgeProvenance(edge) });
        }
        return {
          ...this.brief(x.i),
          hops: x.hops,
          confidence: Number(x.conf.toFixed(3)),
          prior: Number(x.conf.toFixed(3)),
          cycle: ancestors.has(x.i),
          chain,
          via: `${this.nodes[x.prev].id} ${e.type}${e.a === x.prev ? '->' : '<-'}${x.damp < 1 ? ` (hub fan-out, prior x${x.damp.toFixed(2)})` : ''}`,
          source_ref: shortRef(e.ref),
          provenance: this.edgeProvenance(e),
        };
      }),
      omitted: retained.length - cut.length,
      unknownEdgeTypesIgnored: Object.keys(skipped).length ? skipped : undefined,
    };
  }
}

// ---------------------------------------------------------------------------------------------
