import * as fs from 'fs';

export const constants = fs.constants;
export const promises = fs.promises;
export const statSync = fs.statSync;
export default fs;
export const createReadStream = fs.createReadStream;
