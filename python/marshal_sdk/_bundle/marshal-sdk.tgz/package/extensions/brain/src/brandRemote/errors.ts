export type BrandRemoteErrorCode =
  | 'brand_remote_disabled'
  | 'brand_remote_auth_failed'
  | 'brand_remote_unavailable'
  | 'brand_remote_busy'
  | 'brand_remote_timeout'
  | 'brand_remote_cancelled'
  | 'brand_remote_rejected'
  | 'brand_remote_failed';

export class BrandRemoteError extends Error {
  constructor(
    readonly code: BrandRemoteErrorCode,
    message: string,
    readonly httpStatus?: number,
    readonly retryAfterSeconds?: number,
  ) {
    super(message);
    this.name = 'BrandRemoteError';
  }
}
