import type {
  CapabilityDescriptor,
  CapabilityProvider,
  InvocationContext,
} from '@marshal/agent-runtime-core';

const PURGE = 'memory.purge';
export const FORGET_COMPLETELY_NEEDS_HOST_FORGET = 'memory_purge_needs_host_forget';

/**
 * "Forget completely" is not a mode of `memory.purge` (judge wave 3 F3). It erases a memory's whole
 * lineage for good, so it must always ask the user, and a runtime capability cannot demand that
 * per call: an extension permission is decided by the session's permission policy, which an
 * allow-all session or an earlier "always allow" answers without a card, and the host's approval
 * verifier is wired only to the built-in code intelligence. So `completely: true` is refused with
 * a coded error that points at the host `forget` tool, whose card is shown every time and never
 * remembered; that tool reaches the user's memories and the calling session's workspace and
 * project memories (BrainMarshalMemoryStore.forgetCompletely with a session scope). Without
 * `completely`, or with `completely: false`, `memory.purge` is the plain purge, unchanged.
 */
export function withForgetCompletely(provider: CapabilityProvider): CapabilityProvider {
  return {
    id: provider.id,
    ...(provider.version ? { version: provider.version } : {}),
    async list(context) {
      return (await provider.list(context)).map(describe);
    },
    ...(provider.get
      ? {
          async get(name: string, context: InvocationContext) {
            const descriptor = await provider.get!(name, context);
            return descriptor ? describe(descriptor) : descriptor;
          },
        }
      : {}),
    async invoke(name, input, context) {
      const request = (input ?? {}) as Readonly<Record<string, unknown>>;
      if (name !== PURGE || request.completely === undefined) return provider.invoke(name, input, context);
      const { completely, confirm: _confirm, ...plain } = request;
      if (completely !== true) return provider.invoke(name, plain, context);
      throw Object.assign(new Error(
        'Forgetting a memory completely erases it and its whole history for good, so it always needs the user\'s approval on a card, '
        + 'which memory.purge cannot show. Nothing was purged. Use the Marshal host tool `forget` with {"id": "<memory id>", "completely": true} '
        + 'instead: it shows the approval card and reaches your memories and this session\'s workspace and project memories.',
      ), { code: FORGET_COMPLETELY_NEEDS_HOST_FORGET, hostTool: 'forget' });
    },
  };
}

function describe(descriptor: CapabilityDescriptor): CapabilityDescriptor {
  if (descriptor.name !== PURGE) return descriptor;
  const input = descriptor.inputSchema as { properties?: Record<string, unknown> } | undefined;
  return {
    ...descriptor,
    description: `${descriptor.description} To forget a memory completely (every revision and its history, irreversibly), use the host `
      + 'tool `forget` with completely: true, which asks the user on a card; memory.purge refuses completely: true '
      + `(${FORGET_COMPLETELY_NEEDS_HOST_FORGET}) and purges nothing.`,
    inputSchema: {
      ...descriptor.inputSchema,
      properties: {
        ...input?.properties,
        completely: { type: 'boolean', description: 'Refused when true (memory_purge_needs_host_forget): use the host forget tool.' },
      },
    },
  } as CapabilityDescriptor;
}
