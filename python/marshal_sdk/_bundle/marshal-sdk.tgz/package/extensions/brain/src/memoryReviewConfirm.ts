import type { CapabilityDescriptor } from '@marshal/agent-runtime-core';
import { PROTOCOL_VERSION } from '@marshal/agent-runtime-provider-kit';
import type { LazyUserMemory } from './marshalMemoryStore.js';

const MAX_IDS = 500;

/**
 * Confirming that flagged memories still hold writes Brain's review record, so it sits under the
 * same memory.write permission as remember, correct and memory.link, apart from the read-only
 * memory.overview that shows the flags.
 */
export const CONFIRM_REVIEWED_DESCRIPTOR: CapabilityDescriptor = {
  protocolVersion: PROTOCOL_VERSION,
  name: 'memory.review.confirm',
  version: '1.0.0',
  description:
    'Record that the user confirmed these memories still hold, which clears their needs-review flag '
    + '(memory.overview shows needsReview). Only ids memory.overview lists for this session count; '
    + 'the memories themselves are not changed. To change a memory instead, correct it.',
  tags: ['memory', 'review', 'write'],
  permissions: [{ permission: 'memory.write', scope: 'runtime', risk: 'medium' }],
  inputSchema: {
    type: 'object',
    required: ['ids'],
    properties: {
      ids: {
        type: 'array',
        minItems: 1,
        maxItems: MAX_IDS,
        items: { type: 'string', minLength: 1, maxLength: 128 },
        description: 'Memory ids the user confirmed are still true.',
      },
    },
    additionalProperties: false,
  },
  outputSchema: {
    type: 'object',
    required: ['confirmed', 'notVisible'],
    properties: {
      confirmed: { type: 'integer', minimum: 0 },
      notVisible: { type: 'array', items: { type: 'string' } },
    },
    additionalProperties: false,
  },
};

export function confirmReviewed(
  userMemory: LazyUserMemory,
  visible: ReadonlySet<string>,
  rawInput: unknown,
): { confirmed: number; notVisible: string[] } {
  const ids = parseIds(rawInput);
  const notVisible = ids.filter((id) => !visible.has(id));
  return { confirmed: userMemory.reviews.confirm(ids.filter((id) => visible.has(id))), notVisible };
}

function parseIds(rawInput: unknown): readonly string[] {
  const input = rawInput && typeof rawInput === 'object' && !Array.isArray(rawInput) ? rawInput as Record<string, unknown> : undefined;
  if (!input || Object.keys(input).some((key) => key !== 'ids')) throw new Error('Input must be {ids}.');
  const { ids } = input;
  if (!Array.isArray(ids) || ids.length === 0 || ids.length > MAX_IDS
    || ids.some((id) => typeof id !== 'string' || !id || id.length > 128)) {
    throw new Error(`ids must list 1 to ${MAX_IDS} memory ids.`);
  }
  return [...new Set(ids as string[])];
}
