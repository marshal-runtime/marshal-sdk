import { DatabaseSync } from 'node:sqlite';
import type { InvocationContext } from '@marshal/agent-runtime-core';

/**
 * Who stated a memory.link note (judge J2): the session it came from, written by an agent on the
 * user's behalf. User memories carry their source in the fact key; a link note's key is the caller's
 * own, so Brain records it here, by memory id (a replacement is a new id with its own record; a
 * forget-completely purge deletes these rows with the lineage).
 */
export const PROVENANCE_TABLE = 'marshal_memory_provenance_v2';

export interface MemoryProvenanceRecord {
  /** `session/<sessionId>`, rendered by hosts as `src:session/<sessionId>`. */
  readonly source: string;
  /** Always `user`: the user stated it, or an agent wrote it on the user's behalf in their session. */
  readonly author: 'user';
}

export class MemoryProvenance {
  #db: DatabaseSync | undefined;

  constructor(private readonly memoryDbPath: string) {}

  /** Records the session a new note came from; an existing record (the first statement) wins. */
  record(memoryId: string, context: InvocationContext): void {
    const sessionId = context.scope?.sessionId;
    const source = sessionId ? `session/${sessionId}` : 'session';
    this.#open().prepare(`INSERT INTO ${PROVENANCE_TABLE}(memory_id, source, author, recorded_at) VALUES (?, ?, 'user', ?)
      ON CONFLICT(memory_id) DO NOTHING`).run(memoryId, source.slice(0, 200), new Date().toISOString());
  }

  get(memoryId: string): MemoryProvenanceRecord | undefined {
    const row = this.#open().prepare(`SELECT source FROM ${PROVENANCE_TABLE} WHERE memory_id = ?`).get(memoryId) as
      | { source: string }
      | undefined;
    return row ? { source: row.source, author: 'user' } : undefined;
  }

  /** The sources of many memories in one query; ids with no record are absent. */
  getMany(memoryIds: readonly string[]): ReadonlyMap<string, MemoryProvenanceRecord> {
    const sources = new Map<string, MemoryProvenanceRecord>();
    if (memoryIds.length === 0) return sources;
    const rows = this.#open().prepare(
      `SELECT memory_id, source FROM ${PROVENANCE_TABLE} WHERE memory_id IN (SELECT value FROM json_each(?))`,
    ).all(JSON.stringify([...new Set(memoryIds)])) as Array<{ memory_id: string; source: string }>;
    for (const row of rows) sources.set(row.memory_id, { source: row.source, author: 'user' });
    return sources;
  }

  close(): void {
    this.#db?.close();
    this.#db = undefined;
  }

  #open(): DatabaseSync {
    if (this.#db) return this.#db;
    const db = new DatabaseSync(this.memoryDbPath);
    db.exec('PRAGMA busy_timeout = 30000;');
    db.exec(`CREATE TABLE IF NOT EXISTS ${PROVENANCE_TABLE} (
      memory_id TEXT PRIMARY KEY, source TEXT NOT NULL, author TEXT NOT NULL, recorded_at TEXT NOT NULL
    )`);
    this.#db = db;
    return db;
  }
}
