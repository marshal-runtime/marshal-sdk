import { createHash, randomUUID } from 'node:crypto';
import type { DatabaseSync } from 'node:sqlite';
import type { InvocationContext } from '@marshal/agent-runtime-core';
import type {
  DailyMemoryHealingResult,
  MemoryScopeHandle,
  PortableMemoryRuntime,
} from '@marshal/agent-runtime-provider-memory';

export interface HealLog {
  info(message: string, metadata: Readonly<Record<string, unknown>>): void;
  warn(message: string, metadata: Readonly<Record<string, unknown>>): void;
}

const consoleLog: HealLog = {
  info: (message, metadata) => console.info(message, metadata),
  warn: (message, metadata) => console.warn(message, metadata),
};

/** A claim older than this is presumed dead (crashed process) and may be taken over. */
const USER_HEAL_LEASE_MS = 15 * 60 * 1_000;

export interface UserDailyHeal {
  /** Starts the heal in the background at most once per UTC day per user; returns at once. */
  schedule(handles: readonly MemoryScopeHandle[], ownerDate: string, context: InvocationContext): void;
  /** Resolves when every heal this process started has settled. */
  waitForIdle(): Promise<void>;
}

/**
 * The session-start heal, gated per user (principal) and UTC day through the
 * existing healing watermark and lease tables, so many sessions (and agents) of
 * one user trigger one heal a day. Logs one metadata-only line per heal.
 */
export function createUserDailyHeal(
  runtime: PortableMemoryRuntime,
  db: DatabaseSync,
  log: HealLog = consoleLog,
  /** Whether the bundled provider-kit can delete cached lifecycle results (review R13e-L2); surfaced when not. */
  lifecycleResultsPurgeAvailable = true,
): UserDailyHeal {
  const running = new Set<Promise<void>>();
  const run = async (
    handles: readonly MemoryScopeHandle[],
    ownerDate: string,
    context: InvocationContext,
  ): Promise<void> => {
    const ownerKey = userHealKey(context, ownerDate);
    const claimId = claimUserHeal(db, ownerKey);
    if (!claimId) return;
    const startedAt = Date.now();
    try {
      if (finishedMeanwhile(db, ownerKey)) return;
      let result = await runtime.healDaily(handles, ownerDate, context);
      let scopesBackfilled: number | undefined;
      if (result.status === 'already_completed') {
        // This subject's heal ran earlier today (e.g. by the Brain installed before this one):
        // the machine-wide steps still run once today under this user's key.
        const maintenance = await runtime.healMaintenance(handles, context);
        scopesBackfilled = maintenance.scopesBackfilled;
        result = {
          ...result,
          expiredScopeIds: maintenance.expiredScopeIds,
          backlogRetried: maintenance.backlogRetried,
          datesHealed: maintenance.datesHealed,
          datesSuspect: maintenance.datesSuspect,
          sessionRowsRetired: maintenance.sessionRowsRetired,
        };
      }
      // Scopes whose rows reconcile keeps because their files are missing (review round 11 M1).
      const attention = runtime.inspectDailyHealing(handles, ownerDate, context).attention ?? [];
      const line = {
        ...healLine(result, Date.now() - startedAt),
        // A provider-kit without purgeResults: a complete forget leaves recalled text in the results cache.
        ...(lifecycleResultsPurgeAvailable ? {} : { lifecycleResultsPurge: 'unavailable' }),
        ...(attention.length > 0 ? { attention: attention.map(({ scopeId, code, activeRows, wouldDrop, firstSeenAt }) => ({ scopeId, code, activeRows, wouldDrop, firstSeenAt })) } : {}),
        ...(scopesBackfilled === undefined ? {} : { scopesBackfilled }),
        // Re-stamped dates the heal refused to write: restore them from a snapshot (tools/restore-created-at.mjs).
        ...(result.datesSuspect ? { datesSuspect: result.datesSuspect } : {}),
      };
      if (result.status !== 'in_progress') {
        db.prepare(`
          INSERT INTO marshal_memory_healing_watermarks_v2(owner_date, completed_at, result_json)
          VALUES (?, ?, ?)
          ON CONFLICT(owner_date) DO NOTHING
        `).run(ownerKey, new Date().toISOString(), JSON.stringify(line));
      }
      if (attention.length > 0) {
        log.warn('[brain] memory heal: memories kept whose files are missing', line);
      } else if (!lifecycleResultsPurgeAvailable) {
        log.warn('[brain] memory heal: cached lifecycle results cannot be purged (provider-kit without purgeResults)', line);
      } else {
        log.info('[brain] memory heal', line);
      }
    } catch (error) {
      log.warn('[brain] memory heal failed; the next session start retries', {
        status: 'failed',
        errorName: error instanceof Error ? error.name : typeof error,
        errorCode: typeof (error as { code?: unknown })?.code === 'string'
          ? (error as { code: string }).code
          : undefined,
        durationMs: Date.now() - startedAt,
      });
    } finally {
      db.prepare(`
        DELETE FROM marshal_memory_healing_claims_v2 WHERE owner_date = ? AND claim_id = ?
      `).run(ownerKey, claimId);
    }
  };
  return {
    schedule(handles, ownerDate, context) {
      const task: Promise<void> = run(handles, ownerDate, context)
        .catch(() => undefined)
        .finally(() => { running.delete(task); });
      running.add(task);
    },
    async waitForIdle() {
      while (running.size > 0) await Promise.all([...running]);
    },
  };
}

export function healLine(result: DailyMemoryHealingResult, durationMs: number): {
  readonly status: DailyMemoryHealingResult['status'];
  readonly backlogRetried: number;
  readonly scopesExpired: number;
  readonly datesHealed: number;
  readonly sessionRowsRetired: number;
  readonly durationMs: number;
} {
  return {
    status: result.status,
    backlogRetried: result.backlogRetried ?? 0,
    scopesExpired: result.expiredScopeIds.length,
    datesHealed: result.datesHealed ?? 0,
    sessionRowsRetired: result.sessionRowsRetired ?? 0,
    durationMs,
  };
}

function userHealKey(context: InvocationContext, ownerDate: string): string {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(ownerDate)) throw new Error('ownerDate must use YYYY-MM-DD.');
  const user = createHash('sha256')
    .update(JSON.stringify([context.principal.kind, context.principal.id]))
    .digest('hex')
    .slice(0, 32);
  // v2: a v1 row may record a day on which only an older Brain's subject heal ran (no maintenance).
  return `user-heal-v2-${user}:${ownerDate}`;
}

/** A claim id when this caller may heal now; undefined when done today or claimed by a live heal. */
function claimUserHeal(db: DatabaseSync, ownerKey: string): string | undefined {
  const done = db.prepare(`
    SELECT 1 AS done FROM marshal_memory_healing_watermarks_v2 WHERE owner_date = ?
  `).get(ownerKey);
  if (done) return undefined;
  const claimId = randomUUID();
  const now = new Date();
  const leaseExpiresAt = new Date(now.getTime() + USER_HEAL_LEASE_MS).toISOString();
  const inserted = db.prepare(`
    INSERT OR IGNORE INTO marshal_memory_healing_claims_v2(owner_date, claim_id, claimed_at, lease_expires_at)
    VALUES (?, ?, ?, ?)
  `).run(ownerKey, claimId, now.toISOString(), leaseExpiresAt);
  if (Number(inserted.changes) > 0) return claimId;
  const reclaimed = db.prepare(`
    UPDATE marshal_memory_healing_claims_v2
    SET claim_id = ?, claimed_at = ?, lease_expires_at = ?
    WHERE owner_date = ? AND lease_expires_at <= ?
  `).run(claimId, now.toISOString(), leaseExpiresAt, ownerKey, now.toISOString());
  return Number(reclaimed.changes) > 0 ? claimId : undefined;
}

/** Another process may have finished between the watermark check and the claim. */
function finishedMeanwhile(db: DatabaseSync, ownerKey: string): boolean {
  return Boolean(db.prepare(`
    SELECT 1 AS done FROM marshal_memory_healing_watermarks_v2 WHERE owner_date = ?
  `).get(ownerKey));
}
