import { execFile } from 'node:child_process';
import { createSign } from 'node:crypto';
import { access as fileAccess, readFile } from 'node:fs/promises';
import * as os from 'node:os';
import * as path from 'node:path';
import { CloudBrainError } from './errors.js';

export const GOOGLE_TOKEN_URL = 'https://oauth2.googleapis.com/token';
export const GOOGLE_TOKENINFO_URL = 'https://oauth2.googleapis.com/tokeninfo';
export const IAM_CREDENTIALS_URL = 'https://iamcredentials.googleapis.com/v1/projects/-/serviceAccounts';
const ADC_RELATIVE_PATH = path.join('.config', 'gcloud', 'application_default_credentials.json');
const RENEW_MARGIN_MS = 5 * 60_000;
const FALLBACK_LIFETIME_MS = 5 * 60_000;
const GCLOUD_TIMEOUT_MS = 15_000;
const GCLOUD_CANDIDATE_PATHS = [
  path.join('google-cloud-sdk', 'bin', 'gcloud'),
  path.join('.local', 'google-cloud-sdk', 'bin', 'gcloud'),
];
const GCLOUD_SYSTEM_PATHS = [
  '/opt/homebrew/bin/gcloud',
  '/opt/homebrew/share/google-cloud-sdk/bin/gcloud',
  '/usr/local/bin/gcloud',
  '/usr/bin/gcloud',
];
export const SIGN_IN_INSTRUCTION =
  'The Brain is unavailable until the user signs in: ask the user to run `gcloud auth login` once (it opens the browser), then retry. Do not fall back silently; tell the user the Brain was not used.';

/** Which token the gcloud CLI prints: an OAuth access token or the user's own ID token. */
export type GcloudTokenKind = 'access' | 'identity';

export interface GoogleCredentialDeps {
  readonly fetch?: typeof fetch;
  readonly readFile?: (file: string) => Promise<string>;
  readonly now?: () => number;
  readonly env?: Readonly<Record<string, string | undefined>>;
  readonly homeDirectory?: string;
  /** Prints a token from the gcloud CLI login; resolves to an error text when gcloud has no usable login. */
  readonly gcloudToken?: (kind: GcloudTokenKind, signal: AbortSignal) => Promise<{ token: string } | { error: string }>;
}

export interface CallerCredentials {
  /** ID token of the trusted process identity for the outbound service audience. Never logged. */
  readonly idToken: string;
  /** Verified caller email, or the trusted runtime-host claim in delegated mode. */
  readonly caller?: string;
}

export interface CallerCredentialSource {
  credentials(signal: AbortSignal, callerEmail?: string): Promise<CallerCredentials>;
  /** Forgets cached tokens, after the cloud refused one. */
  reset(): void;
}

export const METADATA_IDENTITY_PATH = '/computeMetadata/v1/instance/service-accounts/default/identity';
const EMAIL_PATTERN = /^[a-z0-9][a-z0-9._+-]{0,63}@[a-z0-9][a-z0-9.-]{0,127}\.[a-z]{2,24}$/;
const ID_TOKEN_PATTERN = /^eyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+$/;
const MAX_ID_TOKEN_BYTES = 32 * 1024;

/**
 * Delegated mode, for a process that runs as a service (the Marshal runtime host on Cloud Run): the host service
 * account's own ID token for `audience`, read from the metadata server, plus the asking person's email, which the
 * invocation's trusted principal claims supply per call. No user credential exists in this mode.
 */
export function createMetadataCallerCredentialSource(
  audience: string,
  deps: Pick<GoogleCredentialDeps, 'fetch' | 'now' | 'env'> = {},
): CallerCredentialSource {
  const fetcher = deps.fetch ?? fetch;
  const now = deps.now ?? Date.now;
  const env = deps.env ?? process.env;
  const metadataHost = env.GCE_METADATA_HOST || 'metadata.google.internal';
  let cached: { token: string; expiresAt: number } | undefined;
  return {
    async credentials(signal, callerEmail) {
      if (!isLowercaseEmail(callerEmail)) {
        throw new CloudBrainError('cloud_brain_auth_failed', 'cloud brain auth failed: a trusted runtime caller email is required.');
      }
      if (!cached || cached.expiresAt - now() <= RENEW_MARGIN_MS) {
        const url = `http://${metadataHost}${METADATA_IDENTITY_PATH}?${new URLSearchParams({ audience, format: 'full' })}`;
        let response: Response;
        try {
          response = await fetcher(url, { headers: { 'metadata-flavor': 'Google' }, signal });
        } catch {
          if (signal.aborted) throw signal.reason ?? new CloudBrainError('cloud_brain_cancelled', 'cloud brain credential request was cancelled.');
          throw new CloudBrainError('cloud_brain_auth_failed', 'cloud brain auth failed: the metadata server is unreachable, so the host service account cannot mint an ID token.');
        }
        const token = response.ok ? (await response.text()).trim() : '';
        if (!isIdToken(token)) {
          throw new CloudBrainError(
            'cloud_brain_auth_failed',
            `cloud brain auth failed: the metadata server did not return an ID token for the host service account (HTTP ${response.status}).`,
            { httpStatus: response.status },
          );
        }
        cached = { token, expiresAt: tokenExpiry(token) ?? now() + FALLBACK_LIFETIME_MS };
      }
      return { idToken: cached.token, caller: callerEmail };
    },
    reset() { cached = undefined; },
  };
}

/** Where a service-key host finds its key when `cloudCredentialsFile` is not set: the inline JSON E2B sandboxes carry. */
export const SERVICE_KEY_JSON_ENV = 'GOOGLE_APPLICATION_CREDENTIALS_JSON';
const JWT_BEARER_GRANT = 'urn:ietf:params:oauth:grant-type:jwt-bearer';
const ASSERTION_LIFETIME_SECONDS = 3600;

interface ServiceAccountKey {
  readonly type?: string;
  readonly client_email?: string;
  readonly private_key?: string;
  readonly private_key_id?: string;
}

/**
 * Service-key mode, for a host that runs as a service but has no metadata server (zyg's page agent in an E2B sandbox):
 * the service account's own key signs a JWT bearer assertion that Google exchanges for an ID token with `audience` as
 * its target audience, and the asking person's email comes from the invocation's trusted principal claims, as in
 * delegated mode. The key is read from `credentialsFile`, else the inline JSON in $GOOGLE_APPLICATION_CREDENTIALS_JSON,
 * else the file $GOOGLE_APPLICATION_CREDENTIALS names. The key and the tokens stay in memory and never appear in an error.
 */
export function createServiceKeyCallerCredentialSource(
  audience: string,
  options: { readonly credentialsFile?: string } = {},
  deps: Pick<GoogleCredentialDeps, 'fetch' | 'now' | 'env' | 'readFile'> = {},
): CallerCredentialSource {
  const fetcher = deps.fetch ?? fetch;
  const read = deps.readFile ?? ((file: string) => readFile(file, 'utf8'));
  const now = deps.now ?? Date.now;
  const env = deps.env ?? process.env;
  let cached: { token: string; expiresAt: number } | undefined;

  const loadKey = async (): Promise<{ key: ServiceAccountKey; from: string }> => {
    const inline = env[SERVICE_KEY_JSON_ENV]?.trim();
    const file = options.credentialsFile ?? (inline ? undefined : env.GOOGLE_APPLICATION_CREDENTIALS);
    const from = file ?? `$${SERVICE_KEY_JSON_ENV}`;
    let text: string | undefined;
    try {
      text = file !== undefined ? await read(file) : inline;
    } catch {
      text = undefined;
    }
    if (!text) {
      throw new CloudBrainError(
        'cloud_brain_auth_failed',
        `cloud brain auth failed: service-key mode found no service account key (set cloudCredentialsFile, $${SERVICE_KEY_JSON_ENV} or $GOOGLE_APPLICATION_CREDENTIALS).`,
      );
    }
    let key: ServiceAccountKey;
    try {
      key = JSON.parse(text) as ServiceAccountKey;
    } catch {
      throw new CloudBrainError('cloud_brain_auth_failed', `cloud brain auth failed: the service account key in ${from} is not JSON.`);
    }
    if (key.type !== 'service_account' || !key.client_email || !key.private_key) {
      throw new CloudBrainError('cloud_brain_auth_failed', `cloud brain auth failed: ${from} is not a Google service account key.`);
    }
    return { key, from };
  };

  const mint = async (signal: AbortSignal): Promise<string> => {
    const { key, from } = await loadKey();
    const issuedAt = Math.floor(now() / 1000);
    const part = (value: unknown) => Buffer.from(JSON.stringify(value)).toString('base64url');
    const unsigned = `${part({ alg: 'RS256', typ: 'JWT', ...(key.private_key_id ? { kid: key.private_key_id } : {}) })}.${part({
      iss: key.client_email,
      sub: key.client_email,
      aud: GOOGLE_TOKEN_URL,
      iat: issuedAt,
      exp: issuedAt + ASSERTION_LIFETIME_SECONDS,
      target_audience: audience,
    })}`;
    let signature: string;
    try {
      signature = createSign('RSA-SHA256').update(unsigned).sign(key.private_key!).toString('base64url');
    } catch {
      throw new CloudBrainError('cloud_brain_auth_failed', `cloud brain auth failed: the private key in ${from} could not sign.`);
    }
    const response = await googleFetch(fetcher, GOOGLE_TOKEN_URL, {
      method: 'POST',
      headers: { 'content-type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({ grant_type: JWT_BEARER_GRANT, assertion: `${unsigned}.${signature}` }).toString(),
      signal,
    }, 'mint the cloud Brain ID token from the service account key');
    const body = await jsonBody(response) as { id_token?: unknown };
    if (!response.ok || typeof body.id_token !== 'string' || !isIdToken(body.id_token)) {
      throw new CloudBrainError(
        'cloud_brain_auth_failed',
        `cloud brain auth failed: Google did not issue an ID token for ${key.client_email} (HTTP ${response.status}).`,
        { httpStatus: response.status },
      );
    }
    cached = { token: body.id_token, expiresAt: tokenExpiry(body.id_token) ?? now() + FALLBACK_LIFETIME_MS };
    return body.id_token;
  };

  return {
    async credentials(signal, callerEmail) {
      if (!isLowercaseEmail(callerEmail)) {
        throw new CloudBrainError('cloud_brain_auth_failed', 'cloud brain auth failed: a trusted runtime caller email is required.');
      }
      const token = cached && cached.expiresAt - now() > RENEW_MARGIN_MS ? cached.token : await mint(signal);
      return { idToken: token, caller: callerEmail };
    },
    reset() { cached = undefined; },
  };
}

function isIdToken(value: string): boolean {
  return Buffer.byteLength(value, 'utf8') <= MAX_ID_TOKEN_BYTES && ID_TOKEN_PATTERN.test(value);
}

function isLowercaseEmail(value: string | undefined): value is string {
  return value !== undefined && value === value.trim() && value === value.toLowerCase() && EMAIL_PATTERN.test(value);
}

interface AuthorizedUserFile {
  readonly type?: string;
  readonly client_id?: string;
  readonly client_secret?: string;
  readonly refresh_token?: string;
}

/**
 * Credentials for calling the cloud Brain as the signed-in person: the person's own Google user credentials
 * (an `authorized_user` file such as gcloud's application default credentials) mint an access token, Google's
 * tokeninfo names the person's verified email, and the access token mints an ID token for the trusted service
 * account. Tokens live in memory only, are renewed before they expire and never appear in an error.
 */
export function createCallerCredentialSource(
  options: {
    readonly serviceAccount: string;
    readonly audience: string;
    readonly credentialsFile?: string;
    readonly expectedCaller?: string;
  },
  deps: GoogleCredentialDeps = {},
): CallerCredentialSource {
  const fetcher = deps.fetch ?? fetch;
  const read = deps.readFile ?? ((file: string) => readFile(file, 'utf8'));
  const now = deps.now ?? Date.now;
  const env = deps.env ?? process.env;
  const credentialsFile = options.credentialsFile
    ?? env.GOOGLE_APPLICATION_CREDENTIALS
    ?? path.join(deps.homeDirectory ?? os.homedir(), ADC_RELATIVE_PATH);
  const gcloudToken = deps.gcloudToken ?? defaultGcloudToken(env, deps.homeDirectory ?? os.homedir());
  let access: { token: string; caller: string; expiresAt: number } | undefined;
  let identity: { token: string; expiresAt: number } | undefined;

  const checkedCaller = (caller: string) => {
    if (options.expectedCaller && caller !== options.expectedCaller) {
      throw new CloudBrainError(
        'cloud_brain_auth_failed',
        `cloud brain auth failed: the signed-in Google account is ${caller}, not the configured expectedCaller ${options.expectedCaller}.`,
      );
    }
    return caller;
  };

  const gcloudAccessToken = async (signal: AbortSignal) => {
    const printed = await gcloudToken('access', signal);
    if ('error' in printed) throw new CloudBrainError('cloud_brain_auth_failed', printed.error);
    const { email, expiresInSeconds } = await tokenInfo(fetcher, printed.token, signal);
    const lifetimeMs = expiresInSeconds !== undefined ? expiresInSeconds * 1000 : FALLBACK_LIFETIME_MS;
    return { token: printed.token, caller: checkedCaller(email), expiresAt: now() + lifetimeMs };
  };

  const accessToken = async (signal: AbortSignal) => {
    if (access && access.expiresAt - now() > RENEW_MARGIN_MS) return access;
    try {
      access = await fileAccessToken(signal);
    } catch (fileError) {
      if (!isAuthFailure(fileError)) throw fileError;
      try {
        access = await gcloudAccessToken(signal);
      } catch (gcloudError) {
        if (!isAuthFailure(gcloudError)) throw gcloudError;
        throw noLoginWorks(fileError, gcloudError);
      }
    }
    return access;
  };

  const fileAccessToken = async (signal: AbortSignal) => {
    let file: AuthorizedUserFile;
    try {
      file = JSON.parse(await read(credentialsFile)) as AuthorizedUserFile;
    } catch {
      throw new CloudBrainError(
        'cloud_brain_auth_failed',
        `cloud brain auth failed: no readable Google user credentials at ${credentialsFile}; sign in with \`gcloud auth application-default login\` (inside the dev container) or set credentialsFile.`,
      );
    }
    // Desktop mode impersonates the portal account with a person's refresh token. A service account key is accepted
    // only in cloudCallerMode "service-key", which names the person through trusted claims (Omer, R163, 2026-11-19).
    if (file.type !== 'authorized_user' || !file.refresh_token || !file.client_id) {
      throw new CloudBrainError(
        'cloud_brain_auth_failed',
        `cloud brain auth failed: ${credentialsFile} is not a Google user (authorized_user) credentials file; a service account key needs cloudCallerMode "service-key".`,
      );
    }
    const response = await googleFetch(fetcher, GOOGLE_TOKEN_URL, {
      method: 'POST',
      headers: { 'content-type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({
        grant_type: 'refresh_token',
        client_id: file.client_id,
        client_secret: file.client_secret ?? '',
        refresh_token: file.refresh_token,
      }).toString(),
      signal,
    }, 'refresh the Google user credentials');
    const body = await jsonBody(response) as { access_token?: unknown; expires_in?: unknown };
    if (!response.ok || typeof body.access_token !== 'string') {
      throw new CloudBrainError(
        'cloud_brain_auth_failed',
        `cloud brain auth failed: Google refused the user credentials in ${credentialsFile} (HTTP ${response.status}); sign in again with \`gcloud auth application-default login\`.`,
        { httpStatus: response.status },
      );
    }
    const { email } = await tokenInfo(fetcher, body.access_token, signal);
    const lifetimeMs = typeof body.expires_in === 'number' ? body.expires_in * 1000 : FALLBACK_LIFETIME_MS;
    return { token: body.access_token, caller: checkedCaller(email), expiresAt: now() + lifetimeMs };
  };

  const idToken = async (token: string, signal: AbortSignal) => {
    if (identity && identity.expiresAt - now() > RENEW_MARGIN_MS) return identity.token;
    const response = await googleFetch(
      fetcher,
      `${IAM_CREDENTIALS_URL}/${encodeURIComponent(options.serviceAccount)}:generateIdToken`,
      {
        method: 'POST',
        headers: { authorization: `Bearer ${token}`, 'content-type': 'application/json' },
        body: JSON.stringify({ audience: options.audience, includeEmail: true }),
        signal,
      },
      'mint the cloud Brain ID token',
    );
    const body = await jsonBody(response) as { token?: unknown };
    if (response.status === 403) {
      throw new CloudBrainError(
        'cloud_brain_auth_failed',
        `cloud brain auth failed: Google denied minting an ID token for ${options.serviceAccount}; the signed-in user needs roles/iam.serviceAccountOpenIdTokenCreator on it.`,
        { httpStatus: 403 },
      );
    }
    if (!response.ok || typeof body.token !== 'string') {
      throw new CloudBrainError(
        'cloud_brain_auth_failed',
        `cloud brain auth failed: Google did not issue an ID token for ${options.serviceAccount} (HTTP ${response.status}).`,
        { httpStatus: response.status },
      );
    }
    const expiry = tokenExpiry(body.token);
    identity = { token: body.token, expiresAt: expiry ?? now() + FALLBACK_LIFETIME_MS };
    return body.token;
  };

  return {
    async credentials(signal) {
      const { token, caller } = await accessToken(signal);
      return { idToken: await idToken(token, signal), caller };
    },
    reset() {
      access = undefined;
      identity = undefined;
    },
  };
}

/**
 * Desktop credentials for the Brand Brain: the signed-in person's own Google ID token. The refresh-token grant of an
 * `authorized_user` file (gcloud's application default credentials) returns it when the `openid` scope was granted;
 * its `aud` is the OAuth client, because Google issues no user token for a custom audience. The token's verified
 * `email` names the person. Tokens live in memory only and never appear in an error.
 */
export function createUserIdTokenCredentialSource(
  options: { readonly credentialsFile?: string; readonly expectedCaller?: string } = {},
  deps: GoogleCredentialDeps = {},
): CallerCredentialSource {
  const fetcher = deps.fetch ?? fetch;
  const read = deps.readFile ?? ((file: string) => readFile(file, 'utf8'));
  const now = deps.now ?? Date.now;
  const env = deps.env ?? process.env;
  const credentialsFile = options.credentialsFile
    ?? env.GOOGLE_APPLICATION_CREDENTIALS
    ?? path.join(deps.homeDirectory ?? os.homedir(), ADC_RELATIVE_PATH);
  const gcloudToken = deps.gcloudToken ?? defaultGcloudToken(env, deps.homeDirectory ?? os.homedir());
  let cached: { token: string; caller: string; expiresAt: number } | undefined;

  const verifiedIdToken = (token: string) => {
    const claims = tokenClaims(token);
    const email = typeof claims?.email === 'string' ? claims.email.toLowerCase() : undefined;
    const verified = claims?.email_verified === true || claims?.email_verified === 'true';
    if (!email || !verified) {
      throw new CloudBrainError(
        'cloud_brain_auth_failed',
        'cloud brain auth failed: the Google ID token carries no verified email for the signed-in account.',
      );
    }
    if (options.expectedCaller && email !== options.expectedCaller) {
      throw new CloudBrainError(
        'cloud_brain_auth_failed',
        `cloud brain auth failed: the signed-in Google account is ${email}, not the configured expectedCaller ${options.expectedCaller}.`,
      );
    }
    return { token, caller: email, expiresAt: tokenExpiry(token) ?? now() + FALLBACK_LIFETIME_MS };
  };

  const gcloudIdToken = async (signal: AbortSignal) => {
    const printed = await gcloudToken('identity', signal);
    if ('error' in printed) throw new CloudBrainError('cloud_brain_auth_failed', printed.error);
    if (!isIdToken(printed.token)) {
      throw new CloudBrainError('cloud_brain_auth_failed', 'cloud brain auth failed: gcloud printed no ID token.');
    }
    return verifiedIdToken(printed.token);
  };

  return {
    async credentials(signal) {
      if (cached && cached.expiresAt - now() > RENEW_MARGIN_MS) return { idToken: cached.token, caller: cached.caller };
      try {
        cached = await fileIdToken(signal);
      } catch (fileError) {
        if (!isAuthFailure(fileError)) throw fileError;
        try {
          cached = await gcloudIdToken(signal);
        } catch (gcloudError) {
          if (!isAuthFailure(gcloudError)) throw gcloudError;
          throw noLoginWorks(fileError, gcloudError);
        }
      }
      return { idToken: cached.token, caller: cached.caller };
    },
    reset() { cached = undefined; },
  };

  async function fileIdToken(signal: AbortSignal) {
      let file: AuthorizedUserFile;
      try {
        file = JSON.parse(await read(credentialsFile)) as AuthorizedUserFile;
      } catch {
        throw new CloudBrainError(
          'cloud_brain_auth_failed',
          `cloud brain auth failed: no readable Google user credentials at ${credentialsFile}; sign in with \`gcloud auth application-default login\` or set cloudCredentialsFile.`,
        );
      }
      if (file.type !== 'authorized_user' || !file.refresh_token || !file.client_id) {
        throw new CloudBrainError(
          'cloud_brain_auth_failed',
          `cloud brain auth failed: ${credentialsFile} is not a Google user (authorized_user) credentials file.`,
        );
      }
      const response = await googleFetch(fetcher, GOOGLE_TOKEN_URL, {
        method: 'POST',
        headers: { 'content-type': 'application/x-www-form-urlencoded' },
        body: new URLSearchParams({
          grant_type: 'refresh_token',
          client_id: file.client_id,
          client_secret: file.client_secret ?? '',
          refresh_token: file.refresh_token,
        }).toString(),
        signal,
      }, 'refresh the Google user credentials');
      const body = await jsonBody(response) as { id_token?: unknown };
      if (!response.ok) {
        throw new CloudBrainError(
          'cloud_brain_auth_failed',
          `cloud brain auth failed: Google refused the user credentials in ${credentialsFile} (HTTP ${response.status}); sign in again with \`gcloud auth application-default login\`.`,
          { httpStatus: response.status },
        );
      }
      if (typeof body.id_token !== 'string' || !isIdToken(body.id_token)) {
        throw new CloudBrainError(
          'cloud_brain_auth_failed',
          'cloud brain auth failed: Google returned no ID token for the signed-in account; sign in again with `gcloud auth application-default login` (the openid scope is required).',
        );
      }
      return verifiedIdToken(body.id_token);
  }
}

async function tokenInfo(
  fetcher: typeof fetch,
  accessToken: string,
  signal: AbortSignal,
): Promise<{ email: string; expiresInSeconds?: number }> {
  const response = await googleFetch(fetcher, GOOGLE_TOKENINFO_URL, {
    method: 'POST',
    headers: { 'content-type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({ access_token: accessToken }).toString(),
    signal,
  }, 'read the signed-in Google account');
  const body = await jsonBody(response) as { email?: unknown; email_verified?: unknown; expires_in?: unknown };
  const verified = body.email_verified === true || body.email_verified === 'true';
  if (!response.ok || typeof body.email !== 'string' || !verified) {
    throw new CloudBrainError(
      'cloud_brain_auth_failed',
      'cloud brain auth failed: Google did not report a verified email for the signed-in account (the userinfo.email scope is missing).',
      { httpStatus: response.status },
    );
  }
  const expiresIn = Number(body.expires_in);
  return { email: body.email.toLowerCase(), expiresInSeconds: Number.isFinite(expiresIn) && expiresIn > 0 ? expiresIn : undefined };
}

function isAuthFailure(error: unknown): error is CloudBrainError {
  return error instanceof CloudBrainError && error.code === 'cloud_brain_auth_failed';
}

function noLoginWorks(fileError: CloudBrainError, gcloudError: CloudBrainError): CloudBrainError {
  return new CloudBrainError(
    'cloud_brain_auth_failed',
    `cloud brain auth failed: no Google login works. Application default credentials: ${fileError.message} gcloud login: ${gcloudError.message} ${SIGN_IN_INSTRUCTION}`,
    fileError.httpStatus === undefined ? undefined : { httpStatus: fileError.httpStatus },
  );
}

/** Prints tokens from the gcloud CLI login, which `gcloud auth login` keeps and other tools rarely overwrite. */
export function defaultGcloudToken(
  env: Readonly<Record<string, string | undefined>>,
  homeDirectory: string,
): (kind: GcloudTokenKind, signal: AbortSignal) => Promise<{ token: string } | { error: string }> {
  let binary: Promise<string | undefined> | undefined;
  return async (kind, signal) => {
    binary ??= findGcloud(env, homeDirectory);
    const gcloud = await binary;
    if (!gcloud) return { error: 'cloud brain auth failed: the gcloud CLI is not installed.' };
    const command = kind === 'access' ? 'print-access-token' : 'print-identity-token';
    return new Promise((resolve) => {
      execFile(gcloud, ['auth', command, '--quiet'], { timeout: GCLOUD_TIMEOUT_MS, signal, env: { ...process.env, ...env } }, (error, stdout) => {
        const token = String(stdout ?? '').trim();
        if (error || !token) {
          resolve({ error: `cloud brain auth failed: \`gcloud auth ${command}\` failed; the gcloud login is missing or expired.` });
          return;
        }
        resolve({ token });
      });
    });
  };
}

async function findGcloud(env: Readonly<Record<string, string | undefined>>, homeDirectory: string): Promise<string | undefined> {
  const pathEntries = (env.PATH ?? process.env.PATH ?? '').split(path.delimiter).filter(Boolean).map((dir) => path.join(dir, 'gcloud'));
  const candidates = [
    ...(env.CLOUDSDK_ROOT_DIR ? [path.join(env.CLOUDSDK_ROOT_DIR, 'bin', 'gcloud')] : []),
    ...pathEntries,
    ...GCLOUD_CANDIDATE_PATHS.map((relative) => path.join(homeDirectory, relative)),
    ...GCLOUD_SYSTEM_PATHS,
  ];
  const checks = await Promise.all(candidates.map((candidate) => fileAccess(candidate).then(() => candidate, () => undefined)));
  return checks.find((candidate) => candidate !== undefined);
}

async function googleFetch(
  fetcher: typeof fetch,
  url: string,
  init: RequestInit,
  purpose: string,
): Promise<Response> {
  try {
    return await fetcher(url, init);
  } catch (error) {
    if (init.signal?.aborted) throw init.signal.reason ?? error;
    throw new CloudBrainError(
      'cloud_brain_auth_failed',
      `cloud brain auth failed: could not reach Google to ${purpose}.`,
    );
  }
}

async function jsonBody(response: Response): Promise<unknown> {
  try {
    return await response.json();
  } catch {
    return {};
  }
}

function tokenClaims(token: string): { exp?: unknown; email?: unknown; email_verified?: unknown } | undefined {
  const payload = token.split('.')[1];
  if (!payload) return undefined;
  try {
    return JSON.parse(Buffer.from(payload, 'base64url').toString('utf8')) as { exp?: unknown };
  } catch {
    return undefined;
  }
}

function tokenExpiry(token: string): number | undefined {
  const exp = tokenClaims(token)?.exp;
  return typeof exp === 'number' ? exp * 1000 : undefined;
}
