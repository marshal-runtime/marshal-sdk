import type { InvocationContext } from '@marshal/agent-runtime-core';
import { mkdir, readFile, writeFile } from 'node:fs/promises';
import { homedir } from 'node:os';
import { join } from 'node:path';

/** One node the Brain returned in a search. */
export interface TraceHit {
  readonly id: string;
  readonly kind: string;
  readonly name: string;
  readonly score?: number;
  readonly brand?: number;
}

/** One node a Brain walk opened (knowledge.context, impact or path target). */
export interface TraceOpened {
  readonly id: string;
  readonly kind: string;
  readonly name: string;
  readonly reason?: string;
  readonly channel?: string;
  readonly observedAt?: string;
  readonly verdict?: string;
  readonly brand?: number;
  readonly neighbours: readonly { readonly kind: string; readonly name: string }[];
}

/** One recorded Brain call. */
export interface TraceCall {
  readonly at: number;
  readonly tool: string;
  readonly query?: string;
  readonly hits?: readonly TraceHit[];
  readonly opened?: TraceOpened;
  readonly error?: string;
}

/** A batch of Brain calls the agent made together, as one step of the walk. */
export interface TraceStep {
  readonly step: number;
  readonly searches: readonly { readonly q: string; readonly hits: readonly TraceHit[] }[];
  readonly opened: readonly (TraceOpened & { readonly from: number })[];
  readonly failed: number;
}

const MAX_CALLS_PER_SESSION = 120;
const MAX_SESSIONS = 64;
const MAX_HITS_PER_SEARCH = 10;
const MAX_NEIGHBOURS = 6;
const MAX_NAME_LENGTH = 220;
/** Calls that start within this gap of the previous call belong to the same step. */
export const STEP_GAP_MS = 2500;
const TRACED_TOOLS: ReadonlySet<string> = new Set(['knowledge.search', 'knowledge.context', 'knowledge.impact', 'knowledge.path']);
const BRAND_ID_PATTERN = /^cloud:entity:brand_\w+\/\w+:(\d+):/;

type Json = Record<string, unknown>;
const asObject = (value: unknown): Json | undefined => (value && typeof value === 'object' && !Array.isArray(value) ? (value as Json) : undefined);
const asString = (value: unknown): string | undefined => (typeof value === 'string' && value.trim() ? value.trim() : undefined);
const clip = (value: string) => (value.length > MAX_NAME_LENGTH ? `${value.slice(0, MAX_NAME_LENGTH)}…` : value);

function brandOf(id: string, props: Json | undefined): number | undefined {
  const fromProps = props?.brand_id;
  if (typeof fromProps === 'number') return fromProps;
  const match = BRAND_ID_PATTERN.exec(id);
  return match ? Number(match[1]) : undefined;
}

function nodeKind(node: Json): string {
  const props = asObject(node.props);
  return asString(props?.entityKind) ?? asString(node.entityKind) ?? asString(node.kind) ?? 'node';
}

function toHit(raw: unknown): TraceHit | undefined {
  const hit = asObject(raw);
  const node = asObject(hit?.node) ?? hit;
  const id = asString(node?.id);
  if (!node || !id) return undefined;
  const props = asObject(node.props);
  const brand = brandOf(id, props);
  return {
    id,
    kind: nodeKind(node),
    name: clip(asString(node.name) ?? asString(hit?.snippet) ?? id),
    ...(typeof hit?.score === 'number' ? { score: Math.round(hit.score * 100) / 100 } : {}),
    ...(brand !== undefined ? { brand } : {}),
  };
}

function targetIdOf(input: unknown): string | undefined {
  const value = asObject(input);
  const target = asObject(value?.target) ?? asObject(value?.from);
  return asString(target?.id) ?? asString(target?.path) ?? asString(value?.from) ?? asString(value?.target);
}

function toOpened(input: unknown, output: Json): TraceOpened | undefined {
  const target = asObject(output.target);
  const id = asString(target?.id) ?? targetIdOf(input);
  if (!id) return undefined;
  const props = asObject(target?.props) ?? {};
  const nodes = Array.isArray(output.nodes) ? output.nodes : [];
  const brand = brandOf(id, props);
  return {
    id,
    kind: asString(target?.entityKind) ?? asString(target?.kind) ?? (id.startsWith('cloud:') ? id.split(':')[1] ?? 'node' : 'code'),
    name: clip(asString(props.target_name) ?? asString(target?.name) ?? id),
    ...(asString(props.reason_class) ? { reason: asString(props.reason_class)! } : {}),
    ...(asString(props.channel) ? { channel: asString(props.channel)! } : {}),
    ...(asString(props.observed_at) ? { observedAt: asString(props.observed_at)!.slice(0, 10) } : {}),
    ...(asString(props.verdict) ? { verdict: asString(props.verdict)! } : {}),
    ...(brand !== undefined ? { brand } : {}),
    neighbours: nodes
      .map(asObject)
      .filter((node): node is Json => Boolean(node))
      .map((node) => ({ kind: asString(node.entityKind) ?? asString(node.kind) ?? 'node', name: clip(asString(node.name) ?? asString(node.id) ?? '') }))
      .filter((node) => node.name)
      .slice(0, MAX_NEIGHBOURS),
  };
}

/** The session a Brain call belongs to, or undefined when the host passed none. */
export function sessionIdOf(context: InvocationContext | undefined): string | undefined {
  return asString(context?.scope?.sessionId) ?? asString(context?.scope?.threadId);
}

/** Records every Brain call of each session, in memory and as a JSON file per session. */
export class BrainTraceRecorder {
  private readonly sessions = new Map<string, TraceCall[]>();

  constructor(private readonly directory: string | undefined = join(homedir(), '.marshal', 'brain-traces')) {}

  record(tool: string, input: unknown, result: unknown, context: InvocationContext | undefined, startedAt: number, error?: unknown): void {
    const sessionId = sessionIdOf(context);
    if (!sessionId || !TRACED_TOOLS.has(tool)) return;
    const output = asObject(asObject(result)?.output) ?? asObject(result) ?? {};
    const base = { at: startedAt, tool };
    const call: TraceCall = error !== undefined
      ? { ...base, ...(tool === 'knowledge.search' ? { query: asString(asObject(input)?.query) ?? '' } : {}), error: String((error as Error)?.message ?? error).slice(0, 200) }
      : tool === 'knowledge.search'
        ? {
            ...base,
            query: asString(asObject(input)?.query) ?? '',
            hits: (Array.isArray(output.hits) ? output.hits : []).map(toHit).filter((hit): hit is TraceHit => Boolean(hit)).slice(0, MAX_HITS_PER_SEARCH),
          }
        : { ...base, ...(toOpened(input, output) ? { opened: toOpened(input, output)! } : {}) };
    const calls = this.sessions.get(sessionId) ?? [];
    calls.push(call);
    if (calls.length > MAX_CALLS_PER_SESSION) calls.shift();
    this.sessions.delete(sessionId);
    this.sessions.set(sessionId, calls);
    if (this.sessions.size > MAX_SESSIONS) this.sessions.delete(this.sessions.keys().next().value!);
    void this.persist(sessionId, calls);
  }

  calls(sessionId: string | undefined): readonly TraceCall[] {
    return sessionId ? this.sessions.get(sessionId) ?? [] : [];
  }

  /** The session's calls, read back from its trace file when this process has none (after a restart). */
  async load(sessionId: string | undefined): Promise<readonly TraceCall[]> {
    const live = this.calls(sessionId);
    if (live.length > 0 || !sessionId || !this.directory) return live;
    try {
      const saved = JSON.parse(await readFile(this.fileFor(sessionId), 'utf8')) as { calls?: unknown };
      const calls = Array.isArray(saved.calls) ? (saved.calls as TraceCall[]).filter((call) => typeof call?.at === 'number' && typeof call?.tool === 'string') : [];
      if (calls.length > 0) this.sessions.set(sessionId, [...calls]);
      return calls;
    } catch {
      return [];
    }
  }

  private fileFor(sessionId: string): string {
    return join(this.directory!, `${sessionId.replace(/[^\w.-]/g, '_')}.json`);
  }

  private async persist(sessionId: string, calls: readonly TraceCall[]): Promise<void> {
    if (!this.directory) return;
    try {
      await mkdir(this.directory, { recursive: true });
      await writeFile(this.fileFor(sessionId), JSON.stringify({ sessionId, calls }));
    } catch {
      // The trace file is a convenience copy; the in-memory trace still drives the card.
    }
  }
}

/** Groups recorded calls into steps: calls that start within STEP_GAP_MS of the previous call form one step. */
export function buildSteps(calls: readonly TraceCall[]): readonly TraceStep[] {
  const ordered = [...calls].sort((left, right) => left.at - right.at);
  const batches: TraceCall[][] = [];
  ordered.forEach((call, index) => {
    if (index === 0 || call.at - ordered[index - 1]!.at > STEP_GAP_MS) batches.push([]);
    batches[batches.length - 1]!.push(call);
  });
  const firstSeen = new Map<string, number>();
  return batches.map((batch, index) => {
    const step = index + 1;
    const opened = batch
      .filter((call) => call.opened)
      .map((call) => ({ ...call.opened!, from: firstSeen.get(call.opened!.id) ?? 0 }));
    const searches = batch.filter((call) => call.tool === 'knowledge.search' && call.hits).map((call) => ({ q: call.query ?? '', hits: call.hits! }));
    searches.forEach((search) => search.hits.forEach((hit) => { if (!firstSeen.has(hit.id)) firstSeen.set(hit.id, step); }));
    return { step, searches, opened, failed: batch.filter((call) => call.error).length };
  });
}
