export interface GraphNode {
  id: string;
  kind: string;
  name: string;
  source_ref: string;
  props: Record<string, unknown>;
  record: Record<string, unknown>;
}

export interface GraphEdge {
  a: number;
  b: number;
  type: string;
  conf: number;
  ref: string;
  derivation: string;
}

export class Graph {
  constructor(options?: { directions?: Record<string, string> });
  nodes: GraphNode[];
  edges: GraphEdge[];
  index: Map<string, number>;
  sourceLabel: string;
  addNode(record: Record<string, unknown>): void;
  addEdge(record: Record<string, unknown>): void;
  build(): void;
  search(query: string, options?: { types?: string[]; limit?: number }): Record<string, unknown>[];
  find(text: string, options?: { types?: string[]; limit?: number }): Record<string, unknown>[];
  record(id: string): Record<string, unknown>;
  neighbors(id: string, options?: { edgeTypes?: string[]; direction?: string; kinds?: string[]; limit?: number; perGroup?: number }): Record<string, unknown>;
  path(from: string, to: string, options?: { maxHops?: number; k?: number; edgeTypes?: string[] }): Record<string, unknown>;
  impact(id: string, options?: { maxHops?: number; stopAtTypes?: string[]; kinds?: string[]; limit?: number; minPrior?: number }): Record<string, unknown>;
  stats(): Record<string, unknown>;
}
