import type { CapabilityDescriptor, InvocationContext } from '@marshal/agent-runtime-core';
import { buildSteps, type TraceCall, type TraceStep } from './brainTrace.js';

/** The tool that closes a Brain answer with the answer card. */
export const ANSWER_TOOL = 'knowledge.answer.show';
/** The UI application that renders the answer card. */
export const ANSWER_APP_ID = 'brain-answer';
export const BRAIN_EXTENSION_ID = '@marshal/brain';

const VERSION = '1.0.0';
const MAX_CONCLUSIONS = 8;
const MAX_SOURCES = 8;
const MAX_TEXT = 600;
const MAX_UNUSED = 8;
const CONFIDENCES = ['measured', 'inferred'] as const;
const NOTE_KINDS = ['used', 'dead_end', 'missed'] as const;
const FILE_PATTERN = /\/|\.(ts|tsx|go|py|sql|md|yaml|yml|json)$/i;

export type SourceKind = 'brain' | 'data' | 'code';

/** One source of a conclusion, checked against the session's Brain walk. */
export interface AnswerSource {
  readonly ref: string;
  readonly kind: SourceKind;
  readonly label: string;
  /** For a Brain source: false when the id never appeared in this session's walk. */
  readonly seen?: boolean;
}

/** The state the answer card renders. */
export interface AnswerCardState {
  readonly question: string;
  readonly headline: string;
  readonly conclusions: readonly {
    readonly claim: string;
    readonly evidence?: string;
    readonly confidence: (typeof CONFIDENCES)[number];
    readonly sources: readonly AnswerSource[];
  }[];
  readonly brainNotes: readonly { readonly kind: (typeof NOTE_KINDS)[number]; readonly text: string }[];
  readonly openQuestions: readonly string[];
  readonly unused: readonly { readonly id: string; readonly kind: string; readonly name: string; readonly times: number }[];
  readonly steps: readonly TraceStep[];
  readonly stats: { readonly searches: number; readonly opened: number; readonly distinctHits: number; readonly failed: number };
}

/** auto: close every Brain answer with the card. onRequest: only when the user asks. off: no card and no recording. */
export type AnswerCardMode = 'auto' | 'onRequest' | 'off';
export const ANSWER_CARD_MODES: readonly AnswerCardMode[] = ['auto', 'onRequest', 'off'];
export const DEFAULT_ANSWER_CARD_MODE: AnswerCardMode = 'onRequest';

/** Reads the answerCard setting; an unknown value is a TypeError naming the allowed values. */
export function parseAnswerCardMode(value: unknown): AnswerCardMode {
  if (value === undefined || value === null) return DEFAULT_ANSWER_CARD_MODE;
  if (ANSWER_CARD_MODES.includes(value as AnswerCardMode)) return value as AnswerCardMode;
  throw new TypeError(`answerCard must be one of ${ANSWER_CARD_MODES.join(', ')}.`);
}

const WHEN: Record<Exclude<AnswerCardMode, 'off'>, string> = {
  auto: 'Call once, as the last step of every answer that used the Brain.',
  onRequest: 'Call when the user asks to see the Brain card, the Brain walk or a dashboard of an answer that used the Brain. Do not call it otherwise.',
};

export function answerDescriptor(mode: Exclude<AnswerCardMode, 'off'> = 'auto'): CapabilityDescriptor {
  const text = { type: 'string', minLength: 1, maxLength: MAX_TEXT };
  return {
    protocolVersion: VERSION,
    name: ANSWER_TOOL,
    version: VERSION,
    title: 'Show the Brain answer card',
    description: `${WHEN[mode]} It opens the answer card in the chat: your headline and numbered conclusions first, then a replay of every Brain call this session made (searches, hits, opened nodes), which the extension recorded for you. Each conclusion lists its sources: Brain hit ids (cloud:...) exactly as returned, BigQuery tables (dataset.table) or repository paths. The card marks a Brain id that never appeared in this session, and lists memories the Brain returned that you neither opened nor cited. After the call, end your reply with a short text summary of the same answer.`,
    tags: ['brain', 'answer', 'card'],
    inputSchema: {
      type: 'object',
      additionalProperties: false,
      required: ['question', 'headline', 'conclusions'],
      properties: {
        question: { ...text, description: "The user's question, verbatim." },
        headline: { ...text, description: 'The answer in one sentence.' },
        conclusions: {
          type: 'array',
          minItems: 1,
          maxItems: MAX_CONCLUSIONS,
          items: {
            type: 'object',
            additionalProperties: false,
            required: ['claim', 'confidence', 'sources'],
            properties: {
              claim: { ...text, description: 'One finding, one sentence.' },
              evidence: { ...text, description: 'The numbers or facts behind the claim.' },
              confidence: { enum: [...CONFIDENCES], description: 'measured: read from data. inferred: your interpretation.' },
              sources: { type: 'array', maxItems: MAX_SOURCES, items: { type: 'string', minLength: 1, maxLength: 300 } },
            },
          },
        },
        brainNotes: {
          type: 'array',
          maxItems: 6,
          description: 'What the Brain contributed: used (a hit that shaped the answer), dead_end (a path that led nowhere), missed (a lead you did not follow).',
          items: {
            type: 'object',
            additionalProperties: false,
            required: ['kind', 'text'],
            properties: { kind: { enum: [...NOTE_KINDS] }, text },
          },
        },
        openQuestions: { type: 'array', maxItems: 5, items: text },
      },
    },
    outputSchema: {
      type: 'object',
      additionalProperties: false,
      required: ['shown', 'conclusions', 'steps', 'unusedMemories', 'unseenBrainSources'],
      properties: {
        shown: { type: 'boolean' },
        instanceId: { type: 'string' },
        conclusions: { type: 'integer' },
        steps: { type: 'integer' },
        unusedMemories: { type: 'integer' },
        unseenBrainSources: { type: 'array', items: { type: 'string' } },
        openError: { type: 'string' },
        next: {
          type: 'object',
          additionalProperties: false,
          required: ['capability', 'input'],
          properties: {
            capability: { type: 'string' },
            input: { type: 'object' },
            instruction: { type: 'string' },
          },
        },
      },
    },
    permissions: [{ permission: `marshal.tool.invoke:${ANSWER_TOOL}`, risk: 'low', reason: 'Show the answer card in the chat' }],
  } as unknown as CapabilityDescriptor;
}

type Json = Record<string, unknown>;
const asObject = (value: unknown): Json => (value && typeof value === 'object' && !Array.isArray(value) ? (value as Json) : {});
const text = (value: unknown): string => (typeof value === 'string' ? value.trim().slice(0, MAX_TEXT) : '');
const list = (value: unknown): unknown[] => (Array.isArray(value) ? value : []);

function invalid(message: string): Error {
  return Object.assign(new Error(message), { code: 'invalid_input' });
}

/** Builds the card state from the agent's answer and the session's recorded Brain calls. Throws invalid_input on a malformed answer. */
export function buildAnswerState(input: unknown, calls: readonly TraceCall[]): AnswerCardState {
  const answer = asObject(input);
  const question = text(answer.question);
  const headline = text(answer.headline);
  if (!question || !headline) throw invalid(`${ANSWER_TOOL} needs question and headline.`);
  const rawConclusions = list(answer.conclusions).slice(0, MAX_CONCLUSIONS);
  if (rawConclusions.length === 0) throw invalid(`${ANSWER_TOOL} needs at least one conclusion.`);

  const names = new Map<string, { kind: string; name: string }>();
  calls.forEach((call) => {
    call.hits?.forEach((hit) => names.set(hit.id, { kind: hit.kind, name: hit.name }));
    if (call.opened) names.set(call.opened.id, { kind: call.opened.kind, name: call.opened.name });
  });
  const source = (ref: string): AnswerSource => {
    if (ref.startsWith('cloud:')) {
      const known = names.get(ref);
      return { ref, kind: 'brain', label: known ? `${known.kind}: ${known.name}` : ref, seen: Boolean(known) };
    }
    return { ref, kind: FILE_PATTERN.test(ref) ? 'code' : 'data', label: ref };
  };
  const conclusions = rawConclusions.map((raw) => {
    const conclusion = asObject(raw);
    const claim = text(conclusion.claim);
    if (!claim) throw invalid('Every conclusion needs a claim.');
    const confidence = CONFIDENCES.includes(conclusion.confidence as never) ? (conclusion.confidence as (typeof CONFIDENCES)[number]) : 'inferred';
    const evidence = text(conclusion.evidence);
    return {
      claim,
      ...(evidence ? { evidence } : {}),
      confidence,
      sources: list(conclusion.sources).map(text).filter(Boolean).slice(0, MAX_SOURCES).map(source),
    };
  });

  const cited = new Set(conclusions.flatMap((conclusion) => conclusion.sources.map((item) => item.ref)));
  const opened = new Set(calls.flatMap((call) => (call.opened ? [call.opened.id] : [])));
  const memoryTimes = new Map<string, { kind: string; name: string; times: number }>();
  calls.forEach((call) => call.hits?.forEach((hit) => {
    if (hit.kind !== 'memory' || cited.has(hit.id) || opened.has(hit.id)) return;
    const seen = memoryTimes.get(hit.id);
    memoryTimes.set(hit.id, { kind: hit.kind, name: hit.name, times: (seen?.times ?? 0) + 1 });
  }));
  const unused = [...memoryTimes.entries()]
    .sort((left, right) => right[1].times - left[1].times)
    .slice(0, MAX_UNUSED)
    .map(([id, value]) => ({ id, ...value }));

  const steps = buildSteps(calls);
  const distinct = new Set(calls.flatMap((call) => call.hits?.map((hit) => hit.id) ?? []));
  return {
    question,
    headline,
    conclusions,
    brainNotes: list(answer.brainNotes)
      .map(asObject)
      .filter((note) => NOTE_KINDS.includes(note.kind as never) && text(note.text))
      .map((note) => ({ kind: note.kind as (typeof NOTE_KINDS)[number], text: text(note.text) })),
    openQuestions: list(answer.openQuestions).map(text).filter(Boolean).slice(0, 5),
    unused,
    steps,
    stats: {
      searches: calls.filter((call) => call.tool === 'knowledge.search').length,
      opened: calls.filter((call) => call.opened).length,
      distinctHits: distinct.size,
      failed: calls.filter((call) => call.error).length,
    },
  };
}

/** Runs one host capability on behalf of the calling session. */
export type HostExecute = (request: Json, context: InvocationContext) => Promise<Json>;

/** The ui.application.open input that places the answer card in the calling chat. */
export function answerCardOpenInput(state: AnswerCardState, idempotencyKey: string): Json {
  return { extensionId: BRAIN_EXTENSION_ID, applicationId: ANSWER_APP_ID, placement: 'card', title: `Brain answer — ${state.question.slice(0, 80)}`, state, idempotencyKey };
}

/** Opens the answer card through the host. On failure it returns the open input, so the agent can place the card itself. */
export async function showAnswerCard(state: AnswerCardState, context: InvocationContext, execute: HostExecute | undefined, idempotencyKey: string): Promise<Json> {
  const open = answerCardOpenInput(state, idempotencyKey);
  const summary = { conclusions: state.conclusions.length, steps: state.steps.length, unusedMemories: state.unused.length, unseenBrainSources: state.conclusions.flatMap((c) => c.sources).filter((s) => s.seen === false).map((s) => s.ref) };
  if (!execute) return { shown: false, ...summary, next: { capability: 'ui.application.open', input: open } };
  const errors: string[] = [];
  for (const targetType of ['capability', 'operation']) {
    try {
      const response = await execute({ protocolVersion: VERSION, targetType, target: 'ui.application.open', input: open, ...(context.approval ? { approval: context.approval } : {}) }, context);
      if (response.status === 'success') {
        const output = asObject(asObject(response.result).output);
        const instance = asObject(output.instance);
        const receipt = asObject(output.receipt);
        return { shown: true, instanceId: instance.instanceId ?? receipt.instanceId, ...summary };
      }
      errors.push(`${targetType}: ${String(response.status)} ${JSON.stringify(asObject(response.error)).slice(0, 200)}`);
    } catch (error) {
      errors.push(`${targetType}: ${String((error as Error)?.message ?? error).slice(0, 200)}`);
    }
  }
  return { shown: false, ...summary, openError: errors.join(' | '), next: { capability: 'ui.application.open', input: open, instruction: 'Invoke ui.application.open with this input now, unchanged.' } };
}
