import type { CapabilityProvider } from '@marshal/agent-runtime-core';
import { createProvider, result } from '@marshal/agent-runtime-provider-kit';
import { LazyCompanyGraph, LocalCompanyGraphSource } from './loader.js';
import { COMPANY_GRAPH_DESCRIPTORS } from './schemas.js';
import { readGraphRecord } from './record.js';

export const COMPANY_GRAPH_PROVIDER_ID = 'marshal.company-graph';

interface GraphInput {
  query: string;
  text: string;
  id: string;
  from: string;
  to: string;
  types?: string[];
  edge_types?: string[];
  direction?: string;
  kinds?: string[];
  limit?: number;
  per_group?: number;
  max_hops?: number;
  k?: number;
  stop_at_types?: string[];
  min_prior?: number;
}

export interface CompanyGraphProvider extends CapabilityProvider {
  dispose(): void;
}

export function createCompanyGraphProvider(configuration: Record<string, unknown> = {}, loader?: LazyCompanyGraph): CompanyGraphProvider {
  const configuredDirectory = configuration.companyGraphDir;
  if (configuredDirectory !== undefined && (typeof configuredDirectory !== 'string' || !configuredDirectory.trim())) {
    throw new TypeError('companyGraphDir must be a nonempty local directory path.');
  }
  const graphLoader = loader ?? new LazyCompanyGraph(new LocalCompanyGraphSource(configuredDirectory as string | undefined), configuration.companyGraphFreezeSha);
  const provider = createProvider(COMPANY_GRAPH_PROVIDER_ID, COMPANY_GRAPH_DESCRIPTORS, async (name, rawInput, context) => {
    const input = rawInput as GraphInput;
    const graph = await graphLoader.get();
    let output: unknown;
    switch (name) {
      case 'graph.search':
        output = {
          backend: 'snapshot', ranker: 'lexical', mode: 'lexical', vector_status: 'disabled_by_lexical_mode',
          cloud: { status: 'disabled_by_snapshot_mode' }, results: graph.search(input.query, input),
        };
        break;
      case 'graph.find': output = { results: graph.find(input.text, input) }; break;
      case 'graph.record': output = readGraphRecord(graph, input.id); break;
      case 'graph.neighbors':
        output = graph.neighbors(input.id, { edgeTypes: input.edge_types, direction: input.direction, kinds: input.kinds, limit: input.limit, perGroup: input.per_group });
        break;
      case 'graph.path':
        output = graph.path(input.from, input.to, { maxHops: input.max_hops, k: input.k, edgeTypes: input.edge_types });
        break;
      case 'graph.impact':
        output = graph.impact(input.id, { maxHops: input.max_hops, stopAtTypes: input.stop_at_types, kinds: input.kinds, limit: input.limit, minPrior: input.min_prior });
        break;
      case 'graph.stats': output = graph.stats(); break;
      default: throw new Error(`Unsupported company graph capability: ${name}`);
    }
    return result(output, COMPANY_GRAPH_PROVIDER_ID, name, rawInput, context);
  });
  return Object.assign(provider, { dispose: () => graphLoader.dispose() });
}
