import type { InvocationContext } from '@marshal/agent-runtime-core';
import type { PortableMemoryRuntime } from '@marshal/agent-runtime-provider-memory';

interface LifecycleSessionWithContext {
  readonly context: InvocationContext;
}

interface AdapterVerifiedLifecycleRequest {
  readonly sessionId: string;
  readonly parentSessionId?: string;
}

export function inheritVerifiedParentScopes(
  sessions: ReadonlyMap<string, LifecycleSessionWithContext>,
  request: AdapterVerifiedLifecycleRequest,
  childContext: InvocationContext,
  durableMemory: PortableMemoryRuntime,
): void {
  if (!request.parentSessionId) return;
  const parentSessionId = validateSessionId(request.parentSessionId);
  const matches = [...sessions.values()].filter((candidate) =>
    candidate.context.scope?.sessionId === parentSessionId
    && candidate.context.principal.id === childContext.principal.id
    && candidate.context.principal.kind === childContext.principal.kind
    && candidate.context.scope?.workspaceId === childContext.scope?.workspaceId
    && candidate.context.scope?.projectId === childContext.scope?.projectId);
  if (matches.length === 1) {
    durableMemory.scopes.inheritToChild(matches[0]!.context, childContext, {
      parentSessionId,
      childSessionId: validateSessionId(request.sessionId),
    });
    return;
  }
  if (matches.length > 1) {
    throw Object.assign(new Error('Adapter-verified parent session is not active in this lifecycle.'), {
      code: 'memory_parent_lineage_unavailable',
    });
  }
  durableMemory.scopes.inheritVerifiedParentSession(
    parentSessionId,
    childContext,
    validateSessionId(request.sessionId),
  );
}

function validateSessionId(sessionId: string): string {
  if (typeof sessionId !== 'string' || sessionId.length === 0 || sessionId.length > 1_024) {
    throw new Error('sessionId must be a non-empty string of at most 1024 characters.');
  }
  return sessionId;
}
