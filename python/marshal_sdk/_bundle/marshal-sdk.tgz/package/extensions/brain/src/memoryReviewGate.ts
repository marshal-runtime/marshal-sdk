/**
 * Memory review (sealed transcript review, semantic healing reviews, the Jev
 * memory reasoner) spends model calls. It stays off unless a dedicated key is
 * configured through its own environment variable, never the Jev extension's
 * personal key.
 */
export const MEMORY_REVIEW_KEY_ENV = 'MARSHAL_BRAIN_REVIEW_JEV_KEY';

export interface MemoryReviewGate {
  readonly enabled: boolean;
  readonly reason: 'no-dedicated-key' | 'dedicated-client-not-built';
}

export const MEMORY_REVIEW_OFF: MemoryReviewGate = Object.freeze({ enabled: false, reason: 'no-dedicated-key' });

/** The Jev client is resolved only while review is enabled; otherwise it is never touched. */
export function gatedJevResolver<T>(gate: MemoryReviewGate, resolve: () => T | undefined): () => T | undefined {
  return () => (gate.enabled ? resolve() : undefined);
}

/**
 * This build has no client that uses a dedicated key, so review stays off even when
 * the variable is set (reported as `dedicated-client-not-built`); routing a set key
 * to the Jev extension would spend the personal key instead.
 */
export function resolveMemoryReviewGate(
  env: Readonly<Record<string, string | undefined>> = process.env,
): MemoryReviewGate {
  return env[MEMORY_REVIEW_KEY_ENV]?.trim()
    ? Object.freeze({ enabled: false, reason: 'dedicated-client-not-built' })
    : MEMORY_REVIEW_OFF;
}
