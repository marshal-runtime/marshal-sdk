import * as path from 'node:path';
import type { CapabilityProvider } from '@marshal/agent-runtime-core';
import type { KnowledgeIndex, PortableMemoryRuntime } from '@marshal/agent-runtime-provider-memory';
import { withForgetCompletely } from './forgetCompletely.js';
import { createHealExtras, type HealExtras } from './healExtras.js';
import { createLinkedMemoryProvider } from './linkedMemory.js';
import { createLazyUserMemory, type LazyUserMemory, type MarshalUserMemoryHost } from './marshalMemoryStore.js';
import { withProfileRefresh } from './profileRefresh.js';
import { withSessionNoteOwners } from './sessionNoteOwners.js';

/** The user's memory over Brain's memory database: its ledgers sit beside memory.sqlite, profile.md under the profile projections. */
export function brainUserMemory(
  durable: PortableMemoryRuntime,
  host: MarshalUserMemoryHost,
  roots: { readonly memoryDbPath: string; readonly profileProjectionRoot: string },
): LazyUserMemory {
  return createLazyUserMemory(durable, host, path.dirname(roots.memoryDbPath), roots.profileProjectionRoot);
}

/** After each session start's heal: the code-change review and profile.md, for the bundle's own workspace (healExtras.ts). */
export function brainHealExtras(
  durable: () => PortableMemoryRuntime,
  userMemory: () => LazyUserMemory,
  host: { readonly workspacePath?: string },
): HealExtras {
  return createHealExtras(durable, userMemory, { workspacePath: host.workspacePath });
}

export interface BrainMemoryProviderOptions {
  readonly durable: () => PortableMemoryRuntime;
  readonly userMemory: LazyUserMemory;
  /** Brain's approval routing for operations that need a workspace code index (brainProviders.ts). */
  readonly approve: (provider: CapabilityProvider) => CapabilityProvider;
}

/**
 * The memory.* capabilities Brain serves: the runtime's provider, recording which session owns a
 * legacy session note, behind Brain's approval routing, refusing memory.purge completely:true (the
 * host forget tool does that, forgetCompletely.ts) and refreshing profile.md after each removal.
 */
export function brainMemoryProvider(runtimeProvider: CapabilityProvider, options: BrainMemoryProviderOptions): CapabilityProvider {
  const owned = withSessionNoteOwners(runtimeProvider, options.durable);
  const forgetting = withForgetCompletely(options.approve(owned));
  return withProfileRefresh(forgetting, () => options.userMemory);
}

/**
 * memory.link: a new note records who stated it, the same note again is activity that clears a
 * needs-review flag, and a replaced keyed note leaves profile.md at once.
 */
export function brainLinkedMemoryProvider(
  durable: () => PortableMemoryRuntime,
  index: () => KnowledgeIndex,
  userMemory: LazyUserMemory,
): CapabilityProvider {
  const linked = createLinkedMemoryProvider(durable, index, (id, reused, context) => (
    reused ? userMemory.reviews.recordActivity(id) : userMemory.provenance.record(id, context)
  ));
  return withProfileRefresh(linked, () => userMemory);
}
