import type { CapabilityDescriptor, JsonSchema } from '@marshal/agent-runtime-core';
import { PROTOCOL_VERSION } from '@marshal/agent-runtime-provider-kit';

const text: JsonSchema = { type: 'string' };
const reference: JsonSchema = { type: 'string', minLength: 1, maxLength: 20000 };
const count: JsonSchema = { type: 'integer', minimum: 0 };
const number: JsonSchema = { type: 'number' };
const strings: JsonSchema = { type: 'array', items: reference };
const counts: JsonSchema = { type: 'object', additionalProperties: count };
const recordProperties = {
  source: text, id: text, kind: text, label: text,
  edgeCounts: object({ in: counts, out: counts }),
};
const direction: JsonSchema = { enum: ['out', 'in'] };
const provenance = object({ from: text, to: text, type: text, source_ref: text, derivation: text });
const nodeProperties = { id: text, kind: text, name: text, source_ref: text, node_source_ref: text };
const node = object(nodeProperties);
const findHit = object({ ...nodeProperties, score: number, how: { enum: ['id', 'alias', 'tokens', 'partial'] } });
const edgeProperties = { edge: text, direction, source_ref: text, provenance };
const error = object({ error: text, candidates: array(findHit), which: { enum: ['from', 'to'] } }, ['error']);
const neighborHit = object({ ...nodeProperties, ...edgeProperties, confidence: number });
const lineage = object({ ...nodeProperties, ...edgeProperties, prior: number });
const searchHit = object({
  ...nodeProperties, summary: text, score: number, kind_prior: number,
  backend: { const: 'snapshot' }, ranker: { const: 'lexical' },
  matched_columns: array(object({ id: text, name: text, source_ref: text, node_source_ref: text, lexical_score: number })),
  alternatives: array(object({ id: text, name: text, score: number, source_ref: text, node_source_ref: text })),
  lineage: array(lineage), lineage_total: count,
}, ['id', 'kind', 'name', 'source_ref', 'node_source_ref', 'summary', 'score', 'kind_prior', 'backend', 'ranker', 'matched_columns', 'lineage', 'lineage_total']);
const limit = (defaultValue: number): JsonSchema => ({ type: 'integer', minimum: 1, default: defaultValue });
const hops = (defaultValue: number): JsonSchema => ({ type: 'integer', minimum: 0, default: defaultValue });

export const COMPANY_GRAPH_DESCRIPTORS: readonly CapabilityDescriptor[] = [
  descriptor('search', 'Lexical search over frozen company graph node cards, with kind priors, column-to-table rollup, vendor alternatives and lineage previews. Snapshot only; no cloud, embeddings or model calls.',
    object({ query: reference, types: strings, limit: { type: 'integer', minimum: 1, maximum: 100, default: 10 } }, ['query']),
    object({ backend: { const: 'snapshot' }, ranker: { const: 'lexical' }, mode: { const: 'lexical' }, vector_status: { const: 'disabled_by_lexical_mode' }, cloud: object({ status: { const: 'disabled_by_snapshot_mode' } }), results: array(searchHit) })),
  descriptor('find', 'Resolve a name, alias, ID or natural phrase to frozen company graph nodes, including source references and match quality.',
    object({ text: reference, types: strings, limit: limit(10) }, ['text']), object({ results: array(findHit) })),
  descriptor('record', 'Read the full stored frozen node by exact ID: all properties, review dispositions/feedback, rationale, timestamps and provenance, plus incoming/outgoing edge counts by type. No external fetch. Output is capped at 65536 UTF-8 JSON bytes: truncated=true and node=null if the record is omitted; a truncated error if metadata alone exceeds the cap.',
    object({ id: reference }, ['id']), outputUnion(
      object({ ...recordProperties, node: { type: 'object', additionalProperties: {} }, truncated: { const: false } }),
      object({ ...recordProperties, node: { type: 'null' }, truncated: { const: true } }),
      object({ error: text, truncated: { type: 'boolean' } }),
    )),
  descriptor('neighbors', 'Edges around a frozen graph node, grouped by edge type, direction and other-node kind. Includes edge and node provenance; filters support drilling into omitted groups.',
    object({ id: reference, edge_types: strings, direction: { enum: ['out', 'in', 'both'], default: 'both' }, kinds: strings, limit: limit(25), per_group: { ...limit(5), description: 'Cap per (edge type, direction, other kind); defaults to limit when edge_types or kinds filters are supplied.' } }, ['id']),
    outputUnion(object({ node, note: text, total: count, results: array(neighborHit), omitted: count, omittedByType: counts }, ['node', 'total', 'results', 'omitted', 'omittedByType']), error)),
  descriptor('path', 'Evidence-weighted paths between two frozen graph nodes, walking either direction. A path is evidence to inspect, not a claim of causal impact.',
    object({ from: reference, to: reference, max_hops: hops(6), k: { type: 'integer', minimum: 1, default: 3 }, edge_types: strings }, ['from', 'to']),
    outputUnion(object({ from: node, to: node, notes: strings, paths: array(object({ hops: count, confidence: number, nodes: array(node), steps: array(object({ ...edgeProperties, confidence: number })) })) }), error)),
  descriptor('impact', 'Downstream-only blast radius in the frozen company graph. Direct seed producers and their evidenced SQL/RUNS executors are excluded from output, not expansion. Cyclic overlaps are flagged; the default 0.1 prior floor is an uncalibrated heuristic.',
    object({ id: reference, max_hops: hops(4), stop_at_types: strings, kinds: strings, limit: limit(50), min_prior: { type: 'number', minimum: 0, maximum: 1, default: 0.1 } }, ['id']),
    outputUnion(object({
      node, note: text, direction: { const: 'downstream-only' }, total: count, minPrior: number,
      omittedBelowPrior: count, excludedBuilders: strings, excluded_inputs: strings, upstreamPolicy: text,
      cycleCount: count, returnedCycleCount: count, byKind: counts,
      results: array(object({ ...nodeProperties, hops: count, confidence: number, prior: number, cycle: { type: 'boolean' }, chain: array(object({ from: text, to: text, ...edgeProperties, prior: number })), via: text, provenance })),
      omitted: count, unknownEdgeTypesIgnored: counts,
    }, ['node', 'direction', 'total', 'minPrior', 'omittedBelowPrior', 'excludedBuilders', 'excluded_inputs', 'upstreamPolicy', 'cycleCount', 'returnedCycleCount', 'byKind', 'results', 'omitted']), error)),
  descriptor('stats', 'Counts of nodes, edges, node kinds and edge types in the hash-verified frozen company graph.',
    object({}), object({ source: text, nodes: count, edges: count, dangling: count, kinds: counts, edgeTypes: counts })),
];

function object(properties: Record<string, JsonSchema>, required = Object.keys(properties)): JsonSchema {
  return { type: 'object', properties, required, additionalProperties: false };
}

function array(items: JsonSchema): JsonSchema {
  return { type: 'array', items };
}

function outputUnion(...variants: JsonSchema[]): JsonSchema {
  const properties = Object.assign({}, ...variants.map((variant) => variant.properties));
  return { ...object(properties, []), anyOf: variants };
}

function descriptor(operation: string, description: string, inputSchema: JsonSchema, outputSchema: JsonSchema): CapabilityDescriptor {
  const name = `graph.${operation}`;
  return {
    protocolVersion: PROTOCOL_VERSION, name, version: '1.0.0', description,
    tags: ['graph', 'company', 'snapshot', operation],
    permissions: [{ permission: `marshal.tool.invoke:${name}`, risk: 'low' }],
    inputSchema, outputSchema,
  };
}
