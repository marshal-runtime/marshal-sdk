import { isStopword, recallTokens } from './recallRelevance.js';

export type WindowCategory = 'preference' | 'fact' | 'decision' | 'context';

/** Words that name a kind of memory; asking for "decisions" lists the decision memories. */
const CATEGORY_WORDS = new Map<string, WindowCategory>([
  ['decision', 'decision'], ['decisions', 'decision'], ['decide', 'decision'], ['decided', 'decision'],
  ['preference', 'preference'], ['preferences', 'preference'], ['prefer', 'preference'], ['prefers', 'preference'],
  ['preferred', 'preference'], ['fact', 'fact'], ['facts', 'fact'], ['context', 'context'],
]);

/** Words that place a question in time; the window itself arrives as since/until. */
const TIME_WORDS = new Set((
  'today yesterday tomorrow tonight day days week weeks weekend month months year years quarter hour hours '
  + 'last past previous recent recently lately ago earlier latest newest next since morning afternoon evening '
  + 'night monday tuesday wednesday thursday friday saturday sunday january february march april may june july '
  + 'august september october november december jan feb mar apr jun jul aug sep sept oct nov dec '
  + 'utc gmt z am pm'
).split(' '));

/** Words of asking about memory itself, not about a topic. */
const ASKING_WORDS = new Set((
  'remember remembered recall know knew tell told say said note noted notes store stored save saved make made '
  + 'happen happened discuss discussed talk talked mention mentioned learn learned agree agreed get got '
  + 'anything everything something list show give memory memories thing things us let lets please '
  // How a memory came to be (wave-2 R11 on B: "added", "recorded", "ask you to remember").
  + 'ask asked add added adding record recorded write wrote written create created capture captured '
  + 'log logged keep kept'
).split(' '));

/** A date or time fragment the tokenizer leaves: "2026", "09", "24th", "12". */
const DATE_FRAGMENT = /^\d+(?:st|nd|rd|th)?$/u;


export interface WindowIntent {
  readonly category?: WindowCategory;
}

/**
 * Whether a recall question is about a time window and/or a category of memory
 * rather than a topic ("what did we decide last week?", "my preferences"), so the
 * relevance ranking alone would drop every memory: the words it has left match no
 * memory text. Undefined when neither a window nor a category is given, or the
 * question names any topic ("what did we decide about pnpm"): then relevance ranking
 * answers it alone, and the listing would only pad it with unrelated memories.
 */
export function windowIntent(query: string, hasWindow: boolean): WindowIntent | undefined {
  const tokens = recallTokens(query);
  const category = tokens.map((token) => CATEGORY_WORDS.get(token)).find(Boolean);
  if (!hasWindow && !category) return undefined;
  const topic = new Set(tokens.filter((token) => !isStopword(token) && !TIME_WORDS.has(token)
    && !ASKING_WORDS.has(token) && !CATEGORY_WORDS.has(token) && !DATE_FRAGMENT.test(token)));
  if (topic.size > 0) return undefined;
  return category ? { category } : {};
}
