import { notifyPurged, type LifecycleResultsPurgeSummary, type PurgeListener } from './hostForget.js';

export interface PurgeFollowUpTargets {
  /** Deletes the cached lifecycle results (memoryLifecycle.ts). */
  purgeLifecycleResults(): Promise<LifecycleResultsPurgeSummary>;
}

export interface PurgeFollowUp {
  /** Registered on the user store: purges the cached lifecycle results. */
  readonly listener: PurgeListener;
  settled(): Promise<void>;
  stop(): Promise<void>;
}

/** After a complete forget committed: the cached lifecycle results are deleted before the tool returns. */
export function bundlePurges(targets: PurgeFollowUpTargets): PurgeFollowUp {
  return {
    async listener() {
      return targets.purgeLifecycleResults();
    },
    async settled() {},
    async stop() {},
  };
}

/** Every in-process bundle's follow-up as one (the installed Brain, one bundle per workspace). */
export function combinedPurges(followUps: () => Promise<readonly PurgeFollowUp[]>): PurgeFollowUp {
  return {
    async listener(purgedIds) {
      return notifyPurged((await followUps()).map(({ listener }) => listener), purgedIds);
    },
    async settled() {
      await Promise.all((await followUps()).map((followUp) => followUp.settled()));
    },
    async stop() {
      await Promise.all((await followUps()).map((followUp) => followUp.stop()));
    },
  };
}
