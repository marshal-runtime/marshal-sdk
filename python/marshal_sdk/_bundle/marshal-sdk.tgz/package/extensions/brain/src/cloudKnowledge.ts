import type {
  CapabilityDescriptor,
  CapabilityInvocationResult,
  CapabilityProvider,
  InvocationContext,
  JsonSchema,
} from '@marshal/agent-runtime-core';
import { PROTOCOL_VERSION, assertRecord, result } from '@marshal/agent-runtime-provider-kit';
import { parseCloudRouteConfiguration, type CloudRouteConfiguration } from './cloudBrain/config.js';
import { CloudBrainError, isCloudBrainError, redactCredentials } from './cloudBrain/errors.js';
import { MAX_SHARE_PARTS, shareSession, type SessionShareInput } from './sessionShare.js';
import { createCloudBrainRoute, withCloudDeadline, type CloudBrainRoute, type CloudBrainRouteDeps } from './cloudBrain/route.js';

/** The provider that owns knowledge.search/context/impact; the cloud route wraps it. */
export const KNOWLEDGE_PROVIDER_ID = 'marshal.selected-intelligence';
/** Prefix of every node id that belongs to the cloud Brain; knowledge.context/impact/connect route such ids to it. */
export const CLOUD_ID_PREFIX = 'cloud:';

/** How Brain's knowledge capabilities reach the cloud Brain, decided once per activation from the configuration. */
export type CloudKnowledgeSetting =
  | { readonly state: 'off' }
  | { readonly state: 'misconfigured'; readonly message: string }
  | {
    readonly state: 'on';
    readonly route: CloudBrainRoute;
    readonly configuration: CloudRouteConfiguration;
  };

/**
 * The cloud setting of one activation. A bad cloud value never stops Brain: the local index keeps answering and every
 * search says the cloud is misconfigured and why.
 */
export function cloudKnowledgeSetting(rawConfiguration: unknown, deps: CloudBrainRouteDeps = {}): CloudKnowledgeSetting {
  let configuration: CloudRouteConfiguration;
  try {
    configuration = parseCloudRouteConfiguration(rawConfiguration);
  } catch (error) {
    const enabled = Boolean(rawConfiguration && typeof rawConfiguration === 'object'
      && (rawConfiguration as Record<string, unknown>).cloudEnabled === true);
    if (!enabled) return { state: 'off' };
    return { state: 'misconfigured', message: `The cloud route is on but its configuration cannot be used: ${String((error as Error)?.message ?? error)}` };
  }
  if (!configuration.enabled) return { state: 'off' };
  return { state: 'on', route: createCloudBrainRoute(configuration, deps), configuration };
}

type CloudStatus =
  | 'ok' | 'partial' | 'skipped' | 'timeout' | 'starting' | 'unavailable' | 'busy'
  | 'auth_failed' | 'rejected' | 'cancelled' | 'failed' | 'misconfigured';

interface CloudReport {
  status: CloudStatus;
  hits?: number;
  elapsedMs?: number;
  caller?: string;
  message?: string;
  retryAfterSeconds?: number;
  /** knowledge.search only: the id of this search in the cloud Brain's search log, for knowledge.feedback and knowledge.refine. */
  searchId?: string;
  /** knowledge.search only: what to do with the candidate hits. */
  drill?: string;
  /** knowledge.search only: what the cloud's top candidates are made of; knowledge.refine narrows them. */
  facets?: Record<string, unknown>;
  /** knowledge.search only: the query words and the ones no listed hit shows, with the share of words some hit shows. A signal to read, not a relevance score and not a "nothing found" verdict: the cloud's own `drill` line says how to read it. */
  match?: Record<string, unknown>;
  /** knowledge.search only: how the local and cloud hits were ordered, when a merge flag chose it. */
  merge?: MergeReport;
  /** knowledge.search only: cloud hits that name the same code as a local hit; the local hit carries them as cloudDuplicate. */
  duplicates?: number;
}

const CLOUD_REPORT_PROPERTIES: Readonly<Record<string, JsonSchema>> = {
  status: { enum: ['ok', 'partial', 'skipped', 'timeout', 'starting', 'unavailable', 'busy', 'auth_failed', 'rejected', 'cancelled', 'failed', 'misconfigured'] },
  hits: { type: 'integer', minimum: 0 },
  elapsedMs: { type: 'integer', minimum: 0 },
  caller: { type: 'string', maxLength: 320 },
  message: { type: 'string', maxLength: 2_000 },
  retryAfterSeconds: { type: 'integer', minimum: 0 },
  searchId: { type: 'string', maxLength: 64, description: "The id of this search in the cloud Brain's search log. Pass it to knowledge.feedback to say how the search served you, and to knowledge.refine to narrow its candidates." },
  drill: { type: 'string', maxLength: 600, description: "What to do with the candidate hits: open the fitting ones, send feedback when none fits." },
  match: { type: 'object', description: "The query words (terms), the ones no listed hit shows (unmatchedTerms) and the share some hit shows (coverage). Not a relevance score and not a nothing-found verdict: no coverage level separated questions the Brain cannot answer from answerable ones; a distinctive word in unmatchedTerms is the useful part. The cloud's drill line says the same." },
  facets: { type: 'object', description: "What the cloud's top candidates are made of: pool size, counts by kind and origin, the top paths and files, and the refine line. knowledge.refine narrows them without a new search." },
};

const CLOUD_REPORT_SCHEMA: JsonSchema = {
  type: 'object',
  description: 'What the cloud Brain contributed: ok, partial, skipped, or why it did not (timeout, starting, unavailable, busy, auth_failed, rejected, cancelled, failed, misconfigured). Anything but ok means cloud hits may be missing, not that none exist.',
  required: ['status'],
  properties: {
    ...CLOUD_REPORT_PROPERTIES,
    duplicates: { type: 'integer', minimum: 0, description: 'Cloud hits that name the same code as a local hit. The local hit carries each as cloudDuplicate; when no cloud hit would otherwise show, the best one is listed as its own cloud hit.' },
    merge: {
      type: 'object',
      description: 'How the local and cloud hits were ordered: union-judge (one judge over both), relevance (normalized scores) or alternation; fallback names why a requested judge or score merge was not used.',
      required: ['mode'],
      properties: { mode: { enum: ['union-judge', 'relevance', 'alternation'] }, fallback: { type: 'string', maxLength: 128 } },
      additionalProperties: false,
    },
  },
  additionalProperties: false,
};

const CLOUD_NODE_SCHEMA: JsonSchema = {
  type: 'object',
  required: ['id', 'kind', 'name'],
  properties: {
    id: { type: 'string', minLength: 1, maxLength: 4_200 },
    kind: { type: 'string', maxLength: 64 },
    name: { type: 'string', maxLength: 4_096 },
    path: { type: 'string', maxLength: 4_096 },
    symbol: { type: 'string', maxLength: 1_024 },
    entityKind: { type: 'string', maxLength: 64 },
    url: { type: 'string', maxLength: 4_096 },
    repo: { type: 'string', maxLength: 512, description: 'Code hits: the repository the code is in, when the cloud says.' },
    revision: { type: 'string', maxLength: 128, description: 'Code hits: the revision the cloud indexed, when it says.' },
    snippet: { type: 'string', maxLength: 2_000, description: 'Memories: the memory text, as the cloud returns it.' },
    props: { type: 'object', description: 'Small typed fields of the kind the cloud returns (state, author, createdAt, ...).' },
  },
};

const CLOUD_HIT_SCHEMA: JsonSchema = {
  type: 'object',
  description: 'A hit from the cloud Brain (PRs, tickets, meetings, people, company memories, code of the main branch). Its node id starts with cloud: and works with knowledge.context, knowledge.impact and knowledge.path.',
  required: ['source', 'node', 'rank'],
  properties: {
    source: { const: 'cloud' },
    node: CLOUD_NODE_SCHEMA,
    rank: { type: 'number' },
    cloudRank: { type: 'number' },
    score: { type: 'number' },
    location: { type: 'string', maxLength: 4_096 },
    line: { type: 'integer', minimum: 1, description: 'First line of the matched part of the file.' },
    endLine: { type: 'integer', minimum: 1, description: 'Last line of the matched part of the file.' },
    snippet: { type: 'string', maxLength: 1_000, description: 'One to three lines of the matched part.' },
    summary: { type: 'string', maxLength: 600, description: 'The declaration or outline entry that matched.' },
    why: { type: 'string', maxLength: 400, description: "Why it matched: the lanes that found it (terms with the query words matched, semantic, judge) and the score." },
    links: { type: 'array', maxItems: 5, items: { type: 'string', maxLength: 200 }, description: "What the hit is connected to." },
    next: { enum: ['context', 'get', 'traverse'], description: "How to open it: knowledge.context on its node id." },
    top: { type: 'array', maxItems: 5, items: { type: 'object', properties: { id: { type: 'string', maxLength: 4_200 }, name: { type: 'string', maxLength: 200 } }, additionalProperties: false }, description: "Code files: the best matching nodes in the file." },
    memories: { type: 'array', maxItems: 5, items: { type: 'object', required: ['id'], properties: { id: { type: 'string', maxLength: 4_200 }, key: { type: 'string', maxLength: 300 }, aliases: { type: 'array', maxItems: 10, items: { type: 'string', maxLength: 300 } }, snippet: { type: 'string', maxLength: 400 } }, additionalProperties: false }, description: 'Code files: the generated memories of the file that matched the same search, folded into the file. Open one with knowledge.context on its id.' },
    generatedFrom: { type: 'object', required: ['path'], properties: { path: { type: 'string', maxLength: 4_096 } }, additionalProperties: false, description: 'Generated memories: the repository file the memory was made from, when the search did not list that file. Open it with knowledge.context.' },
  },
  additionalProperties: false,
};

const SOURCE_SCHEMA: JsonSchema = { enum: ['local', 'cloud'] };
const ROUTED_RESULT_PROPERTIES: Readonly<Record<string, JsonSchema>> = {
  source: SOURCE_SCHEMA,
  cloud: CLOUD_REPORT_SCHEMA,
  result: { description: 'The cloud Brain\'s answer, verbatim except that node ids carry the cloud: prefix.' },
  resultText: { type: 'string', description: 'The start of a cloud answer too large to return whole.' },
};

const FILTER_OPS = ['eq', 'in', 'prefix', 'contains', 'range', 'exists', 'not_exists', 'matches', 'any'] as const;

/** The cloud Brain's `filters` argument (search, traverse, impact), as its own schema states it. */
function filtersSchema(description: string): JsonSchema {
  return {
    type: 'array',
    maxItems: 24,
    description,
    items: {
      type: 'object',
      properties: {
        field: { type: 'string', minLength: 1, maxLength: 128, description: 'A field of knowledge.schema (kind, path, state_type, completedAt, ...), `edge:<kind>[:in|out|both]` for a relation, or `$or`.' },
        op: { enum: FILTER_OPS },
        value: { description: 'eq: one value. in: a list. prefix/contains: text. range: {gt?, gte?, lt?, lte?} (ISO dates or numbers). matches: a list of filters on the neighbours. $or/any: a list of filters.' },
      },
      required: ['field', 'op'],
    },
  };
}

/** knowledge.search arguments that go to the cloud's search tool as given; with any of them the cloud's answer is returned whole, in `result`. */
const SEARCH_PASS_THROUGH = ['filters', 'cursor', 'sort', 'aggregate', 'granularity', 'group', 'within'] as const;

const ENTITY_TYPES = ['person', 'pull_request', 'ticket', 'meeting', 'meeting_item', 'branch', 'memory'] as const;
const CLOUD_ID = { type: 'string', minLength: 1, maxLength: 4_200 } as const;

/**
 * The permission every cloud-only capability declares. Marshal's host accepts knowledge.read only for
 * knowledge.search, knowledge.context and knowledge.status; any other capability needs a permission its own extension
 * declares (as knowledge.impact does), which the host keeps in a policy bucket named after the extension.
 */
export const CLOUD_READ_PERMISSION = 'knowledge.cloud.read';
/** The permission of the cloud memory writes: they change memories only the caller sees (audience pinned to the caller). */
export const CLOUD_WRITE_PERMISSION = 'knowledge.cloud.write';
/** The audience every cloud memory write from a Marshal agent carries: the caller alone. */
export const CLOUD_WRITE_AUDIENCE = 'me';
const CLOUD_WRITE_SOURCE = 'marshal agent';
const MEMORY_KEY = { type: 'string', minLength: 1, maxLength: 200 } as const;
const MEMORY_LINKS = {
  type: 'array',
  minItems: 1,
  maxItems: 50,
  items: {
    type: 'object',
    properties: { path: { type: 'string', minLength: 1, maxLength: 1_024 }, symbol: { type: 'string', minLength: 1, maxLength: 512 } },
    required: ['path'],
    additionalProperties: false,
  },
} as const;
const SHORT_TEXT = { type: 'string', minLength: 1, maxLength: 200 } as const;
const SHARED_SESSION = {
  type: 'object',
  properties: {
    id: SHORT_TEXT,
    source: { enum: ['marshal'] },
    title: { type: 'string', maxLength: 500 },
    workspace: SHORT_TEXT,
    createdAt: SHORT_TEXT,
    updatedAt: SHORT_TEXT,
    messages: {
      type: 'array',
      maxItems: 5_000,
      items: {
        type: 'object',
        properties: {
          role: { enum: ['user', 'assistant'] },
          text: { type: 'string', maxLength: 16_000 },
          at: SHORT_TEXT,
          tools: {
            type: 'array',
            maxItems: 200,
            items: {
              type: 'object',
              properties: { name: SHORT_TEXT, input: { type: 'string', maxLength: 2_048 } },
              required: ['name'],
              additionalProperties: false,
            },
          },
        },
        required: ['role', 'text'],
        additionalProperties: false,
      },
    },
  },
  required: ['id', 'source', 'title', 'createdAt', 'messages'],
  additionalProperties: false,
} as const;
/** One of the ordered calls of a session over the Brain's 1 MB request cap; offset is the session index of the part's first message, upload names one share and is the same on every part of it. */
const SHARE_PART = {
  type: 'object',
  properties: {
    index: { type: 'integer', minimum: 0, maximum: 999 },
    count: { type: 'integer', minimum: 1, maximum: 1_000 },
    offset: { type: 'integer', minimum: 0 },
    upload: { type: 'string', minLength: 1, maxLength: 100, pattern: '^[A-Za-z0-9._:-]+$' },
  },
  required: ['index', 'count', 'offset'],
  additionalProperties: false,
} as const;
/** A whole share in one call (one approval): the parts' messages, sent in order with one upload id; session.messages is then empty. */
const SHARE_PARTS = {
  type: 'array',
  minItems: 1,
  maxItems: MAX_SHARE_PARTS,
  items: {
    type: 'object',
    properties: { offset: { type: 'integer', minimum: 0 }, messages: SHARED_SESSION.properties.messages },
    required: ['offset', 'messages'],
    additionalProperties: false,
  },
} as const;
const SHARE_ACCESS = {
  type: 'object',
  properties: {
    audience: { enum: ['team', 'people'] },
    emails: { type: 'array', minItems: 1, maxItems: 50, items: { type: 'string', minLength: 3, maxLength: 320 } },
  },
  required: ['audience'],
  additionalProperties: false,
} as const;
const CODE_KINDS = new Set(['symbol', 'code_file']);

/** When a cloud-first search starts its local fallback: about the cloud proxy's median search latency (2.0 s). */
const LOCAL_HEDGE_MS = 2_000;
/** A ranked search that has no local answer to fall back on waits for the cloud this long, whatever the search budget. */
const CLOUD_SEARCH_HARD_CAP_MS = 45_000;

const RETRYABLE_CLOUD_FAILURES = new Set(['cloud_brain_starting', 'cloud_brain_unavailable', 'cloud_brain_busy', 'cloud_brain_failed', 'cloud_brain_timeout']);

/** A cloud failure that can pass by itself (starting, unavailable, busy, a failed call, a timeout), unlike auth, rejection or cancellation. */
function isRetryableCloudFailure(error: unknown): error is CloudBrainError {
  return isCloudBrainError(error) && RETRYABLE_CLOUD_FAILURES.has(error.code);
}
/** Hits a search answers when the caller names no limit: ten candidates to scan, not one top answer. */
const DEFAULT_SEARCH_HITS = 10;
/** The most the cloud's ranked search returns for one call. */
const MAX_CLOUD_SEARCH_LIMIT = 20;
/** An exhaustive page is at most 500 nodes (the schema's limit maximum); its rows are also mapped into hits. */
const MAX_EXHAUSTIVE_HITS = 500;
const MAX_CLOUD_ONLY_SEARCH_LIMIT = MAX_CLOUD_SEARCH_LIMIT;
/** The most nodes one knowledge.context or knowledge.impact answers; a larger limit is lowered to it. */
const MAX_CLOUD_GRAPH_LIMIT = 100;
const MAX_TRAVERSE_DEPTH = 3;
const MAX_NODE_CHARS = 8_000;

/** The cloud Brain tool whose answer is the cloud status: the schema carries the index generation (indexedSha, indexedAt) and the counts the caller may see. */
const CLOUD_STATUS_TOOL = 'schema';

/** Capabilities only the cloud Brain answers, each one a cloud Brain tool (path, schema, search); listed only while the cloud route is on. */
const CLOUD_ONLY: ReadonlyArray<{ readonly descriptor: CapabilityDescriptor; readonly tool: string }> = [
  {
    tool: 'path',
    descriptor: cloudOnlyDescriptor(
      'knowledge.path',
      'How cloud node A connects to cloud node B: the shortest paths over up to 4 edges, shortest first, as nodes and the edges between them. A and B are cloud: ids from knowledge.search, or refs: a repository path, a PR or Linear URL, a ticket key, #number, an email. An empty answer means no path you may see within maxHops.',
      {
        from: CLOUD_ID,
        to: CLOUD_ID,
        maxHops: { type: 'integer', minimum: 1, maximum: 4 },
        edges: { type: 'array', maxItems: 32, items: { type: 'string', minLength: 1, maxLength: 128 } },
        direction: { enum: ['any', 'follow'] },
        limit: { type: 'integer', minimum: 1, maximum: 10 },
      },
      ['from', 'to'],
    ),
  },
  {
    tool: 'schema',
    descriptor: cloudOnlyDescriptor(
      'knowledge.schema',
      'What the cloud Brain holds and how to ask for it: node kinds with their filterable fields, edge kinds with the direction impact walks them, filter operators, limits and the index generation. Call it before building kinds or edges for knowledge.search, knowledge.context, knowledge.impact or knowledge.path.',
      { kind: { type: 'string', minLength: 1, maxLength: 64 } },
      [],
    ),
  },
  {
    tool: 'refine',
    descriptor: cloudOnlyDescriptor(
      'knowledge.refine',
      "Narrow the candidates of a knowledge.search you already ran, with no new search: filter the cloud's top 200 ranked hits of that search by kind, path, file or origin, and page through them. Use it when one file dominates the hits, when you want only memories or one directory, or to see more than the first page. Take searchId and facets from cloud.searchId and cloud.facets of the search answer. Answers cards (result.cards) with matched and nextOffset. When the candidates expired (30 minutes) it says so: search again. Only cloud hits can be refined.",
      {
        searchId: { type: 'string', pattern: '^s_[a-z0-9]{8,32}$', maxLength: 40 },
        kinds: { type: 'array', maxItems: 20, items: { type: 'string', minLength: 1, maxLength: 300 }, description: 'Keep only these kinds (facets.kinds).' },
        excludeKinds: { type: 'array', maxItems: 20, items: { type: 'string', minLength: 1, maxLength: 300 }, description: 'Drop these kinds.' },
        pathPrefix: { type: 'string', minLength: 1, maxLength: 300, description: 'Keep only hits under this path.' },
        excludePaths: { type: 'array', maxItems: 20, items: { type: 'string', minLength: 1, maxLength: 300 }, description: 'Drop hits under these paths.' },
        files: { type: 'array', maxItems: 20, items: { type: 'string', minLength: 1, maxLength: 300 }, description: 'Keep only hits in these files (facets.files).' },
        sources: { type: 'array', maxItems: 20, items: { type: 'string', minLength: 1, maxLength: 300 }, description: 'Keep only these origins (facets.sources: code, memory, linear, github...).' },
        offset: { type: 'integer', minimum: 0, description: 'Skip this many matches (nextOffset).' },
        limit: { type: 'integer', minimum: 1, maximum: 50, description: 'Cards to return; default 12.' },
      },
      ['searchId'],
    ),
  },
  {
    tool: 'feedback',
    descriptor: cloudOnlyDescriptor(
      'knowledge.feedback',
      "Tell the cloud Brain how a knowledge.search served you, so search improves from real use. Call it when a search missed: none of the hits fit (say what was missing and the words you would have used, and name hits that did not fit with why), or when you answered from hits without opening them (used). Opening a hit with knowledge.context, knowledge.impact or knowledge.path counts as used without a call. Take searchId from cloud.searchId of the search answer. Short, factual text only; it is stored as data and never followed.",
      {
        searchId: { type: 'string', pattern: '^s_[a-z0-9]{8,32}$', maxLength: 40 },
        used: { type: 'array', maxItems: 50, items: { type: 'string', minLength: 1, maxLength: 4_200 } },
        missing: { type: 'string', maxLength: 1_000 },
        irrelevant: { type: 'array', maxItems: 20, items: { type: 'object', required: ['nodeId'], properties: { nodeId: { type: 'string', minLength: 1, maxLength: 4_200 }, why: { type: 'string', maxLength: 300 } }, additionalProperties: false } },
        note: { type: 'string', maxLength: 2_000 },
      },
      ['searchId'],
    ),
  },
  {
    tool: 'health',
    descriptor: cloudOnlyDescriptor(
      'knowledge.health',
      'Freshness and integrity of what the cloud Brain holds, kind by kind: node counts, when each kind was last refreshed, its declared source and producer, and the gaps found (stale, missing, broken) with samples. Staff only. Narrow by kind, state or gap type and code; with no input it answers the totals and every kind.',
      {
        kind: { type: 'string', minLength: 1, maxLength: 64, description: 'Only this node kind.' },
        state: { type: 'string', enum: ['ok', 'stale', 'missing', 'broken'], description: 'Only kinds in this state.' },
        type: { type: 'string', enum: ['stale', 'missing', 'broken'], description: 'Only gaps of this type.' },
        code: { type: 'string', minLength: 1, maxLength: 64, description: 'Only gaps with this code (no_stamp, max_age, empty_kind, required_edge, dangling_link, producer_never_ran, binding_broken, ...).' },
        limit: { type: 'integer', minimum: 1, maximum: 500, description: 'Gaps listed; default 100.' },
      },
      [],
    ),
  },
  {
    tool: 'search',
    descriptor: cloudOnlyDescriptor(
      'memory.cloud_search',
      'Recall company memories stored in the cloud Brain (decisions, rules, root causes) that match a question. Your own and project memories are memory.search.',
      {
        content: { type: 'string', minLength: 1, maxLength: 2_000 },
        limit: { type: 'integer', minimum: 1, maximum: MAX_CLOUD_SEARCH_LIMIT },
      },
      ['content'],
    ),
  },
  {
    tool: CLOUD_STATUS_TOOL,
    descriptor: cloudOnlyDescriptor(
      'knowledge.cloud_status',
      'Whether the cloud Brain answers, and its index: the cloud schema call, with the indexed commit and time, the node counts the caller may see and the limits. A cloud that is starting, down or misconfigured is reported in cloud.status, not thrown. Local index health is knowledge.status.',
      {},
      [],
    ),
  },
  {
    tool: 'memory_get',
    descriptor: cloudOnlyDescriptor(
      'memory.cloud_get',
      'Read one cloud Brain memory by the id a cloud hit, memory.cloud_search or knowledge.list named (the cloud: prefix is optional).',
      { id: { type: 'string', minLength: 1, maxLength: 4_200 } },
      ['id'],
    ),
  },
  {
    tool: 'memory_link',
    descriptor: cloudOnlyDescriptor(
      'memory.cloud_link',
      'Store knowledge in the cloud Brain, linked to the code or docs it explains; cloud knowledge.search and memory.cloud_search find it at once. Writing an existing key replaces its text and links (a correction or a relink), including a memory from the company drop. Only the caller sees what it writes. Knowledge only: definitions, where data lives, how to compute something, which code does what; the Brain refuses brand figures, evaluation answers, personal data and secrets.',
      {
        content: { type: 'string', minLength: 1, maxLength: 4_000 },
        key: MEMORY_KEY,
        links: MEMORY_LINKS,
        source: { type: 'string', minLength: 1, maxLength: 200 },
      },
      ['content', 'links'],
      CLOUD_WRITE_PERMISSION,
    ),
  },
  {
    tool: 'memory_retire',
    descriptor: cloudOnlyDescriptor(
      'memory.cloud_retire',
      'Take a wrong or stale cloud Brain memory out of search, with the reason and the key that replaces it; its text stays in memory.cloud_history. Applies to memories only the caller sees.',
      {
        key: MEMORY_KEY,
        reason: { type: 'string', minLength: 1, maxLength: 1_000 },
        replacedBy: MEMORY_KEY,
      },
      ['key'],
      CLOUD_WRITE_PERMISSION,
    ),
  },
  {
    tool: 'memory_history',
    descriptor: cloudOnlyDescriptor(
      'memory.cloud_history',
      'Every revision of one cloud Brain memory: who wrote, corrected, relinked or retired it, when, and the text each time.',
      { key: MEMORY_KEY },
      ['key'],
    ),
  },
  {
    tool: 'session_search',
    descriptor: cloudOnlyDescriptor(
      'sessions.cloud_search',
      'Search agent sessions shared to the team Brain (Marshal sessions people shared, and zyg-agents runs) that match a question. Optional workspace narrows to one project. Your own local sessions are searchSessions.',
      {
        query: { type: 'string', minLength: 1, maxLength: 2_000 },
        workspace: { type: 'string', minLength: 1, maxLength: 200 },
        since: { type: 'string', minLength: 1, maxLength: 40 },
        until: { type: 'string', minLength: 1, maxLength: 40 },
        limit: { type: 'integer', minimum: 1, maximum: MAX_CLOUD_SEARCH_LIMIT },
      },
      ['query'],
    ),
  },
  {
    tool: 'session_ingest',
    descriptor: cloudOnlyDescriptor(
      'sessions.cloud_share',
      'Share one Marshal session to the team Brain so teammates find it with sessions.cloud_search. Only for a session the user explicitly chose to share from the session menu; the caller redacts it first. Sharing the same id again replaces it. A session over 1 MB goes as ordered calls with part {index, count, offset, upload}: upload is one new id per share, the same on every part; each call before the last answers status partial, the last stored. After an unshare the Brain refuses the rest of that upload; share again from part 0 with a new upload id. Or pass parts [{offset, messages}] with session.messages empty: the extension sends every part itself in one call (each request at most 1 MB, one upload id), waits up to 30 s for an earlier unshare to finish cleaning up and restarts once from part 0 if the session is unshared mid-upload.',
      { session: SHARED_SESSION, access: SHARE_ACCESS, part: SHARE_PART, parts: SHARE_PARTS },
      ['session', 'access'],
      CLOUD_WRITE_PERMISSION,
    ),
  },
  {
    tool: 'session_unshare',
    descriptor: cloudOnlyDescriptor(
      'sessions.cloud_unshare',
      'Stop sharing a session the caller shared to the team Brain; it leaves cloud search.',
      { sessionId: { type: 'string', minLength: 1, maxLength: 200 } },
      ['sessionId'],
      CLOUD_WRITE_PERMISSION,
    ),
  },
];

function cloudOnlyDescriptor(
  name: string,
  description: string,
  properties: Readonly<Record<string, JsonSchema>>,
  required: readonly string[],
  permission: string = CLOUD_READ_PERMISSION,
): CapabilityDescriptor {
  return {
    protocolVersion: PROTOCOL_VERSION,
    name,
    version: '1.0.0',
    description,
    tags: [name.split('.')[0]!, 'quillstone', name.split('.').at(-1)!, 'cloud-brain'],
    permissions: [{ permission, scope: 'workspace', risk: permission === CLOUD_WRITE_PERMISSION ? 'medium' : 'low' }],
    inputSchema: { type: 'object', properties, required, additionalProperties: false },
    outputSchema: {
      type: 'object',
      required: ['source', 'cloud', 'truncated'],
      properties: { ...ROUTED_RESULT_PROPERTIES, truncated: { type: 'boolean' } },
      additionalProperties: false,
    },
  };
}

const CLOUD_ONLY_BY_NAME = new Map(CLOUD_ONLY.map((entry) => [entry.descriptor.name, entry]));
/** Session sharing (sessions.cloud_share/unshare) is a user action from the session menu, so it is not gated by cloudMemoryWrites. */
const CLOUD_WRITE_NAMES = new Set(['memory.cloud_link', 'memory.cloud_retire']);

/**
 * Merge/order options, each off by default except keepDistinctCodeHits. Env override: BRAIN_MERGE_FLAGS=relevanceMerge,keepDistinctCodeHits,prUrlEvidence
 * (or `all`).
 */
export interface CloudMergeFlags {
  /** Order the local and cloud hits of a cloud: true search by per-source normalized score, not a fixed alternation. Opt-in only: `BRAIN_MERGE_FLAGS=all` does not include it; the union judge is the main path. */
  readonly relevanceMerge?: boolean;
  /** On by default; false drops a cloud code hit that repeats a local one. On, a cloud hit survives when it differs from the local one in repository, revision or location, and a true duplicate is folded into the local hit (cloudDuplicate) and counted in cloud.duplicates, never dropped silently. */
  readonly keepDistinctCodeHits?: boolean;
  /** Treat a PR URL, `repo#123` and `PR 123` as pull request questions, whose cloud hits lead the merge. */
  readonly prUrlEvidence?: boolean;
  /** The main merge path: one judge orders the merged local and cloud hits (needs options.judge); falls back to alternation (or to the relevance merge when that is also named). */
  readonly unionJudge?: boolean;
}

export function resolveCloudMergeFlags(
  flags: CloudMergeFlags | undefined,
  env: Readonly<Record<string, string | undefined>> = process.env,
): Required<CloudMergeFlags> {
  const named = new Set((env.BRAIN_MERGE_FLAGS ?? '').split(',').map((name) => name.trim()).filter(Boolean));
  const on = (name: keyof CloudMergeFlags) => flags?.[name] ?? (named.has('all') || named.has(name));
  return {
    // The score merge is unsound against the real cloud (its scores are pre-judge), so `all` leaves it out; name it to use it.
    relevanceMerge: flags?.relevanceMerge ?? named.has('relevanceMerge'),
    // On unless a caller passes false: a cloud hit that repeats local code is folded into that local hit, never dropped.
    keepDistinctCodeHits: flags?.keepDistinctCodeHits ?? true,
    prUrlEvidence: on('prUrlEvidence'),
    unionJudge: on('unionJudge'),
  };
}

/** One hit as the union judge reads it. */
export interface UnionCandidate {
  readonly name: string;
  readonly path?: string;
  readonly summary?: string;
}

/** Orders candidates by one probability each; throws (with a `code` when it has one) when it cannot. */
export type UnionJudge = (
  query: string,
  candidates: readonly UnionCandidate[],
  options: { readonly signal?: AbortSignal; readonly timeoutMs: number },
) => Promise<readonly number[]>;

export interface CloudKnowledgeOptions {
  readonly now?: () => number;
  readonly remoteOnly?: boolean;
  readonly flags?: CloudMergeFlags;
  readonly judge?: UnionJudge;
  /** Longest a ranked search waits for the cloud when the local index cannot answer instead; default 45 s. */
  readonly searchHardCapMs?: number;
  /** Shortest wait before the cloud is asked again after a failure that passes, when nothing local can answer; default 1 s. */
  readonly searchRetryBaseMs?: number;
  /** With remoteOnly: ask the cloud again for a failure that passes, until the hard cap, before failing the search. */
  readonly remoteOnlyRetry?: boolean;
}

/**
 * Brain's knowledge provider with the cloud Brain folded in. The cloud Brain speaks five tools: search, traverse,
 * impact, path and schema. Off, this is the provider unchanged. On:
 * - knowledge.search asks the cloud's search (and the local index only when the cloud cannot answer, or cloud: true
 *   asks both); each hit is labelled `source`, with a `cloud` report saying how the cloud did.
 * - knowledge.context (traverse) and knowledge.impact (impact) send a cloud: id, or a code path or symbol, to the cloud
 *   Brain, anything else to the local index.
 * - Cloud-only: knowledge.path (path), knowledge.schema (schema) and memory.cloud_search (search over memories).
 * Audience filtering stays on the cloud Brain; nothing from it is cached.
 */
export function withCloudKnowledge(
  provider: CapabilityProvider,
  setting: CloudKnowledgeSetting,
  options: CloudKnowledgeOptions = {},
): CapabilityProvider {
  if (setting.state === 'off') return provider;
  const now = options.now ?? Date.now;
  const remoteOnly = options.remoteOnly === true;
  const flags = resolveCloudMergeFlags(options.flags);
  const judge = options.judge;
  const hardCapMs = options.searchHardCapMs ?? CLOUD_SEARCH_HARD_CAP_MS;
  const retryBaseMs = options.searchRetryBaseMs ?? 1_000;
  const remoteOnlyRetry = options.remoteOnlyRetry === true;
  const cloudOnlyOffered = setting.state === 'on';
  const writesOffered = setting.state === 'on' && setting.configuration.memoryWrites;
  const cloudOnly = cloudOnlyOffered
    ? CLOUD_ONLY.map(({ descriptor }) => descriptor).filter(({ name }) => writesOffered || !CLOUD_WRITE_NAMES.has(name))
    : [];
  const extend = (descriptor: CapabilityDescriptor): CapabilityDescriptor => {
    switch (descriptor.name) {
      case 'knowledge.search': return searchDescriptor(descriptor);
      case 'knowledge.context':
      case 'knowledge.impact': return routedDescriptor(descriptor);
      default: return descriptor;
    }
  };

  return {
    id: provider.id,
    ...(provider.version ? { version: provider.version } : {}),
    async list(context) {
      warmCloud(setting);
      const descriptors = (await provider.list(context)).map(extend);
      const routed = remoteOnly
        ? descriptors.filter(({ name }) => ['knowledge.search', 'knowledge.context', 'knowledge.impact'].includes(name))
        : descriptors;
      return [...routed, ...cloudOnly];
    },
    ...(provider.get || cloudOnlyOffered ? {
      async get(name: string, context: InvocationContext) {
        if (CLOUD_ONLY_BY_NAME.has(name)) return cloudOnly.find((descriptor) => descriptor.name === name);
        const descriptor = provider.get
          ? await provider.get(name, context)
          : (await provider.list(context)).find((candidate) => candidate.name === name);
        if (remoteOnly && descriptor && !['knowledge.search', 'knowledge.context', 'knowledge.impact'].includes(name)) return undefined;
        return descriptor ? extend(descriptor) : undefined;
      },
    } : {}),
    async invoke(name, input, context) {
      switch (name) {
        case 'knowledge.search': return search(provider, setting, input, context, now, remoteOnly, flags, judge, hardCapMs, retryBaseMs, remoteOnlyRetry);
        case 'knowledge.context':
        case 'knowledge.impact': return routed(provider, setting, name, input, context, now, remoteOnly);
        default:
          if (CLOUD_WRITE_NAMES.has(name) && !writesOffered) {
            throw new CloudBrainError('cloud_brain_rejected', `${name} is off: the cloudMemoryWrites setting enables the cloud memory writes.`);
          }
          if (CLOUD_ONLY_BY_NAME.has(name)) return cloudOnlyCall(setting, name, input, context, now);
          if (remoteOnly) throw new CloudBrainError('cloud_brain_rejected', `${name} is unavailable in explicit remote-only mode.`);
          warmCloud(setting);
          return provider.invoke(name, input, context);
      }
    },
  };
}

/** Opens the cloud connection ahead of a call when it has been idle (a local knowledge tool is about to run). */
function warmCloud(setting: CloudKnowledgeSetting): void {
  if (setting.state === 'on') setting.route.warm?.();
}

async function search(
  provider: CapabilityProvider,
  setting: Exclude<CloudKnowledgeSetting, { state: 'off' }>,
  rawInput: unknown,
  context: InvocationContext,
  now: () => number,
  remoteOnly: boolean,
  flags: Required<CloudMergeFlags>,
  judge: UnionJudge | undefined,
  hardCapMs: number,
  retryBaseMs: number,
  remoteOnlyRetry: boolean,
): Promise<CapabilityInvocationResult> {
  const { cloud: wanted, entityTypes, scopeIds, scopeHops, scopeMatch, mode, filters, cursor, sort, aggregate, granularity, group, within, ...localInput } = assertRecord(rawInput ?? {});
  if (scopeIds !== undefined || scopeHops !== undefined || scopeMatch !== undefined) {
    throw new CloudBrainError('cloud_brain_rejected', 'scopeIds, scopeHops and scopeMatch are not offered by the cloud search; walk from a node with knowledge.context instead.');
  }
  const passThrough = { filters, cursor, sort, aggregate, granularity, group, within };
  if (mode === 'exhaustive' || Object.values(passThrough).some((value) => value !== undefined) || localInput.query === undefined) {
    // Filters, aggregates, paging and the other cloud search options have no local or merged form: the cloud answers, whole.
    if (wanted === false) throw new CloudBrainError('cloud_brain_rejected', 'filters, aggregate, sort, cursor, granularity, group, within and exhaustive searches are answered by the cloud Brain; they cannot be combined with cloud: false.');
    if (localInput.createdAfter !== undefined || localInput.createdBefore !== undefined) {
      throw new CloudBrainError('cloud_brain_rejected', 'createdAfter/createdBefore filter local memories only; use a createdAt range in filters for the cloud Brain.');
    }
    const cloudPassThrough = withoutCloudIdsInWithin(passThrough);
    return cloudNativeSearch(requireRoute(setting), rawInput, context, {
      ...(mode !== undefined ? { mode } : {}),
      ...(typeof localInput.query === 'string' ? { query: localInput.query } : {}),
      ...(typeof localInput.limit === 'number' ? { limit: localInput.limit } : {}),
      ...Object.fromEntries(SEARCH_PASS_THROUGH.filter((key) => cloudPassThrough[key] !== undefined).map((key) => [key, cloudPassThrough[key]])),
    }, kindsFilter(localInput.kinds, entityTypes));
  }
  const limit = typeof localInput.limit === 'number' ? localInput.limit : DEFAULT_SEARCH_HITS;
  const query = typeof localInput.query === 'string' ? localInput.query : '';
  const filtered = entityTypes !== undefined;
  const cloudKindFilter = kindsFilter(localInput.kinds, entityTypes);
  if (remoteOnly) {
    if (wanted === false) throw new CloudBrainError('cloud_brain_rejected', 'cloud: false is unavailable in explicit remote-only mode.');
    if (localInput.createdAfter !== undefined || localInput.createdBefore !== undefined) {
      throw new CloudBrainError('cloud_brain_rejected', 'createdAfter/createdBefore filters are unavailable in remote-only mode.');
    }
    const route = requireRoute(setting);
    const remoteArgs = {
      query,
      limit: Math.min(limit, MAX_CLOUD_ONLY_SEARCH_LIMIT),
      ...(cloudKindFilter ? { kinds: cloudKindFilter } : {}),
    };
    return remoteOnlyRetry
      ? cloudOnlySearchPatiently(route, rawInput, context, now, remoteArgs, hardCapMs, retryBaseMs)
      : cloudOnlySearch(route, rawInput, context, now, remoteArgs);
  }
  // The cloud Brain is the Brain: a search names neither cloud nor a local-only date window, so the cloud answers it
  // alone; the local index answers only when the cloud cannot, and the answer says why.
  const createdWindow = localInput.createdAfter !== undefined || localInput.createdBefore !== undefined;
  if (wanted === undefined && !filtered && !createdWindow && setting.state === 'on') {
    const signal = context.signal as AbortSignal | undefined;
    const started = now();
    const budget = setting.configuration.searchBudgetMs;
    const hardCap = Math.max(budget, hardCapMs);
    // A hedge: the local search starts only once the cloud is slower than usual (or fails), so a fast cloud costs no
    // local work, and a cloud that misses its budget falls back to local hits that are already mostly computed.
    let localRun: Promise<{ ok: true; value: CapabilityInvocationResult } | { ok: false; error: unknown }> | undefined;
    let localFailure: string | undefined;
    const startLocal = () => (localRun ??= Promise.resolve()
      .then(() => provider.invoke('knowledge.search', { ...localInput, limit }, context))
      .then((value) => ({ ok: true as const, value }), (error: unknown) => {
        localFailure = describeError(error).slice(0, 300);
        return { ok: false as const, error };
      }));
    const localAnswer = (local: CapabilityInvocationResult, error: unknown): CapabilityInvocationResult => {
      const output = local.output as Record<string, unknown> & { hits: Array<Record<string, unknown>> };
      return {
        ...local,
        output: {
          ...output,
          hits: output.hits.map((hit) => ({ ...hit, source: 'local' })),
          cloud: failureReport(error, now() - started),
        },
      };
    };
    // A cloud answer that came while the local search had already failed says so: local was skipped, not empty.
    const withLocalSkipped = (answer: CapabilityInvocationResult): CapabilityInvocationResult => {
      const output = answer.output as Record<string, unknown>;
      if (!localFailure || output.localMemory !== undefined) return answer;
      return {
        ...answer,
        output: {
          ...output,
          localMemory: { status: 'skipped', skipped: ['local index'], reason: localFailure, since: new Date(started).toISOString() },
        },
      };
    };
    const hedge = setTimeout(startLocal, Math.min(LOCAL_HEDGE_MS, budget));
    // The cloud call runs to the hard cap, on a signal of its own, so that missing the budget does not cancel an answer
    // that is still coming when there is nothing else to return.
    const cloudAbort = new AbortController();
    const relay = () => cloudAbort.abort(signal?.reason);
    if (signal?.aborted) relay();
    else signal?.addEventListener('abort', relay, { once: true });
    let budgetTimer: ReturnType<typeof setTimeout> | undefined;
    try {
      const outcome = cloudOnlySearch(setting, rawInput, { ...context, signal: cloudAbort.signal } as InvocationContext, now, {
        query,
        limit: Math.min(limit, MAX_CLOUD_ONLY_SEARCH_LIMIT),
        ...(cloudKindFilter ? { kinds: cloudKindFilter } : {}),
      }, hardCap, true).then(
        (value) => ({ kind: 'cloud' as const, value }),
        (error: unknown) => ({ kind: 'failed' as const, error }),
      );
      const overBudget = new Promise<{ kind: 'budget' }>((resolve) => {
        budgetTimer = setTimeout(() => resolve({ kind: 'budget' }), budget);
      });
      const raced = await Promise.race([outcome, overBudget]);
      let localUsed: Awaited<ReturnType<typeof startLocal>> | undefined;
      let answered: Awaited<typeof outcome>;
      if (raced.kind === 'budget') {
        localUsed = await startLocal();
        const hits = localUsed.ok ? (localUsed.value.output as { hits?: unknown[] }).hits : undefined;
        if (localUsed.ok && hits && hits.length > 0) {
          cloudAbort.abort();
          return localAnswer(localUsed.value, new CloudBrainError(
            'cloud_brain_timeout',
            `cloud brain timeout: no answer within ${budget} ms (the knowledge.search cloud budget; local hits were returned without it). The cloud Brain may be starting, refreshing or loaded; retry later.`,
            { retryAfterSeconds: 30 },
          ));
        }
        // No local answer to return: waiting for the cloud is better than failing.
        answered = await outcome;
      } else {
        answered = raced;
      }
      if (answered.kind === 'cloud') return withLocalSkipped(answered.value);
      if (signal?.aborted) throw answered.error;
      const settled = localUsed ?? await startLocal();
      const localHits = settled.ok ? (settled.value.output as { hits?: unknown[] }).hits : undefined;
      if (settled.ok && localHits && localHits.length > 0) return localAnswer(settled.value, answered.error);
      // Nothing local to return (unavailable, failed or empty): a cloud that failed for a reason that passes is asked
      // again until the hard cap, and only then does the call fail, with the cloud's error.
      let failure = answered.error;
      while (isRetryableCloudFailure(failure) && !cloudAbort.signal.aborted) {
        const waitMs = Math.min(5_000, Math.max(retryBaseMs, (failure.retryAfterSeconds ?? 0) * 1_000));
        const remaining = hardCap - (now() - started);
        if (remaining <= waitMs + 500) break;
        await new Promise<void>((resolve) => {
          const timer = setTimeout(resolve, waitMs);
          cloudAbort.signal.addEventListener('abort', () => { clearTimeout(timer); resolve(); }, { once: true });
        });
        if (cloudAbort.signal.aborted) break;
        try {
          return withLocalSkipped(await cloudOnlySearch(setting, rawInput, { ...context, signal: cloudAbort.signal } as InvocationContext, now, {
            query,
            limit: Math.min(limit, MAX_CLOUD_ONLY_SEARCH_LIMIT),
            ...(cloudKindFilter ? { kinds: cloudKindFilter } : {}),
          }, Math.max(1_000, hardCap - (now() - started)), true));
        } catch (error) {
          failure = error;
        }
      }
      if (isCloudBrainError(failure)) {
        const why = settled.ok ? 'no local hits' : describeError(settled.error).slice(0, 300);
        throw new CloudBrainError(
          failure.code,
          `${failure.message} The local fallback could not answer either (${why}).`,
          { ...(failure.retryAfterSeconds !== undefined ? { retryAfterSeconds: failure.retryAfterSeconds } : {}), ...(failure.httpStatus !== undefined ? { httpStatus: failure.httpStatus } : {}) },
        );
      }
      throw failure;
    } finally {
      clearTimeout(hedge);
      clearTimeout(budgetTimer);
      signal?.removeEventListener('abort', relay);
      cloudAbort.abort();
    }
  }
  if (wanted === 'only' || filtered) {
    if (wanted === false) throw new CloudBrainError('cloud_brain_rejected', 'entityTypes filter the cloud Brain; they cannot be combined with cloud: false.');
    const route = requireRoute(setting);
    return cloudOnlySearch(route, rawInput, context, now, {
      query,
      limit: Math.min(limit, MAX_CLOUD_ONLY_SEARCH_LIMIT),
      ...(cloudKindFilter ? { kinds: cloudKindFilter } : {}),
    });
  }
  const skip = setting.state === 'misconfigured'
    ? { status: 'misconfigured' as const, message: setting.message }
    : wanted === false
      ? { status: 'skipped' as const, message: 'cloud: false was passed; local hits only.' }
      : localInput.createdAfter !== undefined || localInput.createdBefore !== undefined
        ? { status: 'skipped' as const, message: 'createdAfter/createdBefore filter local memories only; the cloud was not asked.' }
        : undefined;

  let cloudCall: Promise<CloudSearchOutcome> | undefined;
  const cloudLed = wantsCloudEvidence(query, flags.prUrlEvidence);
  if (!skip && setting.state === 'on') {
    const { route, configuration } = setting;
    const budget = configuration.searchBudgetMs;
    const signal = context.signal as AbortSignal | undefined;
    const started = now();
    const settle = (call: Promise<{ output: unknown; caller: string; elapsedMs: number }>): Promise<CloudSearchOutcome> => call
      .then((answer) => ({ ok: true as const, answer }), (error: unknown) => ({ ok: false as const, error, elapsedMs: now() - started }));
    // The provider route derives delegated caller identity from this host-owned context, never from search input.
    cloudCall = settle(cloudSearch(route, { query, limit: Math.min(limit, MAX_CLOUD_SEARCH_LIMIT), ...(cloudKindFilter ? { kinds: cloudKindFilter } : {}) },
      { deadlineMs: budget, signal, reason: `the knowledge.search cloud budget; local hits were returned without it`, context }));
  }

  let local: CapabilityInvocationResult | undefined;
  let localError: unknown;
  try {
    // The relevance merge needs the local scores, which the runtime reports with debug: true.
    const scored = flags.relevanceMerge && localInput.debug === undefined && await acceptsDebug(provider, context);
    local = await provider.invoke('knowledge.search', scored ? { ...localInput, debug: true } : localInput, context);
  } catch (error) {
    localError = error;
  }
  const outcome = await cloudCall;
  const cloud = outcome ? cloudSearchHits(outcome) : { hits: [] as CloudHit[], report: skip as CloudReport };

  if (!local) {
    if (cloud.hits.length === 0) throw localError;
    const hits = cloud.hits.slice(0, limit).map((hit, index) => ({ ...hit, rank: index + 1 }));
    return result({
      hits,
      generation: 0,
      truncated: cloud.hits.length > limit,
      routeFailures: [`local: ${describeError(localError)}`.slice(0, 2_000)],
      cloud: { ...cloud.report, hits: hits.length },
    }, KNOWLEDGE_PROVIDER_ID, 'knowledge.search', rawInput, context);
  }

  const output = local.output as { hits: Array<Record<string, unknown>>; truncated: boolean } & Record<string, unknown>;
  const localHits = output.hits.map((hit): Record<string, unknown> => ({ ...hit, source: 'local' }));
  const { cloudHits, merged: mergedLocal, repeated } = flags.keepDistinctCodeHits
    ? mergeDuplicates(localHits, cloud.hits)
    : dropDuplicates(localHits, cloud.hits);
  const evidenceLedMerge = cloudLed && cloud.hits.length > 0;
  let mergeReport: MergeReport | undefined;
  let merged: Array<Record<string, unknown>> | undefined;
  if (flags.unionJudge) {
    if (judge === undefined) mergeReport = { mode: 'alternation', fallback: 'no-judge' };
    else {
      try {
        merged = await mergeByJudge(judge, query, mergedLocal, cloudHits, limit, evidenceLedMerge, context.signal as AbortSignal | undefined);
        mergeReport = { mode: 'union-judge' };
      } catch (error) {
        if ((context.signal as AbortSignal | undefined)?.aborted) throw error;
        mergeReport = { mode: 'alternation', fallback: describeCode(error) };
      }
    }
  }
  if (merged === undefined && flags.relevanceMerge) {
    const byScore = mergeByRelevance(mergedLocal, cloudHits, limit, evidenceLedMerge);
    merged = byScore.merged;
    mergeReport = { mode: byScore.scored ? 'relevance' : 'alternation', ...(mergeReport?.fallback ? { fallback: mergeReport.fallback } : {}) };
  }
  merged ??= alternate(mergedLocal, cloudHits, limit, evidenceLedMerge);
  merged = ensureCloudPresence(merged, cloudHits.length > 0 ? cloudHits : repeated, limit);
  const cloudShown = merged.filter((hit) => hit.source === 'cloud').length;
  const withoutDebug = flags.relevanceMerge && localInput.debug === undefined;
  return {
    ...local,
    output: {
      ...output,
      hits: merged.map((hit, index) => ({ ...(withoutDebug ? withoutLocalDebug(hit) : hit), rank: index + 1 })),
      truncated: output.truncated || mergedLocal.length + cloudHits.length > merged.length,
      cloud: {
        ...cloud.report,
        ...(cloud.report.status === 'ok' || cloud.report.status === 'partial' ? { hits: cloudShown } : {}),
        ...(repeated.length > 0 ? { duplicates: repeated.length } : {}),
        ...(mergeReport ? { merge: mergeReport } : {}),
      },
    },
  };
}

interface MergeReport {
  mode: 'union-judge' | 'relevance' | 'alternation';
  fallback?: string;
}

function describeCode(error: unknown): string {
  const code = error !== null && typeof error === 'object' && 'code' in error ? (error as { code?: unknown }).code : undefined;
  return typeof code === 'string' ? code.slice(0, 128) : error instanceof Error ? error.name.slice(0, 128) : 'unknown';
}

function dropDuplicates(localHits: Array<Record<string, unknown>>, cloud: CloudHit[]) {
  const seen = new Set(localHits.flatMap((hit) => codeKey(hit.node)));
  const isRepeat = (hit: CloudHit) => codeKey(hit.node).some((key) => seen.has(key));
  return { merged: localHits, cloudHits: cloud.filter((hit) => !isRepeat(hit)), repeated: cloud.filter(isRepeat) };
}

const REVISION_FIELDS = ['repo', 'repository', 'revision', 'ref', 'sha', 'commit'] as const;

/** Two code hits with the same kind, path and name are one thing only when nothing says they sit in different repositories, revisions or places. */
function sameCodeIdentity(local: Record<string, unknown>, cloud: CloudHit): boolean {
  const [localKey] = codeKey(local.node);
  const [cloudKey] = codeKey(cloud.node);
  if (!localKey || localKey !== cloudKey) return false;
  const localNode = local.node as Record<string, unknown>;
  for (const field of REVISION_FIELDS) {
    if (typeof localNode[field] === 'string' && typeof cloud.node[field] === 'string' && localNode[field] !== cloud.node[field]) return false;
  }
  const localLine = typeof local.line === 'number' ? local.line : undefined;
  const cloudLine = typeof cloud.line === 'number' ? cloud.line : undefined;
  return localLine === undefined || cloudLine === undefined || localLine === cloudLine;
}

/**
 * Like dropDuplicates, but a cloud hit survives when it differs from the local one in repository, revision or line, and a
 * true duplicate is folded into its local hit (cloudDuplicate) instead of vanishing: both sources agreeing is evidence.
 */
function mergeDuplicates(localHits: Array<Record<string, unknown>>, cloud: CloudHit[]) {
  const merged = localHits.map((hit) => ({ ...hit }));
  const cloudHits: CloudHit[] = [];
  const repeated: CloudHit[] = [];
  for (const hit of cloud) {
    const twin = merged.find((candidate) => sameCodeIdentity(candidate, hit));
    if (!twin) { cloudHits.push(hit); continue; }
    repeated.push(hit);
    twin.cloudDuplicate = {
      id: hit.node.id,
      cloudRank: hit.cloudRank,
      ...(typeof hit.score === 'number' ? { score: hit.score } : {}),
      ...(typeof hit.snippet === 'string' ? { snippet: hit.snippet } : {}),
    };
  }
  return { merged, cloudHits, repeated };
}

/**
 * A search that asked the cloud never lists local hits alone: when no hit in the list comes from the cloud, the best cloud
 * hit takes the second place (the last place of a full list goes), whatever order the merge chose.
 */
function ensureCloudPresence(merged: Array<Record<string, unknown>>, cloudHits: CloudHit[], limit: number): Array<Record<string, unknown>> {
  if (cloudHits.length === 0 || merged.some((hit) => hit.source === 'cloud')) return merged;
  const kept = merged.length >= limit ? merged.slice(0, Math.max(0, limit - 1)) : merged;
  const at = Math.min(1, kept.length);
  return [...kept.slice(0, at), cloudHits[0]!, ...kept.slice(at)];
}

/** Local first, then alternating; a question about a PR, ticket or person leads with two cloud hits per local one. */
function alternate(localHits: Array<Record<string, unknown>>, cloudHits: CloudHit[], limit: number, evidenceLed: boolean): Array<Record<string, unknown>> {
  const pattern = evidenceLed ? ['cloud', 'cloud', 'local'] : ['local', 'cloud'];
  const merged: Array<Record<string, unknown>> = [];
  for (let step = 0, localNext = 0, cloudNext = 0; merged.length < limit && (localNext < localHits.length || cloudNext < cloudHits.length); step += 1) {
    const takeCloud = pattern[step % pattern.length] === 'cloud' ? cloudNext < cloudHits.length : localNext >= localHits.length;
    merged.push(takeCloud ? cloudHits[cloudNext++]! : localHits[localNext++]!);
  }
  return merged;
}

const MIN_SCORED_HITS = 3;
const AGREEMENT_BONUS = 0.5;

/**
 * A hit's score as standard deviations above its own source's mean, so a source's runaway #1 beats the other source's
 * flat list instead of tying with the other source's #1. Null when the source has too few scored hits to normalize.
 */
function standardScores(hits: ReadonlyArray<Record<string, unknown>>): Array<number | null> {
  const scores = hits.map((hit) => (typeof hit.score === 'number' && Number.isFinite(hit.score) ? hit.score : undefined));
  const scored = scores.filter((score): score is number => score !== undefined);
  if (scored.length < MIN_SCORED_HITS || scored.length < hits.length) return hits.map(() => null);
  // A source whose order is not its score order (a judged list with pre-judge scores) has no usable scores.
  if (scored.some((score, index) => index > 0 && score > scored[index - 1]!)) return hits.map(() => null);
  const mean = scored.reduce((sum, score) => sum + score, 0) / scored.length;
  const spread = Math.sqrt(scored.reduce((sum, score) => sum + (score - mean) ** 2, 0) / scored.length);
  return scores.map((score) => (spread > 0 ? (score! - mean) / spread : 0));
}

/**
 * One list ordered by relevance: local and cloud search hits are ordered by their normalized scores; when
 * either source has no usable scores the order falls back to the fixed alternation. Hits both sources returned gain a bonus.
 */
function mergeByRelevance(
  localHits: Array<Record<string, unknown>>,
  cloudHits: CloudHit[],
  limit: number,
  evidenceLed: boolean,
): { merged: Array<Record<string, unknown>>; scored: boolean } {
  const searchHits = cloudHits;
  const localStandard = standardScores(localHits);
  const cloudStandard = standardScores(searchHits);
  if (localStandard.some((value) => value === null) || cloudStandard.some((value) => value === null)) {
    return { merged: alternate(localHits, cloudHits, limit, evidenceLed), scored: false };
  }
  const entries = [
    ...localHits.map((hit, index) => ({ hit, value: localStandard[index]! + (hit.cloudDuplicate ? AGREEMENT_BONUS : 0), tie: index })),
    ...searchHits.map((hit, index) => ({ hit: hit as Record<string, unknown>, value: cloudStandard[index]!, tie: index + 0.5 })),
  ].sort((a, b) => b.value - a.value || a.tie - b.tie);
  return { merged: entries.map((entry) => entry.hit).slice(0, limit), scored: true };
}

const UNION_JUDGE_TIMEOUT_MS = 2_500;
const UNION_POOL_PER_SOURCE = 15;

function unionCandidate(hit: Record<string, unknown>): UnionCandidate {
  const node = (hit.node ?? {}) as Record<string, unknown>;
  const kind = typeof node.kind === 'string' ? node.kind : 'node';
  const name = String(node.name ?? node.id ?? '');
  const label = kind === 'entity' ? `${String(node.entityKind ?? 'entity')} ${name}` : kind === 'memory' ? `memory ${name}` : name;
  const text = [hit.summary, hit.snippet, node.snippet].filter((part): part is string => typeof part === 'string').join('\n');
  return {
    name: label.slice(0, 300),
    ...(typeof node.path === 'string' ? { path: withoutRouteTag(node.path) } : {}),
    ...(text === '' ? {} : { summary: text.slice(0, 400) }),
  };
}

/**
 * One judge over the local and cloud hits together: the only comparison of the two sources that does not rest on scores
 * from different systems. The base order is the alternation, so equal probabilities keep it. Any judge failure is thrown
 * for the caller to fall back and report.
 */
async function mergeByJudge(
  judge: UnionJudge,
  query: string,
  localHits: Array<Record<string, unknown>>,
  cloudHits: CloudHit[],
  limit: number,
  evidenceLed: boolean,
  signal: AbortSignal | undefined,
): Promise<Array<Record<string, unknown>>> {
  const pool = alternate(localHits.slice(0, UNION_POOL_PER_SOURCE), cloudHits.slice(0, UNION_POOL_PER_SOURCE * 2), UNION_POOL_PER_SOURCE * 3, evidenceLed);
  if (pool.length < 2) return pool.slice(0, limit);
  let timer: ReturnType<typeof setTimeout> | undefined;
  const deadline = new Promise<never>((_, reject) => {
    timer = setTimeout(() => reject(Object.assign(new Error(`The union judge did not answer within ${UNION_JUDGE_TIMEOUT_MS} ms.`), { code: 'UNION_JUDGE_TIMEOUT' })), UNION_JUDGE_TIMEOUT_MS);
  });
  deadline.catch(() => undefined);
  const probabilities = await Promise.race([
    judge(query, pool.map(unionCandidate), { ...(signal ? { signal } : {}), timeoutMs: UNION_JUDGE_TIMEOUT_MS }),
    deadline,
  ]).finally(() => clearTimeout(timer));
  if (probabilities.length !== pool.length || probabilities.some((value) => typeof value !== 'number' || !Number.isFinite(value))) {
    throw Object.assign(new Error('The union judge returned a probability count that does not match its candidates.'), { code: 'UNION_JUDGE_INVALID_RESPONSE' });
  }
  const ordered = pool
    .map((hit, index) => ({ hit, index, probability: probabilities[index]! }))
    .sort((left, right) => right.probability - left.probability || left.index - right.index);
  const placed = new Set(pool);
  return [...ordered.map(({ hit }) => hit), ...alternate(localHits, cloudHits, localHits.length + cloudHits.length, evidenceLed).filter((hit) => !placed.has(hit))].slice(0, limit);
}

/** Whether the local knowledge.search declares `debug`, the switch that makes it report scores. */
async function acceptsDebug(provider: CapabilityProvider, context: InvocationContext): Promise<boolean> {
  const descriptor = (await provider.list(context)).find((entry) => entry.name === 'knowledge.search');
  const properties = (descriptor?.inputSchema as { properties?: Record<string, unknown> } | undefined)?.properties;
  return properties !== undefined && 'debug' in properties;
}

function withoutLocalDebug(hit: Record<string, unknown>): Record<string, unknown> {
  if (hit.source !== 'local') return hit;
  const { sourceScores: _sourceScores, ...rest } = hit;
  return rest;
}

/** `within.from` takes the node ids of cloud hits as they were listed (`cloud:` prefix); the cloud's own search wants them without it. */
function withoutCloudIdsInWithin<T extends { within?: unknown }>(passThrough: T): T {
  const within = passThrough.within;
  if (!within || typeof within !== 'object' || !Array.isArray((within as { from?: unknown }).from)) return passThrough;
  const from = ((within as { from: unknown[] }).from).map((entry) => (typeof entry === 'string' && entry.startsWith(CLOUD_ID_PREFIX) ? entry.slice(CLOUD_ID_PREFIX.length) : entry));
  return { ...passThrough, within: { ...(within as object), from } };
}

/**
 * knowledge.search with the cloud search tool's own options (mode, filters, aggregate, sort, cursor, granularity, group):
 * the arguments go to the cloud's search tool as given, and its answer comes back whole in `result` (ids carry the
 * cloud: prefix), never merged with local hits.
 */
async function cloudNativeSearch(
  setting: Extract<CloudKnowledgeSetting, { state: 'on' }>,
  rawInput: unknown,
  context: InvocationContext,
  args: Record<string, unknown>,
  kinds: string[] | undefined,
): Promise<CapabilityInvocationResult> {
  const filters = [...(Array.isArray(args.filters) ? args.filters : []), ...(kinds ? [{ field: 'kind', op: 'in', value: kinds }] : [])];
  const answer = await setting.route.call('search', { ...args, ...(filters.length > 0 ? { filters } : {}) }, {
    deadlineMs: setting.configuration.timeoutMs,
    signal: context.signal as AbortSignal | undefined,
    context,
  });
  const ranked = (answer.output as { mode?: unknown } | null)?.mode === 'ranked';
  const hits = cloudSearchHits({ ok: true, answer: { ...answer, output: searchAnswerAsHits(answer.output) } }).hits
    .slice(0, ranked ? MAX_CLOUD_SEARCH_LIMIT : MAX_EXHAUSTIVE_HITS)
    .map((hit, index) => ({ ...hit, rank: index + 1 }));
  return result({ hits, generation: 0, ...cloudEnvelope(answer, setting.configuration.maxResultChars) }, KNOWLEDGE_PROVIDER_ID, 'knowledge.search', rawInput, context);
}

/**
 * knowledge.search with cloud: 'only' or an entityTypes filter: the cloud alone, under the routed deadline since no
 * local hits wait, up to 20 hits. A cloud that answers nothing throws its coded error.
 */
async function cloudOnlySearch(
  setting: Extract<CloudKnowledgeSetting, { state: 'on' }>,
  rawInput: unknown,
  context: InvocationContext,
  now: () => number,
  args: { query: string; limit: number; kinds?: string[] },
  deadlineMs: number = setting.configuration.timeoutMs,
  failFastOnAuth = false,
  extras: Record<string, unknown> = {},
): Promise<CapabilityInvocationResult> {
  const { route } = setting;
  const signal = context.signal as AbortSignal | undefined;
  const started = now();
  const controller = new AbortController();
  const cancel = () => controller.abort(signal?.reason);
  if (signal?.aborted) cancel();
  signal?.addEventListener('abort', cancel, { once: true });
  let outcome: CloudSearchOutcome;
  try {
    outcome = await withCloudDeadline(
      deadlineMs, controller.signal, 'the knowledge.search cloud budget',
      (callSignal) => cloudSearch(route, args, { deadlineMs, signal: callSignal, context }),
    ).then((answer) => ({ ok: true as const, answer }), (error: unknown) => {
      if (failFastOnAuth && isCloudBrainError(error) && error.code === 'cloud_brain_auth_failed') throw error;
      return { ok: false as const, error, elapsedMs: now() - started };
    });
  } finally {
    controller.abort();
    signal?.removeEventListener('abort', cancel);
  }
  const cloud = cloudSearchHits(outcome);
  if (!outcome.ok && cloud.hits.length === 0) throw outcome.error;
  const hits = cloud.hits.slice(0, args.limit).map((hit, index) => ({ ...hit, rank: index + 1 }));
  const report = { ...cloud.report, hits: hits.length };
  if (report.message) report.message = report.message.replace(/ These results are local only\.$/, '');
  return result({ hits, generation: 0, truncated: cloud.hits.length > hits.length, cloud: report, ...extras }, KNOWLEDGE_PROVIDER_ID, 'knowledge.search', rawInput, context);
}

/**
 * A cloud-only ranked search that asks again, with a short backoff, when the cloud fails for a reason that passes
 * (starting, unavailable, busy, a failed call, a timeout), until the hard cap; then it fails with the cloud's error.
 */
async function cloudOnlySearchPatiently(
  setting: Extract<CloudKnowledgeSetting, { state: 'on' }>,
  rawInput: unknown,
  context: InvocationContext,
  now: () => number,
  args: { query: string; limit: number; kinds?: string[] },
  hardCapMs: number,
  retryBaseMs: number,
): Promise<CapabilityInvocationResult> {
  const signal = context.signal as AbortSignal | undefined;
  const started = now();
  const cap = Math.max(setting.configuration.searchBudgetMs, hardCapMs);
  for (;;) {
    const remaining = cap - (now() - started);
    try {
      return await cloudOnlySearch(setting, rawInput, context, now, args, Math.min(setting.configuration.timeoutMs, Math.max(1_000, remaining)));
    } catch (error) {
      if (!isRetryableCloudFailure(error) || signal?.aborted) throw error;
      const waitMs = Math.min(5_000, Math.max(retryBaseMs, (error.retryAfterSeconds ?? 0) * 1_000));
      if (cap - (now() - started) <= waitMs + 500) throw error;
      await new Promise<void>((resolve) => {
        const timer = setTimeout(resolve, waitMs);
        signal?.addEventListener('abort', () => { clearTimeout(timer); resolve(); }, { once: true });
      });
      if (signal?.aborted) throw error;
    }
  }
}

type CloudRoute = Extract<CloudKnowledgeSetting, { state: 'on' }>['route'];

/** The `kind` filter of a cloud search: the caller's kinds and entity types together, or none. */
function kindsFilter(kinds: unknown, entityTypes: unknown): string[] | undefined {
  const named = [kinds, entityTypes].flatMap((list) => (Array.isArray(list) ? list.filter((kind): kind is string => typeof kind === 'string' && kind.length > 0) : []));
  return named.length > 0 ? [...new Set(named)] : undefined;
}

/** Asks the cloud's search tool and returns its results in the hit shape the merge reads. */
async function cloudSearch(
  route: CloudRoute,
  args: { query: string; limit: number; kinds?: string[] },
  options: Parameters<CloudRoute['call']>[2],
): Promise<{ output: unknown; caller: string; elapsedMs: number }> {
  const answer = await route.call('search', {
    query: args.query,
    limit: Math.min(args.limit, MAX_CLOUD_SEARCH_LIMIT),
    ...(args.kinds ? { filters: [{ field: 'kind', op: 'in', value: args.kinds }] } : {}),
    format: 'cards',
  }, options);
  return { ...answer, output: searchAnswerAsHits(answer.output) };
}

/** The cloud search answer as `{hits, routeFailures?}`: each result in the hit shape, a degraded lane as a route failure. */
function searchAnswerAsHits(output: unknown): { hits: Array<Record<string, unknown>>; routeFailures?: string[] } {
  const record = output && typeof output === 'object' ? output as Record<string, unknown> : {};
  const degraded = Array.isArray(record.degraded)
    ? record.degraded.map((entry) => (typeof entry === 'string' ? entry : entry && typeof entry === 'object' ? String((entry as { message?: unknown; code?: unknown }).message ?? (entry as { code?: unknown }).code ?? '') : '')).filter(Boolean)
    : [];
  const notes = Array.isArray(record.notes) ? record.notes.filter((note): note is string => typeof note === 'string') : [];
  const routeFailures = [...degraded, ...(record.status === 'partial' ? notes : [])];
  const hits = Array.isArray(record.cards) ? searchCardsAsHits(record) : searchResultsAsHits(record);
  return {
    hits,
    ...(typeof record.searchId === 'string' ? { searchId: record.searchId } : {}),
    ...(typeof record.drill === 'string' ? { drill: record.drill } : {}),
    ...(record.facets && typeof record.facets === 'object' && !Array.isArray(record.facets) ? { facets: record.facets } : {}),
    ...(record.match && typeof record.match === 'object' && !Array.isArray(record.match) ? { match: record.match } : {}),
    ...(routeFailures.length > 0 ? { routeFailures } : {}),
  };
}

/** The cloud's candidate cards (format: cards) in the hit shape; a card carries why it matched, what it links to and how to open it. */
function searchCardsAsHits(record: Record<string, unknown>): Array<Record<string, unknown>> {
  return (record.cards as unknown[]).flatMap((entry) => {
    const card = entry as Record<string, unknown> | null;
    if (!card || typeof card !== 'object' || typeof card.id !== 'string') return [];
    return [{
      node: {
        id: card.id,
        kind: typeof card.kind === 'string' ? card.kind : 'node',
        name: typeof card.name === 'string' ? card.name : card.id,
        ...(typeof card.path === 'string' ? { path: card.path } : {}),
        ...(typeof card.key === 'string' ? { key: card.key } : {}),
        ...(typeof card.repoPath === 'string' ? { repoPath: card.repoPath } : {}),
      },
      ...(typeof card.line === 'number' ? { line: card.line } : {}),
      ...(typeof card.snippet === 'string' ? { snippet: card.snippet } : {}),
      ...(typeof card.why === 'string' ? { why: card.why } : {}),
      ...(Array.isArray(card.links) ? { links: card.links } : {}),
      ...(typeof card.next === 'string' ? { next: card.next } : {}),
      ...(Array.isArray(card.top) ? { top: card.top } : {}),
      ...(Array.isArray(card.memories) ? { memories: card.memories } : {}),
      ...(card.generatedFrom && typeof card.generatedFrom === "object" ? { generatedFrom: card.generatedFrom } : {}),
    }];
  });
}

function searchResultsAsHits(record: Record<string, unknown>): Array<Record<string, unknown>> {
  const results = Array.isArray(record.results) ? record.results as Array<Record<string, unknown>> : [];
  return results.flatMap((entry) => {
    if (!entry || typeof entry !== 'object' || typeof entry.id !== 'string') return [];
    const ref = entry.ref && typeof entry.ref === 'object' ? entry.ref as Record<string, unknown> : {};
    const props = entry.props && typeof entry.props === 'object' ? entry.props as Record<string, unknown> : {};
    const top = Array.isArray(entry.topNodes) ? entry.topNodes[0] as Record<string, unknown> | undefined : undefined;
    const lines = Array.isArray(ref.lines) ? ref.lines : undefined;
    const matchExcerpt = Array.isArray(entry.matches) ? (entry.matches[0] as { excerpt?: unknown } | undefined)?.excerpt : undefined;
    const snippet = typeof entry.snippet === 'string' ? entry.snippet : typeof matchExcerpt === 'string' ? matchExcerpt : undefined;
    return [{
      node: {
        id: entry.id,
        kind: typeof entry.kind === 'string' ? entry.kind : 'node',
        name: typeof entry.name === 'string' ? entry.name : entry.id,
        ...(typeof ref.path === 'string' ? { path: ref.path } : {}),
        ...(typeof ref.url === 'string' ? { url: ref.url } : {}),
        ...(typeof ref.repo === 'string' ? { repo: ref.repo } : {}),
        ...(typeof entry.sha === 'string' ? { revision: entry.sha } : {}),
        ...(Object.keys(props).length > 0 ? { props } : {}),
      },
      ...(typeof entry.score === 'number' ? { score: entry.score } : {}),
      ...(lines && typeof lines[0] === 'number' ? { line: lines[0], ...(typeof lines[1] === 'number' ? { endLine: lines[1] } : {}) } : {}),
      ...(snippet ? { snippet } : {}),
      ...(top && typeof top.name === 'string' && top.name !== entry.name ? { summary: `Best match inside: ${top.name}` } : {}),
    }];
  });
}

type CloudSearchOutcome =
  | { readonly ok: true; readonly answer: { output: unknown; caller: string; elapsedMs: number } }
  | { readonly ok: false; readonly error: unknown; readonly elapsedMs: number };

interface CloudHit extends Record<string, unknown> {
  source: 'cloud';
  node: Record<string, unknown>;
  rank: number;
}

function cloudSearchHits(outcome: CloudSearchOutcome): { hits: CloudHit[]; report: CloudReport } {
  if (!outcome.ok) return { hits: [], report: failureReport(outcome.error, outcome.elapsedMs) };
  const { output, caller, elapsedMs } = outcome.answer;
  const record = output && typeof output === 'object' ? output as Record<string, unknown> : {};
  const rawHits = Array.isArray(record.hits) ? record.hits : [];
  const hits: CloudHit[] = [];
  for (const [index, raw] of rawHits.entries()) {
    const hit = cloudHit(raw, index + 1);
    if (hit) hits.push(hit);
  }
  const failures = Array.isArray(record.routeFailures) ? record.routeFailures.filter((entry) => typeof entry === 'string') : [];
  const report: CloudReport = {
    status: failures.length > 0 ? 'partial' : 'ok',
    hits: hits.length,
    elapsedMs: Math.round(elapsedMs),
    caller,
    ...(typeof record.searchId === 'string' ? { searchId: record.searchId.slice(0, 64) } : {}),
    ...(typeof record.drill === 'string' ? { drill: record.drill.slice(0, 600) } : {}),
    ...(record.facets && typeof record.facets === 'object' ? { facets: record.facets as Record<string, unknown> } : {}),
    ...(record.match && typeof record.match === 'object' && !Array.isArray(record.match) ? { match: record.match as Record<string, unknown> } : {}),
    ...(failures.length > 0
      ? { message: `The cloud search is partial (${redactCredentials(String(failures[0])).slice(0, 300)}); missing cloud hits do not mean none exist.` }
      : {}),
  };
  return { hits, report };
}

const EVIDENCE_PATTERNS: readonly RegExp[] = [
  /(^|[^\w&])#\d{2,}\b/, // a pull request number
  /\b(?!(?:SHA|UTF|ISO|RFC|AES|HTTP|TLS|CVE)-)[A-Z][A-Z0-9]{1,9}-\d{1,6}\b/, // a ticket key: INF-5554, LC-2653
  /(^|\s)@[A-Za-z][\w.-]*/, // an @person
  /\bwho\s+(?!calls?\b|uses?\b|imports?\b|references?\b|depends\b|implements?\b|reads?\b|writes?\b)\w+/i, // who owns, reviewed, wrote
  /\b(changed|modified|touched|reviewed|merged|authored|approved)\b/i,
  /\bwhat\s+(prs?|pull requests?)\b/i,
  /\b(modify|change|touch|review|merge|ship)\w*\b.*\b((this|last|past)\s+(week|month|sprint)|today|yesterday)\b/i,
];

/**
 * Whether a search names a pull request, ticket or @person, or asks who or what changed. Those are the questions the
 * cloud answers best (its exact lane resolves keys and numbers), so its hits lead a merge with local hits. Code
 * questions ("who calls X") are left out.
 */
export function wantsCloudEvidence(query: string, prUrls = false): boolean {
  return EVIDENCE_PATTERNS.some((pattern) => pattern.test(query)) || (prUrls && PR_REFERENCE_PATTERNS.some((pattern) => pattern.test(query)));
}

/** Pull requests named without a bare #123: a PR URL, `owner/repo#123`, `PR 123`, `pull request 123`. */
const PR_REFERENCE_PATTERNS: readonly RegExp[] = [
  /\/pull\/\d+\b/,
  /[\w.-]+\/[\w.-]+#\d+\b/,
  /\b(?:prs?|pull\s+requests?)\s*#?\s*\d{2,}\b/i,
];

function cloudHit(raw: unknown, cloudRank: number): CloudHit | undefined {
  if (!raw || typeof raw !== 'object') return undefined;
  const record = raw as Record<string, unknown>;
  const node = record.node && typeof record.node === 'object' ? record.node as Record<string, unknown> : undefined;
  if (!node || typeof node.id !== 'string' || typeof node.kind !== 'string') return undefined;
  const tagged = tagCloudIds(node) as Record<string, unknown>;
  const shown: Record<string, unknown> = {
    ...tagged,
    name: typeof node.name === 'string' ? node.name : String(node.id),
    ...(typeof node.path === 'string' ? { path: withoutRouteTag(node.path) } : {}),
  };
  const bounded = JSON.stringify(shown).length > MAX_NODE_CHARS
    ? Object.fromEntries(Object.entries(shown).filter(([key]) => ['id', 'kind', 'name', 'path', 'symbol', 'entityKind', 'url'].includes(key)))
    : shown;
  return {
    source: 'cloud',
    node: bounded,
    rank: cloudRank,
    cloudRank,
    ...(typeof record.score === 'number' ? { score: record.score } : {}),
    ...(typeof record.location === 'string' ? { location: withoutRouteTag(record.location) } : {}),
    ...detailOf(record),
    ...cardFieldsOf(record),
  };
}

/** The candidate-card fields of a cloud hit: why it matched, what it links to, how to open it, its best nodes. */
function cardFieldsOf(record: Record<string, unknown>): Record<string, unknown> {
  const links = Array.isArray(record.links) ? record.links.filter((link): link is string => typeof link === 'string').slice(0, 5).map((link) => link.slice(0, 200)) : [];
  const top = Array.isArray(record.top)
    ? tagCloudIds(record.top
      .filter((entry): entry is { id: string; name?: unknown } => Boolean(entry) && typeof entry === 'object' && typeof (entry as { id?: unknown }).id === 'string')
      .slice(0, 5)
      .map((entry) => ({ id: entry.id, name: String(entry.name ?? '').slice(0, 200) }))) as unknown[]
    : [];
  const memories = Array.isArray(record.memories)
    ? tagCloudIds(record.memories
      .filter((entry): entry is Record<string, unknown> => Boolean(entry) && typeof entry === 'object' && typeof (entry as { id?: unknown }).id === 'string')
      .slice(0, 5)
      .map((entry) => ({
        id: entry.id,
        ...(typeof entry.key === 'string' ? { key: entry.key.slice(0, 300) } : {}),
        ...(Array.isArray(entry.aliases)
          ? { aliases: entry.aliases.filter((alias): alias is string => typeof alias === 'string').slice(0, 10).map((alias) => alias.slice(0, 300)) }
          : {}),
        ...(typeof entry.snippet === 'string' ? { snippet: entry.snippet.slice(0, 400) } : {}),
      }))) as unknown[]
    : [];
  const generated = record.generatedFrom as { path?: unknown } | null | undefined;
  const generatedFrom = generated && typeof generated === 'object' && typeof generated.path === 'string'
    ? { path: withoutRouteTag(generated.path).slice(0, 4_096) }
    : undefined;
  return {
    ...(typeof record.why === 'string' ? { why: record.why.slice(0, 400) } : {}),
    ...(links.length > 0 ? { links } : {}),
    ...(record.next === 'context' || record.next === 'get' || record.next === 'traverse' ? { next: record.next } : {}),
    ...(top.length > 0 ? { top } : {}),
    ...(memories.length > 0 ? { memories } : {}),
    ...(generatedFrom ? { generatedFrom } : {}),
  };
}

/** The matched lines a cloud code hit carries, bounded like the schema says. */
function detailOf(record: Record<string, unknown>): Record<string, unknown> {
  const line = positiveLine(record.line);
  const endLine = positiveLine(record.endLine);
  return {
    ...(line === undefined ? {} : { line }),
    ...(line === undefined || endLine === undefined || endLine < line ? {} : { endLine }),
    ...(typeof record.snippet === 'string' ? { snippet: record.snippet.slice(0, 1_000) } : {}),
    ...(typeof record.summary === 'string' ? { summary: record.summary.slice(0, 600) } : {}),
  };
}

function positiveLine(value: unknown): number | undefined {
  return typeof value === 'number' && Number.isSafeInteger(value) && value >= 1 ? value : undefined;
}

async function routed(
  provider: CapabilityProvider,
  setting: Exclude<CloudKnowledgeSetting, { state: 'off' }>,
  name: 'knowledge.context' | 'knowledge.impact',
  rawInput: unknown,
  context: InvocationContext,
  now: () => number,
  remoteOnly: boolean,
): Promise<CapabilityInvocationResult> {
  const { source, cloud: wanted, since, match, edges, filters, walkFilters, cursor, targets, ...localInput } = assertRecord(rawInput ?? {});
  const cloudArgs = { match, edges, filters, walkFilters, cursor, targets };
  const hasCloudArgs = Object.values(cloudArgs).some((value) => value !== undefined);
  const target = localInput.target && typeof localInput.target === 'object'
    ? localInput.target as Record<string, unknown>
    : undefined;
  const cloudId = target?.kind === 'node' && typeof target.id === 'string' ? cloudIdOf(target.id) : undefined;
  if (remoteOnly && (source === 'local' || wanted === false)) {
    throw new CloudBrainError('cloud_brain_rejected', 'Local routing is disabled in explicit remote-only mode.');
  }
  const cloudOnly = remoteOnly || source === 'cloud' || wanted === 'only';
  const cloudSkipped = source === 'local' || wanted === false;
  // Merged mode: a code path or symbol is answered by the cloud's main-branch index when it can, else by the local one.
  const preferCloud = !remoteOnly && !cloudOnly && !cloudSkipped && cloudId === undefined && target?.kind === 'code';
  if (!cloudOnly && cloudId === undefined && !preferCloud) {
    if (hasCloudArgs) throw new CloudBrainError('cloud_brain_rejected', `${Object.entries(cloudArgs).filter(([, value]) => value !== undefined).map(([key]) => key).join(', ')} go to the cloud Brain; pass a cloud: node id, a code path or source: 'cloud'.`);
    const local = await provider.invoke(name, localInput, context);
    return { ...local, output: { ...(local.output as Record<string, unknown>), source: 'local' } };
  }
  if (preferCloud && setting.state === 'misconfigured' && !hasCloudArgs) {
    return withLocalFallback(provider, name, localInput, context, { status: 'misconfigured', message: setting.message.slice(0, 2_000) });
  }
  const route = requireRoute(setting);
  if (target?.kind === 'memory') {
    throw new CloudBrainError('cloud_brain_rejected', 'Memory targets are local; pass a cloud: node id or a code path to reach the cloud Brain.');
  }
  const limit = typeof localInput.limit === 'number' ? Math.min(localInput.limit, MAX_CLOUD_GRAPH_LIMIT) : undefined;
  const limitClamped = typeof localInput.limit === 'number' && localInput.limit > MAX_CLOUD_GRAPH_LIMIT;
  const maxDepth = typeof localInput.maxDepth === 'number' ? localInput.maxDepth : undefined;
  const callOptions = {
    deadlineMs: route.configuration.timeoutMs,
    signal: context.signal as AbortSignal | undefined,
    context,
  };
  const started = now();
  let answer: { output: unknown; caller: string; elapsedMs: number };
  const targetNotes: string[] = [];
  try {
    const resolved = await cloudRefOf(route.route, target, cloudId, callOptions);
    const ref = resolved.ref;
    if (resolved.note) targetNotes.push(resolved.note);
    if (name === 'knowledge.context') {
      const more = Array.isArray(targets) ? targets : [];
      const extraRefs = await Promise.all(more.map(async (entry) => {
        const record = entry && typeof entry === 'object' ? entry as Record<string, unknown> : undefined;
        const extra = await cloudRefOf(route.route, record, record?.kind === 'node' && typeof record.id === 'string' ? cloudIdOf(record.id) : undefined, callOptions);
        if (extra.note) targetNotes.push(extra.note);
        return extra.ref;
      }));
      const traverseFilters = [
        ...(Array.isArray(filters) ? filters : []),
        ...(typeof since === 'string' ? [{ field: 'updatedAt', op: 'range', value: { gte: since } }] : []),
      ];
      answer = await route.route.call('traverse', {
        from: [ref, ...extraRefs],
        depth: Math.min(maxDepth ?? 1, MAX_TRAVERSE_DEPTH),
        ...(match !== undefined ? { match } : {}),
        ...(Array.isArray(edges) ? { edges: edges.map(traverseEdge) } : {}),
        ...(walkFilters !== undefined ? { walkFilters } : {}),
        ...(limit !== undefined ? { limit } : {}),
        ...(traverseFilters.length > 0 ? { filters: traverseFilters } : {}),
      }, callOptions);
    } else {
      const impactEdges = Array.isArray(edges) ? edges.map(impactEdge) : localInput.edgeTypes;
      answer = await route.route.call('impact', {
        target: ref,
        direction: IMPACT_DIRECTION[String(localInput.direction)] ?? 'downstream',
        ...(maxDepth !== undefined ? { depth: maxDepth } : {}),
        ...(Array.isArray(impactEdges) ? { edges: impactEdges } : {}),
        ...(filters !== undefined ? { filters } : {}),
        ...(cursor !== undefined ? { cursor } : {}),
        ...(limit !== undefined ? { limit } : {}),
      }, callOptions);
    }
  } catch (error) {
    if (!preferCloud || remoteOnly || hasCloudArgs || (context.signal as AbortSignal | undefined)?.aborted) throw error;
    return withLocalFallback(provider, name, localInput, context, failureReport(error, now() - started));
  }
  const envelope = cloudEnvelope(answer, route.configuration.maxResultChars);
  const clampNote = `limit ${String(localInput.limit)} is above the maximum of ${MAX_CLOUD_GRAPH_LIMIT}; the cloud was asked for ${MAX_CLOUD_GRAPH_LIMIT}.`;
  const notes = [...targetNotes, ...(limitClamped ? [clampNote] : [])];
  const report = envelope.cloud as CloudReport;
  return result({
    target: null,
    nodes: [],
    paths: [],
    generation: 0,
    ...(name === 'knowledge.impact'
      ? { direction: localInput.direction, maxDepth: maxDepth ?? DEFAULT_IMPACT_DEPTH }
      : {}),
    ...envelope,
    ...graphView(envelope),
    ...(limitClamped ? { truncated: true } : {}),
    ...(notes.length > 0 ? {
      cloud: { ...report, message: [report.message, ...notes].filter(Boolean).join(' ').slice(0, 2_000) },
    } : {}),
  }, KNOWLEDGE_PROVIDER_ID, name, rawInput, context);
}


/** A traverse edge as the cloud wants it: an object; a bare kind follows both directions, the cloud's own default. */
function traverseEdge(edge: unknown): unknown {
  return typeof edge === 'string' ? { kind: edge, direction: 'both' } : edge;
}

/** An impact edge as the cloud wants it: a kind string; an object's direction is not an impact argument. */
function impactEdge(edge: unknown): unknown {
  return edge && typeof edge === 'object' && typeof (edge as { kind?: unknown }).kind === 'string' ? (edge as { kind: string }).kind : edge;
}

const GRAPH_LIST_LIMIT = 100;
const LOCAL_NODE_KINDS = new Set(['memory', 'code_file', 'symbol', 'execution_flow', 'evidence']);

/** A cloud node in the declared node shape: other kinds are entities named by entityKind; what the shape has no field for is in fields. */
function declaredNode(raw: unknown, extra: Record<string, unknown> = {}): Record<string, unknown> | undefined {
  if (!raw || typeof raw !== 'object') return undefined;
  const node = raw as Record<string, unknown>;
  if (typeof node.id !== 'string' || node.id === '') return undefined;
  const kind = typeof node.kind === 'string' ? node.kind : 'node';
  const ref = node.ref && typeof node.ref === 'object' ? node.ref as Record<string, unknown> : {};
  const fields = {
    ...extra,
    kind,
    ...(node.props && typeof node.props === 'object' ? { props: node.props } : {}),
    ...(Object.keys(ref).length > 0 ? { ref } : {}),
    ...(node.edgeCounts ? { edgeCounts: node.edgeCounts } : {}),
    ...(node.via !== undefined ? { via: node.via } : {}),
    ...(node.chain !== undefined ? { chain: node.chain } : {}),
    ...(typeof node.indexedAt === 'string' ? { indexedAt: node.indexedAt } : {}),
    ...(typeof node.depth === 'number' ? { depth: node.depth } : {}),
  };
  return {
    id: node.id.slice(0, 4_096),
    kind: LOCAL_NODE_KINDS.has(kind) ? kind : 'entity',
    name: String(node.name ?? node.id).slice(0, 4_096),
    ...(LOCAL_NODE_KINDS.has(kind) ? {} : { entityKind: kind.slice(0, 64) }),
    ...(typeof ref.url === 'string' && ref.url.length <= 4_096 ? { url: ref.url } : {}),
    ...(typeof ref.path === 'string' && ref.path.length <= 4_096 ? { path: ref.path } : typeof node.path === 'string' ? { path: node.path.slice(0, 4_096) } : {}),
    ...(typeof node.symbol === 'string' ? { symbol: node.symbol.slice(0, 1_024) } : {}),
    fields,
  };
}

function viaOf(node: Record<string, unknown> | undefined): { edge?: string; direction?: string; fromId?: string } {
  const via = Array.isArray(node?.via) ? node.via[0] : node?.via;
  return via && typeof via === 'object' ? via as { edge?: string; direction?: string; fromId?: string } : {};
}

/**
 * The top-level target, nodes and paths of a traverse or impact answer, taken from the cloud answer that `result` keeps
 * verbatim: traverse's `from[0]` and `levels[].nodes` (depth from the level), impact's `target` and `nodes` (depth and
 * chain as the cloud gives them). Each path is one reached node's route: its `chain` for impact, its `via` edge for traverse.
 */
function graphView(envelope: Record<string, unknown>): Record<string, unknown> {
  const answer = envelope.result && typeof envelope.result === 'object' ? envelope.result as Record<string, unknown> : undefined;
  if (!answer) return {};
  const targetRaw = (answer.target && typeof answer.target === 'object' ? answer.target : Array.isArray(answer.from) ? answer.from[0] : undefined) as Record<string, unknown> | undefined;
  const reached: Array<Record<string, unknown>> = [];
  const levels = Array.isArray(answer.levels) ? answer.levels as Array<Record<string, unknown>> : [];
  for (const level of levels) {
    for (const node of Array.isArray(level?.nodes) ? level.nodes as Array<Record<string, unknown>> : []) reached.push({ ...node, depth: node.depth ?? level.depth });
  }
  for (const node of Array.isArray(answer.nodes) ? answer.nodes as Array<Record<string, unknown>> : []) reached.push(node);
  const byId = new Map<string, Record<string, unknown>>();
  for (const start of [...(Array.isArray(answer.from) ? answer.from : []), ...(targetRaw ? [targetRaw] : [])] as Array<Record<string, unknown>>) {
    if (typeof start?.id === 'string') byId.set(start.id, start);
  }
  for (const node of reached) if (typeof node.id === 'string' && !byId.has(node.id)) byId.set(node.id, node);
  const nodeOf = (id: string) => declaredNode(byId.get(id) ?? { id, name: id }) as Record<string, unknown>;
  const nodes = reached.flatMap((node) => declaredNode(node) ?? []);
  const paths = reached.flatMap((node) => {
    const own = viaOf(node);
    const chain = Array.isArray(node.chain) ? node.chain.filter((id): id is string => typeof id === 'string') : own.fromId ? [own.fromId, String(node.id)] : [];
    if (chain.length < 2) return [];
    const hops = chain.slice(1).map((id) => viaOf(byId.get(id)));
    const names = chain.map((id) => String(byId.get(id)?.name ?? id));
    return [{
      nodes: chain.map(nodeOf),
      edges: hops.map((hop) => String(hop.edge ?? 'unknown').slice(0, 128)),
      directions: hops.map((hop) => (hop.direction === 'out' ? 'outbound' : hop.direction === 'in' ? 'inbound' : 'both')),
      explanation: names.map((name, index) => (index === 0 ? name : `-${String(hops[index - 1]!.edge ?? '?')}-> ${name}`)).join(' ').slice(0, 20_000),
    }];
  });
  const cut = nodes.length > GRAPH_LIST_LIMIT || paths.length > GRAPH_LIST_LIMIT
    || levels.some((level) => level?.truncated === true) || (typeof answer.total === 'number' && Array.isArray(answer.nodes) && answer.total > answer.nodes.length);
  return {
    target: targetRaw ? declaredNode(targetRaw) ?? null : null,
    nodes: nodes.slice(0, GRAPH_LIST_LIMIT),
    paths: paths.slice(0, GRAPH_LIST_LIMIT),
    ...(cut ? { truncated: true } : {}),
  };
}

/** knowledge.impact's inbound (what depends on the target) is the cloud's downstream; outbound is upstream. */
const IMPACT_DIRECTION: Readonly<Record<string, string>> = { inbound: 'downstream', outbound: 'upstream', both: 'both' };
const DEFAULT_IMPACT_DEPTH = 3;

const SYMBOL_CANDIDATE_LIMIT = 20;

/** The qualified name in a cloud code id (`Method:<encoded path>:Outer.name#key=…` gives `Outer.name`). */
function qualifiedNameOf(id: string): string | undefined {
  const parts = id.split('#')[0]!.split(':');
  return parts.length >= 3 ? parts.slice(2).join(':') : undefined;
}

/**
 * The ref the cloud walks from: a cloud id as is, else the target's repository path. A path with a symbol is resolved to
 * the symbol's id: the cloud's code index answers an exhaustive name filter only with a code kind, so the lookup names
 * kind symbol. A symbol may be qualified (`Outer.name`). Several matching symbols are an ambiguous target: the call is
 * rejected with the candidates, never answered for a guess. When no symbol matches, the file stands for it and `note` says so.
 */
async function cloudRefOf(
  route: CloudRoute,
  target: Record<string, unknown> | undefined,
  cloudId: string | undefined,
  options: Parameters<CloudRoute['call']>[2],
): Promise<{ ref: string; note?: string }> {
  if (cloudId !== undefined) return { ref: cloudId };
  const path = typeof target?.path === 'string' && target.path.length > 0 ? withoutRouteTag(target.path) : undefined;
  const symbol = typeof target?.symbol === 'string' && target.symbol.length > 0 ? target.symbol : undefined;
  if (path !== undefined && symbol !== undefined) {
    const name = symbol.split(/\.|::/).at(-1)!;
    const qualified = name !== symbol;
    let lookupFailed: string | undefined;
    try {
      const found = await route.call('search', {
        mode: 'exhaustive',
        limit: SYMBOL_CANDIDATE_LIMIT,
        filters: [
          { field: 'kind', op: 'eq', value: 'symbol' },
          { field: 'name', op: 'eq', value: name },
          { field: 'path', op: 'prefix', value: path },
        ],
      }, options);
      const results = (found.output as { results?: Array<{ id?: unknown; ref?: { path?: unknown } }> } | null)?.results ?? [];
      const inFile = results.filter((row): row is { id: string; ref?: { path?: unknown } } => typeof row.id === 'string'
        && (typeof row.ref?.path !== 'string' || row.ref.path === path));
      const exact = inFile.filter((row) => qualifiedNameOf(row.id) === symbol);
      const matching = qualified
        ? inFile.filter((row) => { const own = qualifiedNameOf(row.id); return own === undefined || own === symbol || own.endsWith(`.${symbol}`); })
        : inFile;
      const chosen = exact.length === 1 ? exact : matching;
      if (chosen.length === 1) return { ref: chosen[0]!.id };
      if (chosen.length > 1) {
        const listed = chosen.slice(0, 10).map((row) => `${qualifiedNameOf(row.id) ?? name} (cloud:${row.id})`).join('; ');
        throw new CloudBrainError(
          'cloud_brain_rejected',
          `${symbol} names ${chosen.length}${chosen.length >= SYMBOL_CANDIDATE_LIMIT ? '+' : ''} symbols in ${path}: ${listed}. Pass one as {kind: 'node', id} or qualify the symbol (Outer.${name}).`,
          { toolStatus: 'ambiguous_ref' },
        );
      }
    } catch (error) {
      if (options.signal?.aborted || (isCloudBrainError(error) && error.toolStatus === 'ambiguous_ref')) throw error;
      lookupFailed = redactCredentials(describeError(error)).slice(0, 300);
    }
    return {
      ref: path,
      note: lookupFailed === undefined
        ? `No symbol ${symbol} in ${path} in the cloud index; the answer is for the whole file.`
        : `The lookup of symbol ${symbol} in ${path} failed (${lookupFailed}); the answer is for the whole file.`,
    };
  }
  const ref = path ?? symbol;
  if (ref === undefined) throw new CloudBrainError('cloud_brain_rejected', 'A code target for the cloud Brain needs a path or a symbol.');
  return { ref };
}

/** The local answer to a code target the cloud could not give, labelled local with the cloud's report beside it. */
async function withLocalFallback(
  provider: CapabilityProvider,
  name: 'knowledge.context' | 'knowledge.impact',
  localInput: Record<string, unknown>,
  context: InvocationContext,
  report: CloudReport,
): Promise<CapabilityInvocationResult> {
  const local = await provider.invoke(name, localInput, context);
  return { ...local, output: { ...(local.output as Record<string, unknown>), source: 'local', cloud: report } };
}

async function cloudOnlyCall(
  setting: Exclude<CloudKnowledgeSetting, { state: 'off' }>,
  name: string,
  rawInput: unknown,
  context: InvocationContext,
  now: () => number,
): Promise<CapabilityInvocationResult> {
  if (name === 'knowledge.cloud_status') return cloudStatus(setting, rawInput, context, now);
  if (setting.state === 'misconfigured') throw new CloudBrainError('cloud_brain_disabled', setting.message);
  const entry = CLOUD_ONLY_BY_NAME.get(name)!;
  const input = assertRecord(rawInput ?? {});
  let args: Record<string, unknown> = input;
  if (name === 'memory.cloud_get' && typeof input.id === 'string' && input.id.startsWith(CLOUD_ID_PREFIX)) {
    args = { ...input, id: input.id.slice(CLOUD_ID_PREFIX.length) };
  }
  if (name === 'memory.cloud_link') {
    args = { ...input, audience: CLOUD_WRITE_AUDIENCE, source: typeof input.source === 'string' ? input.source : CLOUD_WRITE_SOURCE };
  }
  if (name === 'memory.cloud_retire') args = { ...input, privateOnly: true };
  if (name === 'knowledge.path') {
    const { from, to, ...rest } = input;
    args = { ...rest, from: bareRef(from), to: bareRef(to) };
  }
  if (name === 'knowledge.feedback') {
    args = {
      ...input,
      ...(Array.isArray(input.used) ? { used: input.used.map(bareRef) } : {}),
      ...(Array.isArray(input.irrelevant)
        ? { irrelevant: input.irrelevant.map((entry) => (entry && typeof entry === 'object' ? { ...entry, nodeId: bareRef((entry as { nodeId?: unknown }).nodeId) } : entry)) }
        : {}),
    };
  }
  if (name === 'memory.cloud_search') {
    args = {
      mode: 'ranked',
      query: input.content,
      limit: Math.min(typeof input.limit === 'number' ? input.limit : DEFAULT_SEARCH_HITS, MAX_CLOUD_SEARCH_LIMIT),
      filters: [{ field: 'kind', op: 'eq', value: 'memory' }],
    };
  }
  if (name === 'sessions.cloud_search') {
    args = { ...input, limit: Math.min(typeof input.limit === 'number' ? input.limit : DEFAULT_SEARCH_HITS, MAX_CLOUD_SEARCH_LIMIT) };
  }
  if (name === 'sessions.cloud_share' && input.parts !== undefined) {
    if (input.part !== undefined) throw new CloudBrainError('cloud_brain_rejected', 'Pass either part or parts, not both.');
    const shared = await shareSession(input as unknown as SessionShareInput, {
      call: setting.route.call.bind(setting.route),
      deadlineMs: setting.configuration.timeoutMs,
      signal: context.signal as AbortSignal | undefined,
      context,
    });
    return result(cloudEnvelope(shared, setting.configuration.maxResultChars), KNOWLEDGE_PROVIDER_ID, name, rawInput, context);
  }
  const answer = await setting.route.call(entry.tool, args, {
    deadlineMs: setting.configuration.timeoutMs,
    signal: context.signal as AbortSignal | undefined,
    context,
  });
  return result(cloudEnvelope(answer, setting.configuration.maxResultChars), KNOWLEDGE_PROVIDER_ID, name, rawInput, context);
}

/** A cloud: id's own text; any other ref (a path, URL, ticket key) as written. */
function bareRef(value: unknown): unknown {
  return typeof value === 'string' && value.startsWith(CLOUD_ID_PREFIX) ? value.slice(CLOUD_ID_PREFIX.length) : value;
}
/** The cloud Brain's own status; the cloud's state (starting, down, misconfigured) is the answer, never an error. */
async function cloudStatus(
  setting: Exclude<CloudKnowledgeSetting, { state: 'off' }>,
  rawInput: unknown,
  context: InvocationContext,
  now: () => number,
): Promise<CapabilityInvocationResult> {
  let output: Record<string, unknown>;
  if (setting.state === 'misconfigured') {
    output = { source: 'cloud', cloud: { status: 'misconfigured', message: setting.message.slice(0, 2_000) }, truncated: false };
  } else {
    const started = now();
    try {
      const answer = await setting.route.call(CLOUD_STATUS_TOOL, {}, {
        deadlineMs: setting.configuration.timeoutMs,
        signal: context.signal as AbortSignal | undefined,
        context,
      });
      output = cloudEnvelope(answer, setting.configuration.maxResultChars);
    } catch (error) {
      output = { source: 'cloud', cloud: failureReport(error, now() - started, ''), truncated: false };
    }
  }
  return result(output, KNOWLEDGE_PROVIDER_ID, 'knowledge.cloud_status', rawInput, context);
}

function requireRoute(setting: Exclude<CloudKnowledgeSetting, { state: 'off' }>): Extract<CloudKnowledgeSetting, { state: 'on' }> {
  if (setting.state === 'misconfigured') throw new CloudBrainError('cloud_brain_disabled', setting.message);
  return setting;
}

function cloudEnvelope(
  answer: { output: unknown; caller: string; elapsedMs: number },
  maxResultChars: number,
): Record<string, unknown> {
  const output = tagCloudIds(answer.output);
  const gap = partialAnswer(output);
  const report: CloudReport = {
    status: gap ? 'partial' : 'ok',
    elapsedMs: Math.round(answer.elapsedMs),
    caller: answer.caller,
    ...(gap ? { message: gap } : {}),
  };
  const serialized = JSON.stringify(output) ?? 'null';
  if (serialized.length <= maxResultChars) return { source: 'cloud', cloud: report, truncated: false, result: output };
  const cut = `The cloud answer had ${serialized.length} characters; the first ${maxResultChars} are in resultText. Narrow it (limit, since, kinds) for a whole answer.`;
  return {
    source: 'cloud',
    cloud: { ...report, message: (gap ? `${gap} ${cut}` : cut).slice(0, 2_000) },
    truncated: true,
    resultText: serialized.slice(0, maxResultChars),
  };
}

/** Names what the cloud reported as missing from an answer, so a thin answer is not read as "nothing exists". */
export function partialAnswer(output: unknown): string | undefined {
  if (!output || typeof output !== 'object') return undefined;
  const record = output as {
    status?: unknown;
    notes?: unknown;
    coverage?: { partial?: unknown; sources?: unknown };
    routeFailures?: unknown;
    recall?: unknown;
    entityRecall?: { error?: unknown };
  };
  if (record.coverage?.partial === true) {
    const sources = record.coverage.sources && typeof record.coverage.sources === 'object'
      ? Object.entries(record.coverage.sources as Record<string, unknown>)
        .filter(([, state]) => state !== 'ok' && state !== 'skipped')
        .map(([source, state]) => `${source}=${String(state)}`)
      : [];
    return `The cloud answer is partial${sources.length ? ` (${sources.join(', ')})` : ''}: a short answer does not mean nothing exists; retry later.`;
  }
  if (record.status === 'partial') {
    const notes = Array.isArray(record.notes) ? record.notes.filter((note): note is string => typeof note === 'string') : [];
    return `The cloud answer is partial${notes.length ? ` (${redactCredentials(notes.join('; ')).slice(0, 600)})` : ''}: a short answer does not mean nothing exists.`;
  }
  if (Array.isArray(record.routeFailures) && record.routeFailures.length > 0) {
    return `The cloud answer is partial (${redactCredentials(String(record.routeFailures[0])).slice(0, 300)}).`;
  }
  if (record.recall === 'failed') {
    const reason = typeof record.entityRecall?.error === 'string'
      ? `: ${redactCredentials(record.entityRecall.error).slice(0, 160)}`
      : '';
    return `The cloud memory recall failed on the server${reason}. Its lexical fallback is in result (entityMemories); few or no matches may be why.`;
  }
  return undefined;
}

const FAILURE_STATUS: Readonly<Record<string, CloudStatus>> = {
  cloud_brain_timeout: 'timeout',
  cloud_brain_starting: 'starting',
  cloud_brain_unavailable: 'unavailable',
  cloud_brain_busy: 'busy',
  cloud_brain_auth_failed: 'auth_failed',
  cloud_brain_rejected: 'rejected',
  cloud_brain_cancelled: 'cancelled',
};

function failureReport(error: unknown, elapsedMs: number, consequence = ' These results are local only.'): CloudReport {
  const code = isCloudBrainError(error) ? error.code : undefined;
  const status = (code && FAILURE_STATUS[code]) ?? 'failed';
  return {
    status,
    elapsedMs: Math.max(0, Math.round(elapsedMs)),
    message: `${redactCredentials(describeError(error)).slice(0, 1_500)}${consequence}`,
    ...(isCloudBrainError(error) && error.retryAfterSeconds !== undefined ? { retryAfterSeconds: error.retryAfterSeconds } : {}),
  };
}

function describeError(error: unknown): string {
  if (error instanceof Error) {
    const code = (error as { code?: unknown }).code;
    return `${typeof code === 'string' ? `${code}: ` : ''}${error.message}`;
  }
  return String(error);
}

/** The cloud id inside a cloud: id; cloud entity ids (entity:…, never produced locally) are accepted bare too. */
export function cloudIdOf(id: string): string | undefined {
  if (id.startsWith(CLOUD_ID_PREFIX)) {
    const inner = id.slice(CLOUD_ID_PREFIX.length);
    return inner.length > 0 ? inner : undefined;
  }
  return /^(\[[^\]]+\])?entity:/.test(id) ? id : undefined;
}

/** Keys that hold one cloud node id, or (`chain`) a list of them. */
const ID_KEYS = new Set(['id', 'fromId']);

/** Copies a cloud answer with every node id prefixed cloud:, so a follow-up call routes back to the cloud. */
export function tagCloudIds(value: unknown, depth = 0): unknown {
  if (depth > 32) return value;
  if (Array.isArray(value)) return value.map((item) => tagCloudIds(item, depth + 1));
  if (!value || typeof value !== 'object') return value;
  return Object.fromEntries(Object.entries(value as Record<string, unknown>).map(([key, item]) => {
    if (ID_KEYS.has(key) && typeof item === 'string') return [key, tagged(item)];
    if (key === 'chain' && Array.isArray(item)) return [key, item.map((entry) => (typeof entry === 'string' ? tagged(entry) : tagCloudIds(entry, depth + 1)))];
    return [key, tagCloudIds(item, depth + 1)];
  }));
}

function tagged(id: string): string {
  return id.startsWith(CLOUD_ID_PREFIX) ? id : `${CLOUD_ID_PREFIX}${id}`;
}

/** The repository path inside a code node id (`[tag]Method:services%2Fa.go:Server.Run#key=…`), when it is one. */
export function codePathOf(id: string): string | undefined {
  const match = /^(?:\[[^\]]+\])?[A-Z][A-Za-z]*:([^:#]+)/.exec(id);
  if (!match || /^(entity|changes|memory)$/i.test(id.replace(/^\[[^\]]+\]/, '').split(':')[0]!)) return undefined;
  try {
    const path = decodeURIComponent(match[1]!);
    return path.includes('/') || path.includes('.') ? path : undefined;
  } catch {
    return undefined;
  }
}

function withoutRouteTag(text: string): string {
  return text.replace(/^\[[^\]]+\]/, '');
}

/** Keys a code hit by repository path and name, so the cloud copy of code the local index already returned is dropped. */
function codeKey(node: unknown): string[] {
  if (!node || typeof node !== 'object') return [];
  const record = node as Record<string, unknown>;
  if (typeof record.kind !== 'string' || !CODE_KINDS.has(record.kind) || typeof record.path !== 'string') return [];
  return [`${record.kind}|${withoutRouteTag(record.path)}|${String(record.name ?? '')}`];
}

function searchDescriptor(descriptor: CapabilityDescriptor): CapabilityDescriptor {
  const output = descriptor.outputSchema as Record<string, any>;
  const hits = output.properties?.hits as Record<string, any> | undefined;
  const localHit = hits?.items as Record<string, any> | undefined;
  const input = descriptor.inputSchema as Record<string, any>;
  return {
    ...descriptor,
    description: `${descriptor.description} With the cloud route on, the cloud Brain answers (main-branch code, company memories, PRs, tickets, meetings, people), each hit labelled source cloud, with a cloud report; the local index answers when the cloud cannot, or with cloud: false. It is the cloud's search tool: an exact key, #number, URL or email ranks that node first; kinds narrow the hits (the cloud's knowledge.schema lists them). A plain query is ranked and merged; with filters, aggregate, sort, cursor, granularity, group, within, mode: 'exhaustive' or no query, the cloud's search tool is asked as given and its rows are in hits and its whole answer (nodes, total, counts, cursor) is in result. Cloud hits are candidates to scan, not one top answer: each has why (the lanes that found it and the score), links, snippet and next; cloud.searchId names the search and cloud.facets say what its top 200 candidates are made of. Open the fitting hits with knowledge.context; narrow or page them with knowledge.refine (no new search); when none fits, call knowledge.feedback with the searchId and what was missing.`,
    inputSchema: {
      ...input,
      required: (Array.isArray(input.required) ? input.required : []).filter((key: string) => key !== 'query'),
      properties: {
        ...input.properties,
        limit: { type: 'integer', minimum: 1, maximum: 500, description: 'Ranked: 1..20. With filters, aggregate, sort or cursor (exhaustive): the page size, default 100, at most 500.' },
        mode: { enum: ['ranked', 'exhaustive'], description: 'ranked: the best matches of query. exhaustive: every node the filters match, sorted and paged, with the total; its rows are in hits and the whole answer (total, counts, cursor) is in result. Exhaustive takes NO query: omit query (an empty string and a non-empty query are both rejected). Default: ranked with a query, else exhaustive.' },
        filters: filtersSchema('Cloud only. All must match (AND). Example: [{field:"kind",op:"eq",value:"ticket"},{field:"completedAt",op:"range",value:{gte:"2026-10-01T11:04:00Z",lte:"2026-10-01T11:06:00Z"}}]. `edge:<kind>:in|out|both` filters by relations. Fields and edge kinds: knowledge.schema.'),
        cursor: { type: 'string', minLength: 1, maxLength: 400, description: 'Cloud only, exhaustive: the cursor of the page before (from result).' },
        sort: { type: 'object', properties: { field: { type: 'string', minLength: 1, maxLength: 128 }, order: { enum: ['asc', 'desc'] } }, required: ['field'], description: 'Cloud only, exhaustive: default updatedAt, newest first.' },
        aggregate: { type: 'object', properties: { count: { type: 'boolean' }, groupBy: { type: 'string', minLength: 1, maxLength: 128 } }, description: 'Cloud only, exhaustive: the total and the count per value of groupBy (a schema field, e.g. team) instead of the nodes.' },
        granularity: { enum: ['node', 'file'], description: 'Cloud only, ranked code hits: node (default) ranks every node; file ranks each code file by its best three nodes.' },
        within: {
          type: 'object',
          description: 'Cloud only, ranked: rank query only among the nodes near seed nodes. Seeds are `from` (node ids or refs, at most 20) or the best matches of `seedQuery`; the scope is the nodes within `depth` (0..3, default 1) edges of them, over `edges` ([{kind, direction?}], default all); `filters` (kind, fields, `edge:<kind>` conditions on neighbours) apply to the scope before ranking. The cloud answer, with its `scope`, is in result. Example: {query: "refund complaints", within: {from: ["entity:brand_product/123"], depth: 2}, filters: [{field:"kind",op:"in",value:["brand_insight","ticket","memory"]}]}. Needs the cloud to have scoped search on.',
          properties: {
            from: { type: 'array', minItems: 1, maxItems: 20, items: { type: 'string', minLength: 1, maxLength: 1_024 } },
            seedQuery: { type: 'string', minLength: 1, maxLength: 2_000 },
            seedLimit: { type: 'integer', minimum: 1, maximum: 10 },
            edges: { type: 'array', maxItems: 32, items: { type: 'object', properties: { kind: { type: 'string', minLength: 1, maxLength: 128 }, direction: { enum: ['out', 'in', 'both'] } }, required: ['kind'] } },
            depth: { type: 'integer', minimum: 0, maximum: 3 },
            walkFilters: filtersSchema('Which nodes the scope walk may enter.'),
            includeSeeds: { type: 'boolean' },
          },
        },
        group: { enum: ['file', 'node'], description: 'Cloud only, ranked: file (default) groups code hits under their file with topNodes; node lists every node.' },
        cloud: {
          anyOf: [{ type: 'boolean' }, { const: 'only' }],
          description: 'Default, when the cloud route is on: the cloud Brain alone (code of the main branch, memories, PRs, tickets, people), and the local index only when the cloud cannot answer. true adds the local index\'s hits; false searches the local index alone; \'only\' is the cloud alone, an error if it cannot answer.',
        },
        entityTypes: { type: 'array', minItems: 1, maxItems: 7, items: { enum: ENTITY_TYPES }, description: 'Cloud only: keep these entity types. Implies cloud: \'only\'.' },
      },
    },
    outputSchema: {
      ...output,
      properties: {
        ...output.properties,
        ...(hits && localHit ? {
          hits: {
            ...hits,
            items: {
              anyOf: [
                {
                  ...localHit,
                  properties: {
                    ...localHit.properties,
                    source: { const: 'local' },
                    cloudDuplicate: {
                      type: 'object',
                      description: 'The cloud returned the same code (same path, name and place); its rank, score and snippet are kept here.',
                      properties: { id: { type: 'string' }, cloudRank: { type: 'number' }, score: { type: 'number' }, snippet: { type: 'string', maxLength: 1_000 } },
                      additionalProperties: false,
                    },
                  },
                },
                CLOUD_HIT_SCHEMA,
              ],
            },
          },
        } : {}),
        source: SOURCE_SCHEMA,
        result: ROUTED_RESULT_PROPERTIES.result!,
        resultText: ROUTED_RESULT_PROPERTIES.resultText!,
        cloud: CLOUD_REPORT_SCHEMA,
        localMemory: {
          type: 'object',
          description: 'Present when this workspace\'s local memory indexes were skipped because their runtime lease is held elsewhere: the answer is the cloud Brain\'s (or the workspace index\'s) alone, without local memories.',
          properties: {
            status: { const: 'skipped' },
            skipped: { type: 'array', items: { type: 'string' } },
            reason: { type: 'string' },
            since: { type: 'string' },
          },
        },
      },
    },
  };
}

function routedDescriptor(descriptor: CapabilityDescriptor): CapabilityDescriptor {
  const output = descriptor.outputSchema as Record<string, any>;
  const input = descriptor.inputSchema as Record<string, any>;
  const context = descriptor.name === 'knowledge.context';
  return {
    ...descriptor,
    description: `${descriptor.description} A cloud: node id (from a cloud hit) or source: 'cloud' goes to the cloud Brain (${context ? 'its traverse tool: the neighbours of the node, maxDepth 1 to 3; edges, filters, walkFilters, match and targets narrow the walk' : 'its impact tool: inbound is what depends on the target, outbound what it depends on; edges, filters and cursor narrow and page the answer'}); a cloud answer is mapped into target, nodes (with fields.depth, fields.via) and paths, with the whole answer unchanged in result, source 'cloud' and a cloud report.`,
    inputSchema: {
      ...input,
      properties: {
        ...input.properties,
        source: { enum: ['local', 'cloud'], description: 'Where to look. Default: cloud for cloud: ids; for a code path or symbol the cloud when it answers, else the local index; local for anything else. cloud with a code target asks the main branch in the cloud Brain.' },
        cloud: { anyOf: [{ type: 'boolean' }, { const: 'only' }], description: "'only' is source: 'cloud' (the cloud alone, an error if it cannot answer); false is source: 'local'. limit above 100 is lowered to the cloud's 100 and the answer says truncated." },
        ...(context ? {
          since: { type: 'string', pattern: '^\\d{4}-\\d{2}-\\d{2}', maxLength: 40, description: 'Cloud only: keep the reached nodes updated since this date (traverse).' },
          targets: { type: 'array', maxItems: 19, items: { type: 'object' }, description: 'Cloud only: more start nodes, each shaped like target; with match: all the answer keeps the nodes reached from every start.' },
          match: { enum: ['any', 'all'], description: 'Cloud only, with targets: any (default) lists nodes reached from at least one start, all those reached from every one.' },
          edges: { type: 'array', maxItems: 32, items: { anyOf: [{ type: 'string', minLength: 1, maxLength: 128 }, { type: 'object', properties: { kind: { type: 'string', minLength: 1, maxLength: 128 }, direction: { enum: ['out', 'in', 'both'] } }, required: ['kind'] }] }, description: 'Cloud only: the edge kinds to follow, each a kind string (both directions) or {kind, direction}; default every kind, both directions. Kinds are in knowledge.schema.' },
          filters: filtersSchema('Cloud only: which reached nodes are returned; the walk still passes through the others.'),
          walkFilters: filtersSchema('Cloud only: which nodes the walk may enter; a node that fails them is neither returned nor walked through.'),
        } : {
          edges: { type: 'array', maxItems: 32, items: { anyOf: [{ type: 'string', minLength: 1, maxLength: 128 }, { type: 'object', properties: { kind: { type: 'string', minLength: 1, maxLength: 128 } }, required: ['kind'] }] }, description: 'Cloud only: the dependency edge kinds to walk (default all of them); same as edgeTypes.' },
          filters: filtersSchema('Cloud only: all must match (AND); keeps the listed nodes whose fields match.'),
          cursor: { type: 'string', minLength: 1, maxLength: 400, description: 'Cloud only: the cursor of the page before (from result).' },
        }),
      },
    },
    outputSchema: {
      ...output,
      properties: { ...output.properties, ...ROUTED_RESULT_PROPERTIES },
      // A cloud answer's edges are the cloud's own kinds (implements, derived_from, ...), not the local index's.
      ...(output.$defs?.path ? {
        $defs: {
          ...output.$defs,
          path: {
            ...output.$defs.path,
            properties: {
              ...output.$defs.path.properties,
              edges: { type: 'array', maxItems: 100, items: { type: 'string', maxLength: 128 } },
              directions: { type: 'array', maxItems: 100, items: { enum: ['inbound', 'outbound', 'both'] } },
            },
          },
        },
      } : {}),
    },
  };
}
