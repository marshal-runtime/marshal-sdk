import { randomUUID } from 'node:crypto';
import { CloudBrainError } from './cloudBrain/errors.js';
import type { CloudBrainRoute } from './cloudBrain/route.js';

/** The Brain refuses a request over 1 MB; a part is checked against this before anything is sent. */
export const MAX_SHARE_REQUEST_BYTES = 1_000_000;
export const MAX_SHARE_PARTS = 64;
/** How long part 0 waits, in total, for the Brain to finish cleaning up an earlier unshare. */
export const CLEANING_WAIT_MS = 30_000;
const CLEANING_FIRST_PAUSE_MS = 1_000;

const UNSHARED = /unshared while it was being sent/i;
const CLEANING = /unshare of this session is still being cleaned up/i;

export interface SharePartInput {
  readonly offset: number;
  readonly messages: readonly unknown[];
}

export interface SessionShareInput {
  readonly session: Readonly<Record<string, unknown>>;
  readonly access: unknown;
  readonly parts: readonly SharePartInput[];
}

export interface SessionShareDeps {
  readonly call: CloudBrainRoute['call'];
  readonly deadlineMs: number;
  readonly signal?: AbortSignal;
  readonly context?: Parameters<CloudBrainRoute['call']>[2]['context'];
  readonly sleep?: (ms: number, signal?: AbortSignal) => Promise<void>;
  readonly uploadId?: () => string;
  readonly now?: () => number;
}

export interface SessionShareResult {
  readonly output: { status: string; parts: number; upload: string; restarted: boolean; cleaningWaitMs: number };
  readonly caller: string;
  readonly elapsedMs: number;
}

/** The wire requests of one share: each part carries the session header, its own messages and the share's upload id. */
export function shareRequests(input: SessionShareInput, upload: string): Record<string, unknown>[] {
  const count = input.parts.length;
  if (count < 1 || count > MAX_SHARE_PARTS) {
    throw new CloudBrainError('cloud_brain_rejected', `A shared session goes in 1 to ${MAX_SHARE_PARTS} parts; this one has ${count}.`);
  }
  return input.parts.map((part, index) => {
    const request = {
      session: { ...input.session, messages: part.messages },
      access: input.access,
      part: { index, count, offset: part.offset, upload },
    };
    const bytes = Buffer.byteLength(JSON.stringify(request), 'utf8');
    if (bytes > MAX_SHARE_REQUEST_BYTES) {
      throw new CloudBrainError(
        'cloud_brain_rejected',
        `Part ${index + 1} of ${count} is ${bytes} bytes; the Brain takes at most ${MAX_SHARE_REQUEST_BYTES} per request. Split it further.`,
      );
    }
    return request;
  });
}

function defaultSleep(ms: number, signal?: AbortSignal): Promise<void> {
  return new Promise((resolve, reject) => {
    if (signal?.aborted) return reject(signal.reason ?? new Error('aborted'));
    const timer = setTimeout(() => {
      signal?.removeEventListener('abort', onAbort);
      resolve();
    }, ms);
    const onAbort = (): void => {
      clearTimeout(timer);
      reject(signal?.reason ?? new Error('aborted'));
    };
    signal?.addEventListener('abort', onAbort, { once: true });
  });
}

function messageOf(error: unknown): string {
  return error instanceof Error ? error.message : String(error);
}

function partError(error: unknown, index: number, count: number): unknown {
  if (!(error instanceof CloudBrainError) || count === 1) return error;
  return new CloudBrainError(error.code, `Part ${index + 1} of ${count}: ${error.message}`, {
    ...(error.retryAfterSeconds !== undefined ? { retryAfterSeconds: error.retryAfterSeconds } : {}),
    ...(error.httpStatus !== undefined ? { httpStatus: error.httpStatus } : {}),
  });
}

function statusOf(output: unknown): string | undefined {
  const status = (output as { status?: unknown } | null)?.status;
  return typeof status === 'string' ? status : undefined;
}

/**
 * Sends a whole share as one capability call, so one approval covers it: the parts go in order with one upload id.
 * Part 0 waits (backing off, at most 30 s in total) while the Brain still cleans up an earlier unshare; an unshare
 * during the upload restarts it once from part 0 with a new upload id. Any other failure names the part and stops.
 */
export async function shareSession(input: SessionShareInput, deps: SessionShareDeps): Promise<SessionShareResult> {
  const sleep = deps.sleep ?? defaultSleep;
  const newUpload = deps.uploadId ?? randomUUID;
  const now = deps.now ?? Date.now;
  const started = now();
  shareRequests(input, 'size-check');
  let cleaningWaitMs = 0;
  let restarted = false;
  for (;;) {
    const upload = newUpload();
    const requests = shareRequests(input, upload);
    try {
      let caller = '';
      let status = '';
      for (const [index, request] of requests.entries()) {
        const last = index === requests.length - 1;
        let answer;
        for (let pause = CLEANING_FIRST_PAUSE_MS; ; pause *= 2) {
          try {
            answer = await deps.call('session_ingest', request, { deadlineMs: deps.deadlineMs, signal: deps.signal, context: deps.context });
            break;
          } catch (error) {
            if (index !== 0 || !CLEANING.test(messageOf(error)) || cleaningWaitMs >= CLEANING_WAIT_MS) {
              throw partError(error, index, requests.length);
            }
            const wait = Math.min(pause, CLEANING_WAIT_MS - cleaningWaitMs);
            await sleep(wait, deps.signal);
            cleaningWaitMs += wait;
          }
        }
        caller = answer.caller;
        status = statusOf(answer.output) ?? '';
        const expected = last ? ['stored', 'unchanged'] : ['partial'];
        if (!expected.includes(status)) {
          throw new CloudBrainError(
            'cloud_brain_rejected',
            `Part ${index + 1} of ${requests.length}: the Brain answered status ${status || '(none)'}, expected ${expected.join(' or ')}.`,
          );
        }
      }
      return { output: { status, parts: requests.length, upload, restarted, cleaningWaitMs }, caller, elapsedMs: now() - started };
    } catch (error) {
      if (!restarted && UNSHARED.test(messageOf(error)) && !deps.signal?.aborted) {
        restarted = true;
        continue;
      }
      throw error;
    }
  }
}
