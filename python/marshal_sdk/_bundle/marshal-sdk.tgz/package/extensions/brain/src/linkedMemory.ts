import type {
  CapabilityDescriptor,
  CapabilityProvider,
  InvocationContext,
} from '@marshal/agent-runtime-core';
import { PROTOCOL_VERSION, createProvider, result } from '@marshal/agent-runtime-provider-kit';
import type {
  IndexWriteBatch,
  KnowledgeIndex,
  KnowledgeNodeReference,
  PortableMemoryRuntime,
} from '@marshal/agent-runtime-provider-memory';
const STORAGE_BUSY_CATEGORY = 'STORAGE_BUSY';

/** A failure because storage is busy: replaying the work only adds to the load that caused it. */
function isStorageBusy(error: unknown): boolean {
  const failure = error as { category?: unknown; code?: unknown; errors?: unknown } | undefined;
  if (failure?.category === STORAGE_BUSY_CATEGORY || failure?.code === STORAGE_BUSY_CATEGORY) return true;
  return Array.isArray(failure?.errors) && failure.errors.some(isStorageBusy);
}

const PROVIDER_ID = 'marshal.linked-memory';
const MAX_LINKS = 32;
const MAX_BATCH_ITEMS = 500;
const MAX_CONTENT_CHARS = 20_000;
const MAX_SUMMARY_CHARS = 3_800;
const MAX_CONTEXT_NODES = 100;
const LINK_CHECK_BUDGET_MS = 5_000;
const LINK_CHECK_RETRY_MS = 750;
const LINK_CHECK_TIMED_OUT = Symbol('link check timed out');
const FACT_KEY = /^v1:[A-Za-z0-9][A-Za-z0-9._:/-]{0,252}$/;
const MAX_ACCESS_LABELS = 128;
const ACCESS_LABEL = new RegExp([
  '^(?:staff',
  'brand:[a-z0-9][a-z0-9_-]{0,63}',
  'user:[a-z0-9][a-z0-9._+-]{0,63}@[a-z0-9][a-z0-9.-]{0,127}\\.[a-z]{2,24}',
  'group:[a-z0-9][a-z0-9_-]{0,63})$',
].join('|'), 'u');

const BATCH_DESCRIPTOR: CapabilityDescriptor = {
  protocolVersion: PROTOCOL_VERSION,
  name: 'memory.link.batch',
  version: '1.0.0',
  description:
    'Store several memories in order, each as memory.link would, and publish their index changes together '
    + 'as one delta instead of one index commit per memory. The link check of memory.link is skipped (the '
    + 'memories were checked when first written). Stops at the first memory that fails: results lists one '
    + 'entry per memory handled, so the caller knows where to resume.',
  tags: ['memory', 'knowledge', 'links'],
  permissions: [{ permission: 'memory.write', scope: 'runtime', risk: 'medium' }],
  inputSchema: {
    type: 'object',
    required: ['items'],
    properties: {
      items: {
        type: 'array',
        minItems: 1,
        maxItems: MAX_BATCH_ITEMS,
        items: {
          type: 'object',
          required: ['content', 'links'],
          properties: {
            content: { type: 'string', minLength: 1, maxLength: MAX_CONTENT_CHARS },
            links: { type: 'array', minItems: 0, maxItems: MAX_LINKS },
            summary: { type: 'string', minLength: 1, maxLength: MAX_SUMMARY_CHARS },
            key: { type: 'string', pattern: FACT_KEY.source },
            scope: { enum: ['project', 'workspace'] },
            access: { type: 'array', maxItems: MAX_ACCESS_LABELS },
          },
          additionalProperties: false,
        },
      },
    },
    additionalProperties: false,
  },
  outputSchema: {
    type: 'object',
    required: ['results'],
    properties: {
      results: {
        type: 'array',
        items: {
          type: 'object',
          required: ['ok'],
          properties: {
            ok: { type: 'boolean' },
            memoryId: { type: 'string' },
            reused: { type: 'boolean' },
            replaced: { type: 'string' },
            error: { type: 'string' },
          },
          additionalProperties: false,
        },
      },
    },
    additionalProperties: false,
  },
};

const DESCRIPTOR: CapabilityDescriptor = {
  protocolVersion: PROTOCOL_VERSION,
  name: 'memory.link',
  version: '1.0.0',
  description:
    'Store a durable project memory linked to the files and symbols it explains; every session and '
    + 'worktree of the project shares it (scope: "workspace" keeps it to this checkout). Each link becomes '
    + 'a graph edge, so knowledge.search (expand) and knowledge.impact connect those parts through '
    + 'the memory. Use it for cross-component flows the code does not state (config -> pipeline -> '
    + 'service). On a file several flows share (a registry, shared config, router), give the symbol: '
    + 'a file link asks for review when a change there names the memory\'s topic, a symbol link only when '
    + 'that symbol changes, and a file link next to a symbol link in the same file is not stored. '
    + 'Reusing a key replaces that memory; the replaced revision and its links are hidden '
    + 'unless a read passes includeHistory: true. access limits who reads the memory: the index '
    + 'applies these labels before ranking, so search, context and impact show it only to a caller '
    + 'holding one of them; leave it out for a memory every staff member reads.',
  tags: ['memory', 'knowledge', 'links'],
  permissions: [{ permission: 'memory.write', scope: 'runtime', risk: 'medium' }],
  inputSchema: {
    type: 'object',
    required: ['content', 'links'],
    properties: {
      content: { type: 'string', minLength: 1, maxLength: MAX_CONTENT_CHARS },
      links: {
        type: 'array',
        minItems: 0,
        maxItems: MAX_LINKS,
        items: {
          type: 'object',
          required: ['path'],
          properties: {
            path: { type: 'string', minLength: 1, maxLength: 1_024 },
            symbol: { type: 'string', minLength: 1, maxLength: 512 },
          },
          additionalProperties: false,
        },
      },
      summary: { type: 'string', minLength: 1, maxLength: MAX_SUMMARY_CHARS },
      key: { type: 'string', pattern: FACT_KEY.source },
      scope: { enum: ['project', 'workspace'] },
      deferIndex: { type: 'boolean' },
      access: {
        type: 'array',
        maxItems: MAX_ACCESS_LABELS,
        items: { type: 'string', pattern: ACCESS_LABEL.source },
      },
    },
    additionalProperties: false,
  },
  outputSchema: {
    type: 'object',
    required: ['memoryId', 'links'],
    properties: {
      memoryId: { type: 'string' },
      reused: { type: 'boolean' },
      replaced: { type: 'string' },
      indexPending: { type: 'boolean' },
      linkCheckError: { type: 'string' },
      links: {
        type: 'array',
        items: {
          type: 'object',
          required: ['target', 'linked'],
          properties: { target: { type: 'string' }, linked: { type: 'boolean' }, coveredBySymbol: { type: 'boolean' } },
          additionalProperties: false,
        },
      },
    },
    additionalProperties: false,
  },
};

interface MemoryLink {
  readonly path: string;
  readonly symbol?: string;
}

/**
 * The text under a memory document's `## Retrieval` heading. The document parser ends that section
 * at the next line that opens with one or two `#`, so a synopsis cut from content that starts with
 * a Markdown heading would leave the section empty and the memory could never be indexed. The
 * heading markers are dropped and the words kept.
 */
export function retrievalSynopsisOf(text: string): string {
  const plain = text.split('\n').map((line) => line.replace(/^#{1,2}[ \t]+/u, '')).join('\n').trim();
  return (plain || 'memory').slice(0, MAX_SUMMARY_CHARS);
}

/**
 * Agent-facing route for linked memories. Writes go to the durable project scope (or the
 * workspace scope when asked), shared by every principal and worktree, whose
 * Markdown projection carries `applies-to` code links that the knowledge graph turns into edges.
 */
export function createLinkedMemoryProvider(
  memory: () => PortableMemoryRuntime,
  index: () => KnowledgeIndex,
  /**
   * After each write: a new note records its provenance (the session it came from), a reused one
   * (the same content again) is activity that clears a needs-review flag.
   */
  onStored: (memoryId: string, reused: boolean, context: InvocationContext) => void = () => undefined,
): CapabilityProvider {
  return createProvider(PROVIDER_ID, [DESCRIPTOR, BATCH_DESCRIPTOR], async (name, rawInput, context) => {
    if (name === BATCH_DESCRIPTOR.name) return linkBatch(memory, onStored, rawInput, context);
    if (name !== DESCRIPTOR.name) throw new Error(`Unsupported linked memory capability: ${name}`);
    const input = record(rawInput);
    const { links, targets, covered, request } = parseLinkedInput(rawInput);
    const deferIndex = input.deferIndex === true;
    const stored = await rememberLinked(memory(), context, { ...request, deferIndex });
    onStored(stored.memoryId, stored.reused, context);
    // A deferred write sits in the index window, so its links cannot be read back yet.
    const { nodes: linked, error: linkCheckError } = deferIndex && stored.indexPending
      ? { nodes: [] as readonly KnowledgeNodeReference[] }
      : await linkedTargets(index(), stored.memoryId, callerOf(context));
    return result({
      ...stored,
      ...(linkCheckError ? { linkCheckError } : {}),
      links: links.map((link, position) => ({
        target: targets[position]!,
        linked: linked.some((node) => matchesLink(node, link)),
        ...(covered[position] ? { coveredBySymbol: true } : {}),
      })),
    }, PROVIDER_ID, name, rawInput, context);
  });
}

interface LinkedRequest {
  content: string;
  summary: string;
  key: string | undefined;
  scopeKind: 'project' | 'workspace';
  access: readonly string[];
  targets: readonly string[];
}

function parseLinkedInput(rawInput: unknown): {
  links: readonly MemoryLink[];
  targets: readonly string[];
  covered: readonly boolean[];
  request: LinkedRequest;
} {
  const input = record(rawInput);
  const content = boundedText(input.content, 'content', MAX_CONTENT_CHARS);
  const links = parseLinks(input.links);
  const summary = retrievalSynopsisOf(input.summary === undefined
    ? content
    : boundedText(input.summary, 'summary', MAX_SUMMARY_CHARS));
  const key = parseKey(input.key);
  const scopeKind = parseScope(input.scope);
  const access = parseAccess(input.access);
  const targets = links.map((link) => `code:${link.path}${link.symbol ? `#${link.symbol}` : ''}`);
  // A symbol link in a file supersedes a bare link to the same file (review D9: symbol links flag
  // only when their symbol changes, so a shared file's other edits do not reach this memory).
  const symbolFiles = new Set(links.filter(({ symbol }) => symbol).map(({ path }) => path));
  const covered = links.map((link) => !link.symbol && symbolFiles.has(link.path));
  return {
    links,
    targets,
    covered,
    request: {
      content,
      summary,
      key,
      scopeKind,
      access,
      targets: [...new Set(targets.filter((_, position) => !covered[position]))],
    },
  };
}

/**
 * Stores the memories in order inside one deferred-index scope, so the memory index publishes one
 * bounded delta instead of one commit per memory, and stops at the first one that fails.
 */
async function linkBatch(
  memory: () => PortableMemoryRuntime,
  onStored: (memoryId: string, reused: boolean, context: InvocationContext) => void,
  rawInput: unknown,
  context: InvocationContext,
) {
  const items = record(rawInput).items;
  if (!Array.isArray(items) || items.length === 0 || items.length > MAX_BATCH_ITEMS) {
    throw new Error(`items must list 1 to ${MAX_BATCH_ITEMS} memories.`);
  }
  const results: Array<Record<string, unknown>> = [];
  const runtime = memory();
  await runtime.deferIndexWrites(async (indexWrites) => {
    for (const item of items) {
      try {
        const { request } = parseLinkedInput(item);
        const stored = await rememberLinked(runtime, context, { ...request, indexWrites });
        onStored(stored.memoryId, stored.reused, context);
        results.push({
          ok: true,
          memoryId: stored.memoryId,
          ...(stored.reused ? { reused: true } : {}),
          ...(stored.replaced ? { replaced: stored.replaced } : {}),
        });
      } catch (error) {
        results.push({ ok: false, error: error instanceof Error ? error.message : String(error) });
        return;
      }
    }
  });
  return result({ results }, PROVIDER_ID, BATCH_DESCRIPTOR.name, rawInput, context);
}

async function rememberLinked(
  runtime: PortableMemoryRuntime,
  context: InvocationContext,
  request: {
    content: string;
    summary: string;
    key?: string;
    targets: readonly string[];
    scopeKind: 'project' | 'workspace';
    access: readonly string[];
    deferIndex?: boolean;
    indexWrites?: IndexWriteBatch;
  },
): Promise<{ memoryId: string; reused: boolean; indexPending: boolean; replaced?: string }> {
  const scope = runtime.scopes.ensureBuiltInScopes(context).find(({ kind }) => kind === request.scopeKind);
  const handle = scope && runtime.scopes.handlesForContext(context, 'write')
    .find(({ scopeId }) => scopeId === scope.scopeId);
  if (!handle) throw new Error(`No writable ${request.scopeKind} memory scope is available for this session.`);
  const remember = (expectedHeadRevision?: number) => runtime.remember({
    handle,
    content: request.content,
    retrievalSynopsis: request.summary,
    ...(request.key ? { factKey: request.key } : {}),
    derivedFrom: request.targets,
    access: request.access,
    ...(request.deferIndex ? { deferIndex: true } : {}),
    ...(request.indexWrites ? { indexWrites: request.indexWrites } : {}),
    ...(expectedHeadRevision === undefined ? {} : { expectedHeadRevision }),
  }, context);
  try {
    const stored = await remember();
    return { memoryId: stored.memory.id, reused: stored.reused, indexPending: stored.indexPending };
  } catch (error) {
    if ((error as { code?: unknown })?.code !== 'memory_fact_head_conflict') throw error;
    const head = request.key ? runtime.activeFactHead(handle, request.key, context) : undefined;
    if (!head) throw error;
    const stored = await remember(head.revision);
    return {
      memoryId: stored.memory.id,
      reused: stored.reused,
      indexPending: stored.indexPending,
      replaced: head.id,
    };
  }
}

/**
 * Reads the memory's links back as its writer: the index applies access labels before it reads, so
 * a check without the writer's identity cannot see a memory restricted to them and would report
 * every link as unlinked.
 */
async function linkedTargets(
  index: KnowledgeIndex,
  memoryId: string,
  caller: string | undefined,
): Promise<{ nodes: readonly KnowledgeNodeReference[]; error?: string }> {
  const deadline = Date.now() + LINK_CHECK_BUDGET_MS;
  const timedOut = `link check timed out after ${LINK_CHECK_BUDGET_MS}ms; the memory index is still syncing`;
  let failure = '';
  // Routes briefly report failure while the publication that carried the memory settles. The whole
  // check stays within a fixed budget, and a lookup that fails because the index storage is busy is
  // not repeated: retrying it only adds to the load that made it busy.
  for (let attempt = 0; ; attempt += 1) {
    const remaining = deadline - Date.now();
    if (remaining <= 0) return { nodes: [], error: failure || timedOut };
    let timer: ReturnType<typeof setTimeout> | undefined;
    const expired = new Promise<typeof LINK_CHECK_TIMED_OUT>((resolve) => {
      timer = setTimeout(resolve, remaining, LINK_CHECK_TIMED_OUT);
    });
    const lookup = Promise.resolve().then(() => index.context({
      target: { kind: 'memory', id: memoryId },
      maxDepth: 1,
      limit: MAX_CONTEXT_NODES,
    }, caller ? { caller } : undefined));
    lookup.catch(() => undefined);
    try {
      const found = await Promise.race([lookup, expired]);
      if (found === LINK_CHECK_TIMED_OUT) return { nodes: [], error: timedOut };
      return { nodes: found.nodes.filter((node) => node.memoryId !== memoryId) };
    } catch (error) {
      failure = error instanceof Error ? error.message : String(error);
      if (isStorageBusy(error)) return { nodes: [], error: failure };
    } finally {
      clearTimeout(timer);
    }
    const wait = LINK_CHECK_RETRY_MS * (attempt + 1);
    if (Date.now() + wait >= deadline) return { nodes: [], error: failure };
    await new Promise((resolve) => setTimeout(resolve, wait));
  }
}

function matchesLink(node: KnowledgeNodeReference, link: MemoryLink): boolean {
  const nodePath = (node.path ?? '').replace(/^\[[^\]]+\]/, '').replaceAll('\\', '/');
  if (!(nodePath === link.path || nodePath.endsWith(`/${link.path}`))) return false;
  return !link.symbol || node.name === link.symbol || (node.id ?? '').includes(link.symbol);
}

function parseLinks(value: unknown): readonly MemoryLink[] {
  if (!Array.isArray(value) || value.length > MAX_LINKS) {
    throw new Error(`links must list 0 to ${MAX_LINKS} repository files.`);
  }
  return value.map((item, position) => {
    const link = record(item);
    const path = repositoryPath(link.path, `links[${position}].path`);
    if (link.symbol === undefined) return { path };
    const symbol = boundedText(link.symbol, `links[${position}].symbol`, 512);
    if (/[#\r\n\0]|\]\]/.test(symbol)) throw new Error(`links[${position}].symbol is invalid.`);
    return { path, symbol };
  });
}

function repositoryPath(value: unknown, label: string): string {
  const raw = boundedText(value, label, 1_024).replaceAll('\\', '/').replace(/^\.\//, '');
  const segments = raw.split('/');
  if (
    raw.startsWith('/')
    || /^[A-Za-z]:\//.test(raw)
    || /[#\r\n\0]|\]\]/.test(raw)
    || segments.some((segment) => segment === '' || segment === '.' || segment === '..')
  ) {
    throw new Error(`${label} must be a repository-relative path.`);
  }
  return raw;
}

function parseScope(value: unknown): 'project' | 'workspace' {
  if (value === undefined || value === 'project') return 'project';
  if (value === 'workspace') return 'workspace';
  throw new Error('scope must be "project" or "workspace".');
}

function parseAccess(value: unknown): readonly string[] {
  if (value === undefined) return [];
  if (!Array.isArray(value) || value.length > MAX_ACCESS_LABELS || value.some((label) => typeof label !== 'string' || !ACCESS_LABEL.test(label))) {
    throw new Error('access must list at most 128 labels: staff, brand:<id>, user:<email> or group:<name>.');
  }
  return value as readonly string[];
}

function parseKey(value: unknown): string | undefined {
  if (value === undefined) return undefined;
  if (typeof value !== 'string' || !FACT_KEY.test(value)) {
    throw new Error('key must look like v1:area/topic.');
  }
  return value;
}

function boundedText(value: unknown, label: string, max: number): string {
  if (typeof value !== 'string') throw new Error(`${label} must be a string.`);
  const text = value.replace(/\r\n?/g, '\n').replace(/\0/g, '').trim();
  if (!text || text.length > max) throw new Error(`${label} must be 1 to ${max} characters.`);
  return text;
}

/** The work email the host put on the call principal (as knowledge.* reads it); a model cannot set it. */
function callerOf(context: InvocationContext): string | undefined {
  const email = context.principal.claims?.callerEmail;
  return typeof email === 'string' && email.length > 0 ? email : undefined;
}

function record(value: unknown): Readonly<Record<string, unknown>> {
  if (!value || typeof value !== 'object' || Array.isArray(value)) {
    throw new Error('Input must be an object.');
  }
  return value as Readonly<Record<string, unknown>>;
}
