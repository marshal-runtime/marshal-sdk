import { createHash } from 'node:crypto';
import { realpathSync } from 'fs';
import * as path from 'node:path';

/**
 * Digests that name a Brain bundle's memory roots.
 *
 * `project` names what belongs to the project: the memory projections, shared by every worktree
 * of the project. `index` names one workspace's memory index leases (their owner ids) and their
 * rebuildable data roots. The runtime binds an index lease to one registered workspace and
 * refuses a second lease for the same owner, and Brain opens one bundle per workspace, so two
 * worktrees of one project (the same project id since R9) need distinct owners and data roots.
 */
export function memoryRootDigests(
  projectId: string,
  workspacePath: string,
): { readonly project: string; readonly index: string } {
  return {
    project: sha256(projectId),
    index: sha256(`${projectId}\0${canonicalWorkspacePath(workspacePath)}`),
  };
}

/** The workspace path with symlinks resolved, so one checkout always gets one lease. */
export function canonicalWorkspacePath(workspacePath: string): string {
  const resolved = path.resolve(workspacePath);
  try {
    return realpathSync.native(resolved);
  } catch {
    return resolved;
  }
}

function sha256(value: string): string {
  return createHash('sha256').update(value).digest('hex').slice(0, 24);
}
