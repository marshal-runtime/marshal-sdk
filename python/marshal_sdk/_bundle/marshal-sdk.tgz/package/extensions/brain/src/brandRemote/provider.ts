import type { CapabilityProvider } from '@marshal/agent-runtime-core';
import { result } from '@marshal/agent-runtime-provider-kit';
import type { BrandRemoteClient } from './client.js';
import { BrandRemoteError } from './errors.js';

export const BRAND_REMOTE_PROVIDER_ID = 'marshal.brand-brain.remote';

/**
 * Listing never throws: the runtime kernel lists every provider together, so an unreachable, refusing or changed remote
 * must leave the brand.* tools out (one warning per failure code) instead of breaking listing or session start.
 * Invocations still fail loudly.
 */
export function createBrandRemoteProvider(
  client: BrandRemoteClient,
  options: { readonly warn?: (message: string) => void } = {},
): CapabilityProvider {
  const warn = options.warn ?? ((message: string) => console.warn(message));
  const warned = new Set<string>();
  const unavailable = (error: unknown): [] => {
    const code = error instanceof BrandRemoteError ? error.code : 'brand_remote_failed';
    if (!warned.has(code)) {
      warned.add(code);
      warn(`Brand remote tools are not listed (${code}): ${error instanceof Error ? error.message : 'unknown error'}`);
    }
    return [];
  };
  return {
    id: BRAND_REMOTE_PROVIDER_ID,
    version: '0.1.0',
    async list(context) {
      try {
        return await client.list(context);
      } catch (error) {
        return unavailable(error);
      }
    },
    async get(name, context) {
      try {
        return await client.get(name, context);
      } catch (error) {
        unavailable(error);
        return undefined;
      }
    },
    async invoke(name, input, context) {
      if (!name.startsWith('brand.') || name === 'brand.memory_propose') {
        throw new BrandRemoteError('brand_remote_rejected', `The remote Brand Brain does not expose ${name}.`);
      }
      const descriptor = await client.get(name, context);
      if (!descriptor) throw new BrandRemoteError('brand_remote_rejected', `The remote Brand Brain does not expose ${name}.`);
      const remote = await client.invoke(name, input, descriptor, context);
      return result(remote.output, BRAND_REMOTE_PROVIDER_ID, name, input, context, {
        ...(remote.diagnostics ? { diagnostics: remote.diagnostics } : {}),
        ...(remote.artifacts ? { artifacts: remote.artifacts } : {}),
        ...(remote.metadata ? { metadata: remote.metadata } : {}),
      });
    },
  };
}
