import { createHash } from 'node:crypto';
import type { MarshalMemoryCategory } from './marshalMemoryStore.js';

export const MARSHAL_MEMORY_CATEGORIES: readonly MarshalMemoryCategory[] = [
  'preference',
  'fact',
  'decision',
  'context',
];
// Category and source ride in the fact key so the searchable text stays the fact alone. The key
// is full-text indexed too, so both are encoded (letter code, hex) to never match a real query.
const FACT_KEY_HEADER = /^v1:mu:([pfdc]):([a-f0-9]{0,192}):[a-f0-9]{40}$/;
const CATEGORY_CODES: Readonly<Record<MarshalMemoryCategory, string>> = {
  preference: 'p',
  fact: 'f',
  decision: 'd',
  context: 'c',
};

export function userMemoryFactKey(
  content: string,
  category: MarshalMemoryCategory,
  source: string,
): string {
  const digest = createHash('sha256').update(comparableFact(content)).digest('hex').slice(0, 40);
  return `v1:mu:${CATEGORY_CODES[category]}:${sourceHex(source)}:${digest}`;
}

/** The start every user-memory fact key of `category` shares (for a fact-key prefix query). */
export function userMemoryFactKeyPrefix(category: MarshalMemoryCategory): string {
  return `v1:mu:${CATEGORY_CODES[category]}:`;
}

/** Category and source encoded in a user-memory fact key; undefined parts when it is not one. */
export function decodeUserMemoryFactKey(factKey: string | undefined): {
  readonly category?: MarshalMemoryCategory;
  readonly source?: string;
} {
  const header = FACT_KEY_HEADER.exec(factKey ?? '');
  if (!header) return {};
  const category = MARSHAL_MEMORY_CATEGORIES.find((candidate) => CATEGORY_CODES[candidate] === header[1]);
  return {
    ...(category ? { category } : {}),
    ...(header[2] ? { source: Buffer.from(header[2], 'hex').toString('utf8') } : {}),
  };
}

export function comparableFact(content: string): string {
  return content.toLowerCase().replace(/\s+/g, ' ').trim();
}

function sourceHex(source: string): string {
  return Buffer.from(source || 'session', 'utf8').subarray(0, 96).toString('hex');
}
