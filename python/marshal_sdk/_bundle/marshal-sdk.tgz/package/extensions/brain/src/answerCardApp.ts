import { ANSWER_APP_ID } from './brainAnswer.js';
import { ANSWER_CARD_CSS, ANSWER_CARD_SCRIPT } from './generated/answerCardAssets.js';

const VERSION = '1.0.0' as const;
const RENDER_ID = 'marshal-brain.answer-card.v1';

const inlineSafe = (source: string, tag: string) => source.replace(new RegExp(`</${tag}`, 'gi'), `<\\/${tag}`).replace(/<!--/g, '<\\!--');

/** The answer card UI application: conclusions first, then a replay of the session's Brain walk. */
export function answerCardApplication() {
  const html = [
    '<!doctype html><html lang="en"><head><meta charset="utf-8" /><meta name="color-scheme" content="light" /><title>Brain answer</title>',
    `<style>${inlineSafe(ANSWER_CARD_CSS, 'style')}</style></head><body><div id="root"></div>`,
    `<script>${inlineSafe(ANSWER_CARD_SCRIPT, 'script')}</script></body></html>`,
  ].join('\n');
  return {
    id: ANSWER_APP_ID,
    title: 'Brain answer',
    description: 'The answer card of a Brain answer: headline, numbered conclusions with their sources, and a replay of the session Brain walk. Opened by knowledge.answer.show.',
    renderId: RENDER_ID,
    resource: { uri: 'ui://marshal/brain/answer-card', mimeType: 'text/html', text: html },
    application: { version: VERSION, presentationModes: ['inline', 'fullscreen'] as ('inline' | 'fullscreen')[], tools: [], actions: [] },
    tags: ['brain', 'answer', 'card'],
    metadata: { 'marshal.ui.viewports': ['mobile', 'desktop'] },
  };
}
