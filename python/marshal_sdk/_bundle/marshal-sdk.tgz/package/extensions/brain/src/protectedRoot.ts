import * as fs from 'fs';
import * as path from 'node:path';

/** Validate the external root before any lifecycle payload or replay result is written. */
export function requireProtectedLifecycleResultRoot(
  workspacePath: string,
  configured: string | undefined,
): string {
  if (!configured?.trim()) {
    throw new Error(
      'protectedLifecycleResultRoot is required and must be an absolute harness-private directory outside workspacePath.',
    );
  }
  if (!path.isAbsolute(configured)) {
    throw new Error('protectedLifecycleResultRoot must be absolute when supplied.');
  }
  const workspace = path.resolve(workspacePath);
  const candidate = path.resolve(configured);
  if (isContained(workspace, candidate)) {
    throw new Error('protectedLifecycleResultRoot must be outside workspacePath.');
  }
  fs.mkdirSync(candidate, { recursive: true, mode: 0o700 });
  const stat = fs.lstatSync(candidate);
  if (stat.isSymbolicLink() || !stat.isDirectory()) {
    throw new Error('protectedLifecycleResultRoot must be a real directory.');
  }
  const canonical = fs.realpathSync(candidate);
  if (!samePath(candidate, canonical)) {
    throw new Error('protectedLifecycleResultRoot cannot traverse a symbolic link or junction.');
  }
  if (isContained(workspace, canonical)) {
    throw new Error('protectedLifecycleResultRoot resolved inside workspacePath.');
  }
  return canonical;
}

function isContained(root: string, candidate: string): boolean {
  const relative = path.relative(root, candidate);
  return relative === ''
    || (!relative.startsWith(`..${path.sep}`) && relative !== '..' && !path.isAbsolute(relative));
}

function samePath(left: string, right: string): boolean {
  return process.platform === 'win32'
    ? left.toLowerCase() === right.toLowerCase()
    : left === right;
}
