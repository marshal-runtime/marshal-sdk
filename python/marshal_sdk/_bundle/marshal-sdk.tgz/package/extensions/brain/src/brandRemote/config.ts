export interface BrandRemoteConfiguration {
  readonly enabled: boolean;
  readonly url?: string;
  /** Audience of the outbound ID token (headless mode); defaults to the Brand Brain origin. */
  readonly audience: string;
  readonly timeoutMs: number;
  readonly maxConcurrent: number;
}

export const BRAND_REMOTE_TIMEOUT_MS = { default: 30_000, min: 1_000, max: 120_000 } as const;
export const BRAND_REMOTE_CONCURRENCY = { default: 2, min: 1, max: 8 } as const;

export const BRAND_REMOTE_CONFIGURATION_PROPERTIES = {
  brandRemoteEnabled: { type: 'boolean' },
  brandRemoteUrl: { type: 'string', maxLength: 2048 },
  brandRemoteAudience: { type: 'string', maxLength: 2048 },
  brandRemoteTimeoutMs: {
    type: 'integer', minimum: BRAND_REMOTE_TIMEOUT_MS.min, maximum: BRAND_REMOTE_TIMEOUT_MS.max,
  },
  brandRemoteMaxConcurrent: {
    type: 'integer', minimum: BRAND_REMOTE_CONCURRENCY.min, maximum: BRAND_REMOTE_CONCURRENCY.max,
  },
  headlessRemoteOnly: { type: 'boolean' },
} as const;

export function hasExperimentalBrainRouting(rawConfiguration: unknown): boolean {
  const record = rawConfiguration && typeof rawConfiguration === 'object' && !Array.isArray(rawConfiguration)
    ? rawConfiguration as Record<string, unknown>
    : {};
  return record.brandRemoteEnabled === true
    || record.headlessRemoteOnly === true
    || (record.brandRemoteEnabled !== undefined && record.brandRemoteEnabled !== false)
    || (record.headlessRemoteOnly !== undefined && record.headlessRemoteOnly !== false);
}

export function parseBrandRemoteConfiguration(rawConfiguration: unknown): {
  readonly brand: BrandRemoteConfiguration;
  readonly headlessRemoteOnly: boolean;
} {
  const record = rawConfiguration && typeof rawConfiguration === 'object' && !Array.isArray(rawConfiguration)
    ? rawConfiguration as Record<string, unknown>
    : {};
  if (record.brandRemoteEnabled !== undefined && typeof record.brandRemoteEnabled !== 'boolean') {
    throw new TypeError('brandRemoteEnabled must be a boolean.');
  }
  if (record.headlessRemoteOnly !== undefined && typeof record.headlessRemoteOnly !== 'boolean') {
    throw new TypeError('headlessRemoteOnly must be a boolean.');
  }
  const enabled = record.brandRemoteEnabled === true;
  const url = optionalText(record, 'brandRemoteUrl');
  const audience = optionalText(record, 'brandRemoteAudience');
  if (url !== undefined && url.length > 2_048) throw new RangeError('brandRemoteUrl must be at most 2048 characters.');
  if (url !== undefined) assertHttpsOrigin(url);
  if (enabled && url === undefined) throw new TypeError('brandRemoteEnabled needs brandRemoteUrl.');
  if (audience !== undefined && !/^[\x21-\x7e]{1,2048}$/.test(audience)) {
    throw new TypeError('brandRemoteAudience must be a non-empty printable string of at most 2048 characters.');
  }
  return {
    brand: Object.freeze({
      enabled,
      ...(url === undefined ? {} : { url: new URL(url).origin }),
      audience: audience ?? (url === undefined ? '' : new URL(url).origin),
      timeoutMs: boundedInteger(record.brandRemoteTimeoutMs, BRAND_REMOTE_TIMEOUT_MS, 'brandRemoteTimeoutMs'),
      maxConcurrent: boundedInteger(record.brandRemoteMaxConcurrent, BRAND_REMOTE_CONCURRENCY, 'brandRemoteMaxConcurrent'),
    }),
    headlessRemoteOnly: record.headlessRemoteOnly === true,
  };
}

function optionalText(record: Record<string, unknown>, key: string): string | undefined {
  const value = record[key];
  if (value === undefined || value === null || value === '') return undefined;
  if (typeof value !== 'string') throw new TypeError(`${key} must be a string.`);
  return value.trim();
}

function assertHttpsOrigin(value: string): void {
  let parsed: URL;
  try {
    parsed = new URL(value);
  } catch {
    throw new TypeError('brandRemoteUrl must be an absolute URL.');
  }
  if (parsed.protocol !== 'https:') {
    throw new TypeError('brandRemoteUrl must use https.');
  }
  if (isLoopbackOrWildcardHost(parsed.hostname)) {
    throw new TypeError('brandRemoteUrl must identify a remote runtime host, not a loopback address.');
  }
  if (parsed.username || parsed.password) throw new TypeError('brandRemoteUrl must not carry credentials.');
  if (parsed.pathname !== '/' || parsed.search || parsed.hash) {
    throw new TypeError('brandRemoteUrl must be an origin without a path, query, or fragment.');
  }
}

export function isLoopbackOrWildcardHost(hostname: string): boolean {
  const host = hostname.toLowerCase().replace(/\.$/, '');
  const address = host.startsWith('[') && host.endsWith(']') ? host.slice(1, -1) : host;
  return host === 'localhost' || host.endsWith('.localhost')
    || address === '::1' || address === '::' || address === '0.0.0.0'
    || address.startsWith('127.');
}

function boundedInteger(
  value: unknown,
  bounds: { readonly default: number; readonly min: number; readonly max: number },
  label: string,
): number {
  if (value === undefined || value === null) return bounds.default;
  if (!Number.isInteger(value) || (value as number) < bounds.min || (value as number) > bounds.max) {
    throw new RangeError(`${label} must be an integer between ${bounds.min} and ${bounds.max}.`);
  }
  return value as number;
}
