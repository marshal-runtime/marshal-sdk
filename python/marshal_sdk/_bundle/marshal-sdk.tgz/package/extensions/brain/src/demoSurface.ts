import type { CapabilityDescriptor, CapabilityProvider, InvocationContext } from '@marshal/agent-runtime-core';
import { KNOWLEDGE_PROVIDER_ID, type CloudKnowledgeSetting } from './cloudKnowledge.js';
import { createRemoteOnlyKnowledgeProvider } from './cloudKnowledgeRemoteOnly.js';
import { invokeMemoryTool, MEMORY_TOOLS, memoryDescriptors, type MemoryBackend, type MemoryHomes } from './memoryTools.js';
import { ANSWER_TOOL, answerDescriptor, buildAnswerState, showAnswerCard, type AnswerCardMode, type HostExecute } from './brainAnswer.js';
import { BrainTraceRecorder, sessionIdOf } from './brainTrace.js';

/** Added to every search result: the reminder to close the answer with the card. */
export const ANSWER_REMINDER = `Before your final answer: call ${ANSWER_TOOL} once with your headline, numbered conclusions and their sources. It opens the answer card with this session's Brain walk.`;

/** The Brain tools of the demo surface (the five cloud tools, plus refine and feedback on a search), each answered by the cloud Brain behind cloudUrl. */
export const DEMO_TOOLS = [
  'knowledge.schema',
  'knowledge.search',
  'knowledge.context',
  'knowledge.impact',
  'knowledge.path',
  'knowledge.refine',
  'knowledge.feedback',
  'knowledge.health',
] as const;

/** Workspaces (by directory name) in which the Brain is switched off: no Brain tool is listed or answered. */
export const DEFAULT_NO_BRAIN_WORKSPACES: readonly string[] = ['zyg-nobrain'];

/** Shared-session tools, answered by the same cloud Brain: Marshal's searchSessions and its Share to team Brain action call them. */
export const SESSION_TOOLS = ['sessions.cloud_search', 'sessions.cloud_share', 'sessions.cloud_unshare'] as const;

const TOOL_NAMES: ReadonlySet<string> = new Set(DEMO_TOOLS);
const SESSION_TOOL_NAMES: ReadonlySet<string> = new Set(SESSION_TOOLS);

const DESCRIPTIONS: Readonly<Record<(typeof DEMO_TOOLS)[number], string>> = {
  'knowledge.schema': 'What the company Brain holds and how to ask for it: node kinds with their filterable fields, edge kinds (and the direction impact walks them), filter operators and limits. Call it first, before building kinds, filters or edges for the other four tools.',
  'knowledge.search': "Ranked search over the company Brain: code, data and tables, analyses and metrics, pull requests, tickets, people, meetings and memories. Every hit has an id (cloud:...) for knowledge.context, knowledge.impact and knowledge.path. An exact key, #number, URL or email ranks that node first; kinds and entityTypes narrow the hits (knowledge.schema lists them). For every node of a kind, a count, a sort or a page, use mode 'exhaustive' with filters, aggregate, sort or cursor: its rows are in hits and the whole answer (total, counts, cursor) is in result; omit query, since exhaustive rejects an empty or non-empty query. It finds things; it does not answer what feeds, reads or depends on something (use knowledge.impact or knowledge.path). Hits are candidates to scan, not one top answer: each has why (the lanes and score), links, snippet and next; cloud.searchId names the search and cloud.facets show what its top 200 candidates are made of. Open the fitting hits with knowledge.context; to narrow or page them (one file dominates, only memories, one directory) use knowledge.refine; when none fits, call knowledge.feedback.",
  'knowledge.context': "Traverse: the neighbours of a node, maxDepth 1 to 3. target is {kind:'node', id} with a hit id from knowledge.search, or {kind:'code', path, symbol?}. edges, filters, walkFilters, targets and match narrow the walk; knowledge.schema lists the edge kinds and fields.",
  'knowledge.impact': "Lineage and blast radius of a node: direction 'inbound' is what depends on the target (what feeds or reads it, what breaks if it changes), 'outbound' is what it depends on. target is {kind:'node', id} with a hit id from knowledge.search, or {kind:'code', path, symbol?}. edges, filters and cursor narrow and page the answer; knowledge.schema lists the edge kinds.",
  'knowledge.path': 'How node A connects to node B: the shortest paths over up to 4 edges, shortest first, as nodes and the edges between them. A and B are hit ids from knowledge.search, or refs: a repository path, a PR or Linear URL, a ticket key, #number, an email. An empty answer means no path you may see within maxHops.',
  'knowledge.refine': "Narrow the candidates of a knowledge.search you already ran, with no new search (instant, free): filter its top 200 ranked cloud hits by kinds, excludeKinds, pathPrefix, excludePaths, files or sources, and page with offset and limit. Take searchId and the facets from cloud.searchId and cloud.facets of the search answer. Answers cards in result.cards with matched and nextOffset; expired after 30 minutes (then search again).",
  'knowledge.feedback': "Say how a knowledge.search served you, so search improves: searchId from cloud.searchId, then missing (what you looked for and the words you would have used), irrelevant ([{nodeId, why}]) or used (ids you answered from without opening). Opening a hit with knowledge.context, knowledge.impact or knowledge.path counts as used. Short factual text; it is stored as data.",
  'knowledge.health': 'Freshness and integrity of the company Brain, kind by kind: node counts, last refresh, declared source, and the gaps found (stale, missing, broken). Staff only. Narrow by kind, state, type or code.',
};

const LOCAL_ONLY_SEARCH_INPUTS = ['cloud', 'createdAfter', 'createdBefore', 'includeHistory', 'deep', 'expand'] as const;
const LOCAL_ONLY_GRAPH_INPUTS = ['source', 'cloud', 'includeHistory'] as const;

export function parseNoBrainWorkspaces(value: unknown): readonly string[] {
  if (!Array.isArray(value)) return DEFAULT_NO_BRAIN_WORKSPACES;
  const names = value.filter((entry): entry is string => typeof entry === 'string' && entry.trim().length > 0).map((entry) => entry.trim().toLowerCase());
  return names;
}

/** True when the invocation's workspace directory (or one of its parents) is named in `names`. */
export function isNoBrainWorkspace(context: InvocationContext | undefined, names: readonly string[]): boolean {
  const workspacePath = (context?.scope as { workspacePath?: unknown } | undefined)?.workspacePath;
  if (typeof workspacePath !== 'string' || names.length === 0) return false;
  const wanted = new Set(names.map((name) => name.toLowerCase()));
  return workspacePath.split(/[\\/]+/).some((segment) => wanted.has(segment.toLowerCase()));
}

export interface BrainRoute {
  readonly name: string;
  readonly cloudUrl: string;
  readonly cloudAudience?: string;
  /** true: this route's Brain keeps graph memories, and its workspaces get the memory tools (with memoryRoute set: their workspace home). */
  readonly memory?: boolean;
  /** true: a directory `<name>-<suffix>` (a worktree such as `zygstinct-3e20e278`) also matches this route, after every exact match. */
  readonly matchPrefix?: boolean;
  /** A repository file the route's Brain has indexed, linking proposals that name no file. */
  readonly memoryAnchorPath?: string;
}

const MAX_BRAIN_ROUTES = 16;
const ORG_WORKSPACE_ROUTE_KEY = /^ws:[a-z0-9][a-z0-9-]{0,62}$/;

/**
 * `brainRoutes`: `{ "<workspace directory name>": { cloudUrl, cloudAudience? } }`. A workspace whose path has a segment of
 * that name uses that Brain instance instead of the default one. A key `ws:<id>` is an org workspace id instead: a session whose invocation metadata
 * `marshalOrgWorkspaceId` equals it uses that route, ahead of any directory-name route. Throws a TypeError naming the bad entry.
 */
export function parseBrainRoutes(value: unknown, noBrainNames: readonly string[] = []): readonly BrainRoute[] {
  if (value === undefined || value === null) return [];
  if (typeof value !== 'object' || Array.isArray(value)) throw new TypeError('brainRoutes must be an object keyed by workspace directory name.');
  const entries = Object.entries(value as Record<string, unknown>);
  if (entries.length > MAX_BRAIN_ROUTES) throw new TypeError(`brainRoutes has more than ${MAX_BRAIN_ROUTES} entries.`);
  const noBrain = new Set(noBrainNames.map((name) => name.toLowerCase()));
  const seen = new Set<string>();
  return entries.map(([rawName, rawRoute]) => {
    const name = rawName.trim().toLowerCase();
    if (name.startsWith('ws:')) {
      if (!ORG_WORKSPACE_ROUTE_KEY.test(name)) throw new TypeError(`brainRoutes: "${rawName}" is not a valid org workspace id (ws:<lowercase letters, digits, hyphens>).`);
    } else if (!name || /[\\/:]/.test(name)) throw new TypeError(`brainRoutes: "${rawName}" is not a workspace directory name.`);
    if (seen.has(name)) throw new TypeError(`brainRoutes: "${name}" appears twice.`);
    seen.add(name);
    if (noBrain.has(name)) throw new TypeError(`brainRoutes: "${name}" is also a no-Brain workspace.`);
    if (!rawRoute || typeof rawRoute !== 'object' || Array.isArray(rawRoute)) throw new TypeError(`brainRoutes.${name} must be an object.`);
    const route = rawRoute as Record<string, unknown>;
    for (const key of Object.keys(route)) {
      if (!['cloudUrl', 'cloudAudience', 'memory', 'memoryAnchorPath', 'matchPrefix'].includes(key)) throw new TypeError(`brainRoutes.${name}.${key} is not allowed (cloudUrl, cloudAudience, memory, memoryAnchorPath, matchPrefix).`);
    }
    if (typeof route.cloudUrl !== 'string' || !route.cloudUrl.trim()) throw new TypeError(`brainRoutes.${name}.cloudUrl is required.`);
    if (route.cloudAudience !== undefined && (typeof route.cloudAudience !== 'string' || !route.cloudAudience.trim())) {
      throw new TypeError(`brainRoutes.${name}.cloudAudience must be a nonempty string when set.`);
    }
    if (route.memory !== undefined && typeof route.memory !== 'boolean') throw new TypeError(`brainRoutes.${name}.memory must be true or false.`);
    if (route.matchPrefix !== undefined && typeof route.matchPrefix !== 'boolean') throw new TypeError(`brainRoutes.${name}.matchPrefix must be true or false.`);
    if (route.memoryAnchorPath !== undefined && (typeof route.memoryAnchorPath !== 'string' || !route.memoryAnchorPath.trim())) {
      throw new TypeError(`brainRoutes.${name}.memoryAnchorPath must be a nonempty repository path when set.`);
    }
    return {
      name,
      cloudUrl: route.cloudUrl.trim(),
      ...(typeof route.cloudAudience === 'string' ? { cloudAudience: route.cloudAudience.trim() } : {}),
      ...(route.memory === true ? { memory: true } : {}),
      ...(route.matchPrefix === true ? { matchPrefix: true } : {}),
      ...(typeof route.memoryAnchorPath === 'string' ? { memoryAnchorPath: route.memoryAnchorPath.trim() } : {}),
    };
  });
}

const WORKTREE_SUFFIX_SEPARATOR = '-';

/**
 * The name of the route a session matches. A `ws:<id>` route equal to the invocation metadata's `marshalOrgWorkspaceId` wins; otherwise a directory segment equal to a route name wins, the deepest such segment first. Failing that, a segment
 * `<name>-<suffix>` (a worktree such as `zygstinct-3e20e278`) matches the longest name in `prefixNames` that prefixes it up to the hyphen, deepest segment first;
 * `zyg` never matches `zygstinct`.
 */
export function routeNameFor(context: InvocationContext | undefined, names: ReadonlySet<string>, prefixNames: ReadonlySet<string> = new Set()): string | undefined {
  const orgWorkspaceId = (context?.metadata as { marshalOrgWorkspaceId?: unknown } | undefined)?.marshalOrgWorkspaceId;
  if (typeof orgWorkspaceId === 'string' && names.has(orgWorkspaceId.toLowerCase())) return orgWorkspaceId.toLowerCase();
  const workspacePath = (context?.scope as { workspacePath?: unknown } | undefined)?.workspacePath;
  if (typeof workspacePath !== 'string' || names.size === 0) return undefined;
  const segments = workspacePath.split(/[\\/]+/).map((segment) => segment.toLowerCase());
  for (let index = segments.length - 1; index >= 0; index -= 1) if (names.has(segments[index]!)) return segments[index];
  for (let index = segments.length - 1; index >= 0; index -= 1) {
    let longest: string | undefined;
    for (const name of prefixNames) {
      if (segments[index]!.startsWith(name + WORKTREE_SUFFIX_SEPARATOR) && (longest === undefined || name.length > longest.length)) longest = name;
    }
    if (longest !== undefined) return longest;
  }
  return undefined;
}

const WORKSPACE_NAME = /^[a-z0-9][a-z0-9._-]{0,62}$/;

/** The session's workspace directory name (lower case), the scope key of a workspace with no Brain of its own. */
function workspaceNameOf(context: InvocationContext | undefined): string | undefined {
  const workspacePath = (context?.scope as { workspacePath?: unknown } | undefined)?.workspacePath;
  if (typeof workspacePath !== 'string') return undefined;
  const last = workspacePath.split(/[\\/]+/).filter(Boolean).pop()?.toLowerCase();
  return last && WORKSPACE_NAME.test(last) ? last : undefined;
}

function demoDescriptor(descriptor: CapabilityDescriptor): CapabilityDescriptor {
  if (SESSION_TOOL_NAMES.has(descriptor.name)) return descriptor;
  const name = descriptor.name as (typeof DEMO_TOOLS)[number];
  const input = descriptor.inputSchema as Record<string, any>;
  const properties = { ...(input.properties ?? {}) } as Record<string, any>;
  const drop = name === 'knowledge.search' ? LOCAL_ONLY_SEARCH_INPUTS : name === 'knowledge.context' || name === 'knowledge.impact' ? LOCAL_ONLY_GRAPH_INPUTS : [];
  for (const key of drop) delete properties[key];
  if ((name === 'knowledge.context' || name === 'knowledge.impact') && properties.target?.properties?.kind) {
    properties.target = { ...properties.target, properties: { ...properties.target.properties, kind: { enum: ['node', 'code'] } } };
  }
  return { ...descriptor, description: DESCRIPTIONS[name], inputSchema: { ...input, properties } };
}

function brainUnavailable(reason: string): Error {
  return Object.assign(new Error(reason), { code: 'brain_unavailable' });
}

/**
 * The demo Brain surface: exactly the five cloud Brain tools (schema, search, traverse, impact, path), none of them
 * answered locally. In a workspace named in `noBrainWorkspaces` it lists nothing and answers nothing, so a chat there
 * has no Brain tool at all. A workspace named in `routes` is answered by that route's Brain instance instead of the
 * default one; every other workspace uses the default.
 */
export function createDemoBrainProvider(
  setting: CloudKnowledgeSetting,
  options: {
    readonly noBrainWorkspaces?: readonly string[];
    readonly routes?: ReadonlyMap<string, CloudKnowledgeSetting>;
    /** The route names that also match a worktree directory `<name>-<suffix>`. */
    readonly prefixRoutes?: ReadonlySet<string>;
    /** Memory tools (memory.propose, memory.review) per route name: only a workspace that matches a route listed here has them. */
    readonly memory?: ReadonlyMap<string, MemoryBackend>;
    /** The one route whose memory tools every workspace (except a no-Brain one) gets, so a person's memories land in one store wherever they work. */
    readonly memoryRoute?: string;
    readonly searchHardCapMs?: number;
    readonly searchRetryBaseMs?: number;
    /** Records each session's Brain calls for the answer card; absent means no recording and no answer tool. */
    readonly recorder?: BrainTraceRecorder;
    /** Runs a host capability for the answer card (ui.application.open). */
    readonly execute?: HostExecute;
    readonly answerMode?: AnswerCardMode;
    readonly now?: () => number;
  } = {},
): CapabilityProvider {
  const answerMode = options.answerMode ?? 'auto';
  const recorder = answerMode === 'off' ? undefined : options.recorder;
  const cardMode = answerMode === 'off' ? 'auto' : answerMode;
  const now = options.now ?? Date.now;
  const noBrain = options.noBrainWorkspaces ?? DEFAULT_NO_BRAIN_WORKSPACES;
  const make = (cloud: CloudKnowledgeSetting) => (cloud.state === 'on' ? createRemoteOnlyKnowledgeProvider(cloud, {
    remoteOnlyRetry: true,
    ...(options.searchHardCapMs !== undefined ? { searchHardCapMs: options.searchHardCapMs } : {}),
    ...(options.searchRetryBaseMs !== undefined ? { searchRetryBaseMs: options.searchRetryBaseMs } : {}),
  }) : undefined);
  const fallback = make(setting);
  // A route whose instance is not usable stays in the map without a provider: its workspace gets no Brain, never the default instance's.
  const routed = new Map<string, CapabilityProvider | undefined>();
  for (const [name, cloud] of options.routes ?? []) routed.set(name.toLowerCase(), make(cloud));
  const routeNames: ReadonlySet<string> = new Set(routed.keys());
  const prefixRouteNames: ReadonlySet<string> = new Set([...(options.prefixRoutes ?? [])].map((name) => name.toLowerCase()).filter((name) => routed.has(name)));
  const memoryBackends = new Map([...(options.memory ?? [])].map(([name, backend]) => [name.toLowerCase(), backend] as const));
  const memoryTools: ReadonlySet<string> = new Set(MEMORY_TOOLS);
  const pinnedMemory = options.memoryRoute === undefined ? undefined : memoryBackends.get(options.memoryRoute.toLowerCase());
  const memoryFor = (context: InvocationContext | undefined): MemoryHomes | undefined => {
    if (isNoBrainWorkspace(context, noBrain)) return undefined;
    const name = routeNameFor(context, routeNames, prefixRouteNames);
    const own = name === undefined || routed.get(name) === undefined ? undefined : memoryBackends.get(name);
    if (!pinnedMemory) return own ? { personal: own } : undefined;
    // The same workspace:<name> scope in the workspace's own Brain and in the default one, so one scopePrefix finds it wherever it landed.
    if (own) return { personal: pinnedMemory, workspace: { backend: own, scope: `workspace:${name!}`, ownBrain: true } };
    const workspace = name ?? workspaceNameOf(context);
    return workspace ? { personal: pinnedMemory, workspace: { backend: pinnedMemory, scope: `workspace:${workspace}`, ownBrain: false } } : { personal: pinnedMemory };
  };
  const pick = (context: InvocationContext | undefined) => {
    if (isNoBrainWorkspace(context, noBrain)) return undefined;
    const name = routeNameFor(context, routeNames, prefixRouteNames);
    return name === undefined ? fallback : routed.get(name);
  };
  return {
    id: KNOWLEDGE_PROVIDER_ID,
    ...(fallback?.version ? { version: fallback.version } : {}),
    async list(context) {
      const inner = pick(context);
      if (inner === undefined) return memoryFor(context) ? memoryDescriptors() : [];
      const brain = (await inner.list(context)).filter(({ name }) => TOOL_NAMES.has(name) || SESSION_TOOL_NAMES.has(name)).map(demoDescriptor);
      const withAnswer = recorder ? [...brain, answerDescriptor(cardMode)] : brain;
      return memoryFor(context) ? [...withAnswer, ...memoryDescriptors()] : withAnswer;
    },
    async get(name, context) {
      if (memoryTools.has(name)) return memoryFor(context) ? memoryDescriptors().find((descriptor) => descriptor.name === name) : undefined;
      const inner = pick(context);
      if (inner === undefined) return undefined;
      if (name === ANSWER_TOOL) return recorder ? answerDescriptor(cardMode) : undefined;
      if (!TOOL_NAMES.has(name) && !SESSION_TOOL_NAMES.has(name)) return undefined;
      const descriptor = inner.get ? await inner.get(name, context) : (await inner.list(context)).find((candidate) => candidate.name === name);
      return descriptor ? demoDescriptor(descriptor) : undefined;
    },
    async invoke(name, input, context) {
      if (isNoBrainWorkspace(context, noBrain)) throw brainUnavailable('The Brain is unavailable in this workspace. Use git and the files.');
      if (memoryTools.has(name)) {
        const homes = memoryFor(context);
        if (!homes) throw brainUnavailable(`${name} is not available in this workspace.`);
        return invokeMemoryTool(homes, name, input, context);
      }
      const inner = pick(context);
      if (inner === undefined) throw brainUnavailable('The Brain is not configured in this Marshal.');
      if (name === ANSWER_TOOL && recorder && context) {
        const sessionId = sessionIdOf(context);
        const state = buildAnswerState(input, await recorder.load(sessionId));
        return { output: await showAnswerCard(state, context, options.execute, `brain-answer-${sessionId ?? 'nosession'}-${now()}`) };
      }
      if (SESSION_TOOL_NAMES.has(name)) return inner.invoke(name, input, context);
      if (!TOOL_NAMES.has(name)) throw brainUnavailable(`${name} is not a Brain tool.`);
      if (!recorder) return inner.invoke(name, input, context);
      const startedAt = now();
      try {
        const result = await inner.invoke(name, input, context);
        recorder.record(name, input, result, context, startedAt);
        return name === 'knowledge.search' && answerMode === 'auto' ? withReminder(result) : result;
      } catch (error) {
        recorder.record(name, input, undefined, context, startedAt, error);
        throw error;
      }
    },
  };
}

function withReminder<T>(result: T): T {
  const output = (result as { output?: unknown })?.output;
  if (!output || typeof output !== 'object' || Array.isArray(output)) return result;
  return { ...result, output: { ...output, closing: ANSWER_REMINDER } };
}

const NO_PROMPT_MEMORIES =Object.freeze({ entries: [] as never[], omitted: { count: 0 } });

/**
 * The memory store the Brain registers with the host, with the always-on prompt block emptied for a session whose
 * workspace is a no-Brain workspace (the host passes the session's workspacePath to selectForPrompt). Everything else
 * is the store itself: the host's recall, listMemories and remember carry no session or workspace, so they cannot be
 * scoped here (see README, "Memory in the no-Brain workspace").
 */
export function withNoBrainPrompt<T extends object>(store: T, names: readonly string[]): T {
  const scoped = (request: { readonly workspacePath?: unknown } | undefined) =>
    typeof request?.workspacePath === 'string' && isNoBrainWorkspace({ scope: { workspacePath: request.workspacePath } } as unknown as InvocationContext, names);
  return new Proxy(store, {
    get(target, property) {
      const value = Reflect.get(target, property, target);
      if (property === 'selectForPrompt' && typeof value === 'function') {
        return (request: { readonly workspacePath?: unknown }) => (scoped(request) ? NO_PROMPT_MEMORIES : value.call(target, request));
      }
      return typeof value === 'function' ? value.bind(target) : value;
    },
  });
}

/** The same provider, listing and answering nothing in a no-Brain workspace (used for the company graph, when switched on). */
export function hiddenInNoBrainWorkspaces<T extends CapabilityProvider>(provider: T, names: readonly string[]): T {
  return {
    ...provider,
    async list(context: InvocationContext) {
      return isNoBrainWorkspace(context, names) ? [] : provider.list(context);
    },
    ...(provider.get ? { async get(name: string, context: InvocationContext) { return isNoBrainWorkspace(context, names) ? undefined : provider.get!(name, context); } } : {}),
    async invoke(name: string, input: unknown, context: InvocationContext) {
      if (isNoBrainWorkspace(context, names)) throw brainUnavailable('The Brain is unavailable in this workspace. Use git and the files.');
      return provider.invoke(name, input, context);
    },
  } as T;
}
