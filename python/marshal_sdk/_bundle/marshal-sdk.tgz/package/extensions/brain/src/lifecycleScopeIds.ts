import { createHash } from 'node:crypto';

/** Host identities as the runtime issues them (runtime-workspace-identity.ts). */
const HOST_PROJECT_ID = /^project-[0-9a-f]{24}$/u;
const HOST_WORKSPACE_ID = /^workspace-[0-9a-f]{24}$/u;

export interface LifecycleTrustedIds {
  readonly projectId?: string;
  readonly workspaceId?: string;
}

/**
 * The workspace/project ids a lifecycle session uses for its scopes. A host-issued id is
 * used verbatim, exactly as agents' invocation contexts carry it, so the lifecycle and the
 * agents resolve the same (shared) project and workspace scopes. Anything else (tests, older
 * embedders passing a raw registry key) is hashed as before.
 */
export function lifecycleScopeIds(
  workspacePath: string,
  trusted: LifecycleTrustedIds = {},
): { readonly workspaceId: string; readonly projectId: string } {
  const projectId = trusted.projectId?.trim();
  const workspaceId = trusted.workspaceId?.trim();
  return {
    workspaceId: workspaceId && HOST_WORKSPACE_ID.test(workspaceId) ? workspaceId : stableId('workspace', workspacePath),
    projectId: projectId && HOST_PROJECT_ID.test(projectId) ? projectId : stableId('project', projectId || workspacePath),
  };
}

export function stableId(kind: string, value: string): string {
  const normalized = process.platform === 'win32' ? value.toLocaleLowerCase() : value;
  return `${kind}-${createHash('sha256').update(normalized).digest('hex').slice(0, 24)}`;
}
