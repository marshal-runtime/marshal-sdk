import type { MarshalMemoryCategory, MarshalMemoryEntry } from './marshalMemoryStore.js';

/** Mirror of the host's MemoryPromptSelectionRequest (electron/backend/ports.ts). */
export interface MemoryPromptSelectionRequest {
  /** UTF-8 byte budget for the rendered fact lines (default 8192). */
  readonly budgetBytes: number;
  /** Session workspace path (unused) and git project id: project memories of other projects are not candidates. */
  readonly workspacePath?: string;
  readonly projectId?: string;
}

export interface MemoryPromptSelection {
  /** In render order. */
  readonly entries: MarshalMemoryEntry[];
  /** Candidates (global or this project) that did not fit the budget; other projects are not counted. */
  readonly omitted: { readonly count: number };
}

export const DEFAULT_PROMPT_BUDGET_BYTES = 8_192;
const CATEGORY_PRIORITY: readonly MarshalMemoryCategory[] = ['preference', 'decision', 'fact', 'context'];
// The host's renderMemoryPromptLine (electron/marshal-runtime/memory/prompt-provenance.ts):
// one line per fact, closing tag escaped, allowlisted category and src: prefix.
const UNTRUSTED_MEMORY_CLOSE_TAG = /<\s*\/\s*untrusted_memory\b[^>]*>/gi;
const LINE_BREAKS = /\r\n|[\n\r\u2028\u2029]/g;
const RENDERED_SOURCES: ReadonlySet<string> = new Set(['session', 'import', 'promoted', 'brain', 'local']);
const RENDERED_CATEGORIES: ReadonlySet<string> = new Set(CATEGORY_PRIORITY);

/**
 * The exact line the host renders for one memory: `- [category|YYYY-MM-DD|src:<prefix>] fact`.
 * The date is createdAt in UTC (`undated` if unparsable); the category is `unknown` outside
 * the four known ones; the prefix is `source` up to its first `/`, or `external` outside
 * session/import/promoted/brain/local; line breaks in the fact become one space each and
 * `</untrusted_memory>` closing tags are escaped.
 */
export function renderPromptLine(entry: MarshalMemoryEntry): string {
  const parsed = typeof entry.createdAt === 'string' ? Date.parse(entry.createdAt) : Number.NaN;
  const date = Number.isNaN(parsed) ? 'undated' : new Date(parsed).toISOString().slice(0, 10);
  const prefix = typeof entry.source === 'string' ? entry.source.split('/', 1)[0] ?? '' : '';
  const source = RENDERED_SOURCES.has(prefix) ? prefix : 'external';
  const category = promptSafeCategory(entry.category);
  return `- [${category}|${date}|src:${source}] ${promptSafeFact(entry.fact)}`;
}

/** One line of prompt text: line breaks become one space each and `</untrusted_memory>` closing tags are escaped. */
export function promptSafeFact(value: unknown): string {
  const rawFact = typeof value === 'string' ? value : String(value ?? '');
  return rawFact.replace(LINE_BREAKS, ' ').replace(UNTRUSTED_MEMORY_CLOSE_TAG, () => '<\\/untrusted_memory>');
}

/** A category as a prompt line shows it: one of the known ones, else "unknown". */
export function promptSafeCategory(value: unknown): string {
  return typeof value === 'string' && RENDERED_CATEGORIES.has(value) ? value : 'unknown';
}

/**
 * Category priority preference → decision → fact → context, newest first inside a
 * category; an entry whose line would overflow the budget is skipped (a later,
 * shorter one may still fit) and counted as omitted. Line bytes exclude separators.
 */
export function selectForPrompt(
  active: readonly MarshalMemoryEntry[],
  request: MemoryPromptSelectionRequest,
): MemoryPromptSelection {
  const budget = Number.isFinite(request?.budgetBytes) && request.budgetBytes >= 0
    ? Math.trunc(request.budgetBytes)
    : DEFAULT_PROMPT_BUDGET_BYTES;
  const ordered = active.filter((entry) => appliesHere(entry, request?.projectId)).sort(comparePromptOrder);
  const entries: MarshalMemoryEntry[] = [];
  let used = 0;
  let omitted = 0;
  for (const entry of ordered) {
    const bytes = Buffer.byteLength(renderPromptLine(entry), 'utf8');
    if (used + bytes > budget) {
      omitted += 1;
      continue;
    }
    entries.push(entry);
    used += bytes;
  }
  return { entries, omitted: { count: omitted } };
}

/** Global memories, plus those of the request's project; other projects' are not candidates. */
function appliesHere(entry: MarshalMemoryEntry, projectId: string | undefined): boolean {
  const appliesTo = entry.appliesTo;
  return appliesTo === undefined || appliesTo === 'global' || (projectId !== undefined && appliesTo === projectId);
}

function comparePromptOrder(left: MarshalMemoryEntry, right: MarshalMemoryEntry): number {
  const byCategory = categoryRank(left.category) - categoryRank(right.category);
  if (byCategory !== 0) return byCategory;
  const byDate = timestamp(right.createdAt) - timestamp(left.createdAt);
  if (byDate !== 0) return byDate;
  return left.id < right.id ? -1 : left.id > right.id ? 1 : 0;
}

function categoryRank(category: MarshalMemoryCategory): number {
  const rank = CATEGORY_PRIORITY.indexOf(category);
  return rank === -1 ? CATEGORY_PRIORITY.length : rank;
}

function timestamp(value: string): number {
  const parsed = Date.parse(value);
  return Number.isFinite(parsed) ? parsed : 0;
}
