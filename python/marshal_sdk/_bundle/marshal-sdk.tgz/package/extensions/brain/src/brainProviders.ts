import { createHash } from 'node:crypto';
import { mkdirSync } from 'fs';
import * as path from 'node:path';
import type {
  CapabilityInvocationResult,
  CapabilityProvider,
  InvocationContext,
  RuntimeBackgroundJobHandler,
  RuntimeExecResponse,
  RuntimeExecuteRequest,
} from '@marshal/agent-runtime-core';
import type { RuntimeServiceAccessor, RuntimeServiceToken } from '@marshal/agent-runtime-composer';
import type { RuntimeCodeIntelligenceService } from '@marshal/agent-runtime-code-intelligence';
import type {
  RuntimeHostContextService,
  RuntimeHostContextSnapshot,
} from '@marshal/agent-runtime-host';
import { result } from '@marshal/agent-runtime-provider-kit';
import {
  createKnowledgeIndexProvider,
  type HolographicMemoryCapabilities,
  type KnowledgeIndex,
  type KnowledgeIndexRequestOptions,
  type KnowledgeIndexStatus,
  type LocalMemoryPrincipal,
  type MemoryBrainJobEnqueuer,
  type MemoryBrainLimits,
  type PortableMemoryRuntime,
  type RebuildableKnowledgeIndex,
  type SqliteTranscriptStore,
} from '@marshal/agent-runtime-provider-memory';
import type { ILLMClient, IMemoryReasoner } from '@marshal/holographic-memory';
import {
  RUNTIME_DELEGATION_CHILD_SCOPE_LINEAGE_SERVICE,
  type DelegationChildScopeLineageService,
} from '@marshal/runtime/delegation';
import {
  createRuntimeMemoryLifecycle,
  type RuntimeMemoryLifecycleBundle,
} from './memoryLifecycle.js';
import type { RuntimeProvidersLifecyclePort } from './lifecycleTypes.js';
import {
  MARSHAL_USER_MEMORY_AGENT_ID,
  type LazyUserMemory,
} from './marshalMemoryStore.js';
import { brainHealExtras, brainLinkedMemoryProvider, brainMemoryProvider, brainUserMemory } from './brainMemoryWiring.js';
import { createMemoryOverviewProvider } from './memoryOverview.js';
export { authorizeMemoryNode } from './memoryFacets.js';
import { memoryRootDigests } from './memoryIndexKeys.js';
import { bundlePurges, combinedPurges, type PurgeFollowUp } from './purgeFollowUp.js';
import { purgeLegacyIndexSlots } from './legacyIndexPurge.js';
import { NotConfiguredKnowledgeIndex } from './notConfiguredKnowledgeIndex.js';
import { KNOWLEDGE_PROVIDER_ID } from './cloudKnowledge.js';
import { resolveMemoryReviewGate } from './memoryReviewGate.js';
import { runProjectScopeMigration } from './projectScopeStartup.js';

export const RUNTIME_HOST_CONTEXT_TOKEN =
  Symbol.for('@marshal/agent-runtime-host:context') as RuntimeServiceToken<RuntimeHostContextService>;
export const RUNTIME_CODE_INTELLIGENCE_TOKEN =
  Symbol.for('@marshal/agent-runtime-code-intelligence:service') as RuntimeServiceToken<RuntimeCodeIntelligenceService>;
export const MEMORY_REASONER_SERVICE =
  Symbol.for('@marshal/brain:memory-reasoner') as RuntimeServiceToken<IMemoryReasoner>;

export { RUNTIME_DELEGATION_CHILD_SCOPE_LINEAGE_SERVICE };
export type { DelegationChildScopeLineageService };

export interface BrainProvidersOptions {
  readonly services: RuntimeServiceAccessor;
  readonly hostContext?: RuntimeHostContextSnapshot;
  readonly llmClient?: ILLMClient;
  readonly memoryReasoner?: IMemoryReasoner;
  readonly memoryBrainLimits?: MemoryBrainLimits;
  readonly brainJobs?: MemoryBrainJobEnqueuer;
  /** Set only from the desktop host's configuration: the one local reader of calls that carry no access claim. */
  readonly localPrincipal?: LocalMemoryPrincipal;
  readonly execute?: (
    request: RuntimeExecuteRequest,
    context?: InvocationContext,
  ) => Promise<RuntimeExecResponse>;
}

export interface BrainProvidersBundle {
  readonly providers: readonly CapabilityProvider[];
  readonly lifecycle: RuntimeProvidersLifecyclePort;
  readonly memory: HolographicMemoryCapabilities;
  readonly durableMemory: PortableMemoryRuntime;
  readonly transcripts: SqliteTranscriptStore;
  readonly jobHandlers: readonly RuntimeBackgroundJobHandler[];
  readonly userMemory: LazyUserMemory;
  /** This bundle's results purge and slot compaction after a complete forget (purgeFollowUp.ts). */
  readonly purges: PurgeFollowUp;
  initialize(): Promise<void>;
  dispose(): Promise<void>;
}

export interface InstalledBrainProvidersBundle {
  readonly providers: readonly CapabilityProvider[];
  readonly lifecycle: RuntimeProvidersLifecyclePort;
  readonly jobHandlers: readonly RuntimeBackgroundJobHandler[];
  readonly userMemory: LazyUserMemory;
  /** Every in-process bundle's purge follow-up (purgeFollowUp.ts). */
  readonly purges: PurgeFollowUp;
  persistScopeInheritance(
    parent: InvocationContext,
    childThreadId: string,
  ): Promise<void>;
  dispose(): Promise<void>;
}

export interface BrainSourceContext {
  readonly services: RuntimeServiceAccessor;
  readonly hostContext?: RuntimeHostContextSnapshot;
  readonly jobManager: MemoryBrainJobEnqueuer;
}

export function createBrainSource(
  options: Omit<BrainProvidersOptions, 'services' | 'hostContext'> = {},
): (context: BrainSourceContext) => BrainProvidersBundle {
  return (context) => createBrainProviders({
    ...options,
    services: context.services,
    hostContext: context.hostContext,
    brainJobs: context.jobManager,
  });
}

export function createBrainProviders(options: BrainProvidersOptions): BrainProvidersBundle {
  const host = options.hostContext
    ?? options.services.get(RUNTIME_HOST_CONTEXT_TOKEN).snapshot();
  const workspaceContext = hostInvocationContext(host);
  const initialIntelligence = options.services.get(RUNTIME_CODE_INTELLIGENCE_TOKEN);
  const roots = createMemoryRoots(host, initialIntelligence, workspaceContext);
  mkdirSync(path.dirname(roots.memoryDbPath), { recursive: true });
  mkdirSync(roots.projectProjectionRoot, { recursive: true });
  mkdirSync(roots.profileProjectionRoot, { recursive: true });

  let lifecycleBundle: RuntimeMemoryLifecycleBundle | undefined;
  try {
    lifecycleBundle = createRuntimeMemoryLifecycle({
      workspacePath: host.workspacePath,
      stateRoot: host.stateRoot,
      trustedProjectId: host.projectId, trustedWorkspaceId: host.workspaceId,
      memoryDbPath: roots.memoryDbPath,
      memoryProjectionRoot: roots.projectProjectionRoot,
      memoryProfileProjectionRoot: roots.profileProjectionRoot,
      protectedLifecycleResultRoot: host.protectedLifecycleResultRoot,
      principal: host.principal,
      ...(options.localPrincipal ? { localPrincipal: options.localPrincipal } : {}),
      llmClient: options.llmClient,
      memoryReasoner: options.memoryReasoner,
      memoryBrainLimits: options.memoryBrainLimits,
      brainJobs: options.brainJobs,
      afterDailyHeal: brainHealExtras(() => lifecycleBundle!.durableMemory, () => userMemory, host),
      memoryProfileId: roots.profileId,
      // One user memory: an 'agent' scope from any session is the user's own scope.
      sharedAgentScope: {
        principalId: MARSHAL_USER_MEMORY_AGENT_ID,
        agentId: MARSHAL_USER_MEMORY_AGENT_ID,
      },
      memoryReview: resolveMemoryReviewGate(),
    });
  } catch (error) {
    void lifecycleBundle?.dispose();
    throw error;
  }
  if (!lifecycleBundle) throw new Error('Memory lifecycle construction did not complete.');
  const userMemory = brainUserMemory(lifecycleBundle.durableMemory, host, roots);
  const purges = bundlePurges({ purgeLifecycleResults: () => lifecycleBundle.purgeLifecycleResults() });
  userMemory.onPurged(purges.listener);
  const noIndex = new NotConfiguredKnowledgeIndex();
  const memoryProvider = brainMemoryProvider(lifecycleBundle.memory.provider, {
    durable: () => lifecycleBundle.durableMemory,
    userMemory,
    approve: (provider) => provider,
  });
  const knowledgeProvider = createKnowledgeIndexProvider(noIndex, KNOWLEDGE_PROVIDER_ID);

  let disposed = false;
  let projectMigration: Promise<void> | undefined;
  const bundle: BrainProvidersBundle = {
    providers: [
      memoryProvider,
      knowledgeProvider,
      brainLinkedMemoryProvider(() => lifecycleBundle.durableMemory, () => noIndex, userMemory),
      createMemoryOverviewProvider(() => lifecycleBundle.durableMemory, userMemory),
    ],
    lifecycle: lifecycleBundle.lifecycle,
    memory: lifecycleBundle.memory,
    durableMemory: lifecycleBundle.durableMemory,
    transcripts: lifecycleBundle.transcripts,
    jobHandlers: [lifecycleBundle.memory.brainJobHandler],
    userMemory,
    purges,
    async initialize() {
      if (disposed) throw new Error('Memory Brain providers are disposed.');
      startLegacyIndexPurge(host, initialIntelligence.forContext(workspaceContext).paths(), roots);
      // Background: pre-sharing workspace/project memories join the shared project scope.
      projectMigration ??= runProjectScopeMigration(
        lifecycleBundle.durableMemory,
        workspaceContext,
        roots.projectProjectionRoot,
      );
    },
    async dispose() {
      if (disposed) return;
      disposed = true;
      const failures: unknown[] = [];
      const steps: ReadonlyArray<() => Promise<unknown> | undefined> = [
        () => projectMigration,
        () => purges.stop(),
        () => lifecycleBundle.dispose(),
      ];
      for (const step of steps) {
        try {
          await step();
        } catch (error) {
          failures.push(error);
        }
      }
      if (failures.length === 1) throw failures[0];
      if (failures.length > 1) throw new AggregateError(failures, 'Failed to dispose Memory Brain providers.');
    },
  };
  return bundle;
}

let legacyIndexPurgeStarted = false;

/** Once per process, at startup: deletes the index folders earlier versions left behind (legacyIndexPurge.ts). Never rejects. */
function startLegacyIndexPurge(
  host: RuntimeHostContextSnapshot,
  paths: ReturnType<RuntimeCodeIntelligenceService['paths']>,
  roots: MemoryRoots,
): void {
  if (legacyIndexPurgeStarted) return;
  legacyIndexPurgeStarted = true;
  const profileDigest = roots.profileId.replace(/^profile-/u, '');
  void purgeLegacyIndexSlots({
    memoryRootParents: [path.join(host.protectedLifecycleResultRoot, 'bq', profileDigest), paths.profileDataRoot],
    dataRoots: [paths.profileDataRoot, paths.workspaceDataRoot, path.join(paths.runtimeDataRoot, 'runtime-index')],
    preservedPaths: [path.dirname(roots.memoryDbPath), roots.projectProjectionRoot, roots.profileProjectionRoot],
  }).then(
    (purged) => { if (purged.removed.length > 0 || purged.failures.length > 0) console.info('[brain] removed old index folders', { removed: purged.removed.length, failed: purged.failures.length }); },
    () => undefined,
  );
}

interface MemoryRoots {
  readonly memoryDbPath: string;
  readonly projectProjectionRoot: string;
  readonly profileProjectionRoot: string;
  readonly projectDataRoot: string;
  readonly profileDataRoot: string;
  readonly profileId: string;
  readonly ownerSuffix: string;
}

function createMemoryRoots(
  host: RuntimeHostContextSnapshot,
  intelligence: RuntimeCodeIntelligenceService,
  context: InvocationContext,
): MemoryRoots {
  const paths = intelligence.forContext(context).paths();
  const profileIdentity = host.identity.profileId ?? host.identity.userId
    ?? host.identity.installationId ?? `${host.identity.harnessId}:default`;
  const profileDigest = digest(profileIdentity, 24);
  const { project: projectDigest, index: indexDigest } = memoryRootDigests(host.projectId, host.workspacePath);
  const root = path.join(paths.profileRoot, 'brain');
  const defaultProfileDataRoot = path.join(paths.profileRoot, 'quillstone');
  const usesDefaultProfileDataRoot = paths.profileDataRoot === defaultProfileDataRoot;
  // Keep default native paths compact enough for the native index's Windows sidecar path budget.
  const defaultBrainDataRoot = path.join(host.protectedLifecycleResultRoot, 'bq', profileDigest);
  return {
    memoryDbPath: path.join(root, 'memory.sqlite'),
    projectProjectionRoot: path.join(paths.projectProjectionRoot, `brain-${projectDigest}`),
    profileProjectionRoot: path.join(paths.profileProjectionRoot, 'brain'),
    projectDataRoot: usesDefaultProfileDataRoot
      ? path.join(defaultBrainDataRoot, `p-${indexDigest}`)
      : path.join(paths.profileDataRoot, `brain-project-${indexDigest}`),
    profileDataRoot: usesDefaultProfileDataRoot
      ? path.join(defaultBrainDataRoot, `u-${indexDigest}`)
      : path.join(paths.profileDataRoot, `brain-profile-${indexDigest}`),
    profileId: `profile-${profileDigest}`,
    ownerSuffix: indexDigest,
  };
}

export function createInstalledBrainProviders(
    options: BrainProvidersOptions,
  ): InstalledBrainProvidersBundle {
      const baseHost = options.hostContext
        ?? options.services.get(RUNTIME_HOST_CONTEXT_TOKEN).snapshot();
      const base = createBrainProviders({ ...options, hostContext: baseHost });
      const baseKey = workspaceKey(baseHost.workspacePath, baseHost.workspaceId, baseHost.projectId);
      const bundles = new Map<string, Promise<BrainProvidersBundle>>([[baseKey, Promise.resolve(base)]]);
      const initialized = new WeakSet<BrainProvidersBundle>();
      const sessionWorkspaces = new Map<string, string>();
      let disposed = false;

      const bundleFor = async (context: InvocationContext): Promise<BrainProvidersBundle> => {
        // A call still in flight when its lifetime is replaced must not open a bundle that nothing
        // will dispose: its leases would block the next lifetime.
        if (disposed) throw new Error('Memory Brain providers are disposed.');
        const host = contextualHostSnapshot(baseHost, context);
        const key = workspaceKey(host.workspacePath, host.workspaceId, host.projectId);
        bindSessionWorkspace(sessionWorkspaces, context.scope?.sessionId, key);
        let pending = bundles.get(key);
        if (!pending) {
          pending = initializeBundle(createBrainProviders({ ...options, hostContext: host }));
          // The host forgets through the base bundle's store; this bundle's slots follow it too.
          void pending.then((bundle) => base.userMemory.onPurged(bundle.purges.listener), () => undefined);
          bundles.set(key, pending);
          pending.catch(() => bundles.delete(key));
        } else {
          pending = pending.then(async (bundle) => {
            if (!initialized.has(bundle)) {
              await bundle.initialize();
              initialized.add(bundle);
            }
            return bundle;
          });
          bundles.set(key, pending);
        }
        return pending;
      };

      const routeProvider = (index: number): CapabilityProvider => {
        const descriptorProvider = base.providers[index]!;
        return {
          id: descriptorProvider.id,
          ...(descriptorProvider.version ? { version: descriptorProvider.version } : {}),
          list: (context) => descriptorProvider.list(context),
          ...(descriptorProvider.get
            ? { get: (name: string, context: InvocationContext) => descriptorProvider.get!(name, context) }
            : {}),
          async invoke(name, input, context) {
            return (await bundleFor(context)).providers[index]!.invoke(name, input, context);
          },
        };
      };
      const lifecycle: RuntimeProvidersLifecyclePort = {
        async startSession(request) {
          const bundle = await lifecycleBundleFor(request);
          return bundle.lifecycle.startSession(request);
        },
        async observeTurn(request) {
          const bundle = await lifecycleBundleFor(request);
          return bundle.lifecycle.observeTurn(request);
        },
        async endSession(request) {
          const bundle = await lifecycleBundleFor(request);
          try {
            return await bundle.lifecycle.endSession(request);
          } finally {
            sessionWorkspaces.delete(request.sessionId);
          }
        },
      };
      const jobHandler: RuntimeBackgroundJobHandler = {
        kind: base.jobHandlers[0]!.kind,
        leaseDurationMs: base.jobHandlers[0]!.leaseDurationMs,
        async start(request, context, control) {
          return (await bundleFor(context)).jobHandlers[0]!.start(request, context, control);
        },
        async resume(job, context, control) {
          const handler = (await bundleFor(context)).jobHandlers[0]!;
          if (!handler.resume) throw new Error('Memory Brain job recovery is unavailable.');
          return handler.resume(job, context, control);
        },
        async cancel(job, context) {
          const handler = (await bundleFor(context)).jobHandlers[0]!;
          return handler.cancel?.(job, context);
        },
      };
      const persistScopeInheritance = async (
        parent: InvocationContext,
        childThreadId: string,
      ): Promise<void> => {
        const parentSessionId = parent.scope?.sessionId;
        if (!parentSessionId) {
          throw new Error('Delegation scope inheritance requires a trusted parent session identity.');
        }
        if (
          typeof childThreadId !== 'string'
          || childThreadId.length === 0
          || childThreadId.length > 1_024
        ) {
          throw new Error('childThreadId must be a non-empty string of at most 1024 characters.');
        }
        const bundle = await bundleFor(parent);
        const childContext: InvocationContext = {
          principal: parent.principal,
          ...(parent.identity ? { identity: parent.identity } : {}),
          scope: {
            ...parent.scope,
            sessionId: childThreadId,
            threadId: childThreadId,
          },
        };
        bundle.durableMemory.scopes.inheritToChild(parent, childContext, {
          parentSessionId,
          childSessionId: childThreadId,
        });
      };

      return {
        providers: base.providers.map((_, index) => routeProvider(index)),
        lifecycle,
        jobHandlers: [jobHandler],
        userMemory: base.userMemory,
        purges: combinedPurges(async () => (await Promise.allSettled([...bundles.values()]))
          .flatMap((entry) => (entry.status === 'fulfilled' ? [entry.value.purges] : []))),
        persistScopeInheritance,
        async dispose() {
          if (disposed) return;
          disposed = true;
          const settled = await Promise.allSettled([...new Set(bundles.values())]);
          bundles.clear();
          sessionWorkspaces.clear();
          const failures: unknown[] = [];
          for (const entry of settled) {
            if (entry.status === 'rejected') {
              failures.push(entry.reason);
              continue;
            }
            try {
              await entry.value.dispose();
            } catch (error) {
              failures.push(error);
            }
          }
          if (failures.length === 1) throw failures[0];
          if (failures.length > 1) {
            throw new AggregateError(failures, 'Failed to dispose installed Memory Brain workspaces.');
          }
        },
      };

      async function initializeBundle(bundle: BrainProvidersBundle): Promise<BrainProvidersBundle> {
        await bundle.initialize();
        initialized.add(bundle);
        return bundle;
      }

      async function lifecycleBundleFor(
        request: {
          readonly sessionId: string;
          readonly workspacePath?: string;
          readonly metadata?: Readonly<Record<string, unknown>>;
        },
      ): Promise<BrainProvidersBundle> {
        const bound = sessionWorkspaces.get(request.sessionId);
        if (bound) {
          const existing = bundles.get(bound);
          if (!existing) throw new Error('Memory lifecycle workspace is no longer available.');
          return existing;
        }
        const workspacePath = request.workspacePath;
        const workspaceId = optionalMetadataString(request.metadata, 'workspaceId');
        const projectId = optionalMetadataString(request.metadata, 'projectId');
        if (!workspacePath || !workspaceId || !projectId) {
          if (!workspacePath || samePath(workspacePath, baseHost.workspacePath)) {
            const context = hostInvocationContext(baseHost);
            return bundleFor({
              ...context,
              scope: { ...context.scope, sessionId: request.sessionId },
            });
          }
          throw new Error(
            'Host-normalized lifecycle metadata must include workspaceId and projectId for a non-default workspace.',
          );
        }
        return bundleFor({
          principal: baseHost.principal,
          identity: baseHost.identity,
          scope: {
            sessionId: request.sessionId,
            workspacePath,
            workspaceId,
            projectId,
          },
          metadata: { ...request.metadata, workspacePath },
        });
      }
  }


function withoutCapability(provider: CapabilityProvider, excluded: string): CapabilityProvider {
  return {
    id: provider.id,
    ...(provider.version ? { version: provider.version } : {}),
    async list(context) {
      return (await provider.list(context)).filter((descriptor) => descriptor.name !== excluded);
    },
    ...(provider.get
      ? {
          async get(name: string, context: InvocationContext) {
            return name === excluded ? undefined : provider.get!(name, context);
          },
        }
      : {}),
    invoke(name, input, context) {
      if (name === excluded) {
        throw new Error(
          'Workspace index initialization requires user approval through knowledge.workspace.ensure.',
        );
      }
      return provider.invoke(name, input, context);
    },
  };
}

function signalOptions(context: InvocationContext): KnowledgeIndexRequestOptions | undefined {
  return context.signal instanceof AbortSignal ? { signal: context.signal } : undefined;
}

function isBrainOperation(
  value: string,
): value is 'observe' | 'remember' | 'recall' | 'reflect' {
  return value === 'observe' || value === 'remember' || value === 'recall' || value === 'reflect';
}

function digest(value: string, length: number): string {
  return createHash('sha256').update(value).digest('hex').slice(0, length);
}

function hostInvocationContext(host: RuntimeHostContextSnapshot): InvocationContext {
  return {
    principal: host.principal,
    identity: host.identity,
    scope: {
      workspaceId: host.workspaceId,
      projectId: host.projectId,
      workspacePath: host.workspacePath,
    },
    metadata: { workspacePath: host.workspacePath },
  };
}

function contextualHostSnapshot(
  base: RuntimeHostContextSnapshot,
  context: InvocationContext,
): RuntimeHostContextSnapshot {
  const workspacePath = context.scope?.workspacePath ?? context.metadata?.workspacePath;
  const workspaceId = context.scope?.workspaceId;
  const projectId = context.scope?.projectId;
  if (
    typeof workspacePath !== 'string'
    || !path.isAbsolute(workspacePath)
    || !workspaceId
    || !projectId
  ) {
    throw new Error(
      'Host-authoritative workspacePath, workspaceId, and projectId are required for Memory Brain.',
    );
  }
  return {
    ...base,
    workspacePath: path.resolve(workspacePath),
    workspaceId,
    projectId,
    principal: context.principal,
    identity: context.identity ?? base.identity,
  };
}

function bindSessionWorkspace(
  bindings: Map<string, string>,
  sessionId: string | undefined,
  key: string,
): void {
  if (!sessionId) return;
  const previous = bindings.get(sessionId);
  if (previous && previous !== key) {
    throw new Error('A Memory Brain session cannot switch host-authorized workspaces.');
  }
  bindings.set(sessionId, key);
}

function workspaceKey(
  workspacePath: string,
  workspaceId: string,
  projectId: string,
): string {
  return JSON.stringify([
    normalizePath(workspacePath),
    workspaceId,
    projectId,
  ]);
}

function samePath(left: string, right: string): boolean {
  return normalizePath(left) === normalizePath(right);
}

function normalizePath(value: string): string {
  const resolved = path.resolve(value);
  return process.platform === 'win32' ? resolved.toLocaleLowerCase() : resolved;
}

function optionalMetadataString(
  metadata: Readonly<Record<string, unknown>> | undefined,
  key: string,
): string | undefined {
  const value = metadata?.[key];
  return typeof value === 'string' && value.trim() ? value : undefined;
}

function record(value: unknown): Readonly<Record<string, unknown>> {
  return value && typeof value === 'object' && !Array.isArray(value)
    ? value as Readonly<Record<string, unknown>>
    : {};
}