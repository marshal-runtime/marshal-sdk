import type {
  CapabilityDescriptor,
  CapabilityInvocationResult,
  InvocationContext,
} from '@marshal/agent-runtime-core';
import { assertRuntimeOutputSchema } from '@marshal/agent-runtime-core';
import type { BrandRemoteConfiguration } from './config.js';
import { BrandRemoteError } from './errors.js';
import { CloudBrainError, redactCredentials } from '../cloudBrain/errors.js';
import type { CallerCredentialSource } from '../cloudBrain/googleCredentials.js';
import { RuntimeIdentityError, trustedRuntimeCaller } from '../runtimeIdentity.js';

const RUNTIME_PROTOCOL_VERSION = '1.0.0';
const MCP_PROTOCOL_VERSION = '2025-06-18';
const CLIENT_INFO = { name: 'marshal-brand-brain-remote', version: '0.1.0' } as const;
const MAX_REQUEST_BYTES = 256 * 1024;
const MAX_RESPONSE_BYTES = 4 * 1024 * 1024;
const MAX_DESCRIPTOR_BYTES = 64 * 1024;
const MAX_RESULT_ROWS = 5_000;
const MAX_RESULT_NODES = 50_000;
const MAX_RESULT_DEPTH = 24;
const MAX_SESSIONS = 256;
const MAX_TOOL_PAGES = 5;
const SESSION_TTL_MS = 15 * 60_000;
const DESCRIPTOR_TTL_MS = 10 * 60_000;
const DESKTOP_CONVERSATION = 'desktop';
const BRAND_READ_PERMISSION = 'brand.read';
/** The Brand Brain MCP tools this route exposes, as capability `brand.<name>`. Anything else the service lists is ignored. */
const BRAND_TOOLS: ReadonlySet<string> = new Set([
  'search', 'context', 'impact', 'paths', 'timeline', 'recipes', 'run', 'benchmark', 'entity_story',
]);

interface RpcMessage {
  readonly jsonrpc?: unknown;
  readonly id?: unknown;
  readonly result?: unknown;
  readonly error?: { readonly code: number; readonly message: string };
}

interface RemoteSession {
  readonly callerEmail: string | undefined;
  readonly conversationId: string;
  lastUsedAt: number;
  protocolVersion: string;
  sessionId?: string;
  initialized: boolean;
  initializing?: Promise<void>;
}

interface CallIdentity {
  /** Delegated mode: the trusted runtime-host claim. Desktop mode: undefined, the credential names the person. */
  readonly callerEmail: string | undefined;
  readonly conversationId: string;
}

export interface BrandRemoteClient {
  list(context: InvocationContext): Promise<readonly CapabilityDescriptor[]>;
  get(name: string, context: InvocationContext): Promise<CapabilityDescriptor | undefined>;
  invoke(
    name: string,
    input: unknown,
    descriptor: CapabilityDescriptor,
    context: InvocationContext,
  ): Promise<CapabilityInvocationResult>;
  dispose(): void;
}

export interface BrandRemoteClientDeps {
  readonly credentials: CallerCredentialSource;
  /** `delegated` (runtime host): the asking person comes from the invocation's trusted principal claims. */
  readonly callerMode: 'desktop' | 'delegated';
  readonly fetch?: typeof fetch;
  readonly now?: () => number;
  /** One line per skipped remote tool; defaults to console.warn. */
  readonly warn?: (message: string) => void;
}

export function createBrandRemoteClient(
  configuration: BrandRemoteConfiguration,
  deps: BrandRemoteClientDeps,
): BrandRemoteClient {
  if (!configuration.enabled || !configuration.url) {
    throw new BrandRemoteError('brand_remote_disabled', 'Brand remote route is off.');
  }
  const fetcher = deps.fetch ?? fetch;
  const now = deps.now ?? Date.now;
  const warn = deps.warn ?? ((message: string) => console.warn(message));
  const skippedTools = new Set<string>();
  const skip = (tool: string, reason: string) => {
    if (skippedTools.has(tool)) return;
    skippedTools.add(tool);
    warn(`Brand remote tool ${tool} is not listed: ${reason}`);
  };
  const endpoint = `${new URL(configuration.url).origin}/mcp`;
  const sessions = new Map<string, RemoteSession>();
  const gate = new ConcurrencyGate(configuration.maxConcurrent);
  let nextId = 0;
  let descriptors: { readonly list: readonly CapabilityDescriptor[]; readonly fetchedAt: number } | undefined;

  const callerCredentials = async (identity: CallIdentity, signal?: AbortSignal) => {
    try {
      return await deps.credentials.credentials(signal ?? new AbortController().signal, identity.callerEmail);
    } catch (error) {
      if (signal?.aborted) {
        if (signal.reason instanceof BrandRemoteError) throw signal.reason;
        throw new BrandRemoteError('brand_remote_cancelled', 'Brand remote call was cancelled by the runtime host.');
      }
      const detail = error instanceof CloudBrainError ? safeErrorMessage(error.message) : '';
      throw new BrandRemoteError(
        'brand_remote_auth_failed',
        `Brand remote could not obtain an ID token for the caller${detail ? `: ${detail}` : '.'}`,
      );
    }
  };

  const post = async (
    session: RemoteSession,
    identity: CallIdentity,
    body: string,
    signal: AbortSignal | undefined,
    retryUnauthorized: boolean,
    unavailable: string,
  ): Promise<Response> => {
    const credentials = await callerCredentials(identity, signal);
    const caller = identity.callerEmail ?? credentials.caller;
    let response: Response;
    try {
      response = await fetcher(endpoint, {
        method: 'POST',
        headers: {
          authorization: `Bearer ${credentials.idToken}`,
          'content-type': 'application/json',
          accept: 'application/json, text/event-stream',
          'mcp-protocol-version': session.protocolVersion,
          'x-marshal-conversation-id': identity.conversationId,
          ...(caller ? { 'x-marshal-caller-email': caller } : {}),
          ...(session.sessionId ? { 'mcp-session-id': session.sessionId } : {}),
        },
        body,
        ...(signal ? { signal } : {}),
      });
    } catch (error) {
      if (signal?.aborted) throw signal.reason ?? error;
      throw new BrandRemoteError('brand_remote_unavailable', unavailable);
    }
    if (response.status === 401 && retryUnauthorized) {
      await discard(response);
      deps.credentials.reset();
      return post(session, identity, body, signal, false, unavailable);
    }
    return response;
  };

  const rpc = async (
    session: RemoteSession,
    identity: CallIdentity,
    method: string,
    params?: Readonly<Record<string, unknown>>,
    signal?: AbortSignal,
  ): Promise<{ readonly message: RpcMessage; readonly response: Response }> => {
    const id = ++nextId;
    const body = JSON.stringify({ jsonrpc: '2.0', id, method, ...(params ? { params } : {}) });
    if (Buffer.byteLength(body, 'utf8') > MAX_REQUEST_BYTES) {
      throw new BrandRemoteError('brand_remote_rejected', 'Brand remote request exceeded the configured payload limit.');
    }
    const response = await post(session, identity, body, signal, true,
      'Brand remote is unavailable: its authenticated endpoint could not be reached.');
    await assertHttpOk(response);
    const message = await readRpcMessage(response, id, signal);
    if (message.error) {
      const detail = safeErrorMessage(message.error.message);
      throw new BrandRemoteError('brand_remote_rejected', `Brand remote rejected ${method}${detail ? `: ${detail}` : '.'}`);
    }
    return { message, response };
  };

  const sessionFor = (context: InvocationContext): { identity: CallIdentity; session: RemoteSession } => {
    let identity: CallIdentity;
    if (deps.callerMode === 'delegated') {
      try {
        identity = trustedRuntimeCaller(context);
      } catch (error) {
        if (!(error instanceof RuntimeIdentityError)) throw error;
        throw new BrandRemoteError('brand_remote_auth_failed', 'Brand remote calls from the runtime host require a trusted caller email (principal claim callerEmail) and conversation; none was provided.');
      }
    } else {
      identity = { callerEmail: undefined, conversationId: context.scope?.sessionId ?? DESKTOP_CONVERSATION };
    }
    for (const [conversationId, active] of sessions) {
      if (now() - active.lastUsedAt > SESSION_TTL_MS) sessions.delete(conversationId);
    }
    const existing = sessions.get(identity.conversationId);
    if (existing && existing.callerEmail !== identity.callerEmail) {
      throw new BrandRemoteError('brand_remote_auth_failed', 'Brand remote caller identity changed within an established conversation.');
    }
    if (!existing && sessions.size >= MAX_SESSIONS) {
      throw new BrandRemoteError('brand_remote_busy', 'Brand remote session capacity is full; start a fresh runtime conversation.');
    }
    const session = existing ?? {
      callerEmail: identity.callerEmail,
      conversationId: identity.conversationId,
      lastUsedAt: now(),
      protocolVersion: MCP_PROTOCOL_VERSION,
      initialized: false,
    };
    session.lastUsedAt = now();
    sessions.set(identity.conversationId, session);
    return { identity, session };
  };

  const ensureInitialized = async (
    session: RemoteSession,
    identity: CallIdentity,
    signal?: AbortSignal,
  ): Promise<void> => {
    if (session.initialized) return;
    if (!session.initializing) {
      session.initializing = (async () => {
        const { message, response } = await rpc(session, identity, 'initialize', {
          protocolVersion: MCP_PROTOCOL_VERSION,
          capabilities: {},
          clientInfo: CLIENT_INFO,
        }, signal);
        const result = asRecord(message.result, 'initialize result');
        if (typeof result.protocolVersion !== 'string' || !result.protocolVersion.startsWith('2025-')) {
          throw new BrandRemoteError('brand_remote_failed', 'Brand remote returned an unsupported MCP protocol version.');
        }
        session.protocolVersion = result.protocolVersion;
        const sessionId = response.headers.get('mcp-session-id');
        if (sessionId !== null && !/^[\x21-\x7E]{1,512}$/.test(sessionId)) {
          throw new BrandRemoteError('brand_remote_failed', 'Brand remote returned an invalid MCP session id.');
        }
        session.sessionId = sessionId ?? undefined;
        const notified = await post(session, identity,
          JSON.stringify({ jsonrpc: '2.0', method: 'notifications/initialized' }), signal, true,
          'Brand remote is unavailable while opening its authenticated session.');
        await assertHttpOk(notified);
        await discard(notified);
        session.initialized = true;
      })().finally(() => { session.initializing = undefined; });
    }
    await session.initializing;
  };

  const request = async (
    session: RemoteSession,
    identity: CallIdentity,
    method: string,
    params: Readonly<Record<string, unknown>>,
    signal?: AbortSignal,
  ): Promise<RpcMessage> => {
    await ensureInitialized(session, identity, signal);
    try {
      return (await rpc(session, identity, method, params, signal)).message;
    } catch (error) {
      // A stateful service that restarted or routed us to another instance no longer knows the session id.
      if (error instanceof BrandRemoteError && error.httpStatus === 404 && session.sessionId) {
        session.initialized = false;
        session.sessionId = undefined;
        await ensureInitialized(session, identity, signal);
        return (await rpc(session, identity, method, params, signal)).message;
      }
      throw error;
    }
  };

  const discover = async (context: InvocationContext): Promise<readonly CapabilityDescriptor[]> => {
    const { identity, session } = sessionFor(context);
    if (descriptors && now() - descriptors.fetchedAt < DESCRIPTOR_TTL_MS) return descriptors.list;
    const cancellation = monitorRuntimeCancellation(context.signal);
    return withDeadline(configuration.timeoutMs, cancellation.signal, async (deadlineSignal) => {
      const release = await gate.acquire(deadlineSignal);
      try {
        const found = new Map<string, CapabilityDescriptor>();
        let cursor: string | undefined;
        for (let page = 0; page < MAX_TOOL_PAGES; page += 1) {
          const message = await request(session, identity, 'tools/list', cursor ? { cursor } : {}, deadlineSignal);
          const result = asRecord(message.result, 'tools/list result');
          if (!Array.isArray(result.tools)) {
            throw new BrandRemoteError('brand_remote_failed', 'Brand remote tools/list returned no tools array.');
          }
          for (const tool of result.tools) {
            const descriptor = descriptorFromTool(tool, skip);
            if (descriptor) found.set(descriptor.name, descriptor);
          }
          if (typeof result.nextCursor !== 'string' || result.nextCursor.length === 0) break;
          cursor = result.nextCursor;
        }
        const list = [...found.values()];
        descriptors = { list, fetchedAt: now() };
        return list;
      } finally {
        release();
      }
    }).finally(cancellation.dispose);
  };

  return {
    dispose() { sessions.clear(); descriptors = undefined; },
    list: discover,
    async get(name, context) {
      if (!name.startsWith('brand.')) return undefined;
      return (await discover(context)).find((descriptor) => descriptor.name === name);
    },
    async invoke(name, input, descriptor, context) {
      if (!name.startsWith('brand.') || !BRAND_TOOLS.has(name.slice('brand.'.length)) || descriptor.name !== name) {
        throw new BrandRemoteError('brand_remote_rejected', `Brand remote does not expose ${name}.`);
      }
      const requestInput = input ?? {};
      assertBoundedJson(requestInput, MAX_REQUEST_BYTES - 512, `${name} input`);
      if (descriptor.inputSchema) {
        try {
          assertRuntimeOutputSchema(requestInput, descriptor.inputSchema, `${name} input`);
        } catch (error) {
          const detail = error instanceof Error ? safeErrorMessage(error.message) : '';
          throw new BrandRemoteError('brand_remote_rejected', `${name} input did not match the remote schema${detail ? `: ${detail}` : '.'}`);
        }
      }
      const { identity, session } = sessionFor(context);
      const cancellation = monitorRuntimeCancellation(context.signal);
      return withDeadline(configuration.timeoutMs, cancellation.signal, async (deadlineSignal) => {
        const release = await gate.acquire(deadlineSignal);
        try {
          const tool = `brand_${name.slice('brand.'.length)}`;
          const message = await request(session, identity, 'tools/call', { name: tool, arguments: requestInput }, deadlineSignal);
          const output = toolCallOutput(asRecord(message.result, `${tool} result`), tool);
          assertResultBounds(output, name);
          try {
            assertRuntimeOutputSchema(output, descriptor.outputSchema, `${name} output`);
          } catch (error) {
            const detail = error instanceof Error ? safeErrorMessage(error.message) : '';
            throw new BrandRemoteError('brand_remote_failed', `${name} output did not match the remote schema${detail ? `: ${detail}` : '.'}`);
          }
          return { output };
        } finally {
          release();
        }
      }).finally(cancellation.dispose);
    },
  };
}

function descriptorFromTool(raw: unknown, skip: (tool: string, reason: string) => void): CapabilityDescriptor | undefined {
  if (!isRecord(raw) || typeof raw.name !== 'string' || !raw.name.startsWith('brand_')) return undefined;
  const short = raw.name.slice('brand_'.length);
  if (!BRAND_TOOLS.has(short)) return undefined;
  if (!isRecord(raw.inputSchema) || !isBoundedJson(raw.inputSchema)) {
    skip(raw.name, 'it declares no usable inputSchema.');
    return undefined;
  }
  if (!isStrictObjectOutputSchema(raw.outputSchema) || !isBoundedJson(raw.outputSchema)) {
    skip(raw.name, 'its outputSchema must be an object schema with explicit properties and additionalProperties false.');
    return undefined;
  }
  const description = typeof raw.description === 'string' && raw.description.length > 0
    ? raw.description.slice(0, 8_000)
    : `Stripes Brand Brain ${short.replace('_', ' ')}.`;
  const descriptor: CapabilityDescriptor = {
    protocolVersion: RUNTIME_PROTOCOL_VERSION,
    name: `brand.${short}`,
    version: '1.0.0',
    description,
    tags: ['brand', 'stripes', short],
    permissions: [{ permission: BRAND_READ_PERMISSION, risk: 'low' }],
    inputSchema: raw.inputSchema,
    outputSchema: raw.outputSchema as Record<string, unknown>,
  };
  if (serializedBytes(descriptor) > MAX_DESCRIPTOR_BYTES) {
    skip(raw.name, 'its descriptor exceeds the size limit.');
    return undefined;
  }
  return descriptor;
}

/** The runtime kernel rejects a capability whose outputSchema is not exactly this shape, so a tool without it is never listed. */
function isStrictObjectOutputSchema(schema: unknown): boolean {
  if (!isRecord(schema)) return false;
  return schema.type === 'object'
    && isRecord(schema.properties)
    && schema.additionalProperties === false;
}

function toolCallOutput(result: Record<string, unknown>, tool: string): unknown {
  if (result.isError === true) {
    const text = Array.isArray(result.content)
      ? result.content.find((entry) => isRecord(entry) && typeof entry.text === 'string')
      : undefined;
    const detail = isRecord(text) ? safeErrorMessage(text.text) : '';
    throw new BrandRemoteError('brand_remote_rejected', `Brand remote rejected ${tool}${detail ? `: ${detail}` : '.'}`);
  }
  return readToolOutput(result, tool);
}

function assertResultBounds(value: unknown, capability: string): void {
  let nodes = 0;
  const visit = (current: unknown, depth: number): void => {
    nodes += 1;
    if (nodes > MAX_RESULT_NODES || depth > MAX_RESULT_DEPTH) {
      throw new BrandRemoteError('brand_remote_failed', `${capability} output exceeded the remote structure limit.`);
    }
    if (Array.isArray(current)) {
      if (current.length > MAX_RESULT_ROWS) {
        throw new BrandRemoteError('brand_remote_failed', `${capability} output exceeded the ${MAX_RESULT_ROWS}-row limit.`);
      }
      for (const entry of current) visit(entry, depth + 1);
    } else if (isRecord(current)) {
      for (const entry of Object.values(current)) visit(entry, depth + 1);
    }
  };
  visit(value, 0);
}

function readToolOutput(result: Record<string, unknown>, tool: string): unknown {
  if (isRecord(result.structuredContent)) return result.structuredContent;
  if (!Array.isArray(result.content)) {
    throw new BrandRemoteError('brand_remote_failed', `Brand remote ${tool} response had neither structured content nor text content.`);
  }
  const textContent = result.content.find((entry) => isRecord(entry) && entry.type === 'text' && typeof entry.text === 'string');
  if (!isRecord(textContent) || typeof textContent.text !== 'string') {
    throw new BrandRemoteError('brand_remote_failed', `Brand remote ${tool} response did not contain a text JSON payload.`);
  }
  try {
    return JSON.parse(textContent.text) as unknown;
  } catch {
    throw new BrandRemoteError('brand_remote_failed', `Brand remote ${tool} response contained malformed JSON.`);
  }
}

async function readRpcMessage(response: Response, id: number, signal?: AbortSignal): Promise<RpcMessage> {
  const contentType = response.headers.get('content-type') ?? '';
  if (contentType.includes('text/event-stream')) return readSseRpcMessage(response, id, signal);
  const text = await boundedText(response, signal);
  const message = findRpcMessage([text], id);
  if (message) return message;
  throw new BrandRemoteError('brand_remote_failed', 'Brand remote response was not a JSON-RPC reply for this request.');
}

async function readSseRpcMessage(response: Response, id: number, signal?: AbortSignal): Promise<RpcMessage> {
  const declaredBytes = Number(response.headers.get('content-length'));
  if (Number.isFinite(declaredBytes) && declaredBytes > MAX_RESPONSE_BYTES) {
    await discard(response);
    throw new BrandRemoteError('brand_remote_failed', 'Brand remote response exceeded the maximum allowed size.');
  }
  if (!response.body) throw new BrandRemoteError('brand_remote_failed', 'Brand remote returned an empty event stream.');
  const reader = response.body.getReader();
  const decoder = new TextDecoder('utf-8', { fatal: true });
  let buffer = '';
  let total = 0;
  try {
    while (true) {
      if (signal?.aborted) throw signal.reason;
      const { done, value } = await reader.read();
      if (done) {
        buffer += decoder.decode();
        const last = parseSseBlock(buffer, id);
        if (last) return last;
        break;
      }
      total += value.byteLength;
      if (total > MAX_RESPONSE_BYTES) {
        await reader.cancel();
        throw new BrandRemoteError('brand_remote_failed', 'Brand remote response exceeded the maximum allowed size.');
      }
      buffer += decoder.decode(value, { stream: true });
      while (true) {
        const boundary = buffer.search(/\r?\n\r?\n/);
        if (boundary < 0) break;
        const matched = /\r?\n\r?\n/.exec(buffer.slice(boundary))!;
        const block = buffer.slice(0, boundary);
        buffer = buffer.slice(boundary + matched[0].length);
        const message = parseSseBlock(block, id);
        if (message) {
          await reader.cancel();
          return message;
        }
      }
    }
  } catch (error) {
    if (error instanceof BrandRemoteError) throw error;
    if (signal?.aborted) throw signal.reason ?? error;
    throw new BrandRemoteError('brand_remote_failed', 'Brand remote returned an invalid event stream.');
  } finally {
    reader.releaseLock();
  }
  throw new BrandRemoteError('brand_remote_failed', 'Brand remote event stream ended without a JSON-RPC reply for this request.');
}

function parseSseBlock(block: string, id: number): RpcMessage | undefined {
  const data = block.split(/\r?\n/)
    .filter((line) => line.startsWith('data:'))
    .map((line) => line.slice(5).trimStart())
    .join('\n');
  return data ? findRpcMessage([data], id) : undefined;
}

function findRpcMessage(candidates: readonly string[], id: number): RpcMessage | undefined {
  for (const candidate of candidates) {
    let parsed: unknown;
    try { parsed = JSON.parse(candidate); } catch {
      throw new BrandRemoteError('brand_remote_failed', 'Brand remote returned malformed JSON-RPC data.');
    }
    for (const entry of Array.isArray(parsed) ? parsed : [parsed]) {
      if (!isRecord(entry) || entry.id !== id) continue;
      const hasResult = Object.hasOwn(entry, 'result');
      const hasError = Object.hasOwn(entry, 'error');
      if (entry.jsonrpc !== '2.0' || hasResult === hasError) {
        throw new BrandRemoteError('brand_remote_failed', 'Brand remote returned a malformed JSON-RPC envelope.');
      }
      if (hasError && (!isRecord(entry.error) || !Number.isInteger(entry.error.code)
        || typeof entry.error.message !== 'string' || entry.error.message.length > 4_096)) {
        throw new BrandRemoteError('brand_remote_failed', 'Brand remote returned a malformed JSON-RPC error.');
      }
      return entry as unknown as RpcMessage;
    }
  }
  return undefined;
}

function serializedBytes(value: unknown): number {
  try { return Buffer.byteLength(JSON.stringify(value), 'utf8'); } catch { return Infinity; }
}

function assertBoundedJson(value: unknown, maxBytes: number, label: string): void {
  let bytes = 0;
  let nodes = 0;
  const active = new WeakSet<object>();
  const add = (count: number) => {
    bytes += count;
    if (bytes > maxBytes) throw new BrandRemoteError('brand_remote_rejected', `${label} exceeded the remote payload limit.`);
  };
  const quotedStringBytes = (text: string) => {
    if (text.length > maxBytes) throw new BrandRemoteError('brand_remote_rejected', `${label} exceeded the remote payload limit.`);
    let count = 2;
    for (const character of text) {
      const codePoint = character.codePointAt(0)!;
      count += character === '"' || character === '\\'
        || ['\b', '\t', '\n', '\f', '\r'].includes(character) ? 2
        : codePoint < 0x20 || (codePoint >= 0xD800 && codePoint <= 0xDFFF) ? 6
          : Buffer.byteLength(character, 'utf8');
      if (count > maxBytes) throw new BrandRemoteError('brand_remote_rejected', `${label} exceeded the remote payload limit.`);
    }
    return count;
  };
  const visit = (current: unknown, depth: number): void => {
    nodes += 1;
    if (nodes > 10_000 || depth > 24) {
      throw new BrandRemoteError('brand_remote_rejected', `${label} exceeded the remote structure limit.`);
    }
    if (current === null) { add(4); return; }
    if (typeof current === 'boolean') { add(current ? 4 : 5); return; }
    if (typeof current === 'number') {
      if (!Number.isFinite(current)) throw new BrandRemoteError('brand_remote_rejected', `${label} must contain finite JSON numbers.`);
      add(String(current).length);
      return;
    }
    if (typeof current === 'string') { add(quotedStringBytes(current)); return; }
    if (!current || typeof current !== 'object') throw new BrandRemoteError('brand_remote_rejected', `${label} must contain JSON values only.`);
    if (active.has(current)) throw new BrandRemoteError('brand_remote_rejected', `${label} must not contain cyclic values.`);
    active.add(current);
    if (Array.isArray(current)) {
      if (current.length > 10_000) throw new BrandRemoteError('brand_remote_rejected', `${label} exceeded the remote structure limit.`);
      add(2);
      for (let index = 0; index < current.length; index += 1) {
        if (index > 0) add(1);
        visit(current[index], depth + 1);
      }
    } else {
      const prototype = Object.getPrototypeOf(current);
      if (prototype !== Object.prototype && prototype !== null) {
        throw new BrandRemoteError('brand_remote_rejected', `${label} must contain plain JSON objects.`);
      }
      const entries = Object.entries(current);
      if (entries.length > 10_000) throw new BrandRemoteError('brand_remote_rejected', `${label} exceeded the remote structure limit.`);
      add(2);
      for (let index = 0; index < entries.length; index += 1) {
        const [key, entry] = entries[index]!;
        if (index > 0) add(1);
        add(quotedStringBytes(key));
        add(1);
        visit(entry, depth + 1);
      }
    }
    active.delete(current);
  };
  visit(value, 0);
}

function isBoundedJson(value: unknown, depth = 0, budget = { nodes: 2_048 }): boolean {
  budget.nodes -= 1;
  if (budget.nodes < 0 || depth > 16) return false;
  if (value === null || typeof value === 'boolean') return true;
  if (typeof value === 'number') return Number.isFinite(value);
  if (typeof value === 'string') return value.length <= 8_192;
  if (Array.isArray(value)) return value.length <= 2_048 && value.every((entry) => isBoundedJson(entry, depth + 1, budget));
  if (!isRecord(value)) return false;
  const entries = Object.entries(value);
  return entries.length <= 2_048 && entries.every(([key, entry]) => key.length <= 256 && isBoundedJson(entry, depth + 1, budget));
}

async function boundedText(response: Response, signal?: AbortSignal): Promise<string> {
  const contentLength = Number(response.headers.get('content-length'));
  if (Number.isFinite(contentLength) && contentLength > MAX_RESPONSE_BYTES) {
    await discard(response);
    throw new BrandRemoteError('brand_remote_failed', 'Brand remote response exceeded the maximum allowed size.');
  }
  if (!response.body) return '';
  const reader = response.body.getReader();
  const chunks: Uint8Array[] = [];
  let total = 0;
  try {
    while (true) {
      if (signal?.aborted) throw signal.reason;
      const { done, value } = await reader.read();
      if (done) break;
      total += value.byteLength;
      if (total > MAX_RESPONSE_BYTES) {
        await reader.cancel();
        throw new BrandRemoteError('brand_remote_failed', 'Brand remote response exceeded the maximum allowed size.');
      }
      chunks.push(value);
    }
  } finally {
    reader.releaseLock();
  }
  const joined = new Uint8Array(total);
  let offset = 0;
  for (const chunk of chunks) {
    joined.set(chunk, offset);
    offset += chunk.byteLength;
  }
  try {
    return new TextDecoder('utf-8', { fatal: true }).decode(joined);
  } catch {
    throw new BrandRemoteError('brand_remote_failed', 'Brand remote response was not valid UTF-8.');
  }
}

async function assertHttpOk(response: Response): Promise<void> {
  if (response.ok) return;
  await discard(response);
  if (response.status === 401 || response.status === 403) {
    throw new BrandRemoteError('brand_remote_auth_failed', `Brand remote refused the authenticated staff caller (HTTP ${response.status}).`, response.status);
  }
  if (response.status === 429) {
    throw new BrandRemoteError('brand_remote_busy', 'Brand remote is rate limiting this request (HTTP 429).', 429, 5);
  }
  if (response.status === 502 || response.status === 503 || response.status === 504) {
    throw new BrandRemoteError('brand_remote_unavailable', `Brand remote is unavailable (HTTP ${response.status}).`, response.status, 30);
  }
  if (response.status >= 400 && response.status < 500) {
    throw new BrandRemoteError('brand_remote_rejected', `Brand remote rejected the request (HTTP ${response.status}).`, response.status);
  }
  throw new BrandRemoteError('brand_remote_failed', `Brand remote failed with HTTP ${response.status}.`, response.status);
}

async function withDeadline<T>(
  deadlineMs: number,
  parent: AbortSignal | undefined,
  work: (signal: AbortSignal) => Promise<T>,
): Promise<T> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(new BrandRemoteError(
    'brand_remote_timeout', `Brand remote did not answer within ${deadlineMs} ms.`, undefined, 30,
  )), deadlineMs);
  const cancel = () => controller.abort(new BrandRemoteError('brand_remote_cancelled', 'Brand remote call was cancelled by the runtime host.'));
  if (parent?.aborted) cancel();
  parent?.addEventListener?.('abort', cancel, { once: true });
  try {
    return await Promise.race([
      work(controller.signal),
      new Promise<never>((_, reject) => {
        if (controller.signal.aborted) reject(controller.signal.reason);
        controller.signal.addEventListener('abort', () => reject(controller.signal.reason), { once: true });
      }),
    ]);
  } catch (error) {
    if (controller.signal.aborted && controller.signal.reason instanceof BrandRemoteError) throw controller.signal.reason;
    if (parent?.aborted) throw new BrandRemoteError('brand_remote_cancelled', 'Brand remote call was cancelled by the runtime host.');
    throw error;
  } finally {
    clearTimeout(timer);
    parent?.removeEventListener?.('abort', cancel);
  }
}

interface ConcurrencyWaiter {
  readonly resolve: () => void;
  readonly reject: (error: unknown) => void;
  readonly signal: AbortSignal;
}

class ConcurrencyGate {
  #running = 0;
  readonly #waiting: ConcurrencyWaiter[] = [];

  constructor(private readonly limit: number) {}

  async acquire(signal: AbortSignal): Promise<() => void> {
    if (signal.aborted) throw new BrandRemoteError('brand_remote_cancelled', 'Brand remote call was cancelled before it started.');
    let permitTransferred = false;
    if (this.#running >= this.limit) {
      await new Promise<void>((resolve, reject) => {
        let waiting!: ConcurrencyWaiter;
        const abort = () => {
          const index = this.#waiting.indexOf(waiting);
          if (index >= 0) this.#waiting.splice(index, 1);
          reject(new BrandRemoteError('brand_remote_cancelled', 'Brand remote call was cancelled while waiting for capacity.'));
        };
        waiting = {
          resolve: () => { permitTransferred = true; signal.removeEventListener('abort', abort); resolve(); },
          reject: (error) => { signal.removeEventListener('abort', abort); reject(error); },
          signal,
        };
        signal.addEventListener('abort', abort, { once: true });
        this.#waiting.push(waiting);
      });
    }
    if (!permitTransferred) this.#running += 1;
    return () => {
      while (this.#waiting.length > 0) {
        const next = this.#waiting.shift()!;
        if (next.signal.aborted) {
          next.reject(new BrandRemoteError('brand_remote_cancelled', 'Brand remote call was cancelled while waiting for capacity.'));
          continue;
        }
        next.resolve();
        return;
      }
      this.#running -= 1;
    };
  }
}

function monitorRuntimeCancellation(signal: InvocationContext['signal']): {
  readonly signal?: AbortSignal;
  readonly dispose: () => void;
} {
  if (!signal) return { dispose() {} };
  const eventedSignal = signal as typeof signal & { addEventListener?: unknown };
  if (typeof eventedSignal.addEventListener === 'function') {
    return { signal: signal as AbortSignal, dispose() {} };
  }
  const controller = new AbortController();
  const check = () => {
    if (signal.aborted && !controller.signal.aborted) {
      controller.abort(signal.reason ?? new BrandRemoteError('brand_remote_cancelled', 'Brand remote call was cancelled by the runtime host.'));
    }
  };
  check();
  if (controller.signal.aborted) return { signal: controller.signal, dispose() {} };
  const timer = setInterval(check, 100);
  return { signal: controller.signal, dispose: () => clearInterval(timer) };
}

function asRecord(value: unknown, label: string): Record<string, unknown> {
  if (!isRecord(value)) throw new BrandRemoteError('brand_remote_failed', `Brand remote returned malformed ${label}.`);
  return value;
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return Boolean(value && typeof value === 'object' && !Array.isArray(value));
}

function safeErrorMessage(value: unknown): string {
  if (typeof value !== 'string') return '';
  return redactCredentials(value).slice(0, 400);
}

async function discard(response: Response): Promise<void> {
  try { await response.body?.cancel(); } catch { /* best-effort response cleanup */ }
}
