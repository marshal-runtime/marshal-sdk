import type { InvocationContext } from '@marshal/agent-runtime-core';
import type {
  ForeignAgentMemory,
  ForeignAgentPromotionPlan,
  ForeignAgentPromotionResult,
  MemoryScopeHandle,
  PortableMemoryRuntime,
} from '@marshal/agent-runtime-provider-memory';
import type { MarshalMemoryEntry } from './marshalMemoryStore.js';
import { comparableFact, decodeUserMemoryFactKey, userMemoryFactKey } from './userMemoryFactKey.js';

export const AGENT_SCOPE_PROMOTION_MIGRATION_ID = 'marshal-user-memory/agent-scope-promotion/v1';
export const HOST_MEMORY_BLESSING_MIGRATION_ID = 'marshal-user-memory/bless-host-written/v1';

export type UserScopeMigrationResult = ForeignAgentPromotionResult & { readonly blessed: number };

/**
 * One-time move of memories that sessions wrote to their own agent scopes into
 * the user's scope. Content, blessed and createdAt carry over; the category comes
 * from a user-memory fact key when the original has one, else it is a fact. The
 * source records where it came from (`promoted/<original id>`). Afterwards every
 * host-written memory of the user scope (promoted copies included) is blessed, so
 * only the host store can change it.
 */
export async function promoteAgentScopesIntoUserMemory(
  runtime: PortableMemoryRuntime,
  handle: MemoryScopeHandle,
  context: InvocationContext,
  activeUserMemories: () => readonly MarshalMemoryEntry[],
): Promise<UserScopeMigrationResult> {
  // Listed on the first foreign memory only, so a start with nothing to promote stays one query.
  let existingFacts: Map<string, string> | undefined;
  const existing = () => (existingFacts ??= new Map(activeUserMemories().map((entry) => [comparableFact(entry.fact), entry.id])));
  const promotion = await runtime.promoteForeignAgentScopes({
    targetHandle: handle,
    migrationId: AGENT_SCOPE_PROMOTION_MIGRATION_ID,
    plan: (source) => planPromotion(source, existing()),
    // Two sessions may have stored the same text: the second reuses the first copy.
    recorded: ({ memory }, targetMemoryId) => {
      const fact = comparableFact(memory.content);
      if (!existing().has(fact)) existing().set(fact, targetMemoryId);
    },
  }, context);
  const blessing = await runtime.blessHostWrittenMemories({
    targetHandle: handle,
    migrationId: HOST_MEMORY_BLESSING_MIGRATION_ID,
  }, context);
  return { ...promotion, blessed: blessing.status === 'completed' ? blessing.blessed : 0 };
}

function planPromotion(
  { memory }: ForeignAgentMemory,
  existing: ReadonlyMap<string, string>,
): ForeignAgentPromotionPlan {
  const reuseMemoryId = existing.get(comparableFact(memory.content));
  if (reuseMemoryId) return { reuseMemoryId };
  const decoded = decodeUserMemoryFactKey(memory.factKey);
  return {
    content: memory.content,
    retrievalSynopsis: memory.retrievalSynopsis || memory.content.slice(0, 3_800),
    factKey: userMemoryFactKey(
      memory.content,
      decoded.category ?? 'fact',
      decoded.source ?? `promoted/${memory.id}`,
    ),
  };
}
