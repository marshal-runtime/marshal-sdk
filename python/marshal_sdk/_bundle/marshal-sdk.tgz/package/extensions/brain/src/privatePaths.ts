import * as fs from 'fs';
import * as path from 'node:path';

export function requireExternalPrivateDirectory(
  workspacePath: string,
  configured: string | undefined,
  label: string,
): string {
  if (!configured?.trim() || !path.isAbsolute(configured)) {
    throw new Error(`${label} is required and must be an absolute harness-private directory outside workspacePath.`);
  }
  const workspace = path.resolve(workspacePath);
  const candidate = path.resolve(configured);
  if (isContained(workspace, candidate)) throw new Error(`${label} must be outside workspacePath.`);
  fs.mkdirSync(candidate, { recursive: true, mode: 0o700 });
  const stat = fs.lstatSync(candidate);
  if (stat.isSymbolicLink() || !stat.isDirectory()) throw new Error(`${label} must be a real directory.`);
  const canonical = fs.realpathSync(candidate);
  if (!samePath(candidate, canonical) || isContained(workspace, canonical)) {
    throw new Error(`${label} cannot traverse a symbolic link or junction or resolve inside workspacePath.`);
  }
  return canonical;
}

export function requireExternalPrivateFile(
  workspacePath: string,
  configured: string | undefined,
  label: string,
): string {
  if (!configured?.trim() || !path.isAbsolute(configured)) {
    throw new Error(`${label} is required and must be an absolute harness-private file outside workspacePath.`);
  }
  const candidate = path.resolve(configured);
  const parent = requireExternalPrivateDirectory(workspacePath, path.dirname(candidate), `${label} parent`);
  const resolved = path.join(parent, path.basename(candidate));
  if (fs.existsSync(resolved)) {
    const stat = fs.lstatSync(resolved);
    if (stat.isSymbolicLink() || !stat.isFile()) throw new Error(`${label} must be a real file.`);
    if (!samePath(resolved, fs.realpathSync(resolved))) throw new Error(`${label} cannot traverse a symbolic link or junction.`);
  }
  return resolved;
}

function isContained(root: string, candidate: string): boolean {
  const relative = path.relative(root, candidate);
  return relative === ''
    || (!relative.startsWith(`..${path.sep}`) && relative !== '..' && !path.isAbsolute(relative));
}

function samePath(left: string, right: string): boolean {
  return process.platform === 'win32' ? left.toLowerCase() === right.toLowerCase() : left === right;
}
