/** Every way a cloud Brain call can fail, as the `code` of the thrown error. */
export type CloudBrainErrorCode =
  | 'cloud_brain_disabled'
  | 'cloud_brain_auth_failed'
  | 'cloud_brain_unavailable'
  | 'cloud_brain_starting'
  | 'cloud_brain_busy'
  | 'cloud_brain_timeout'
  | 'cloud_brain_cancelled'
  | 'cloud_brain_rejected'
  | 'cloud_brain_failed';

/** A failed cloud Brain call. The message never holds a credential; `retryAfterSeconds` is set when waiting helps. */
export class CloudBrainError extends Error {
  readonly code: CloudBrainErrorCode;
  readonly retryAfterSeconds?: number;
  readonly httpStatus?: number;
  /** The status the cloud tool answered with (`not-found`, `invalid-request`, ...), when the failure came from the tool itself. */
  readonly toolStatus?: string;

  constructor(
    code: CloudBrainErrorCode,
    message: string,
    options: { retryAfterSeconds?: number; httpStatus?: number; toolStatus?: string } = {},
  ) {
    super(message);
    this.name = 'CloudBrainError';
    this.code = code;
    if (options.retryAfterSeconds !== undefined) this.retryAfterSeconds = options.retryAfterSeconds;
    if (options.httpStatus !== undefined) this.httpStatus = options.httpStatus;
    if (options.toolStatus !== undefined) this.toolStatus = options.toolStatus;
  }
}

export function isCloudBrainError(value: unknown): value is CloudBrainError {
  return value instanceof CloudBrainError;
}

const BEARER = /Bearer\s+[A-Za-z0-9._~+/=-]+/g;
const JWT = /eyJ[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]{8,}\.[A-Za-z0-9_-]{8,}/g;
const GOOGLE_TOKEN = /ya29\.[A-Za-z0-9._-]+/g;
const REFRESH_TOKEN = /1\/\/[A-Za-z0-9._-]{20,}/g;

/** Removes anything shaped like a bearer, ID, access or refresh token from text that may reach a caller. */
export function redactCredentials(text: string): string {
  return text
    .replace(BEARER, 'Bearer [redacted]')
    .replace(JWT, '[redacted-jwt]')
    .replace(GOOGLE_TOKEN, '[redacted-token]')
    .replace(REFRESH_TOKEN, '[redacted-token]');
}
