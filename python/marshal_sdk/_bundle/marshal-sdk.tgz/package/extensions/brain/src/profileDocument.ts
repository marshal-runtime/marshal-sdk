import { mkdirSync, readFileSync, renameSync, writeFileSync } from 'fs';
import * as path from 'node:path';
import { timedKind } from './memoryReview.js';

/** One memory as the profile sees it; `projectId` for project/workspace memories, `appliesTo` for the user's. */
export interface ProfileMemory {
  readonly id: string;
  readonly text: string;
  readonly category?: 'preference' | 'fact' | 'decision' | 'context';
  readonly createdAt: string;
  /** "global" or a project id. */
  readonly appliesTo: string;
  readonly factKey?: string;
  readonly needsReview?: string;
}

export interface ProfileWriteResult {
  readonly path: string;
  readonly written: boolean;
  readonly lines: number;
}

const LINE_CHARS = 220;
export const PROFILE_FILE = 'profile.md';

/** Where profile.md lives: beside the profile projections (their sibling directory), never indexed as a memory. */
export function profileDocumentPath(profileProjectionRoot: string): string {
  return path.join(path.dirname(profileProjectionRoot), 'brain-profile', PROFILE_FILE);
}

/**
 * profile.md (review D10): a deterministic one-pager, generated at heal from the active memories with
 * no model call. Static part: rules and preferences, grouped by the project they apply to. Dynamic
 * part: active programs and context, decisions and incidents with their dates, and what needs review.
 * Every line cites its memory id. Same memories on the same day give the same bytes.
 */
export function renderProfile(memories: readonly ProfileMemory[], generatedOn: string, projectNames: ReadonlyMap<string, string> = new Map()): string {
  const ordered = [...memories].sort((left, right) => right.createdAt.localeCompare(left.createdAt) || left.id.localeCompare(right.id));
  const line = (memory: ProfileMemory) => {
    const text = memory.text.replace(/\s+/g, ' ').trim();
    const clipped = text.length > LINE_CHARS ? `${text.slice(0, LINE_CHARS - 1)}…` : text;
    return `- ${clipped} (${memory.id}, ${memory.createdAt.slice(0, 10)})`;
  };
  const project = (appliesTo: string) => (appliesTo === 'global' ? 'All projects' : projectNames.get(appliesTo) ?? appliesTo);
  const sections: string[] = [
    '# Profile',
    '',
    `> Generated ${generatedOn} by Brain from ${memories.length} active memories. Derived, regenerable, not authoritative:`,
    '> the cited memories are the source of truth. Heal regenerates this file; edits here are overwritten.',
    '',
    '## Static: rules and preferences',
  ];
  const rules = ordered.filter((memory) => memory.category === 'preference');
  const groups = [...new Set(rules.map(({ appliesTo }) => appliesTo))]
    .sort((left, right) => (left === 'global' ? -1 : right === 'global' ? 1 : project(left).localeCompare(project(right))));
  if (groups.length === 0) sections.push('', '_None._');
  for (const group of groups) {
    sections.push('', `### ${project(group)}`, ...rules.filter(({ appliesTo }) => appliesTo === group).map(line));
  }
  const incidents = ordered.filter((memory) => timedKind({ content: memory.text, fact_key: memory.factKey ?? null }) === 'incident');
  const incidentIds = new Set(incidents.map(({ id }) => id));
  const dynamic: Array<[string, readonly ProfileMemory[]]> = [
    ['Active programs and context', ordered.filter((memory) => memory.category === 'context' && !incidentIds.has(memory.id))],
    ['Decisions', ordered.filter((memory) => memory.category === 'decision' && !incidentIds.has(memory.id))],
    ['Incidents', incidents],
  ];
  sections.push('', '## Dynamic');
  for (const [title, entries] of dynamic) {
    sections.push('', `### ${title}`, ...(entries.length > 0 ? entries.map(line) : ['_None._']));
  }
  const review = ordered.filter((memory) => memory.needsReview);
  sections.push('', '### Needs review', ...(review.length > 0
    ? review.map((memory) => `${line(memory)} — ${memory.needsReview}`)
    : ['_None._']));
  return `${sections.join('\n')}\n`;
}

/** Writes the profile when its bytes changed (atomic rename); the path either way. */
export function writeProfile(filePath: string, content: string): ProfileWriteResult {
  const lines = content.split('\n').filter((entry) => entry.startsWith('- ')).length;
  let previous: string | undefined;
  try {
    previous = readFileSync(filePath, 'utf8');
  } catch {
    previous = undefined;
  }
  if (previous === content) return { path: filePath, written: false, lines };
  mkdirSync(path.dirname(filePath), { recursive: true, mode: 0o700 });
  const temporary = `${filePath}.${process.pid}.tmp`;
  writeFileSync(temporary, content, { encoding: 'utf8', mode: 0o600 });
  renameSync(temporary, filePath);
  return { path: filePath, written: true, lines };
}

/** After a purge: drops every profile line citing a purged id, so the purged text leaves this file too. */
export function dropFromProfile(filePath: string, memoryIds: readonly string[]): boolean {
  let current: string;
  try {
    current = readFileSync(filePath, 'utf8');
  } catch {
    return false;
  }
  const kept = current.split('\n').filter((entry) => !memoryIds.some((id) => entry.includes(`(${id},`)));
  const next = kept.join('\n');
  if (next === current) return false;
  writeProfile(filePath, next);
  return true;
}
