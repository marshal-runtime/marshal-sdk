import type { RuntimePackageDeclaration } from '@marshal/runtime';

export const BRAIN_PACKAGE_DECLARATION: RuntimePackageDeclaration = {
  packageId: '@marshal/brain',
  packageVersion: '0.1.0',
  capabilityPrefixes: ['memory.', 'knowledge.', 'code.'],
  skills: [{
    id: 'marshal.brain/memory',
    title: 'Use Marshal Brain',
    description: 'Use Brain for natural-language repository intelligence, architecture, rationale, related implementation, blast radius, scoped recall, durable memory, correction, promotion, and forgetting.',
    tags: ['memory', 'brain', 'code', 'knowledge'],
    content: [
      '# Marshal Brain',
      '',
      'Brain is the agent’s repository-intelligence and memory assistant. For natural-language questions about architecture, mechanisms, tradeoffs, design rationale, related implementation, blast radius, unfamiliar subsystems, cross-cutting behavior, or prior decisions—especially without an exact symbol—call `memory.brain.recall` first with the full user question. It searches scoped memory and the Runtime-selected code intelligence service. Use direct repository tools for an exact known file or symbol and for simple local edits.',
      'For an ordinary historical question, make the runtime execution call to `memory.brain.recall` with input `{ "content": "<the user question>" }` your first runtime action; do not rediscover its known schema first. Never infer or merely assert that Brain is unavailable: only use a fallback after that exact call returns a tool-level unavailable or unknown-tool rejection. Recall can already search scoped memory and unified code knowledge, so start there instead of issuing separate status, search, context, and impact calls speculatively.',
      'Successful recall is synchronous and complete, not a background job. When recall returns selected durable memory and linked code paths, that is sufficient historical and path-level evidence: answer immediately and cite the returned paths without opening files merely to add line numbers. Inspect only returned targets when recall explicitly marks evidence missing, incomplete, contradictory, or in need of current-code verification. Do not run broad repository inventories, history sweeps, or synonym searches. Remember, unlike recall, continues durably in the background after acceptance.',
      'Route explicit remember requests and accepted stable preferences, decisions, constraints, or reusable discoveries to `memory.brain.remember`; it durably enqueues background work, so return after acceptance instead of waiting for completion.',
      'For unified code, memory, and evidence context, use `knowledge.search` to resolve a target when needed, then `knowledge.context` to expand it.',
      'For blast-radius, dependency, or change-impact questions across code and memory, use `knowledge.impact` with the requested direction.',
      'Use only the host-issued `scopeHandles` supplied to Brain; fixed session/agent/workspace/project selectors remain compatible. Brain may search several currently granted scopes in one bounded request, but it cannot invent scope IDs, expand grants, or use stale policy versions.',
      'For a correction or supersession, first resolve exactly one authorized scoped memory, then use `memory.correct`; never invent or copy an unreturned memory ID.',
      'Use `promote_memory` for an explicit scope-boundary move; the runtime reauthorizes the source and target through `memory.promote`, creates a derived target, and returns promotion status plus lineage.',
      'For forgetting or deletion, first resolve exactly one authorized scoped memory, then use soft-delete `memory.delete`. Use irreversible `memory.purge` only for an explicit privacy-purge request.',
      'Lifecycle hooks append bounded deterministic transcript evidence. They do not run per-turn semantic analysis. One sealed-session review, or abandoned-session recovery, owns automatic durable extraction; do not invoke or duplicate `memory.brain.observe` or `memory.brain.reflect` during an ordinary task.',
      'Use `knowledge.workspace.status` before creating or refreshing a workspace code index. When Brain reports that repository intelligence is uninitialized, request user approval through `knowledge.workspace.ensure` with `{ "mode": "create-if-missing" }`; do not autoapprove or wait synchronously for indexing.',
      'Durable memory scopes are Markdown-authoritative; SQLite is their rebuildable working cache and remains temporary authority only for ephemeral scopes. Retrieval synopses, fact keys, lifecycle state, and typed lineage are memory semantics; vectors, rankings, receipts, counters, and graph generations are not memory truth.',
    ].join('\n'),
  }],
  lifecyclePhases: [
    'session.start',
    'prompt.submit',
    'tool.result',
    'assistant.complete',
    'session.end',
  ],
};
