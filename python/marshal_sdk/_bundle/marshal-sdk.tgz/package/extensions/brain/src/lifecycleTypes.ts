export interface RuntimeSessionStartRequest {
  readonly protocolVersion?: string;
  readonly eventId?: string;
  readonly sessionId: string;
  readonly parentSessionId?: string;
  readonly agentId?: string;
  readonly workspacePath?: string;
  readonly metadata?: Readonly<Record<string, unknown>>;
}

export interface RuntimeTurnObservationRequest {
  readonly protocolVersion?: string;
  readonly eventId?: string;
  readonly sessionId: string;
  readonly parentSessionId?: string;
  readonly kind: 'user_message' | 'tool_result' | 'assistant_turn';
  readonly content: unknown;
  readonly toolName?: string;
  readonly agentId?: string;
  readonly workspacePath?: string;
  readonly metadata?: Readonly<Record<string, unknown>>;
}

export interface RuntimeSessionEndRequest {
  readonly protocolVersion?: string;
  readonly eventId?: string;
  readonly sessionId: string;
  readonly parentSessionId?: string;
  readonly outcome?: string;
  readonly agentId?: string;
  readonly workspacePath?: string;
  readonly metadata?: Readonly<Record<string, unknown>>;
}

export interface RuntimeProvidersLifecyclePort {
  startSession(request: RuntimeSessionStartRequest): Promise<unknown>;
  observeTurn(request: RuntimeTurnObservationRequest): Promise<unknown>;
  endSession(request: RuntimeSessionEndRequest): Promise<unknown>;
}
