import type { CapabilityProvider } from '@marshal/agent-runtime-core';
import type { PortableMemoryRuntime } from '@marshal/agent-runtime-provider-memory';

/**
 * Judge J3: after a legacy memory.store {scope: "session"} succeeds, records which session owns the
 * row, so ending that session (or the heal, once the session is gone) retires it. Recording never
 * fails the store.
 */
export function withSessionNoteOwners(provider: CapabilityProvider, runtime: () => PortableMemoryRuntime): CapabilityProvider {
  return {
    id: provider.id,
    ...(provider.version ? { version: provider.version } : {}),
    list: (context) => provider.list(context),
    ...(provider.get ? { get: (name: string, context: Parameters<CapabilityProvider['list']>[0]) => provider.get!(name, context) } : {}),
    async invoke(name, input, context) {
      const output = await provider.invoke(name, input, context);
      if (name === 'memory.store' && (input as { scope?: unknown } | null)?.scope === 'session') {
        try {
          runtime().recordSessionNoteOwner(context);
        } catch {
          // the heal's idle rule still retires the row once the session has been quiet long enough
        }
      }
      return output;
    },
  };
}
