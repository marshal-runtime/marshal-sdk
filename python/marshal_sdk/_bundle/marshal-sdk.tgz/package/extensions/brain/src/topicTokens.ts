/**
 * Cheap topic words for the needs-review code scan: identifiers and words of 5+ characters,
 * lower-cased, with snake_case, kebab-case and camelCase parts split out, minus English stop-words
 * and words any code or config uses. Words are reduced to a light stem so "connectors" meets
 * "connector", "retries" and "retried" meet "retry", and "delayed" meets "delay".
 */
const MIN_LENGTH = 5;

const STOP_WORDS = new Set(`
  about above across after again against along already although always among another anything
  around because before being below between both cannot could doing during either else every
  everything further having here itself later might never nothing often other others ourselves
  perhaps rather shall should since something still their theirs there these they those though
  through under unless until using where whether which while whose within without would yours
  first second third plus also instead only just shown given gives makes turns based means each
  when what with from that this than then them into onto over upon your ours very much many more
  most some such same sure make made uses used does done like well three seven eight fifty sixty
  seventy eighty ninety hundred thousand million
`.trim().toLowerCase().split(/\s+/));

const CODE_WORDS = new Set(`
  string strings number numbers boolean integer float float64 int64 int32 uint64 bytes array arrays
  object objects value values return returns import imports export exports function functions
  const class classes interface interfaces public private protected static async await true false
  null undefined none self super struct package module modules method methods param params
  argument arguments options option settings setting config configs configuration context index
  types typed default defaults error errors result results input inputs output outputs request
  requests response responses handler handlers service services server servers client clients
  table tables query queries select where insert update delete create created schema schemas model
  models field fields column columns length count source sources target targets data test tests
  testing main file files path paths name names format logger debug warning message messages
  version versions local global shared utils util helper helpers common status state states check checks
  enabled disabled value label labels description title items entry entries record records list
  lists println printf sprintf errorf fmtprint yaml json python golang typescript javascript script
  scripts stringagg timestamp datetime current_date coalesce cast case group order limit
  offset having join inner outer left right union distinct exists isnull notnull varchar text
  todo fixme note notes readme example examples docs document documents markdown section
  properties property attribute attributes element elements component components props children
  className style styles render event events callback callbacks promise promises handle handles
  mutex logging metrics metric trace traces span spans build builds deploy deploys
`.trim().toLowerCase().split(/\s+/));

const IDENTIFIER = /[A-Za-z_][A-Za-z0-9_-]*/g;

function parts(identifier: string): string[] {
  return identifier
    .split(/[_-]+/)
    .flatMap((piece) => piece.split(/(?<=[a-z0-9])(?=[A-Z])|(?<=[A-Z])(?=[A-Z][a-z])/))
    .filter(Boolean);
}

/** Porter's measure m of a stem: the number of vowel-consonant sequences in it. */
function measure(stem: string): number {
  return stem.replace(/[aeiouy]+/g, 'V').replace(/[^V]+/g, 'C').split('VC').length - 1;
}

/**
 * Plural and -ed/-ing endings, Porter step 1 style. -eed loses its "d" only when m > 0 (agreed, not
 * speed); -ed and -ing go only from a stem with m > 0 (not bring). A stem ending in at, bl or iz, or
 * a short consonant-vowel-consonant one (stor, mov), gets its "e" back; a doubled consonant is
 * undone; any other stem of three letters keeps its ending (embed).
 */
function stem(lower: string): string {
  if (lower.length <= 4) return lower;
  if (/(?:ies|ied)$/.test(lower)) return `${lower.slice(0, -3)}y`;
  if (/(?:sses|ss)$/.test(lower)) return lower.endsWith('sses') ? lower.slice(0, -2) : lower;
  if (lower.endsWith('s') && !/(?:us|is)$/.test(lower)) return lower.slice(0, -1);
  if (lower.endsWith('eed')) return measure(lower.slice(0, -3)) > 0 ? lower.slice(0, -1) : lower;
  const ending = /(?:ing|ed)$/.exec(lower)?.[0];
  if (!ending) return lower;
  const base = lower.slice(0, -ending.length);
  if (measure(base) === 0) return lower;
  if (/(?:at|bl|iz)$/.test(base)) return `${base}e`;
  if (/([b-df-hj-np-tv-z])\1$/.test(base) && !/(?:ll|ss|zz)$/.test(base)) return base.slice(0, -1);
  if (measure(base) === 1 && /[^aeiou][aeiouy][^aeiouwxy]$/.test(base)) return `${base}e`;
  return base.length < 4 ? lower : base;
}

function normalized(word: string): string {
  return stem(word.toLowerCase());
}

/** Length and stop-words judge the word as written and its stem ("updated" is as generic as "update"). */
function keep(word: string, raw: string): boolean {
  const lower = raw.toLowerCase();
  return lower.length >= MIN_LENGTH && word.length >= 3 && !/^\d/.test(lower)
    && !STOP_WORDS.has(word) && !CODE_WORDS.has(word) && !STOP_WORDS.has(lower) && !CODE_WORDS.has(lower);
}

/** Every topic word on a line of code, config or prose (repeats included). */
export function lineTokens(line: string): string[] {
  const tokens: string[] = [];
  for (const [identifier] of line.matchAll(IDENTIFIER)) {
    const whole = normalized(identifier);
    if (keep(whole, identifier)) tokens.push(whole);
    const split = parts(identifier);
    if (split.length > 1) for (const part of split) if (keep(normalized(part), part)) tokens.push(normalized(part));
  }
  return tokens;
}

/**
 * Each memory's distinctive words ranked by TF-IDF over the given memories: how often it uses a word,
 * weighted by how few of the others do. A word most of them use (df above half, from three memories
 * up) is dropped: it names the shared domain, not one memory's topic. Equal scores (on a short memory
 * every word ties) rank by first appearance: the words a memory leads with are its topic.
 */
export function rankTopicWords(texts: ReadonlyMap<string, string>): Map<string, string[]> {
  const counts = new Map([...texts].map(([id, text]) => {
    const count = new Map<string, number>();
    for (const token of lineTokens(text)) count.set(token, (count.get(token) ?? 0) + 1);
    return [id, count] as const;
  }));
  const documents = new Map<string, number>();
  for (const count of counts.values()) for (const word of count.keys()) documents.set(word, (documents.get(word) ?? 0) + 1);
  const total = counts.size;
  const ranked = new Map<string, string[]>();
  for (const [id, count] of counts) {
    const scored = [...count]
      .filter(([word]) => total < 3 || documents.get(word)! * 2 <= total)
      .map(([word, times], position) => [word, times * Math.log((total + 1) / documents.get(word)!), position] as const)
      .sort((left, right) => right[1] - left[1] || left[2] - right[2]);
    ranked.set(id, scored.map(([word]) => word));
  }
  return ranked;
}

/** A memory's distinctive words. */
export function distinctiveTokens(text: string): ReadonlySet<string> {
  return new Set(lineTokens(text));
}
