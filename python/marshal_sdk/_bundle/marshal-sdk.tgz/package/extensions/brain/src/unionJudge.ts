import type { UnionCandidate, UnionJudge } from './cloudKnowledge.js';

/** The part of the Jev client the union judge uses. */
export interface UnionJudgeClient {
  ask(
    request: {
      readonly state: unknown;
      readonly questions: Readonly<Record<string, {
        readonly type: 'choice';
        readonly criteria: Readonly<Record<string, unknown>>;
        readonly instructions: string;
      }>>;
    },
    options?: { readonly signal?: AbortSignal; readonly timeoutMs?: number },
  ): Promise<{ readonly answers: Readonly<Record<string, unknown>> }>;
}

const QUESTION = 'best';
const INSTRUCTIONS =
  'Which candidate (a code symbol, a file, a memory, a pull request, a ticket, a meeting or a person) best answers what the query describes? Judge by its name, path and text.';

export function unionJudgeRequest(query: string, candidates: readonly UnionCandidate[]) {
  const criteria: Record<string, unknown> = {};
  candidates.forEach((candidate, index) => {
    criteria[`c${index + 1}`] = {
      symbol: candidate.name,
      ...(candidate.path === undefined ? {} : { path: candidate.path }),
      ...(candidate.summary === undefined ? {} : { doc: candidate.summary }),
    };
  });
  return {
    state: { task: 'code search', query },
    questions: { [QUESTION]: { type: 'choice' as const, criteria, instructions: INSTRUCTIONS } },
  };
}

/** A union judge backed by the Jev client, resolved per call so it follows the Jev extension being enabled or removed. */
export function createUnionJudge(resolveClient: () => UnionJudgeClient | undefined): UnionJudge {
  return async (query, candidates, options) => {
    const client = resolveClient();
    if (client === undefined) throw Object.assign(new Error('The Jev client service is not available.'), { code: 'JEV_NOT_INSTALLED' });
    const response = await client.ask(unionJudgeRequest(query, candidates), {
      timeoutMs: options.timeoutMs,
      ...(options.signal ? { signal: options.signal } : {}),
    });
    const answer = response.answers[QUESTION];
    const probabilities = answer !== null && typeof answer === 'object'
      ? (answer as { probabilities?: unknown }).probabilities
      : undefined;
    if (probabilities === null || typeof probabilities !== 'object') {
      throw Object.assign(new Error('Jev returned no choice probabilities.'), { code: 'JEV_INVALID_RESPONSE' });
    }
    return candidates.map((_, index) => {
      const value = (probabilities as Record<string, unknown>)[`c${index + 1}`];
      return typeof value === 'number' && Number.isFinite(value) ? value : 0;
    });
  };
}
