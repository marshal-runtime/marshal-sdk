import { createHash } from 'node:crypto';
import { DatabaseSync } from 'node:sqlite';
import * as path from 'node:path';
import type { ILLMClient, IMemoryReasoner } from '@marshal/holographic-memory';
import type { InvocationContext, RuntimePrincipal } from '@marshal/agent-runtime-core';
import {
  createHolographicMemoryCapabilities,
  createPortableMemoryBrainProvider,
  createWorkspaceMemoryProjection,
  DurableMemoryBrainJobProducer,
  PortableMemoryLifecycle,
  PortableMemoryRuntime,
  SqliteTranscriptStore,
  type HolographicMemoryCapabilities,
  type MemoryBrainLimits,
  type MemoryBrainJobEnqueuer,
  type KnowledgeIndex,
  type LocalMemoryPrincipal,
  type MemoryLifecycleTurn,
  type MemoryScopeHandle,
  type SharedAgentScopeOwner,
} from '@marshal/agent-runtime-provider-memory';
import {
  DurableLifecycleEventCoordinator,
  withLifecycleReceipt,
} from '@marshal/agent-runtime-provider-kit';
import type {
  RuntimeProvidersLifecyclePort,
  RuntimeSessionEndRequest,
  RuntimeSessionStartRequest,
  RuntimeTurnObservationRequest,
} from './lifecycleTypes.js';
import { requireExternalPrivateFile } from './privatePaths.js';
import { requireExternalPrivateDirectory } from './privatePaths.js';
import { requireProtectedLifecycleResultRoot } from './protectedRoot.js';
import { inheritVerifiedParentScopes } from './memoryLifecycleLineage.js';
import { MEMORY_REVIEW_OFF, type MemoryReviewGate } from './memoryReviewGate.js';
import { createUserDailyHeal, type HealLog } from './userDailyHeal.js';
import { lifecycleScopeIds, type LifecycleTrustedIds } from './lifecycleScopeIds.js';

export { DurableLifecycleEventCoordinator, DurableMemoryBrainJobProducer, withLifecycleReceipt };

export interface RuntimeMemoryLifecycleOptions {
  readonly workspacePath: string;
  readonly stateRoot: string;
  /** Trusted registry identity used for stable project scope across worktrees (host id used verbatim). */
  readonly trustedProjectId?: string;
  /** Host workspace id; used verbatim so lifecycle and agents share the workspace scope. */
  readonly trustedWorkspaceId?: string;
  /** Required absolute harness-private SQLite file outside workspacePath. */
  readonly memoryDbPath: string;
  /** External Markdown-authoritative durable memory root; defaults beside memoryDbPath. */
  readonly memoryProjectionRoot?: string;
  /** Profile-owned durable Markdown root shared across project partitions. */
  readonly memoryProfileProjectionRoot?: string;
  /** Absolute harness-private root for replay result bodies; never place this below workspacePath. */
  readonly protectedLifecycleResultRoot?: string;
  readonly principal?: RuntimePrincipal;
  readonly llmClient?: ILLMClient;
  readonly memoryReasoner?: IMemoryReasoner;
  readonly memoryBrainLimits?: MemoryBrainLimits;
  readonly brainJobs?: MemoryBrainJobEnqueuer;
  readonly knowledgeIndex?: KnowledgeIndex;
  readonly memoryProfileId?: string;
  /** Every caller's built-in agent scope resolves to this owner's scope. */
  readonly sharedAgentScope?: SharedAgentScopeOwner;
  /** Who the one local reader is when a call carries no access claim; set only by the desktop host's configuration. Without it such a call reads no memory. */
  readonly localPrincipal?: LocalMemoryPrincipal;
  /** Sealed transcript and semantic healing reviews run only when this is enabled (default off). */
  readonly memoryReview?: MemoryReviewGate;
  readonly healLog?: HealLog;
  /** How often the index backlog is looked at between session starts (default one minute; 0 turns the drain off). */
  /** The daily heal's dry-run check of the stale repository sweeps (purgeFollowUp.ts; review R13l-L2). */
  /** Runs after each session start's daily heal settles (the code-change review and profile.md; healExtras.ts). */
  readonly afterDailyHeal?: {
    schedule(handles: readonly MemoryScopeHandle[], context: InvocationContext, after: Promise<unknown>): void;
    waitForIdle(): Promise<void>;
    /** Stops running work (a running git is killed) before dispose waits for it. */
    cancel?(): void;
  };
}

export interface RuntimeMemoryLifecycleBundle {
  readonly lifecycle: RuntimeProvidersLifecyclePort;
  readonly memory: HolographicMemoryCapabilities;
  readonly durableMemory: PortableMemoryRuntime;
  readonly transcripts: SqliteTranscriptStore;
  /**
   * Deletes every cached lifecycle callback result under provider-events (recalled memory text,
   * injected context), after a complete forget (judge wave 3 F1). A later duplicate of an old event
   * replays with resultUnavailable and never reruns. `available: false` on a runtime without it.
   */
  purgeLifecycleResults(): Promise<LifecycleResultsPurge>;
  dispose(): Promise<void>;
}

export interface LifecycleResultsPurge {
  readonly available: boolean;
  readonly removed: number;
}

/** Cached lifecycle results expire after a day either way (runtime 01e38cc; ignored before it). */
const LIFECYCLE_RESULT_RETENTION_MS = 86_400_000;

type PurgeResults = (filter: { readonly all: true }) => Promise<{
  readonly removed: number;
  readonly removedUnreadable?: number;
  readonly removedTemporary?: number;
  readonly truncated?: boolean;
}>;

function requireMemoryProfileId(value: string | undefined): string {
  if (!value || !/^profile-[a-f0-9]{24,64}$/.test(value)) {
    throw new Error('memoryProfileId must be an opaque profile digest.');
  }
  return value;
}

/**
 * Compose only the durable memory lifecycle used by latency-sensitive harness
 * hooks. This deliberately excludes artifacts, attachments, code intelligence,
 * TypeScript, UI, effects, jobs, scheduling, and native delegation.
 */
export function createRuntimeMemoryLifecycle(
  options: RuntimeMemoryLifecycleOptions,
): RuntimeMemoryLifecycleBundle {
  if (!path.isAbsolute(options.workspacePath)) throw new Error('workspacePath must be absolute.');
  if (!path.isAbsolute(options.stateRoot)) throw new Error('stateRoot must be absolute.');
  const workspacePath = path.resolve(options.workspacePath);
  const stateRoot = path.resolve(options.stateRoot);
  const protectedLifecycleResultRoot = requireProtectedLifecycleResultRoot(
    workspacePath,
    options.protectedLifecycleResultRoot,
  );
  const memoryDbPath = requireExternalPrivateFile(workspacePath, options.memoryDbPath, 'memoryDbPath');
  const memoryProjectionRoot = requireExternalPrivateDirectory(
    workspacePath,
    options.memoryProjectionRoot ?? path.join(path.dirname(memoryDbPath), 'memory-v2'),
    'memoryProjectionRoot',
  );
  const memoryProfileProjectionRoot = requireExternalPrivateDirectory(
    workspacePath,
    options.memoryProfileProjectionRoot ?? memoryProjectionRoot,
    'memoryProfileProjectionRoot',
  );
  const principal: RuntimePrincipal = options.principal
    ? {
        id: options.principal.id,
        kind: options.principal.kind,
        ...(options.principal.claims ? { claims: { ...options.principal.claims } } : {}),
      }
    : { id: 'agent-runtime', kind: 'agent' };
  // Sealed and semantic reviews are model work: only with a dedicated review key.
  const reviewJobs = (options.memoryReview ?? MEMORY_REVIEW_OFF).enabled ? options.brainJobs : undefined;
  const portableDb = new DatabaseSync(memoryDbPath);
  portableDb.exec('PRAGMA busy_timeout = 30000;');
  const durableMemory = new PortableMemoryRuntime(portableDb, {
    rootDirectory: memoryProjectionRoot,
    profileRootDirectory: memoryProfileProjectionRoot,
    legacyProfileRootDirectories: [memoryProjectionRoot],
    ...(options.knowledgeIndex
      ? {
          knowledgeIndex: options.knowledgeIndex,
          memoryKnowledgeIndex: options.knowledgeIndex,
        }
      : {}),
    ...(reviewJobs ? { brainJobs: reviewJobs } : {}),
    ...(options.sharedAgentScope ? { sharedAgentScope: options.sharedAgentScope } : {}),
    ...(options.localPrincipal ? { localPrincipal: options.localPrincipal } : {}),
  });
  const transcripts = new SqliteTranscriptStore(portableDb);
  // Review R13e-L2: a provider-kit without purgeResults (main's, not host-42's) cannot delete the
  // cached lifecycle results; the heal line and every complete forget say so.
  const resultsPurgeAvailable = typeof (DurableLifecycleEventCoordinator.prototype as { purgeResults?: unknown }).purgeResults === 'function';
  const userHeal = createUserDailyHeal(durableMemory, portableDb, options.healLog, resultsPurgeAvailable);
  const durableLifecycle = new PortableMemoryLifecycle({
    runtime: durableMemory,
    transcripts,
    ...(reviewJobs ? { brainJobs: reviewJobs } : {}),
    scheduleDailyHealing: (handles, ownerDate, context) => {
      userHeal.schedule(handles, ownerDate, context);
      options.afterDailyHeal?.schedule(handles, context, userHeal.waitForIdle());
    },
  });
  const memory = createHolographicMemoryCapabilities({
    dbPath: memoryDbPath,
    llmClient: options.llmClient,
    reasoner: options.memoryReasoner,
    brainJobs: options.brainJobs,
    brainLimits: options.memoryBrainLimits,
    brainMemoryProvider: createPortableMemoryBrainProvider(durableMemory),
    portableMemoryRuntime: durableMemory,
    lifecycleBrainJobs: false,
    enforceBrainSearchBeforeWrite: true,
    ...(options.knowledgeIndex
      ? {
          knowledgeIndex: options.knowledgeIndex,
          knowledgeMemoryScopes: (context: InvocationContext) =>
            durableMemory.scopes.handlesForContext(context).map(({ scopeId }) => scopeId),
          projection: createWorkspaceMemoryProjection({
            workspaceRoot: workspacePath,
            directory: memoryProjectionRoot,
            profileId: requireMemoryProfileId(options.memoryProfileId),
            knowledgeIndex: options.knowledgeIndex,
          }),
        }
      : {}),
  });
  const sessions = new Map<string, LifecycleSession>();
  const trustedIds: LifecycleTrustedIds = { projectId: options.trustedProjectId, workspaceId: options.trustedWorkspaceId };

  const lifecycleDelegate: RuntimeProvidersLifecyclePort = {
    async startSession(request) {
      validateSessionId(request.sessionId);
      const context = toInvocationContext(request, workspacePath, principal, trustedIds);
      const key = lifecycleSessionRegistryKey(context);
      const existing = sessions.get(key);
      if (existing) {
        return { sessionId: request.sessionId, injectedContext: null, reused: true };
      }
      try {
        inheritVerifiedParentScopes(sessions, request, context, durableMemory);
        await durableMemory.activate(context);
        durableMemory.scopes.registerVerifiedSession(context);
        const memoryResult = await memory.lifecycle.startSession(context);
        let portable;
        try {
          portable = await durableLifecycle.startSession(context);
        } catch (error) {
          await memory.lifecycle.endSession(context);
          throw error;
        }
        sessions.set(key, { key, context, turnIndex: 0, sessionEpoch: portable.sessionEpoch });
        return mergeLifecycleResult(memoryResult, { durableMemory: portable });
      } catch (error) {
        sessions.delete(key);
        throw error;
      }
    },
    async observeTurn(request) {
      const session = await ensureSession(
        sessions,
        request,
        workspacePath,
        principal,
        memory,
        durableMemory,
        durableLifecycle,
        trustedIds,
      );
      const explicitTurnIndex = readTurnIndex(request.metadata);
      const turnIndex = explicitTurnIndex ?? session.turnIndex;
      session.turnIndex = Math.max(session.turnIndex + 1, turnIndex + 1);
      const content = normalizeTurnContent(request.content, request.toolName);
      const turn: MemoryLifecycleTurn = {
        role: request.kind === 'user_message' ? 'user' : 'assistant',
        phase: request.kind,
        content,
        turnIndex,
        toolCalls: request.toolName ? [{ name: request.toolName, result: content }] : undefined,
      };
      const captured = durableLifecycle.append(session.context, session.sessionEpoch, {
        ...(request.eventId ? { eventId: request.eventId } : {}),
        kind: request.kind,
        content,
        turnIndex,
        ...(readNonNegativeInteger(request.metadata, 'compactionSegment') === undefined
          ? {}
          : { compactionSegment: readNonNegativeInteger(request.metadata, 'compactionSegment') }),
        ...(request.toolName ? { toolName: request.toolName } : {}),
        ...(readMetadataString(request.metadata, 'toolResultReference')
          ? { toolResultReference: readMetadataString(request.metadata, 'toolResultReference') }
          : {}),
        ...(readMetadataString(request.metadata, 'timestamp')
          ? { timestamp: readMetadataString(request.metadata, 'timestamp') }
          : {}),
        receiptCorrelationIds: readMetadataStringArray(request.metadata, 'receiptCorrelationIds', 16),
      });
      const legacy = await memory.lifecycle.observeTurn(turn, session.context);
      return mergeLifecycleResult(legacy, { transcript: captured });
    },
    async endSession(request) {
      const session = await ensureSession(
        sessions,
        request,
        workspacePath,
        principal,
        memory,
        durableMemory,
        durableLifecycle,
        trustedIds,
      );
      let durableResult: Awaited<ReturnType<PortableMemoryLifecycle['endSession']>> | undefined;
      let durableError: unknown;
      try {
        try {
          durableResult = await durableLifecycle.endSession(
            session.context,
            session.sessionEpoch,
            request.outcome === 'abandoned',
          );
        } catch (error) {
          durableError = error;
        }
        const memoryResult = await memory.lifecycle.endSession(session.context);
        if (durableError) throw durableError;
        return mergeLifecycleResult(memoryResult, { durableMemory: durableResult });
      } finally {
        sessions.delete(session.key);
      }
    },
  };
  // The provider-events result directory is Brain's alone: no other provider or extension writes
  // there (the host's own coordinator uses host-events), though every Brain bundle shares it.
  const lifecycleResultOptions = {
    resultDirectory: path.join(protectedLifecycleResultRoot, 'provider-events'),
    resultRetentionMs: LIFECYCLE_RESULT_RETENTION_MS,
  };
  const lifecycleEvents = new DurableLifecycleEventCoordinator(
    path.join(stateRoot, 'lifecycle', 'provider-events'),
    lifecycleResultOptions,
  );
  const lifecycle: RuntimeProvidersLifecyclePort = {
    async startSession(request) {
      return withLifecycleReceipt(
        await lifecycleEvents.apply('session_start', request, (normalized) =>
          lifecycleDelegate.startSession(normalized),
        ),
      );
    },
    async observeTurn(request) {
      return withLifecycleReceipt(
        await lifecycleEvents.apply('turn_observation', request, (normalized) =>
          lifecycleDelegate.observeTurn(normalized),
        ),
      );
    },
    async endSession(request) {
      return withLifecycleReceipt(
        await lifecycleEvents.apply('session_end', request, (normalized) =>
          lifecycleDelegate.endSession(normalized),
        ),
      );
    },
  };

  let disposeOperation: Promise<void> | undefined;
  return {
    lifecycle,
    memory,
    durableMemory,
    transcripts,
    async purgeLifecycleResults() {
      const purge = (lifecycleEvents as unknown as { purgeResults?: PurgeResults }).purgeResults;
      if (typeof purge !== 'function') {
        (options.healLog ?? console).warn('[brain] cached lifecycle results were not purged: the bundled provider-kit has no purgeResults', { available: false });
        return { available: false, removed: 0 };
      }
      let removed = 0;
      // One call scans a bounded number of entries; with all, each call empties that many.
      for (let round = 0; round < 100; round += 1) {
        const purged = await purge.call(lifecycleEvents, { all: true });
        removed += purged.removed + (purged.removedUnreadable ?? 0) + (purged.removedTemporary ?? 0);
        if (!purged.truncated) break;
      }
      return { available: true, removed };
    },
    dispose() {
      if (disposeOperation) return disposeOperation;
      sessions.clear();
      memory.dispose();
      options.afterDailyHeal?.cancel?.();
      disposeOperation = Promise.all([
        userHeal.waitForIdle(),
        options.afterDailyHeal?.waitForIdle(),
        durableMemory.waitForScheduledHealing(),
      ]).then(
        () => undefined,
        () => undefined,
      ).then(() => {
        portableDb.close();
      });
      return disposeOperation;
    },
  };
}

function toInvocationContext(
  request: RuntimeSessionStartRequest,
  defaultWorkspacePath: string,
  principal: RuntimePrincipal,
  trusted: LifecycleTrustedIds = {},
): InvocationContext {
  const effectiveWorkspace = path.resolve(request.workspacePath ?? defaultWorkspacePath);
  const sameWorkspace = process.platform === 'win32'
    ? effectiveWorkspace.toLocaleLowerCase() === defaultWorkspacePath.toLocaleLowerCase()
    : effectiveWorkspace === defaultWorkspacePath;
  if (!sameWorkspace) {
    throw new Error('Lifecycle workspacePath must match the workspace used to create the memory lifecycle.');
  }
  return {
    principal,
    scope: {
      ...lifecycleScopeIds(effectiveWorkspace, trusted),
      sessionId: request.sessionId,
      threadId: typeof request.metadata?.threadId === 'string' ? request.metadata.threadId : undefined,
    },
    metadata: {
      ...request.metadata,
      agentId: request.agentId,
      workspacePath: effectiveWorkspace,
      ...(request.parentSessionId
        ? { verifiedParentSessionId: validateSessionId(request.parentSessionId) }
        : {}),
    },
  };
}

function validateSessionId(sessionId: string): string {
  if (typeof sessionId !== 'string' || sessionId.length === 0 || sessionId.length > 1_024) {
    throw new Error('sessionId must be a non-empty string of at most 1024 characters.');
  }
  return sessionId;
}

async function ensureSession(
  sessions: Map<string, LifecycleSession>,
  request: RuntimeTurnObservationRequest | RuntimeSessionEndRequest,
  workspacePath: string,
  principal: RuntimePrincipal,
  memory: HolographicMemoryCapabilities,
  durableMemory: PortableMemoryRuntime,
  durableLifecycle: PortableMemoryLifecycle,
  trustedIds?: LifecycleTrustedIds,
): Promise<LifecycleSession> {
  validateSessionId(request.sessionId);
  const context = toInvocationContext(request, workspacePath, principal, trustedIds);
  const key = lifecycleSessionRegistryKey(context);
  const existing = sessions.get(key);
  if (existing) return existing;
  try {
    inheritVerifiedParentScopes(sessions, request, context, durableMemory);
    await durableMemory.activate(context);
    durableMemory.scopes.registerVerifiedSession(context);
    await memory.lifecycle.startSession(context);
    const portable = await durableLifecycle.startSession(context);
    const reconstructed = {
      key,
      context,
      turnIndex: readTurnIndex(request.metadata) ?? 0,
      sessionEpoch: portable.sessionEpoch,
    };
    sessions.set(key, reconstructed);
    return reconstructed;
  } catch (error) {
    sessions.delete(key);
    throw error;
  }
}

interface LifecycleSession {
  readonly key: string;
  readonly context: InvocationContext;
  readonly sessionEpoch: number;
  turnIndex: number;
}

function lifecycleSessionRegistryKey(context: InvocationContext): string {
  return createHash('sha256').update(JSON.stringify({
    principalId: context.principal.id,
    principalKind: context.principal.kind,
    agentId: context.identity?.agentId ?? context.metadata?.agentId ?? context.principal.id,
    workspaceId: context.scope?.workspaceId,
    projectId: context.scope?.projectId,
    sessionId: context.scope?.sessionId,
  })).digest('hex');
}

function normalizeTurnContent(content: unknown, toolName?: string): string {
  let normalized: string;
  if (typeof content === 'string') normalized = content;
  else {
    try {
      normalized = JSON.stringify(content);
    } catch {
      normalized = String(content);
    }
  }
  if (normalized.length > 1_000_000) normalized = `${normalized.slice(0, 1_000_000)}…`;
  return toolName ? `[${toolName}] ${normalized}` : normalized;
}

function readTurnIndex(metadata: Readonly<Record<string, unknown>> | undefined): number | undefined {
  return readNonNegativeInteger(metadata, 'turnIndex');
}

function readNonNegativeInteger(
  metadata: Readonly<Record<string, unknown>> | undefined,
  key: string,
): number | undefined {
  const value = metadata?.[key];
  return Number.isSafeInteger(value) && (value as number) >= 0 ? value as number : undefined;
}

function readMetadataString(
  metadata: Readonly<Record<string, unknown>> | undefined,
  key: string,
): string | undefined {
  const value = metadata?.[key];
  return typeof value === 'string' && value.trim() ? value : undefined;
}

function readMetadataStringArray(
  metadata: Readonly<Record<string, unknown>> | undefined,
  key: string,
  maxItems: number,
): readonly string[] {
  const value = metadata?.[key];
  if (value === undefined) return [];
  if (
    !Array.isArray(value)
    || value.length > maxItems
    || value.some((item) => typeof item !== 'string')
  ) {
    throw new Error(`${key} must contain at most ${maxItems} strings.`);
  }
  return value as string[];
}

function mergeLifecycleResult(
  value: unknown,
  extra: Readonly<Record<string, unknown>>,
): Readonly<Record<string, unknown>> {
  if (value && typeof value === 'object' && !Array.isArray(value)) {
    return { ...(value as Readonly<Record<string, unknown>>), ...extra };
  }
  return { memory: value, ...extra };
}
