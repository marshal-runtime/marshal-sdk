/**
 * Recall abstention for the user scope. Brain's lexical search ORs every query token,
 * so "What is the name of Omer's dog?" matches any memory containing "the" or "Omer".
 * A hit is kept only when it contains at least one informative query term: not a
 * stopword or possessive fragment, and not so common in the user's memories that it
 * says nothing (e.g. the user's own name). Tokens follow the FTS tokenizer
 * (unicode61, diacritics removed, lowercase, no stemming), so a term counts exactly
 * when the search itself could have matched it.
 */

// NLTK English stopword list, apostrophes removed as the tokenizer does.
const STOPWORDS = new Set((
  'i me my myself we our ours ourselves you your yours yourself yourselves he him his himself she '
  + 'her hers herself it its itself they them their theirs themselves what which who whom this that '
  + 'these those am is are was were be been being have has had having do does did doing a an the and '
  + 'but if or because as until while of at by for with about against between into through during '
  + 'before after above below to from up down in out on off over under again further then once here '
  + 'there when where why how all any both each few more most other some such no nor not only own same '
  + 'so than too very s t can will just don should now d ll m o re ve y ain aren couldn didn doesn '
  + 'hadn hasn haven isn ma mightn mustn needn shan shouldn wasn weren won wouldn'
).split(' '));

export const isStopword = (term: string): boolean => STOPWORDS.has(term);

/** A term in more than this share of the user's memories is ubiquitous… */
export const UBIQUITOUS_SHARE = 0.2;
/** …but only once it appears in at least this many, so tiny scopes keep their terms. */
const UBIQUITOUS_MIN_DOCUMENTS = 3;

export function recallTokens(text: string): string[] {
  return text
    .normalize('NFKD')
    .replace(/\p{M}+/gu, '')
    .toLowerCase()
    .split(/[^\p{L}\p{N}]+/u)
    .filter(Boolean);
}

/** Query terms that can tell one of the user's memories from the rest. */
export function informativeTerms(query: string, corpus: readonly string[]): Set<string> {
  const candidates = new Set(recallTokens(query).filter((term) => !STOPWORDS.has(term)));
  const documentFrequency = new Map<string, number>();
  for (const text of corpus) {
    for (const token of new Set(recallTokens(text))) {
      if (candidates.has(token)) documentFrequency.set(token, (documentFrequency.get(token) ?? 0) + 1);
    }
  }
  for (const [term, count] of documentFrequency) {
    if (count >= UBIQUITOUS_MIN_DOCUMENTS && count / corpus.length > UBIQUITOUS_SHARE) candidates.delete(term);
  }
  return candidates;
}

/** Keeps search order; drops hits that matched only on uninformative terms. */
export function keepInformativeHits<T>(
  hits: readonly T[],
  hitText: (hit: T) => string,
  query: string,
  corpus: readonly string[],
): T[] {
  const terms = informativeTerms(query, corpus);
  if (terms.size === 0) return [];
  return hits.filter((hit) => recallTokens(hitText(hit)).some((token) => terms.has(token)));
}
