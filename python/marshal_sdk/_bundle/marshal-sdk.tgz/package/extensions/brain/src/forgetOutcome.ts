import type { MemoryLineagePurgeResult } from '@marshal/agent-runtime-provider-memory';

/** A lineage preview (PortableMemoryRuntime.purgeLineage with preview and captureContent), or null when the id is not here. */
export type LineagePreview = () => Promise<MemoryLineagePurgeResult | null>;

/**
 * The memory `forget completely` would erase, resolved in any state (active, deleted by a plain
 * forget, superseded), for the host's approval card (judge wave 3 F2): a plain forget no longer
 * makes the id unknown. `text` is the requested revision's text, or the newest text any revision
 * of its lineage still holds; undefined when none does (a tombstone whose history is gone).
 */
export interface ForgetTarget {
  readonly id: string;
  readonly state: string;
  readonly text: string | undefined;
  /** Every revision a complete forget would erase (the tombstone and its history). */
  readonly revisions: number;
  /** Revisions that still hold text. */
  readonly revisionsWithText: number;
}

/**
 * What a plain forget leaves, stated truthfully (judge wave 3 F2): the memory leaves recall and its
 * own text is blanked; earlier revisions (a correction's predecessors) keep their text until a
 * complete forget, and a content-free tombstone (id, dates, a hashed key) stays either way.
 */
export interface PlainForgetOutcome {
  readonly forgotten: true;
  readonly contentBlanked: true;
  /** Earlier revisions of this memory that still hold text. */
  readonly historyRevisionsWithText: number;
  readonly tombstoneKept: true;
  readonly message: string;
}

export async function forgetTarget(id: string, preview: LineagePreview): Promise<ForgetTarget | null> {
  const lineage = await preview();
  if (!lineage?.preview) return null;
  const contents = lineage.purgedContents ?? [];
  const at = lineage.purgedIds.indexOf(id);
  const requested = lineage.preview[at];
  if (!requested) return null;
  const ownText = contents[at]?.trim() ? contents[at] : undefined;
  const newestOther = lineage.preview
    .map((revision, index) => ({ revision, text: contents[index] }))
    .filter(({ revision, text }) => revision.id !== id && text?.trim())
    .sort((left, right) => rank(left.revision.state) - rank(right.revision.state))[0]?.text;
  return {
    id,
    state: requested.state,
    text: ownText ?? newestOther,
    revisions: lineage.purgedIds.length,
    revisionsWithText: lineage.preview.filter(({ hasContent }) => hasContent).length,
  };
}

export function plainForgetOutcome(id: string, lineage: MemoryLineagePurgeResult | null): PlainForgetOutcome {
  const history = (lineage?.preview ?? []).filter((revision) => revision.id !== id && revision.hasContent).length;
  const kept = history > 0
    ? `${history} earlier revision${history === 1 ? '' : 's'} of it still hold${history === 1 ? 's' : ''} older text. `
      + 'Forgetting it completely erases those and the tombstone.'
    : 'No earlier revision holds its text; only a content-free tombstone (its id and dates) remains, '
      + 'which forgetting it completely also removes.';
  return {
    forgotten: true,
    contentBlanked: true,
    historyRevisionsWithText: history,
    tombstoneKept: true,
    message: `Forgotten: it no longer appears in recall and its text has been blanked. ${kept}`,
  };
}

/** The active revision's text first, then superseded ones, then anything else. */
function rank(state: string): number {
  return state === 'active' ? 0 : state === 'superseded' ? 1 : 2;
}
