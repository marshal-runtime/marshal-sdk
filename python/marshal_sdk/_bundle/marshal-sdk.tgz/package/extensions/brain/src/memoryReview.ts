import { DatabaseSync } from 'node:sqlite';
import { decodeUserMemoryFactKey } from './userMemoryFactKey.js';

/**
 * "Needs review" (review D9): a derived flag, never a memory state. Brain keeps what it needs in
 * its own table, keyed by memory id (a correction is a new id, so it starts unflagged):
 * - a code reason, set at heal when code a memory links to changed on main (codeReviewScan.ts);
 * - an explicit review-by date (a memory's text may also say "review by YYYY-MM-DD");
 * - when the user last confirmed the memory, or stated it again (either clears the flag).
 * Incident and context memories are also flagged after N days without activity.
 */
const TABLE = 'marshal_memory_review_v2';
const HEADS = 'marshal_memory_review_heads_v2';
const LABELS = 'marshal_memory_project_labels_v2';
export const INACTIVE_DAYS_ENV = 'MARSHAL_BRAIN_REVIEW_INACTIVE_DAYS';
export const DEFAULT_INACTIVE_DAYS = 14;
const DAY_MS = 24 * 60 * 60 * 1_000;
const REVIEW_BY_TEXT = /\b(?:review[- ]?by|revisit (?:by|on)|expires?(?: on)?)\s*:?\s*(\d{4}-\d{2}-\d{2})\b/i;
const INCIDENT_KEY = /^v1:(?:[\w.-]+\/)*(?:incidents?|repairs?)\//i;
const INCIDENT_TEXT = /^\s*incident\b/i;

export interface MemoryReviewOptions {
  /** Days without activity after which an incident or context memory needs review. */
  readonly inactiveDays?: number;
  readonly now?: () => Date;
}

interface ReviewRow {
  readonly id: string;
  readonly content: string;
  readonly fact_key: string | null;
  readonly created_at: string | null;
  readonly code_reason: string | null;
  readonly code_flagged_at: string | null;
  readonly review_by: string | null;
  readonly confirmed_at: string | null;
  readonly active_at: string | null;
}

export class MemoryReviews {
  #db: DatabaseSync | undefined;
  readonly #inactiveDays: number;
  readonly #now: () => Date;

  constructor(private readonly memoryDbPath: string, options: MemoryReviewOptions = {}) {
    const configured = options.inactiveDays ?? Number(process.env[INACTIVE_DAYS_ENV] ?? DEFAULT_INACTIVE_DAYS);
    this.#inactiveDays = Number.isFinite(configured) && configured > 0 ? Math.trunc(configured) : DEFAULT_INACTIVE_DAYS;
    this.#now = options.now ?? (() => new Date());
  }

  get inactiveDays(): number {
    return this.#inactiveDays;
  }

  /** The reason each of `memoryIds` needs review; ids that do not are absent. */
  reasons(memoryIds: readonly string[]): ReadonlyMap<string, string> {
    const reasons = new Map<string, string>();
    if (memoryIds.length === 0) return reasons;
    const rows = this.#open().prepare(`
      SELECT memory.id, memory.content, memory.fact_key, memory.created_at, review.code_reason, review.code_flagged_at,
        review.review_by, review.confirmed_at, review.active_at
      FROM marshal_memories_v2 memory LEFT JOIN ${TABLE} review ON review.memory_id = memory.id
      WHERE memory.id IN (SELECT value FROM json_each(?)) AND memory.active = 1 AND memory.state = 'active'
    `).all(JSON.stringify([...new Set(memoryIds)])) as unknown as ReviewRow[];
    for (const row of rows) {
      const reason = this.#reason(row);
      if (reason) reasons.set(row.id, sanitizeReviewText(reason));
    }
    return reasons;
  }

  reason(memoryId: string): string | undefined {
    return this.reasons([memoryId]).get(memoryId);
  }

  /** Records a code change on each memory (heal); a later confirm or restatement clears it. */
  flagCode(flags: ReadonlyArray<{ readonly memoryId: string; readonly reason: string }>): void {
    if (flags.length === 0) return;
    const now = this.#now().toISOString();
    this.#write((db) => {
      const upsert = db.prepare(`INSERT INTO ${TABLE}(memory_id, code_reason, code_flagged_at) VALUES (?, ?, ?)
        ON CONFLICT(memory_id) DO UPDATE SET code_reason = excluded.code_reason, code_flagged_at = excluded.code_flagged_at`);
      for (const { memoryId, reason } of flags) upsert.run(memoryId, reason.slice(0, 300), now);
    });
  }

  /** The explicit confirm: the user reviewed these memories and they still hold. */
  confirm(memoryIds: readonly string[]): number {
    return this.#touch(memoryIds, 'confirmed_at');
  }

  /** The memory was stated again (a re-remember of the same fact, a reused memory.link). */
  recordActivity(memoryId: string): void {
    this.#touch([memoryId], 'active_at');
  }

  setReviewBy(memoryId: string, reviewBy: string | null): void {
    if (reviewBy !== null && !/^\d{4}-\d{2}-\d{2}$/.test(reviewBy)) throw new Error('reviewBy must be YYYY-MM-DD.');
    this.#write((db) => {
      db.prepare(`INSERT INTO ${TABLE}(memory_id, review_by) VALUES (?, ?)
        ON CONFLICT(memory_id) DO UPDATE SET review_by = excluded.review_by`).run(memoryId, reviewBy);
    });
  }

  /** Active memories of these scopes that link to code (memory.link's `code:` targets). */
  codeLinked(scopeIds: readonly string[]): Array<{ memoryId: string; links: string[]; text: string }> {
    const rows = this.#open().prepare(`
      SELECT id, derived_from_json, content FROM marshal_memories_v2
      WHERE scope_id IN (SELECT value FROM json_each(?)) AND active = 1 AND state = 'active' AND derived_from_json LIKE '%"code:%'
      ORDER BY id
    `).all(JSON.stringify([...new Set(scopeIds)])) as Array<{ id: string; derived_from_json: string; content: string }>;
    return rows.map(({ id, derived_from_json: json, content }) => ({
      memoryId: id,
      links: (JSON.parse(json) as unknown[]).filter((link): link is string => typeof link === 'string' && link.startsWith('code:')),
      text: content,
    }));
  }

  /** Names a project (its id and its scope ids) for profile.md, e.g. by its repository's name. */
  labelProject(keys: readonly string[], label: string): void {
    this.#write((db) => {
      const upsert = db.prepare(`INSERT INTO ${LABELS}(label_key, label) VALUES (?, ?)
        ON CONFLICT(label_key) DO UPDATE SET label = excluded.label`);
      for (const key of new Set(keys)) upsert.run(key, label);
    });
  }

  projectLabels(): ReadonlyMap<string, string> {
    const rows = this.#open().prepare(`SELECT label_key, label FROM ${LABELS}`).all() as Array<{ label_key: string; label: string }>;
    return new Map(rows.map(({ label_key: key, label }) => [key, label]));
  }

  /** Every active project and workspace memory (the user's own profile file lists them by project). */
  projectMemories(): Array<{ id: string; scopeId: string; content: string; factKey?: string; createdAt: string }> {
    const rows = this.#open().prepare(`
      SELECT id, scope_id, content, fact_key, created_at FROM marshal_memories_v2
      WHERE scope_kind IN ('project', 'workspace') AND active = 1 AND state = 'active'
      ORDER BY created_at DESC, id
    `).all() as Array<{ id: string; scope_id: string; content: string; fact_key: string | null; created_at: string }>;
    return rows.map((row) => ({
      id: row.id,
      scopeId: row.scope_id,
      content: row.content,
      createdAt: row.created_at,
      ...(row.fact_key ? { factKey: row.fact_key } : {}),
    }));
  }

  /** The main-branch commit this repository's code-linked memories were last checked against. */
  head(repositoryKey: string): string | undefined {
    return (this.#open().prepare(`SELECT head FROM ${HEADS} WHERE repository_key = ?`).get(repositoryKey) as { head: string } | undefined)?.head;
  }

  recordHead(repositoryKey: string, head: string): void {
    this.#write((db) => {
      db.prepare(`INSERT INTO ${HEADS}(repository_key, head, recorded_at) VALUES (?, ?, ?)
        ON CONFLICT(repository_key) DO UPDATE SET head = excluded.head, recorded_at = excluded.recorded_at`)
        .run(repositoryKey, head, this.#now().toISOString());
    });
  }

  close(): void {
    this.#db?.close();
    this.#db = undefined;
  }

  #reason(row: ReviewRow): string | undefined {
    const touched = latest(row.confirmed_at, row.active_at);
    if (row.code_reason && row.code_flagged_at && (!touched || touched < row.code_flagged_at)) return row.code_reason;
    const now = this.#now();
    const today = now.toISOString().slice(0, 10);
    const reviewBy = row.review_by ?? REVIEW_BY_TEXT.exec(row.content)?.[1];
    if (reviewBy && reviewBy < today && !(touched && touched.slice(0, 10) >= reviewBy)) return `review-by ${reviewBy} passed`;
    const kind = timedKind(row);
    const since = latest(row.created_at, touched);
    if (kind && since) {
      const idleDays = Math.floor((now.getTime() - Date.parse(since)) / DAY_MS);
      if (idleDays >= this.#inactiveDays) return `${kind}, no activity for ${idleDays} days`;
    }
    return undefined;
  }

  #touch(memoryIds: readonly string[], column: 'confirmed_at' | 'active_at'): number {
    if (memoryIds.length === 0) return 0;
    const now = this.#now().toISOString();
    let changed = 0;
    this.#write((db) => {
      const upsert = db.prepare(`INSERT INTO ${TABLE}(memory_id, ${column}) VALUES (?, ?)
        ON CONFLICT(memory_id) DO UPDATE SET ${column} = excluded.${column}`);
      const exists = db.prepare('SELECT 1 AS present FROM marshal_memories_v2 WHERE id = ?');
      for (const memoryId of new Set(memoryIds)) {
        if (!exists.get(memoryId)) continue;
        upsert.run(memoryId, now);
        changed += 1;
      }
    });
    return changed;
  }

  #write(write: (db: DatabaseSync) => void): void {
    const db = this.#open();
    db.exec('BEGIN IMMEDIATE');
    try {
      write(db);
      db.exec('COMMIT');
    } catch (error) {
      db.exec('ROLLBACK');
      throw error;
    }
  }

  #open(): DatabaseSync {
    if (this.#db) return this.#db;
    const db = new DatabaseSync(this.memoryDbPath);
    db.exec('PRAGMA busy_timeout = 30000;');
    db.exec(`
      CREATE TABLE IF NOT EXISTS ${TABLE} (
        memory_id TEXT PRIMARY KEY, code_reason TEXT, code_flagged_at TEXT, review_by TEXT, confirmed_at TEXT, active_at TEXT
      );
      CREATE TABLE IF NOT EXISTS ${HEADS} (repository_key TEXT PRIMARY KEY, head TEXT NOT NULL, recorded_at TEXT NOT NULL);
      CREATE TABLE IF NOT EXISTS ${LABELS} (label_key TEXT PRIMARY KEY, label TEXT NOT NULL);
    `);
    this.#db = db;
    return db;
  }
}

/** "incident" or "context" for memories that go stale by time alone; undefined for rules and facts. */
export function timedKind(memory: { readonly content: string; readonly fact_key: string | null }): 'incident' | 'context' | undefined {
  if (INCIDENT_KEY.test(memory.fact_key ?? '') || INCIDENT_TEXT.test(memory.content)) return 'incident';
  return decodeUserMemoryFactKey(memory.fact_key ?? undefined).category === 'context' ? 'context' : undefined;
}

/** The marker recall and prompt lines carry. */
export function needsReviewMarker(reason: string): string {
  return ` [needs review: ${sanitizeReviewText(reason)}]`;
}

/**
 * A review reason names files and symbols from a repository (review round 9 L3): no brackets
 * (they would close or forge the marker), control or line-break characters, and at most 300 characters.
 */
export function sanitizeReviewText(text: string): string {
  return text
    .replace(/[\u0000-\u001f\u007f-\u009f\u2028\u2029]+/g, ' ')
    .replace(/\[/g, '(')
    .replace(/\]/g, ')')
    .replace(/\s+/g, ' ')
    .trim()
    .slice(0, 300);
}

const FORGED_MARKER = /\[(\s*needs\s+review\s*:)/gi;

/** A memory's own text cannot carry the marker: on read paths, one it contains shows as "(needs review:". */
export function withoutReviewMarker(text: string): string {
  return text.replace(FORGED_MARKER, '($1');
}

function latest(...values: ReadonlyArray<string | null | undefined>): string | undefined {
  return values.filter((value): value is string => Boolean(value)).sort().pop();
}
