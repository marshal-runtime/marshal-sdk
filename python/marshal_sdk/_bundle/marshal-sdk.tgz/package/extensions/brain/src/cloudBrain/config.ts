/**
 * Brain's cloud route settings, read from the extension configuration's flat `cloud*` keys (the host merges
 * configuration shallowly, so one changed key keeps the manifest defaults of the others). Off unless `cloudEnabled`.
 */
/**
 * How the cloud route proves who calls: `desktop` (the signed-in person), `delegated` (the host service account's
 * metadata-server token, the person from trusted claims), `service-key` (the same with a service account key, for a
 * host with no metadata server such as an E2B sandbox) or `org` (the org broker).
 */
export type CloudCallerMode = 'desktop' | 'delegated' | 'service-key' | 'org';
export const CLOUD_CALLER_MODES: readonly CloudCallerMode[] = ['desktop', 'delegated', 'service-key', 'org'];

/** A host that runs as a service and names the asking person per call from the invocation's trusted claims. */
export function isServiceCallerMode(mode: CloudCallerMode): boolean {
  return mode === 'delegated' || mode === 'service-key';
}

export interface CloudRouteConfiguration {
  readonly enabled: boolean;
  readonly callerMode: CloudCallerMode;
  /** Origin of the authenticating proxy in front of the cloud Brain; its MCP endpoint is `<url>/mcp`. */
  readonly url?: string;
  /**
   * Audience of the ID token, when the proxy that checks it sits behind a different URL than `url` (a Cloud Run revision
   * tag, a local relay). Defaults to the origin of `url`.
   */
  readonly audience?: string;
  /** Desktop mode's service account to impersonate; delegated mode uses the host service account's metadata-server ID token. */
  readonly callerServiceAccount?: string;
  /** Google user credentials file (`authorized_user`); defaults to `GOOGLE_APPLICATION_CREDENTIALS`, then gcloud's ADC. */
  readonly credentialsFile?: string;
  /** When set, a call is refused unless the signed-in Google account has exactly this email. */
  readonly expectedCaller?: string;
  /** How long knowledge.search waits for cloud hits after it starts; local hits never wait longer. */
  readonly searchBudgetMs: number;
  /**
   * Kept for older configurations: the cloud search alone answers every query, so this budget no longer differs.
   */
  readonly evidenceBudgetMs: number;
  /** Deadline of a call routed to the cloud by id (knowledge.context, knowledge.impact, knowledge.path, knowledge.schema). */
  readonly timeoutMs: number;
  /** Calls in flight to the shared cloud Brain at once; more wait, within their own deadline. */
  readonly maxConcurrent: number;
  /** Largest serialized routed answer returned whole; a larger one comes back as truncated text. */
  readonly maxResultChars: number;
  /** Offers the cloud memory writes (memory.cloud_link, memory.cloud_retire) in the full surface; the five-tool route itself has no write tool. */
  readonly memoryWrites: boolean;
  /**
   * While the cloud route is in use, a cheap `schema` call at most this often keeps the cloud Brain's per-caller runtime
   * from going cold after a quiet moment (the first call after about 15 s of silence costs about 6 s more). 0: off.
   */
  readonly keepWarmMs: number;
}

export const CLOUD_SEARCH_BUDGET_MS = { default: 6_000, min: 250, max: 30_000 } as const;
export const CLOUD_EVIDENCE_BUDGET_MS = { default: 5_000, min: 250, max: 30_000 } as const;
export const CLOUD_TIMEOUT_MS = { default: 30_000, min: 1_000, max: 120_000 } as const;
export const CLOUD_CONCURRENCY = { default: 2, min: 1, max: 8 } as const;
export const CLOUD_RESULT_CHARS = { default: 200_000, min: 1_000, max: 1_000_000 } as const;
export const CLOUD_KEEP_WARM_SECONDS = { default: 0, min: 5, max: 120 } as const;

const EMAIL = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

/** The configuration keys of the cloud route, merged into the extension manifest's configuration schema. */
export const CLOUD_ROUTE_CONFIGURATION_PROPERTIES = {
  cloudEnabled: { type: 'boolean' },
  cloudCallerMode: { type: 'string', enum: CLOUD_CALLER_MODES },
  cloudUrl: { type: 'string', maxLength: 2048 },
  cloudAudience: { type: 'string', maxLength: 2048 },
  cloudCallerServiceAccount: { type: 'string', maxLength: 320 },
  cloudCredentialsFile: { type: 'string', maxLength: 4096 },
  cloudExpectedCaller: { type: 'string', maxLength: 320 },
  cloudSearchBudgetMs: { type: 'integer', minimum: CLOUD_SEARCH_BUDGET_MS.min, maximum: CLOUD_SEARCH_BUDGET_MS.max },
  cloudEvidenceBudgetMs: { type: 'integer', minimum: CLOUD_EVIDENCE_BUDGET_MS.min, maximum: CLOUD_EVIDENCE_BUDGET_MS.max },
  cloudTimeoutMs: { type: 'integer', minimum: CLOUD_TIMEOUT_MS.min, maximum: CLOUD_TIMEOUT_MS.max },
  cloudMaxConcurrent: { type: 'integer', minimum: CLOUD_CONCURRENCY.min, maximum: CLOUD_CONCURRENCY.max },
  cloudMaxResultChars: { type: 'integer', minimum: CLOUD_RESULT_CHARS.min, maximum: CLOUD_RESULT_CHARS.max },
  cloudMemoryWrites: { type: 'boolean' },
  cloudKeepWarmSeconds: { type: 'integer', minimum: 0, maximum: CLOUD_KEEP_WARM_SECONDS.max },
} as const;

/** Reads the raw extension configuration; throws a TypeError/RangeError naming the key that cannot be used. */
export function parseCloudRouteConfiguration(raw: unknown): CloudRouteConfiguration {
  const record = raw && typeof raw === 'object' && !Array.isArray(raw)
    ? raw as Record<string, unknown>
    : {};
  if (record.cloudEnabled !== undefined && typeof record.cloudEnabled !== 'boolean') {
    throw new TypeError('cloudEnabled must be a boolean.');
  }
  const enabled = record.cloudEnabled === true;
  if (record.cloudMemoryWrites !== undefined && typeof record.cloudMemoryWrites !== 'boolean') {
    throw new TypeError('cloudMemoryWrites must be a boolean.');
  }
  const callerMode = record.cloudCallerMode === undefined ? 'desktop' : record.cloudCallerMode;
  if (!CLOUD_CALLER_MODES.includes(callerMode as CloudCallerMode)) {
    throw new TypeError('cloudCallerMode must be desktop, delegated, service-key or org.');
  }
  const url = optionalText(record, 'cloudUrl');
  const audience = optionalText(record, 'cloudAudience');
  const callerServiceAccount = optionalText(record, 'cloudCallerServiceAccount');
  const credentialsFile = optionalText(record, 'cloudCredentialsFile');
  const expectedCaller = optionalText(record, 'cloudExpectedCaller')?.toLowerCase();
  if (url !== undefined) assertHttpsOrigin(url);
  if (audience !== undefined) assertAudience(audience);
  if (callerServiceAccount !== undefined && !EMAIL.test(callerServiceAccount)) {
    throw new TypeError('cloudCallerServiceAccount must be a service account email.');
  }
  if (expectedCaller !== undefined && !EMAIL.test(expectedCaller)) {
    throw new TypeError('cloudExpectedCaller must be an email.');
  }
  if (enabled && callerMode === 'org') {
    // Org mode needs no cloudUrl: the broker is reached through the org session. cloudUrl plus cloudCallerServiceAccount, when both are set, are the gcloud fallback.
  } else if (enabled && url === undefined) {
    throw new TypeError(callerMode === 'desktop'
      ? 'cloudEnabled needs cloudUrl and cloudCallerServiceAccount.'
      : `cloudEnabled with ${String(callerMode)} caller mode needs cloudUrl.`);
  }
  if (enabled && callerMode === 'desktop' && callerServiceAccount === undefined) {
    throw new TypeError('cloudEnabled in desktop caller mode needs cloudCallerServiceAccount.');
  }
  return Object.freeze({
    enabled,
    callerMode: callerMode as CloudCallerMode,
    ...(url === undefined ? {} : { url: new URL(url).origin }),
    ...(audience === undefined ? {} : { audience: new URL(audience).origin }),
    ...(callerServiceAccount === undefined ? {} : { callerServiceAccount }),
    ...(credentialsFile === undefined ? {} : { credentialsFile }),
    ...(expectedCaller === undefined ? {} : { expectedCaller }),
    searchBudgetMs: boundedInteger(record.cloudSearchBudgetMs, CLOUD_SEARCH_BUDGET_MS, 'cloudSearchBudgetMs'),
    evidenceBudgetMs: boundedInteger(record.cloudEvidenceBudgetMs, CLOUD_EVIDENCE_BUDGET_MS, 'cloudEvidenceBudgetMs'),
    timeoutMs: boundedInteger(record.cloudTimeoutMs, CLOUD_TIMEOUT_MS, 'cloudTimeoutMs'),
    maxConcurrent: boundedInteger(record.cloudMaxConcurrent, CLOUD_CONCURRENCY, 'cloudMaxConcurrent'),
    maxResultChars: boundedInteger(record.cloudMaxResultChars, CLOUD_RESULT_CHARS, 'cloudMaxResultChars'),
    memoryWrites: record.cloudMemoryWrites === true,
    keepWarmMs: keepWarmSeconds(record.cloudKeepWarmSeconds) * 1_000,
  });
}

/** 0 turns the keep-warm calls off; otherwise the interval in seconds, 5 to 120. */
function keepWarmSeconds(value: unknown): number {
  if (value === 0) return 0;
  return boundedInteger(value, CLOUD_KEEP_WARM_SECONDS, 'cloudKeepWarmSeconds');
}

function optionalText(record: Record<string, unknown>, key: string): string | undefined {
  const value = record[key];
  if (value === undefined || value === null || value === '') return undefined;
  if (typeof value !== 'string') throw new TypeError(`${key} must be a string.`);
  return value.trim();
}

function assertHttpsOrigin(value: string, label = 'cloudUrl'): void {
  let parsed: URL;
  try {
    parsed = new URL(value);
  } catch {
    throw new TypeError(`${label} must be an absolute URL.`);
  }
  const loopback = parsed.hostname === '127.0.0.1' || parsed.hostname === 'localhost';
  if (parsed.protocol !== 'https:' && !(loopback && parsed.protocol === 'http:')) {
    throw new TypeError(`${label} must use https.`);
  }
  if (parsed.username || parsed.password) throw new TypeError(`${label} must not carry credentials.`);
}

function assertAudience(value: string): void {
  let parsed: URL;
  try {
    parsed = new URL(value);
  } catch {
    throw new TypeError('cloudAudience must be an absolute https URL.');
  }
  if (parsed.protocol !== 'https:') throw new TypeError('cloudAudience must be an absolute https URL.');
  if (parsed.username || parsed.password) throw new TypeError('cloudAudience must not carry credentials.');
}

function boundedInteger(
  value: unknown,
  bounds: { readonly default: number; readonly min: number; readonly max: number },
  label: string,
): number {
  if (value === undefined || value === null) return bounds.default;
  if (!Number.isInteger(value) || (value as number) < bounds.min || (value as number) > bounds.max) {
    throw new RangeError(`${label} must be an integer between ${bounds.min} and ${bounds.max}.`);
  }
  return value as number;
}
