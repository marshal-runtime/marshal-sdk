import type { Graph } from './core.js';

export const MAX_GRAPH_RECORD_BYTES = 64 * 1024;

export function readGraphRecord(graph: Graph, id: string): Record<string, unknown> {
  const output = graph.record(id);
  const fits = (value: unknown) => Buffer.byteLength(JSON.stringify(value), 'utf8') <= MAX_GRAPH_RECORD_BYTES;
  if (fits(output)) return output;
  const omitted = { ...output, node: null, truncated: true };
  if (fits(omitted)) return omitted;
  return { error: `Graph record metadata exceeds the ${MAX_GRAPH_RECORD_BYTES}-byte output cap.`, truncated: true };
}
