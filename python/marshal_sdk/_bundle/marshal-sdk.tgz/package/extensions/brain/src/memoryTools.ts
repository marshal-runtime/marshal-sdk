import type { CapabilityDescriptor, CapabilityInvocationResult, InvocationContext } from '@marshal/agent-runtime-core';
import { PROTOCOL_VERSION, result } from '@marshal/agent-runtime-provider-kit';
import { KNOWLEDGE_PROVIDER_ID } from './cloudKnowledge.js';
import type { CloudBrainClient } from './cloudBrain/client.js';
import { CloudBrainError } from './cloudBrain/errors.js';
import type { CallerCredentialSource } from './cloudBrain/googleCredentials.js';
import type { CloudBrainRoute } from './cloudBrain/route.js';

/** The graph memory capabilities: each is a memory node of the company Brain's Spanner graph, written at once (no approval). */
export const GRAPH_MEMORY_TOOLS = {
  'memory.create': 'memory_create',
  'memory.update': 'memory_update',
  'memory.link': 'memory_add_links',
  'memory.delete': 'memory_delete',
  'memory.search': 'memory_search',
  'memory.list': 'memory_list',
} as const;
type GraphMemoryTool = keyof typeof GRAPH_MEMORY_TOOLS;

/** The memory tools of a routed workspace. They are never listed or answered anywhere else. */
export const MEMORY_TOOLS = ['memory.propose', 'memory.review', ...(Object.keys(GRAPH_MEMORY_TOOLS) as GraphMemoryTool[])] as const;

const MEMORY_DEADLINE_MS = 30_000;
const MAX_LINKS = 8;
const KEY_PATTERN = /^v1:[A-Za-z0-9][A-Za-z0-9._:/-]{0,252}$/;
const REVIEW_LIST_FIELDS = ['total', 'proposed', 'items'] as const;

const PROPOSE_OUTPUT_SCHEMA = {
  type: 'object',
  properties: {
    key: { type: 'string' },
    audience: { anyOf: [{ type: 'string' }, { type: 'array', items: { type: 'string' } }] },
    approval_state: { type: 'string' },
    memoryId: { type: ['string', 'null'] },
    ref: { type: 'string' },
    warnings: { type: 'array', items: { type: 'string' } },
    details: { type: 'object', description: 'The Brain\'s full answer to the proposal.' },
  },
  required: ['details'],
  additionalProperties: false,
} as const;

const REVIEW_OUTPUT_SCHEMA = {
  type: 'object',
  properties: {
    action: { enum: ['list', 'approve', 'reject'] },
    total: { type: 'number' },
    proposed: { type: 'boolean' },
    items: {
      type: 'array',
      items: {
        type: 'object',
        properties: {
          key: { type: 'string' },
          audience: { anyOf: [{ type: 'string' }, { type: 'array', items: { type: 'string' } }] },
          links: { type: 'array', items: { type: 'object' } },
          approval_state: { type: 'string' },
          proposed_by: { type: 'string' },
          captured_by: { type: 'string' },
          content: { type: 'string' },
          approvable: { type: 'boolean' },
        },
      },
    },
    result: { type: 'object', description: 'The Brain\'s answer to a decision, or any list field not named above.' },
  },
  required: ['action'],
  additionalProperties: false,
} as const;

function asObject(value: unknown): Record<string, unknown> {
  return value && typeof value === 'object' && !Array.isArray(value) ? (value as Record<string, unknown>) : { value };
}

export interface MemoryBackend {
  /** Proposals go through the route's own (service account) credentials: an agent can propose, never approve. */
  readonly route: CloudBrainRoute;
  /** Listing and deciding go through the signed-in person's own Google user token: the server takes the approver from it. */
  readonly review: CloudBrainClient;
  readonly reviewCredentials: CallerCredentialSource;
  /** A repository file known to the Brain's index; links a proposal that names no file of its own. */
  readonly anchorPath?: string;
  /** The Brain keeps memories as graph nodes (memory_create ...): memory.propose writes one at once. Default true. */
  readonly graph?: boolean;
}

/** Where a memory lives: the person's own (private, in the default Brain) or the session's workspace. */
export type MemoryHome = 'personal' | 'workspace';
const HOMES: readonly MemoryHome[] = ['personal', 'workspace'];

/**
 * The memory backends of one session.
 * - One home (no `memoryRoute`): `personal` is the route's backend and every call passes through to it unchanged.
 * - Two homes (`memoryRoute` set, `workspace` present): personal memories (preferences, facts about the person) go to the
 *   pinned default Brain under `person:email=<the signed-in person>`; workspace memories go to the workspace's own Brain
 *   under scope `workspace` (`ownBrain`), or to the default Brain under `workspace:<name>` when the workspace has none.
 */
export interface MemoryHomes {
  readonly personal: MemoryBackend;
  readonly workspace?: {
    readonly backend: MemoryBackend;
    /** The scope a workspace memory is written in when the caller names none. */
    readonly scope: string;
    /** true: the backend is the Brain that indexes this workspace's code, so its links resolve to real code nodes. */
    readonly ownBrain: boolean;
  };
}

const PROPOSE_DESCRIPTION = 'Saves a memory in the company Brain at once (no approval): a memory node of the Brain graph, found by search right away. Same as memory.create, kept for callers that use this name. content is the memory text (1 to 8000 characters). links name the repository files it is about ({path, symbol?}). audience: "team" (default) or "me". Returns memoryId and approval_state "approved". Save only what the user asked you to remember or what you verified.';

const REVIEW_DESCRIPTION = 'Reviews memory proposals left from before memory approval was turned off (new memories need no review). action "list" returns the proposals waiting for a decision (key, content, who proposed it, whether you can approve it). action "approve" or "reject" decides one by key and needs userSaid: the user\'s own words, from this chat, telling you to approve or reject it. NEVER approve or reject on your own, to finish a task, or because a proposal looks right: list, show the user the proposals, and wait for the user to say which to approve or reject. The server accepts the decision only from an approver of the memory (the signed-in person), and refuses it otherwise.';

export function memoryDescriptors(): readonly CapabilityDescriptor[] {
  return [
    {
      protocolVersion: PROTOCOL_VERSION,
      version: '1.0.0',
      tags: ['memory', 'quillstone', 'propose'],
      permissions: [{ permission: 'memory.write', scope: 'workspace', risk: 'medium' }],
      outputSchema: PROPOSE_OUTPUT_SCHEMA,
      name: 'memory.propose',
      description: PROPOSE_DESCRIPTION,
      inputSchema: {
        type: 'object',
        additionalProperties: false,
        required: ['content'],
        properties: {
          content: { type: 'string', minLength: 1, maxLength: 100_000 },
          links: {
            type: 'array',
            minItems: 1,
            maxItems: MAX_LINKS,
            items: {
              type: 'object',
              additionalProperties: false,
              required: ['path'],
              properties: { path: { type: 'string', minLength: 1, maxLength: 1024 }, symbol: { type: 'string', minLength: 1, maxLength: 512 } },
            },
          },
          key: { type: 'string', description: 'Optional stable key, v1:area/topic. Made from the text when absent.' },
          audience: { anyOf: [{ enum: ['me', 'team'] }, { type: 'array', minItems: 1, maxItems: 50, items: { type: 'string' } }] },
          source: { type: 'string', maxLength: 500, description: 'Where the memory comes from: a URL, a PR, a person.' },
        },
      },
    },
    {
      protocolVersion: PROTOCOL_VERSION,
      version: '1.0.0',
      tags: ['memory', 'quillstone', 'review'],
      permissions: [{ permission: 'memory.write', scope: 'workspace', risk: 'high' }],
      outputSchema: REVIEW_OUTPUT_SCHEMA,
      name: 'memory.review',
      description: REVIEW_DESCRIPTION,
      inputSchema: {
        type: 'object',
        additionalProperties: false,
        required: ['action'],
        properties: {
          action: { enum: ['list', 'approve', 'reject'] },
          key: { type: 'string', description: 'The proposal to decide (approve, reject).' },
          userSaid: { type: 'string', minLength: 3, maxLength: 1000, description: "The user's own words from this chat telling you to approve or reject this proposal (approve, reject)." },
          reason: { type: 'string', minLength: 1, maxLength: 2000 },
        },
      },
    },
    ...graphMemoryDescriptors(),
  ];
}

const LINK_ITEM = {
  type: 'object',
  additionalProperties: false,
  properties: {
    nodeId: { type: 'string', minLength: 1, maxLength: 300, description: 'A graph node id (from knowledge.search or memory.search).' },
    path: { type: 'string', minLength: 1, maxLength: 1000, description: 'A file the memory explains.' },
    symbol: { type: 'string', minLength: 1, maxLength: 300 },
    sessionId: { type: 'string', minLength: 1, maxLength: 200, description: 'The session where it was learned or that it is about.' },
    personId: { type: 'string', minLength: 1, maxLength: 200, description: 'The person it is about (an email).' },
    rel: { type: 'string', minLength: 1, maxLength: 60 },
  },
} as const;
const LINKS = { type: 'array', maxItems: 50, items: LINK_ITEM } as const;
const CATEGORY = { enum: ['preference', 'decision', 'fact', 'context'] } as const;
const SCOPES = { type: 'array', maxItems: 20, items: { type: 'string', maxLength: 300 }, description: "The session's scopes (the SDK's route sends them); every company memory you may read is in reach." } as const;
const MEMORY_RECORD = {
  type: 'object',
  properties: {
    id: { type: 'string' },
    content: { type: 'string' },
    category: { type: 'string' },
    scope: { type: 'string' },
    alwaysOn: { type: 'boolean' },
    createdAt: { type: 'string' },
    updatedAt: { type: 'string' },
    links: { type: 'array', items: { type: 'object' } },
    sessionId: { type: 'string' },
    author: { type: 'string' },
    access: { type: 'array', items: { type: 'string' } },
    legacyKey: { type: 'string' },
    home: { enum: HOMES, description: 'personal (yours, in the default Brain) or workspace (this workspace\'s Brain).' },
  },
} as const;
const HOME = {
  enum: HOMES,
  description: "personal: about you, private, in every workspace (preferences, personal facts). workspace: knowledge about this workspace's code, kept in its own Brain and linked to its code. Default: personal for a preference or a person: scope, otherwise workspace when the workspace has its own Brain.",
} as const;
const ONE = { type: 'object', additionalProperties: false, properties: { memory: MEMORY_RECORD }, required: ['memory'] } as const;
const MANY = {
  type: 'object',
  additionalProperties: false,
  properties: {
    memories: { type: 'array', items: MEMORY_RECORD },
    mode: { type: 'string' },
    nextOffset: { type: 'integer', minimum: 0, description: 'The offset of the next page (with two homes, applied to each home).' },
    degraded: { type: 'array', items: { enum: HOMES }, description: 'Homes that could not be read: the answer holds only the others.' },
  },
  required: ['memories'],
} as const;

const GRAPH_DESCRIPTIONS: Record<GraphMemoryTool, string> = {
  'memory.create':
    'Saves a memory as a node of the Brain graph, at once (no approval), with edges to what it is about (links: a graph node id, a file path and symbol, a session, a person). home picks where it lives: personal (about you: preferences, personal facts; private, shown in every workspace, kept in the default Brain) or workspace (knowledge about this workspace\'s code, kept in the workspace\'s own Brain so a path link resolves to its code node). Default: personal for a preference, otherwise workspace when the workspace has its own Brain. scope overrides the home\'s scope; preferences are always on in their scope. supersedes names the memory it corrects. audience "me" keeps a workspace memory to you. Returns {memory} with its home.',
  'memory.update': 'Changes a Brain memory in place by id (found in either home; home skips the search): text, category, always-on flag, or its whole link set (links replaces every edge). Returns {memory}.',
  'memory.link': 'Adds edges from a Brain memory (by id, in either home) to graph nodes, files, sessions or people. Returns {memory}.',
  'memory.delete': 'Deletes a Brain memory node and its edges by id (in either home). Returns {deleted}.',
  'memory.search': "Finds Brain memories by meaning: the Brain's hybrid search over your memories and this workspace's, best first, without superseded ones; each carries its home (home narrows to one). Returns {memories}.",
  'memory.list': 'Lists Brain memories newest first, from both homes (home narrows to one); scope or scopePrefix (a scope and every scope under it) picks one scope (alwaysOn for the ones every session of the scope shows, since for a review of the day). At most 200 a page: when the answer has nextOffset, call again with offset: nextOffset. Returns {memories, nextOffset?}.',
};

const GRAPH_INPUTS: Record<GraphMemoryTool, Record<string, unknown>> = {
  'memory.create': {
    type: 'object',
    additionalProperties: false,
    required: ['content'],
    properties: {
      content: { type: 'string', minLength: 1, maxLength: 8000 },
      category: CATEGORY,
      home: HOME,
      scope: { type: 'string', minLength: 1, maxLength: 300 },
      alwaysOn: { type: 'boolean' },
      links: LINKS,
      supersedes: { type: 'string', minLength: 1, maxLength: 512 },
      sessionId: { type: 'string', minLength: 1, maxLength: 200 },
      audience: { enum: ['team', 'me'] },
      key: { type: 'string', minLength: 1, maxLength: 200, description: "Idempotency key (a migration's source row, e.g. desktop:<uuid>): the same person and key name one memory, and a create whose memory exists returns it unchanged." },
      id: { type: 'string', minLength: 1, maxLength: 200, pattern: '^[A-Za-z0-9._:/#@-]+$', description: 'The node id you choose for an import (e.g. desktop:<uuid>; not mem_...): created once, and a create whose memory exists returns it unchanged.' },
      createdAt: { type: 'string', maxLength: 40, description: 'When the memory was first made (ISO 8601), for a migrated one.' },
      sourceId: { type: 'string', minLength: 1, maxLength: 200, description: 'Same as key (the desktop migration sends this name).' },
      author: { type: 'string', maxLength: 320, description: 'Ignored: the author is the signed-in person.' },
    },
  },
  'memory.update': {
    type: 'object',
    additionalProperties: false,
    required: ['id'],
    properties: { id: { type: 'string', minLength: 1, maxLength: 512 }, home: HOME, scopes: SCOPES, content: { type: 'string', minLength: 1, maxLength: 8000 }, category: CATEGORY, alwaysOn: { type: 'boolean' }, links: LINKS },
  },
  'memory.link': {
    type: 'object',
    additionalProperties: false,
    required: ['id', 'links'],
    properties: { id: { type: 'string', minLength: 1, maxLength: 512 }, home: HOME, scopes: SCOPES, links: { ...LINKS, minItems: 1 } },
  },
  'memory.delete': { type: 'object', additionalProperties: false, required: ['id'], properties: { id: { type: 'string', minLength: 1, maxLength: 512 }, home: HOME, scopes: SCOPES } },
  'memory.search': {
    type: 'object',
    additionalProperties: false,
    required: ['query'],
    properties: { query: { type: 'string', minLength: 1, maxLength: 500 }, home: HOME, scopes: SCOPES, limit: { type: 'integer', minimum: 1, maximum: 50 }, category: CATEGORY },
  },
  'memory.list': {
    type: 'object',
    additionalProperties: false,
    properties: { home: HOME, scope: { type: 'string', minLength: 1, maxLength: 300 }, scopePrefix: { type: 'string', minLength: 1, maxLength: 300, description: 'A scope and every scope under it: person:email=<you> lists your global and every project memory.' }, alwaysOn: { type: 'boolean' }, since: { type: 'string', maxLength: 40 }, category: CATEGORY, limit: { type: 'integer', minimum: 1, maximum: 200 }, offset: { type: 'integer', minimum: 0, description: 'Where the page starts: the nextOffset of the previous answer.' } },
  },
};

const GRAPH_OUTPUTS: Record<GraphMemoryTool, Record<string, unknown>> = {
  'memory.create': ONE,
  'memory.update': ONE,
  'memory.link': ONE,
  'memory.delete': { type: 'object', additionalProperties: false, properties: { deleted: { type: 'boolean' } }, required: ['deleted'] },
  'memory.search': MANY,
  'memory.list': MANY,
};

function graphMemoryDescriptors(): CapabilityDescriptor[] {
  return (Object.keys(GRAPH_MEMORY_TOOLS) as GraphMemoryTool[]).map((name) => {
    const write = name !== 'memory.search' && name !== 'memory.list';
    return {
      protocolVersion: PROTOCOL_VERSION,
      version: '1.0.0',
      tags: ['memory', 'quillstone', 'graph'],
      permissions: [{ permission: write ? 'memory.write' : 'memory.read', scope: 'workspace', risk: write ? 'medium' : 'low' }],
      outputSchema: GRAPH_OUTPUTS[name],
      name,
      description: GRAPH_DESCRIPTIONS[name],
      inputSchema: GRAPH_INPUTS[name],
    } as CapabilityDescriptor;
  });
}

/**
 * One graph memory tool of the Brain, as the signed-in person (their own Google token, so the author and a private memory
 * are theirs); when this Marshal has no personal credentials, through the route's service account, which reads and writes
 * the company's memories only.
 */
async function graphCall(backend: MemoryBackend, tool: string, args: Record<string, unknown>, context: InvocationContext): Promise<Record<string, unknown>> {
  try {
    const answer = await backend.review.callTool(tool, args, deadlineSignal(undefined));
    return asObject(answer.output);
  } catch (error) {
    if (!(error instanceof CloudBrainError) || error.code !== 'cloud_brain_auth_failed') throw error;
    const answer = await backend.route.call(tool, args, { deadlineMs: MEMORY_DEADLINE_MS, context });
    return asObject(answer.output);
  }
}

async function graphMemory(homes: MemoryHomes, name: GraphMemoryTool, rawInput: unknown, context: InvocationContext): Promise<unknown> {
  const input = record(rawInput);
  const schema = GRAPH_INPUTS[name] as { properties: Record<string, unknown>; required?: string[] };
  rejectUnknown(input, Object.keys(schema.properties), name);
  for (const field of schema.required ?? []) if (input[field] === undefined) throw refusal('invalid_input', `${name}: ${field} is required.`);
  const { author: _author, sourceId, home: rawHome, ...args } = input;
  if (rawHome !== undefined && !HOMES.includes(rawHome as MemoryHome)) throw refusal('invalid_input', `${name}: home is personal or workspace.`);
  const home = rawHome as MemoryHome | undefined;
  if (sourceId !== undefined) {
    if (args.key !== undefined && args.key !== sourceId) throw refusal('invalid_input', `${name}: sourceId and key name different memories.`);
    args.key = sourceId;
  }
  // One home: every call passes through to the route's backend unchanged.
  if (!homes.workspace) return declaredOutput(name, await graphCall(homes.personal, GRAPH_MEMORY_TOOLS[name], args, context));
  const workspace = homes.workspace;
  switch (name) {
    case 'memory.create': {
      const chosen = home ?? defaultHome(args, workspace.ownBrain);
      if (args.scope === undefined) {
        if (chosen === 'workspace') args.scope = workspace.scope;
        else {
          const person = await signedInPerson(homes.personal);
          if (!person) throw refusal('memory_needs_person', 'memory.create: a personal memory is saved as the signed-in person, and this Marshal has no Google user credentials (gcloud auth application-default login).');
          args.scope = `person:email=${person}`;
        }
      }
      const answer = await graphCall(backendOf(homes, chosen), GRAPH_MEMORY_TOOLS[name], args, context);
      return declaredOutput(name, tagOne(answer, homes, chosen));
    }
    case 'memory.update':
    case 'memory.link':
    case 'memory.delete': {
      const order: MemoryHome[] = home ? [home] : distinct(homes) ? ['workspace', 'personal'] : ['personal'];
      let lastMissing: unknown;
      for (const candidate of order) {
        try {
          const answer = await graphCall(backendOf(homes, candidate), GRAPH_MEMORY_TOOLS[name], args, context);
          return declaredOutput(name, tagOne(answer, homes, candidate));
        } catch (error) {
          if (!isNotFound(error) || order.length === 1) throw error;
          lastMissing = error;
        }
      }
      throw lastMissing;
    }
    case 'memory.search':
    case 'memory.list': {
      const targets = readTargets(homes, name, args, home);
      const settled = await Promise.allSettled(targets.map((target) => graphCall(backendOf(homes, target), GRAPH_MEMORY_TOOLS[name], args, context)));
      const answers = settled.flatMap((outcome, index) => (outcome.status === 'fulfilled' ? [{ home: targets[index]!, answer: outcome.value }] : []));
      if (answers.length === 0) throw (settled[0] as PromiseRejectedResult).reason;
      const degraded = settled.flatMap((outcome, index) => (outcome.status === 'rejected' ? [targets[index]!] : []));
      const lists = answers.map(({ home: from, answer }) => memoriesOf(answer).map((memory) => tagMemory(memory, distinct(homes) ? from : undefined)));
      const merged = name === 'memory.search' ? interleave(lists) : newestFirst(lists);
      const limit = typeof args.limit === 'number' ? args.limit : undefined;
      const memories = targets.length > 1 && limit !== undefined ? merged.slice(0, limit) : merged;
      const nextOffsets = answers.map(({ answer }) => answer.nextOffset).filter((value): value is number => typeof value === 'number');
      const mode = answers.map(({ answer }) => answer.mode).find((value) => typeof value === 'string');
      return {
        memories,
        ...(mode !== undefined ? { mode } : {}),
        ...(nextOffsets.length ? { nextOffset: Math.max(...nextOffsets) } : {}),
        ...(degraded.length ? { degraded } : {}),
      };
    }
  }
}

function declaredOutput(name: GraphMemoryTool, answer: Record<string, unknown>): Record<string, unknown> {
  // The declared output is strict: keep only its fields, so a field the server adds later never fails the call.
  const declared = Object.keys((GRAPH_OUTPUTS[name] as { properties: Record<string, unknown> }).properties);
  return Object.fromEntries(declared.flatMap((key) => (answer[key] === undefined ? [] : [[key, answer[key]]])));
}

/** A memory with no home named: personal for a person scope or a preference; workspace for a workspace scope; otherwise workspace only when the workspace has its own Brain. */
function defaultHome(args: Record<string, unknown>, ownBrain: boolean): MemoryHome {
  const fromScope = typeof args.scope === 'string' ? scopeHome(args.scope) : undefined;
  if (fromScope) return fromScope;
  if (args.category === 'preference') return 'personal';
  return ownBrain ? 'workspace' : 'personal';
}

/** The home a scope names: person:... is personal, workspace or workspace:... (any workspace's) is workspace, anything else none. */
function scopeHome(scope: string): MemoryHome | undefined {
  if (scope.startsWith('person:')) return 'personal';
  if (scope === 'workspace' || scope.startsWith('workspace:') || scope.startsWith('workspace/')) return 'workspace';
  return undefined;
}

function backendOf(homes: MemoryHomes, home: MemoryHome): MemoryBackend {
  if (home === 'workspace') {
    if (!homes.workspace) throw refusal('invalid_input', 'This workspace has no workspace memory home.');
    return homes.workspace.backend;
  }
  return homes.personal;
}

/** true when the two homes are different Brains (so a read fans out and a write by id may need to look in both). */
function distinct(homes: MemoryHomes): boolean {
  return homes.workspace !== undefined && homes.workspace.backend !== homes.personal;
}

/** The homes a search or list reads: the named one, the one a scope belongs to, or both. Two homes in one Brain are one read. */
function readTargets(homes: MemoryHomes, name: GraphMemoryTool, args: Record<string, unknown>, home: MemoryHome | undefined): MemoryHome[] {
  if (home) return [home];
  if (!distinct(homes)) return ['personal'];
  const scope = typeof args.scope === 'string' ? args.scope : typeof args.scopePrefix === 'string' ? args.scopePrefix : undefined;
  if (name === 'memory.list' && scope !== undefined) {
    return [scopeHome(scope) ?? 'personal'];
  }
  return ['workspace', 'personal'];
}

function isNotFound(error: unknown): boolean {
  return error instanceof CloudBrainError && (error.toolStatus === 'not-found' || error.toolStatus === 'not_found');
}

function memoriesOf(answer: Record<string, unknown>): Record<string, unknown>[] {
  return Array.isArray(answer.memories) ? answer.memories.filter((memory): memory is Record<string, unknown> => !!memory && typeof memory === 'object' && !Array.isArray(memory)) : [];
}

/** Tags a memory with its home: the Brain it came from when the homes are two Brains, otherwise the home its scope names. */
function tagMemory(memory: Record<string, unknown>, from: MemoryHome | undefined): Record<string, unknown> {
  if (from) return { ...memory, home: from };
  const scope = typeof memory.scope === 'string' ? memory.scope : '';
  return { ...memory, home: scopeHome(scope) ?? 'personal' };
}

function tagOne(answer: Record<string, unknown>, homes: MemoryHomes, home: MemoryHome): Record<string, unknown> {
  const memory = answer.memory;
  if (!memory || typeof memory !== 'object' || Array.isArray(memory)) return answer;
  return { ...answer, memory: tagMemory(memory as Record<string, unknown>, distinct(homes) ? home : undefined) };
}

/** Ranked lists merged by rank (the first list first at each rank), each memory once. */
function interleave(lists: Record<string, unknown>[][]): Record<string, unknown>[] {
  const seen = new Set<unknown>();
  const merged: Record<string, unknown>[] = [];
  for (let rank = 0; lists.some((list) => rank < list.length); rank += 1) {
    for (const list of lists) {
      const memory = list[rank];
      if (!memory || (memory.id !== undefined && seen.has(memory.id))) continue;
      seen.add(memory.id);
      merged.push(memory);
    }
  }
  return merged;
}

function newestFirst(lists: Record<string, unknown>[][]): Record<string, unknown>[] {
  const time = (memory: Record<string, unknown>) => Date.parse(String(memory.updatedAt ?? memory.createdAt ?? '')) || 0;
  return interleave(lists).sort((a, b) => time(b) - time(a));
}

function refusal(code: string, message: string): Error {
  return Object.assign(new Error(message), { code });
}

function record(input: unknown): Record<string, unknown> {
  if (!input || typeof input !== 'object' || Array.isArray(input)) throw refusal('invalid_input', 'The input must be an object.');
  return input as Record<string, unknown>;
}

function rejectUnknown(input: Record<string, unknown>, allowed: readonly string[], tool: string): void {
  for (const key of Object.keys(input)) {
    if (!allowed.includes(key)) throw refusal('invalid_input', `${tool}: ${key} is not an input of this tool (${allowed.join(', ')}).`);
  }
}

function deadlineSignal(signal: AbortSignal | undefined): AbortSignal {
  const timeout = AbortSignal.timeout(MEMORY_DEADLINE_MS);
  return signal ? AbortSignal.any([signal, timeout]) : timeout;
}

async function proposeMemory(backend: MemoryBackend, rawInput: unknown, context: InvocationContext, scope?: string): Promise<unknown> {
  const input = record(rawInput);
  rejectUnknown(input, ['content', 'links', 'key', 'audience', 'source'], 'memory.propose');
  if (typeof input.content !== 'string' || !input.content.trim() || input.content.length > 100_000) {
    throw refusal('invalid_input', 'memory.propose: content is required (1 to 100000 characters).');
  }
  if (backend.graph !== false) {
    // No approval any more (owner's order, 2026-11-17): a proposal is a graph memory at once.
    const links = Array.isArray(input.links) ? input.links : [];
    if (links.length > MAX_LINKS) throw refusal('invalid_input', `memory.propose: links must hold at most ${MAX_LINKS} {path, symbol?} items.`);
    const source = typeof input.source === 'string' && input.source.trim() ? `\n\nSource: ${input.source.trim()}` : '';
    const created = await graphCall(
      backend,
      GRAPH_MEMORY_TOOLS['memory.create'],
      {
        content: `${input.content.trim()}${source}`.slice(0, 8000),
        links,
        ...(scope !== undefined ? { scope } : {}),
        ...(input.audience === 'me' ? { audience: 'me' } : {}),
      },
      context,
    );
    const memory = asObject(created.memory);
    return {
      ...(typeof memory.id === 'string' ? { memoryId: memory.id } : {}),
      approval_state: 'approved',
      ...(typeof input.key === 'string' ? { key: input.key } : {}),
      details: created,
    };
  }
  let links = input.links;
  if (links === undefined) {
    if (!backend.anchorPath) throw refusal('memory_no_anchor', 'memory.propose: name at least one repository file in links; this Marshal has no anchor file configured.');
    links = [{ path: backend.anchorPath }];
  }
  if (!Array.isArray(links) || links.length === 0 || links.length > MAX_LINKS) {
    throw refusal('invalid_input', `memory.propose: links must hold 1 to ${MAX_LINKS} {path, symbol?} items.`);
  }
  if (input.key !== undefined && (typeof input.key !== 'string' || !KEY_PATTERN.test(input.key))) {
    throw refusal('invalid_input', 'memory.propose: key must look like v1:area/topic.');
  }
  const args: Record<string, unknown> = {
    content: input.content,
    links,
    state: 'proposed',
    ...(input.key !== undefined ? { key: input.key } : {}),
    ...(input.audience !== undefined ? { audience: input.audience } : {}),
    ...(input.source !== undefined ? { source: input.source } : {}),
    capturedBy: 'marshal-agent',
  };
  // The person on record: the server records the caller service account as proposer, so the signed-in person goes in as a relayed speaker.
  const person = await signedInPerson(backend);
  if (person) {
    args.speaker = { kind: 'human', id: person, relayedBy: 'marshal-agent' };
    args.trust = 'human-relayed';
  }
  const answer = await backend.route.call('memory_link', args, { deadlineMs: MEMORY_DEADLINE_MS, context });
  return proposeOutput(asObject(answer.output));
}

function proposeOutput(details: Record<string, unknown>): Record<string, unknown> {
  const { key, audience, approval_state: approvalState, memoryId, ref, warnings } = details;
  const stringList = (value: unknown) => Array.isArray(value) && value.every((item) => typeof item === 'string');
  return {
    ...(typeof key === 'string' ? { key } : {}),
    ...(typeof audience === 'string' || stringList(audience) ? { audience } : {}),
    ...(typeof approvalState === 'string' ? { approval_state: approvalState } : {}),
    ...(typeof memoryId === 'string' || memoryId === null ? { memoryId } : {}),
    ...(typeof ref === 'string' ? { ref } : {}),
    ...(stringList(warnings) ? { warnings } : {}),
    details,
  };
}

function listOutput(raw: Record<string, unknown>): Record<string, unknown> {
  const { total, proposed, items } = raw;
  const known: Record<string, unknown> = {
    ...(typeof total === 'number' ? { total } : {}),
    ...(typeof proposed === 'boolean' ? { proposed } : {}),
    ...(Array.isArray(items) ? { items } : {}),
  };
  const rest = Object.fromEntries(Object.entries(raw).filter(([name]) => !(REVIEW_LIST_FIELDS as readonly string[]).includes(name) || !(name in known)));
  return { action: 'list', ...known, ...(Object.keys(rest).length ? { result: rest } : {}) };
}

async function signedInPerson(backend: MemoryBackend): Promise<string | undefined> {
  try {
    const { caller } = await backend.reviewCredentials.credentials(deadlineSignal(undefined));
    return caller ? caller.toLowerCase() : undefined;
  } catch {
    return undefined;
  }
}

async function reviewMemory(backend: MemoryBackend, rawInput: unknown): Promise<unknown> {
  const input = record(rawInput);
  rejectUnknown(input, ['action', 'key', 'userSaid', 'reason'], 'memory.review');
  const signal = deadlineSignal(undefined);
  if (input.action === 'list') {
    const answer = await backend.review.callTool('memory_review_queue', { proposed: true }, signal);
    return listOutput(asObject(answer.output));
  }
  if (input.action !== 'approve' && input.action !== 'reject') {
    throw refusal('invalid_input', 'memory.review: action is list, approve or reject.');
  }
  if (typeof input.key !== 'string' || !KEY_PATTERN.test(input.key)) {
    throw refusal('invalid_input', 'memory.review: key is the key of a proposal from action "list" (v1:...).');
  }
  if (typeof input.userSaid !== 'string' || input.userSaid.trim().length < 3) {
    throw refusal(
      'approval_needs_user',
      `memory.review: ${input.action} needs userSaid, the user's own words from this chat telling you to ${input.action} this proposal. List the proposals, show them to the user and wait; never decide on your own.`,
    );
  }
  const args = {
    key: input.key,
    outcome: input.action,
    ...(typeof input.reason === 'string' && input.reason.trim() ? { reason: input.reason } : {}),
  };
  try {
    const answer = await backend.review.callTool('memory_review', args, signal);
    return { action: input.action, result: asObject(answer.output) };
  } catch (error) {
    if (error instanceof CloudBrainError && error.code === 'cloud_brain_auth_failed') {
      throw new CloudBrainError(error.code, `${error.message} Approving needs the signed-in person's own Google credentials (gcloud auth application-default login), not the service account.`);
    }
    throw error;
  }
}

export async function invokeMemoryTool(homes: MemoryHomes, name: string, input: unknown, context: InvocationContext): Promise<CapabilityInvocationResult> {
  // A proposal is team knowledge: with two homes it is a workspace memory; the legacy review queue is the default Brain's.
  if (name === 'memory.propose') {
    const target = homes.workspace ? { backend: homes.workspace.backend, scope: homes.workspace.scope } : { backend: homes.personal };
    return result(await proposeMemory(target.backend, input, context, target.scope), KNOWLEDGE_PROVIDER_ID, name, input, context);
  }
  if (name === 'memory.review') return result(await reviewMemory(homes.personal, input), KNOWLEDGE_PROVIDER_ID, name, input, context);
  if (name in GRAPH_MEMORY_TOOLS) return result(await graphMemory(homes, name as GraphMemoryTool, input, context), KNOWLEDGE_PROVIDER_ID, name, input, context);
  throw refusal('brain_unavailable', `${name} is not a memory tool.`);
}
