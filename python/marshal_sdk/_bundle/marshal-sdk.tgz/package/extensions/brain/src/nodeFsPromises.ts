import { promises as fs } from 'fs';

export const access = fs.access.bind(fs);
export const chmod = fs.chmod.bind(fs);
export const copyFile = fs.copyFile.bind(fs);
export const link = fs.link.bind(fs);
export const lstat = fs.lstat.bind(fs);
export const mkdir = fs.mkdir.bind(fs);
export const open = fs.open.bind(fs);
export const opendir = fs.opendir.bind(fs);
export const readFile = fs.readFile.bind(fs);
export const readdir = fs.readdir.bind(fs);
export const realpath = fs.realpath.bind(fs);
export const rename = fs.rename.bind(fs);
export const rm = fs.rm.bind(fs);
export const stat = fs.stat.bind(fs);
export const unlink = fs.unlink.bind(fs);
export const writeFile = fs.writeFile.bind(fs);
export default fs;
