import type { CapabilityProvider } from '@marshal/agent-runtime-core';
import type { LazyUserMemory } from './marshalMemoryStore.js';
import { renderProfile, writeProfile, type ProfileMemory, type ProfileWriteResult } from './profileDocument.js';
import { decodeUserMemoryFactKey } from './userMemoryFactKey.js';

/**
 * profile.md from the user's memories and every project's and workspace's memories (Brain's own
 * database; the file sits in the user's private profile directory), so any session writes the same file.
 */
export function regenerateProfile(userMemory: LazyUserMemory): ProfileWriteResult {
  const store = userMemory.store();
  const memories: ProfileMemory[] = store.list().map((entry) => ({
    id: entry.id,
    text: entry.fact,
    category: entry.category,
    createdAt: entry.createdAt,
    appliesTo: entry.appliesTo ?? 'global',
  }));
  for (const memory of userMemory.reviews.projectMemories()) {
    const category = decodeUserMemoryFactKey(memory.factKey).category;
    memories.push({
      id: memory.id,
      text: memory.content,
      ...(category ? { category } : {}),
      createdAt: memory.createdAt,
      appliesTo: memory.scopeId,
      ...(memory.factKey ? { factKey: memory.factKey } : {}),
    });
  }
  const reasons = userMemory.reviews.reasons(memories.map(({ id }) => id));
  const withReview = memories.map((memory) => {
    const reason = reasons.get(memory.id);
    return reason ? { ...memory, needsReview: reason } : memory;
  });
  const labels = userMemory.reviews.projectLabels();
  return writeProfile(userMemory.profilePath, renderProfile(withReview, new Date().toISOString().slice(0, 10), labels));
}

/**
 * After a delete, purge or correction, profile.md loses the old line now instead of at the next
 * heal (review round 9 L5). A failure never fails the write that caused it; the next heal rewrites the file.
 */
export function refreshProfile(userMemory: LazyUserMemory): void {
  try {
    regenerateProfile(userMemory);
  } catch {
    // the next session start's heal regenerates profile.md
  }
}

/** Capabilities after which a memory profile.md lists may be gone or superseded. */
const REMOVING = new Set(['memory.delete', 'memory.purge', 'memory.correct']);

/** Refreshes profile.md after each removing capability, and after a memory.link (or memory.link.batch) that replaced a note. */
export function withProfileRefresh(provider: CapabilityProvider, userMemory: () => LazyUserMemory): CapabilityProvider {
  return {
    id: provider.id,
    ...(provider.version ? { version: provider.version } : {}),
    list: (context) => provider.list(context),
    ...(provider.get ? { get: (name: string, context: Parameters<CapabilityProvider['list']>[0]) => provider.get!(name, context) } : {}),
    async invoke(name, input, context) {
      const invoked = await provider.invoke(name, input, context);
      const output = (invoked as { output?: unknown } | undefined)?.output as
        { replaced?: unknown; results?: ReadonlyArray<{ replaced?: unknown }> } | undefined;
      if (
        REMOVING.has(name)
        || (name === 'memory.link' && output?.replaced)
        || (name === 'memory.link.batch' && output?.results?.some((entry) => entry.replaced))
      ) refreshProfile(userMemory());
      return invoked;
    },
  };
}
