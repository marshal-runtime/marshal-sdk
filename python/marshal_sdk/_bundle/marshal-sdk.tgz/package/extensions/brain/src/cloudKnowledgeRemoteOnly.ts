import type { CapabilityProvider } from '@marshal/agent-runtime-core';
import {
  createKnowledgeIndexProvider,
  type RebuildableKnowledgeIndex,
} from '@marshal/agent-runtime-provider-memory';
import { withCloudKnowledge, KNOWLEDGE_PROVIDER_ID, type CloudKnowledgeOptions, type CloudKnowledgeSetting } from './cloudKnowledge.js';

/** A descriptor-only provider for the explicit remote-only host mode; no index or Quillstone slot is created. */
export function createRemoteOnlyKnowledgeProvider(
  setting: CloudKnowledgeSetting,
  options: Pick<CloudKnowledgeOptions, 'remoteOnlyRetry' | 'searchHardCapMs' | 'searchRetryBaseMs'> = {},
): CapabilityProvider {
  const descriptorSource = createKnowledgeIndexProvider(
    new Proxy({} as RebuildableKnowledgeIndex, {
      get() { throw new Error('The local knowledge index is unavailable in remote-only mode.'); },
    }),
    KNOWLEDGE_PROVIDER_ID,
  );
  return withCloudKnowledge(descriptorSource, setting, { ...options, remoteOnly: true });
}
