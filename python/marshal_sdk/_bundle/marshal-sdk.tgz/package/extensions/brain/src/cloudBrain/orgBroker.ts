import { createCloudBrainClient, type CloudBrainClient } from './client.js';
import { CloudBrainError, isCloudBrainError } from './errors.js';
import type { CallerCredentialSource } from './googleCredentials.js';

/** The broker path the Marshal org serves in front of the Brain MCP endpoint. */
export const ORG_BROKER_BRAIN_PATH = '/v1/broker/brain/mcp';
/** Runtime service token the Marshal desktop registers: a host-side fetch that adds the org bearer itself. */
export const ORG_BROKER_FETCH_SERVICE = Symbol.for('@marshal/org:broker-fetch');
/** After the broker refused or was unavailable, the gcloud route answers for this long before the broker is tried again. */
export const ORG_BROKER_RETRY_MS = 60_000;
const BROKER_ORIGIN = 'https://org-broker.invalid';

/** Runtime service token for who is signed in to an org; undefined result means nobody is. */
export const ORG_IDENTITY_SERVICE = Symbol.for('@marshal/org:identity');
export interface OrgIdentity {
  readonly email: string;
  readonly orgId: string;
  readonly orgDisplayName: string;
}
export type OrgIdentityService = () => Promise<OrgIdentity | undefined>;

/** The host's accepted request: GET or POST, only accept / content-type / mcp-session-id headers, string body up to 1 MiB. */
export interface BrokerFetchInit {
  readonly method?: 'GET' | 'POST';
  readonly headers?: Readonly<Record<string, string>>;
  readonly body?: string;
}
/** The host's answer: set-cookie removed, body a string up to 8 MiB (an event stream is buffered whole). */
export interface BrokerFetchResponse {
  readonly status: number;
  readonly headers: Readonly<Record<string, string>>;
  readonly body: string;
}
/**
 * The desktop's broker fetch. `path` must be under `/v1/broker/` (anything else throws with code `path-not-allowed`); the
 * host adds the org bearer, follows no redirects and times out after 60 s, so this extension never sees the token.
 */
export type BrokerFetch = (path: string, init?: BrokerFetchInit) => Promise<BrokerFetchResponse>;
/** The broker fetch when an org identity exists, else undefined. Evaluated on every call. */
export type BrokerFetchSource = () => Promise<BrokerFetch | undefined> | BrokerFetch | undefined;

const ALLOWED_REQUEST_HEADERS = new Set(['accept', 'content-type', 'mcp-session-id']);

/** Source over the host's `@marshal/org:identity` and `@marshal/org:broker-fetch` services; a failing or missing service means no org session. */
export function hostBrokerFetchSource(tryGet: (token: symbol) => unknown): BrokerFetchSource {
  return async () => {
    try {
      const identity = tryGet(ORG_IDENTITY_SERVICE);
      const fetcher = tryGet(ORG_BROKER_FETCH_SERVICE);
      if (typeof identity !== 'function' || typeof fetcher !== 'function') return undefined;
      return (await (identity as OrgIdentityService)()) ? fetcher as BrokerFetch : undefined;
    } catch {
      return undefined;
    }
  };
}

/** Adapts the host's broker fetch to the `fetch` the MCP client uses; any authorization header is dropped, the host sets its own. */
export function brokerFetchAsFetch(brokerFetch: BrokerFetch): typeof fetch {
  return (async (input: string | URL | Request, init: RequestInit = {}) => {
    const url = new URL(String(input), BROKER_ORIGIN);
    const headers: Record<string, string> = {};
    new Headers(init.headers).forEach((value, key) => {
      if (ALLOWED_REQUEST_HEADERS.has(key.toLowerCase())) headers[key.toLowerCase()] = value;
    });
    const method = (init.method ?? 'GET').toUpperCase();
    const answer = await brokerFetch(`${url.pathname}${url.search}`, {
      method: method === 'POST' ? 'POST' : 'GET',
      headers,
      ...(typeof init.body === 'string' ? { body: init.body } : {}),
    });
    const noBody = answer.status === 204 || answer.status === 205 || answer.status === 304;
    return new Response(noBody ? null : answer.body, { status: answer.status, headers: answer.headers as Record<string, string> });
  }) as typeof fetch;
}

/**
 * Brain calls through the org broker: MCP over `/v1/broker/brain/mcp` via the host's broker fetch. When there is no org
 * identity, the host fails the call (path, timeout), or the broker answers 401/403/503 (or has no such route), the `fallback` client (the gcloud route) answers
 * instead, and the broker is not tried again for a minute.
 */
export function createOrgBrokerBrainClient(
  options: { readonly source: BrokerFetchSource; readonly fallback?: CloudBrainClient },
  deps: { readonly now?: () => number } = {},
): CloudBrainClient {
  const now = deps.now ?? Date.now;
  let skipUntil = 0;
  let inner: { readonly host: BrokerFetch; readonly client: CloudBrainClient } | undefined;

  const hostCredentials: CallerCredentialSource = {
    async credentials() { return { idToken: 'host-managed', caller: 'org-broker' }; },
    reset() { /* The host holds the token. */ },
  };
  const brokerClient = (host: BrokerFetch): CloudBrainClient => {
    if (inner?.host !== host) {
      inner = {
        host,
        client: createCloudBrainClient(
          { url: BROKER_ORIGIN, endpoint: `${BROKER_ORIGIN}${ORG_BROKER_BRAIN_PATH}`, credentials: hostCredentials, sendCaller: false },
          { fetch: brokerFetchAsFetch(host) },
        ),
      };
    }
    return inner.client;
  };

  return {
    async callTool(tool, args, signal, callerEmail) {
      const host = await Promise.resolve().then(options.source).catch(() => undefined);
      if (!host || now() < skipUntil) {
        if (!options.fallback) {
          throw new CloudBrainError('cloud_brain_auth_failed', 'cloud brain auth failed: no Marshal org session is signed in.');
        }
        return options.fallback.callTool(tool, args, signal, callerEmail);
      }
      try {
        return await brokerClient(host).callTool(tool, args, signal, callerEmail);
      } catch (error) {
        if (!options.fallback || !brokerRefused(error)) throw error;
        skipUntil = now() + ORG_BROKER_RETRY_MS;
        return options.fallback.callTool(tool, args, signal, callerEmail);
      }
    },
    warm() {
      options.fallback?.warm?.();
    },
  };
}

/** The broker is not usable for this person right now: refused (401/403), not configured (503), or not served (404 other than a lost session). */
function brokerRefused(error: unknown): boolean {
  if (!isCloudBrainError(error)) return false;
  if (error.code === 'cloud_brain_auth_failed') return true;
  // 503 broker-unavailable, or the host's own failure (path-not-allowed, 60 s timeout, oversize answer): no HTTP status.
  if (error.code === 'cloud_brain_unavailable') return true;
  return error.code === 'cloud_brain_rejected' && error.httpStatus === 404 && !/unknown-session/i.test(error.message);
}
