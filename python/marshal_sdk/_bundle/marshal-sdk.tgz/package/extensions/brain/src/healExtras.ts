import * as path from 'node:path';
import type { InvocationContext } from '@marshal/agent-runtime-core';
import type { MemoryScopeHandle, PortableMemoryRuntime } from '@marshal/agent-runtime-provider-memory';
import { COMMIT_ID, mainHead, scanCodeChanges, type CodeChangeScan } from './codeReviewScan.js';
import type { LazyUserMemory } from './marshalMemoryStore.js';
import type { ProfileWriteResult } from './profileDocument.js';
import { regenerateProfile } from './profileRefresh.js';
import type { HealLog } from './userDailyHeal.js';

export interface HealExtrasResult {
  /**
   * `baseline`: the first check of this repository (or one whose recorded head is not a commit id)
   * only records main's head. `too-large`: the change lists more files than git's output limit;
   * main's head is recorded so the next session does not redo it (review round 9 L1).
   */
  readonly codeReview: 'baseline' | 'unchanged' | 'scanned' | 'too-large' | 'no-repository' | 'failed';
  readonly scan?: Pick<CodeChangeScan, 'base' | 'head' | 'changedFiles' | 'meaningfulFiles' | 'cosmeticFiles' | 'unaffectedLinks' | 'tooLargeFiles'> & {
    readonly flagged: number;
  };
  readonly profile?: ProfileWriteResult;
}

export interface HealExtras {
  /** After a session start's heal (`after`): the code-change review and profile.md; one run in flight per project. */
  schedule(handles: readonly MemoryScopeHandle[], context: InvocationContext, after: Promise<unknown>): void;
  /** Runs both now, ungated (tests and replays). */
  run(handles: readonly MemoryScopeHandle[], context: InvocationContext): Promise<HealExtrasResult>;
  waitForIdle(): Promise<void>;
  /** On dispose: kills a running git (review round 9 M5) and schedules nothing more. */
  cancel(): void;
}

const consoleLog: HealLog = {
  info: (message, metadata) => console.info(message, metadata),
  warn: (message, metadata) => console.warn(message, metadata),
};

export interface HealExtrasOptions {
  /** The bundle's own workspace: session-start contexts may not carry one. */
  readonly workspacePath?: string;
  readonly log?: HealLog;
}

export function createHealExtras(
  runtime: () => PortableMemoryRuntime,
  userMemory: () => LazyUserMemory,
  options: HealExtrasOptions = {},
): HealExtras {
  const log = options.log ?? consoleLog;
  const workspaceOf = (context: InvocationContext) => context.scope?.workspacePath ?? options.workspacePath;
  const inFlight = new Set<string>();
  const running = new Set<Promise<unknown>>();
  const abort = new AbortController();
  const run = async (handles: readonly MemoryScopeHandle[], context: InvocationContext): Promise<HealExtrasResult> => {
    const { signal } = abort;
    await labelProject(runtime(), userMemory(), handles, context, workspaceOf(context), signal).catch(() => undefined);
    const codeReview = await reviewCode(runtime(), userMemory(), handles, context, workspaceOf(context), signal).catch((error: unknown) => {
      log.warn('[brain] memory code review failed; the next heal retries', { errorName: error instanceof Error ? error.name : typeof error });
      return { codeReview: 'failed' as const };
    });
    const profile = regenerateProfile(userMemory());
    return { ...codeReview, profile };
  };
  return {
    run,
    schedule(handles, context, after) {
      // Each session start: cheap when main has not moved (two rev-parses) and profile.md is unchanged.
      const key = context.scope?.projectId ?? workspaceOf(context) ?? '';
      if (inFlight.has(key) || abort.signal.aborted) return;
      inFlight.add(key);
      const task = after.catch(() => undefined).then(() => run(handles, context)).then((result) => {
        log.info('[brain] memory review and profile', {
          codeReview: result.codeReview,
          flagged: result.scan?.flagged ?? 0,
          meaningfulFiles: result.scan?.meaningfulFiles.length ?? 0,
          cosmeticFiles: result.scan?.cosmeticFiles.length ?? 0,
          profileLines: result.profile?.lines ?? 0,
        });
      }).catch(() => undefined).finally(() => {
        inFlight.delete(key);
        running.delete(task);
      });
      running.add(task);
    },
    async waitForIdle() {
      while (running.size > 0) await Promise.all([...running]);
    },
    cancel() {
      abort.abort();
    },
  };
}

/** profile.md names projects by their repository (the main checkout's directory name). */
async function labelProject(
  runtime: PortableMemoryRuntime,
  userMemory: LazyUserMemory,
  handles: readonly MemoryScopeHandle[],
  context: InvocationContext,
  workspacePath: string | undefined,
  signal: AbortSignal,
): Promise<void> {
  if (!workspacePath) return;
  const main = await mainHead(workspacePath, signal);
  const commonDir = main?.key.slice(0, main.key.lastIndexOf('#'));
  const label = commonDir && path.basename(commonDir) === '.git' ? path.basename(path.dirname(commonDir)) : path.basename(workspacePath);
  const scopeIds = runtime.scopes.authorize(handles, 'read', context)
    .filter(({ kind }) => kind === 'project' || kind === 'workspace').map(({ scopeId }) => scopeId);
  userMemory.reviews.labelProject([...scopeIds, ...(context.scope?.projectId ? [context.scope.projectId] : [])], label);
}

async function reviewCode(
  runtime: PortableMemoryRuntime,
  userMemory: LazyUserMemory,
  handles: readonly MemoryScopeHandle[],
  context: InvocationContext,
  workspacePath: string | undefined,
  signal: AbortSignal,
): Promise<Pick<HealExtrasResult, 'codeReview' | 'scan'>> {
  const main = workspacePath ? await mainHead(workspacePath, signal) : undefined;
  if (!workspacePath || !main) return { codeReview: 'no-repository' };
  const reviews = userMemory.reviews;
  const previous = reviews.head(main.key);
  if (!previous || !COMMIT_ID.test(previous)) {
    reviews.recordHead(main.key, main.head);
    return { codeReview: 'baseline' };
  }
  if (previous === main.head) return { codeReview: 'unchanged' };
  const scopeIds = runtime.scopes.authorize(handles, 'read', context).map(({ scopeId }) => scopeId);
  const scan = await scanCodeChanges(workspacePath, previous, main.head, reviews.codeLinked(scopeIds), signal).catch((error: unknown) => {
    if ((error as { code?: unknown } | null)?.code === 'code_review_diff_too_large') return undefined;
    throw error;
  });
  if (!scan) {
    reviews.recordHead(main.key, main.head);
    return { codeReview: 'too-large' };
  }
  reviews.flagCode(scan.flags);
  reviews.recordHead(main.key, main.head);
  const { flags, ...counts } = scan;
  return { codeReview: 'scanned', scan: { ...counts, flagged: flags.length } };
}
