import type { InvocationContext } from '@marshal/agent-runtime-core';
import type {
  DurableMemoryRecord,
  MemoryScopeHandle,
  PortableMemoryRuntime,
} from '@marshal/agent-runtime-provider-memory';
import type { MarshalMemoryCategory } from './marshalMemoryStore.js';
import { comparableFact, userMemoryFactKey } from './userMemoryFactKey.js';

export interface UserMemoryReplacement {
  readonly replaces: string;
  readonly content: string;
  readonly category: MarshalMemoryCategory;
  readonly source: string;
  /** Other active user memories, to refuse a replacement that duplicates one of them. */
  readonly active: ReadonlyArray<{ readonly id: string; readonly fact: string }>;
  /** A project id, null for global; omitted keeps the replaced memory's appliesTo. */
  readonly appliesTo?: string | null;
}

function replaceError(message: string, code: string): Error {
  return Object.assign(new Error(message), { code });
}

/**
 * "This replaces that": a correction in the user scope. The new revision is active
 * and blessed, the replaced one becomes superseded (superseded_by = new id), so the
 * prompt shows only the new fact and lineage stays visible with includeHistory.
 * Unknown, inactive or other-scope ids fail with a clear error and write nothing.
 */
export async function replaceUserMemory(
  runtime: PortableMemoryRuntime,
  handle: MemoryScopeHandle,
  context: InvocationContext,
  request: UserMemoryReplacement,
): Promise<DurableMemoryRecord> {
  const id = typeof request.replaces === 'string' ? request.replaces.trim() : '';
  if (!id) throw replaceError('replaces must be the id of an existing memory.', 'memory_replace_invalid_id');
  let target: DurableMemoryRecord | null;
  try {
    target = runtime.get(handle, id, context, true);
  } catch {
    target = null;
  }
  if (!target || target.scopeId !== handle.scopeId) {
    throw replaceError(
      `Memory ${id} is not one of the user's memories; use an id from recall or listMemories.`,
      'memory_replace_not_found',
    );
  }
  if (!target.active || target.state !== 'active' || !target.head) {
    throw replaceError(
      `Memory ${id} is ${target.state}${target.supersededBy ? ` (replaced by ${target.supersededBy})` : ''}; only an active memory can be replaced.`,
      'memory_replace_not_active',
    );
  }
  const duplicate = request.active.find((entry) =>
    entry.id !== id && comparableFact(entry.fact) === comparableFact(request.content));
  if (duplicate) {
    throw replaceError(
      `That fact is already stored as ${duplicate.id}; delete ${id} instead of replacing it.`,
      'memory_replace_duplicate',
    );
  }
  const { memory } = await runtime.correct({
    handle,
    memoryId: id,
    expectedRevision: target.revision,
    content: request.content,
    retrievalSynopsis: request.content.slice(0, 3_800),
    factKey: userMemoryFactKey(request.content, request.category, request.source),
    blessed: true,
    ...(request.appliesTo !== undefined ? { appliesTo: request.appliesTo } : {}),
  }, context);
  return memory;
}
