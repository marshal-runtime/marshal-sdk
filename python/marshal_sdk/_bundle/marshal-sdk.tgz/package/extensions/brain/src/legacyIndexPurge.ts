import { promises as fs } from 'node:fs';
import * as path from 'node:path';

/**
 * Startup cleanup of the index folders earlier versions left on a user's machine. Their pages kept the
 * text of memories the user later forgot, and nothing reads them any more, so they are deleted.
 *
 * Only these are ever removed, each verified by name and type before anything is deleted:
 * - a direct child directory of a given parent named `p-`, `u-`, `brain-project-` or `brain-profile-`
 *   followed by 24 hex digits (optionally a `.tomb-<pid>-<ms>` leftover), and its `<name>.brain-root.json` marker;
 * - the `slots` directory of a direct child of `<dataRoot>/repositories`.
 * Symlinks are never followed or removed, and a candidate that contains or lies inside a preserved path
 * (memory.sqlite and the projections), or that directly holds a memory.sqlite file, is refused.
 */

const MEMORY_ROOT_NAME = /^(?:p|u|brain-project|brain-profile)-[0-9a-f]{24}(?:\.tomb-\d+-\d+)?$/u;
const MEMORY_ROOT_MARKER = /^(?:p|u|brain-project|brain-profile)-[0-9a-f]{24}\.brain-root\.json$/u;
const REPOSITORY_NAME = /^[A-Za-z0-9._-]{1,128}$/u;
const MAX_ENTRIES = 5_000;

export interface LegacyIndexPurgeRoots {
  /** Directories whose direct children may be memory index roots (the `bq/<profile>` and data-root directories). */
  readonly memoryRootParents: readonly string[];
  /** Data roots whose `repositories/<id>/slots` folders held code indexes. */
  readonly dataRoots: readonly string[];
  /** Paths that must survive: memory.sqlite, the projections and anything else the user's data lives in. */
  readonly preservedPaths: readonly string[];
}

export interface LegacyIndexPurgeResult {
  readonly removed: readonly string[];
  readonly refused: readonly string[];
  readonly failures: readonly string[];
}

const within = (inner: string, outer: string): boolean => {
  const relative = path.relative(outer, inner);
  return relative === '' || (!relative.startsWith('..') && !path.isAbsolute(relative));
};

async function realDirectory(directory: string): Promise<string | undefined> {
  const stat = await fs.lstat(directory).catch(() => undefined);
  if (!stat?.isDirectory()) return undefined;
  return fs.realpath(directory).catch(() => undefined);
}

async function children(directory: string): Promise<string[]> {
  const entries = await fs.readdir(directory).catch(() => [] as string[]);
  return entries.slice(0, MAX_ENTRIES);
}

export async function purgeLegacyIndexSlots(roots: LegacyIndexPurgeRoots): Promise<LegacyIndexPurgeResult> {
  const removed: string[] = [];
  const refused: string[] = [];
  const failures: string[] = [];
  const preserved = await Promise.all(roots.preservedPaths.map(async (item) =>
    (await fs.realpath(item).catch(() => undefined)) ?? path.resolve(item)));

  const remove = async (candidate: string, directory: boolean): Promise<void> => {
    const stat = await fs.lstat(candidate).catch(() => undefined);
    if (!stat || stat.isSymbolicLink() || stat.isDirectory() !== directory) return;
    if (preserved.some((kept) => within(candidate, kept) || within(kept, candidate))) {
      refused.push(candidate);
      return;
    }
    if (directory && (await children(candidate)).some((entry) => entry.startsWith('memory.sqlite'))) {
      refused.push(candidate);
      return;
    }
    try {
      await fs.rm(candidate, { recursive: directory, force: true });
      removed.push(candidate);
    } catch (error) {
      failures.push(`${candidate}: ${error instanceof Error ? error.message : String(error)}`);
    }
  };

  for (const parent of roots.memoryRootParents) {
    const real = await realDirectory(parent);
    if (!real) continue;
    for (const name of await children(real)) {
      if (MEMORY_ROOT_NAME.test(name)) await remove(path.join(real, name), true);
      else if (MEMORY_ROOT_MARKER.test(name)) await remove(path.join(real, name), false);
    }
  }
  for (const dataRoot of roots.dataRoots) {
    const repositories = await realDirectory(path.join(dataRoot, 'repositories'));
    if (!repositories) continue;
    for (const name of await children(repositories)) {
      if (REPOSITORY_NAME.test(name)) await remove(path.join(repositories, name, 'slots'), true);
    }
  }
  return { removed, refused, failures };
}
