import { execFile } from 'node:child_process';
import { realpathSync } from 'fs';
import * as path from 'node:path';
import { promisify } from 'node:util';
import { distinctiveTokens, lineTokens, rankTopicWords } from './topicTokens.js';

const run = promisify(execFile);
const MAX_FILES = 2_000;
/**
 * Every git call (review round 9 M5, L1): a hung git (a credential prompt through a hook, a stuck
 * network filesystem, a lock) is killed after timeoutMs, and output over maxBytes is "too large".
 * Mutable for tests only.
 */
export const GIT_LIMITS = { timeoutMs: 20_000, maxBytes: 8 * 1024 * 1024 };
/** A commit id from Brain's database is used as a revision only in this shape (review round 9 L2). */
export const COMMIT_ID = /^[0-9a-f]{40}(?:[0-9a-f]{24})?$/;
/**
 * A file-level link's gate: the memory's top topic words, of which a change must name two, or one of
 * its LEAD_WORDS leading ones. Review round 10 M1, 30 daily windows of zyg main plus 132 synthetic
 * one-word changes: one leading word missed 43 of 132 at 1 FP in 19 flags; three miss 22 at 3 in 21.
 */
const TOPIC_WORDS = 10;
const LEAD_WORDS = 3;
const TOPIC_MATCHES = 2;
const COMMENT_LINE = /^\s*(?:\/\/|#(?!include|!)|\/\*|\*\/?|<!--|-->|--\s|;;|")/;
const DECLARATION = /^\s*(?:export\s+)?(?:default\s+)?(?:async\s+)?(?:func|function|class|interface|type|enum|def|const|let|var|struct|trait|impl|fn)\b/;

export interface CodeLinkedMemory {
  readonly memoryId: string;
  /** `code:<repo-relative path>` or `code:<path>#<symbol>` targets (memory.link's derivedFrom). */
  readonly links: readonly string[];
  /** The memory's own text: a file-level link flags only a change that names its topic (fileTopics). */
  readonly text?: string;
}

export interface CodeChangeFlag {
  readonly memoryId: string;
  readonly reason: string;
}

export interface CodeChangeScan {
  readonly base: string;
  readonly head: string;
  readonly changedFiles: number;
  /** Changed files whose change is more than whitespace, blank lines, comments or formatting. */
  readonly meaningfulFiles: readonly string[];
  readonly cosmeticFiles: readonly string[];
  readonly flags: readonly CodeChangeFlag[];
  /** Links to a changed file whose own symbol the change did not touch (not flagged). */
  readonly unaffectedLinks: number;
  /** File-level links to a changed file whose change does not name the memory's topic (not flagged). */
  readonly offTopicLinks: number;
  /** Linked files whose diff was over GIT_LIMITS.maxBytes: their links are flagged "too large to compare". */
  readonly tooLargeFiles: readonly string[];
}

interface Hunk {
  readonly start: number;
  readonly end: number;
  readonly header: string;
  readonly lines: readonly string[];
}

interface FileChange {
  readonly status: string;
  readonly path: string;
  readonly renamedTo?: string;
  /** Meaningful hunks only; empty when every hunk was cosmetic. */
  readonly hunks: readonly Hunk[];
  /** The diff was over GIT_LIMITS.maxBytes: changed, not compared. */
  readonly tooLarge?: boolean;
}

async function git(repository: string, args: readonly string[], signal?: AbortSignal): Promise<string> {
  const { stdout } = await run('git', ['-C', repository, ...args], {
    maxBuffer: GIT_LIMITS.maxBytes,
    encoding: 'utf8',
    timeout: GIT_LIMITS.timeoutMs,
    killSignal: 'SIGKILL',
    ...(signal ? { signal } : {}),
    env: { ...process.env, GIT_TERMINAL_PROMPT: '0', GIT_OPTIONAL_LOCKS: '0' },
  });
  return stdout;
}

function tooLarge(error: unknown): boolean {
  return (error as { code?: unknown } | null)?.code === 'ERR_CHILD_PROCESS_STDIO_MAXBUFFER';
}

function coded(code: string, message: string): Error {
  return Object.assign(new Error(message), { code });
}

/**
 * The main branch's commit and a key naming the repository (its common git directory) and branch.
 * The remote-tracking branch comes first: it moves on every fetch, while a local main a developer
 * never checks out stays where it was cloned.
 */
export async function mainHead(
  workspacePath: string,
  signal?: AbortSignal,
): Promise<{ readonly key: string; readonly head: string } | undefined> {
  let common: string;
  try {
    common = (await git(workspacePath, ['rev-parse', '--git-common-dir'], signal)).trim();
  } catch {
    return undefined;
  }
  const commonDir = realpathSync.native(path.resolve(workspacePath, common));
  for (const branch of ['origin/main', 'main', 'origin/master', 'master']) {
    const ref = branch.startsWith('origin/') ? `refs/remotes/${branch}` : `refs/heads/${branch}`;
    try {
      const head = (await git(workspacePath, ['rev-parse', '--verify', '--quiet', `${ref}^{commit}`], signal)).trim();
      if (COMMIT_ID.test(head)) return { key: `${commonDir}#${branch}`, head };
    } catch {
      // try the next branch name
    }
  }
  return undefined;
}

/**
 * The memories whose code links a change between `from` and `to` touched. A file-level link is
 * touched by the file's removal or rename, or by meaningful hunks that name the memory's topic
 * (fileTopics; any meaningful hunk when the memory has no text); a symbol link only when
 * a meaningful hunk overlaps the symbol's declaration block in the new file, names the symbol, or
 * the symbol is gone. Whitespace-only, blank-line, comment-only and formatting-only hunks (the same
 * tokens once spaces, quotes and trailing commas are normalized) never count.
 */
export async function scanCodeChanges(
  repository: string,
  from: string,
  to: string,
  memories: readonly CodeLinkedMemory[],
  signal?: AbortSignal,
): Promise<CodeChangeScan> {
  if (!COMMIT_ID.test(from) || !COMMIT_ID.test(to)) throw coded('code_review_bad_revision', 'A code review compares two commit ids.');
  const base = await mergeBase(repository, from, to, signal);
  const linkedFiles = new Set(memories.flatMap(({ links }) => links.map((link) => parseLink(link)?.path ?? '')));
  const listing = await git(repository, ['diff', '--name-status', '-M', '--no-color', '--end-of-options', base, to], signal).catch((error: unknown) => {
    if (tooLarge(error)) throw coded('code_review_diff_too_large', `The change ${base.slice(0, 7)}..${to.slice(0, 7)} lists more than ${GIT_LIMITS.maxBytes} bytes of files.`);
    throw error;
  });
  const nameStatus = listing.split('\n').filter(Boolean).slice(0, MAX_FILES);
  const changes = new Map<string, FileChange>();
  const cosmeticFiles: string[] = [];
  for (const line of nameStatus) {
    const [status = '', file = '', renamed] = line.split('\t');
    if (!linkedFiles.has(file)) continue;
    if (status.startsWith('D') || status.startsWith('R')) {
      changes.set(file, { status: status[0]!, path: file, ...(renamed ? { renamedTo: renamed } : {}), hunks: [] });
      continue;
    }
    const diff = await git(repository, ['diff', '-U0', '-w', '--ignore-blank-lines', '--no-color', '--end-of-options', base, to, '--', file], signal)
      .catch((error: unknown) => {
        if (tooLarge(error)) return undefined;
        throw error;
      });
    if (diff === undefined) {
      changes.set(file, { status: status[0]!, path: file, hunks: [], tooLarge: true });
      continue;
    }
    const hunks = meaningfulHunks(diff);
    if (hunks.length === 0) cosmeticFiles.push(file);
    else changes.set(file, { status: status[0]!, path: file, hunks });
  }
  const flags: CodeChangeFlag[] = [];
  let unaffectedLinks = 0;
  let offTopicLinks = 0;
  const topics = fileTopics(memories);
  const sources = new Map<string, Promise<readonly string[]>>();
  const source = (file: string) => {
    if (!sources.has(file)) sources.set(file, git(repository, ['show', '--end-of-options', `${to}:${file}`], signal).then((text) => text.split('\n'), () => []));
    return sources.get(file)!;
  };
  const range = `${base.slice(0, 7)}..${to.slice(0, 7)}`;
  for (const memory of memories) {
    const touched: string[] = [];
    for (const link of memory.links) {
      const target = parseLink(link);
      const change = target && changes.get(target.path);
      if (!target || !change) continue;
      if (change.status === 'D') touched.push(`${target.path} removed`);
      else if (change.tooLarge) touched.push(`${target.path} changed, too large to compare`);
      else if (change.status === 'R') touched.push(`${target.path} renamed to ${change.renamedTo}`);
      else if (!target.symbol) {
        const topic = topics.get(memory.memoryId);
        const words = topic?.files.get(target.path);
        const named = words && topicWords(change.hunks, words, topic!.leading);
        if (!words) touched.push(`${target.path} changed`);
        else if (named) touched.push(`${target.path} changed (names "${named}")`);
        else offTopicLinks += 1;
      }
      else if (await symbolTouched(target.symbol, change.hunks, await source(target.path))) touched.push(`${target.path}#${target.symbol} changed`);
      else unaffectedLinks += 1;
    }
    if (touched.length > 0) {
      const more = touched.length > 2 ? ` and ${touched.length - 2} more` : '';
      flags.push({ memoryId: memory.memoryId, reason: `code changed on main ${range}: ${touched.slice(0, 2).join(', ')}${more}` });
    }
  }
  const tooLargeFiles = [...changes.values()].filter((change) => change.tooLarge).map(({ path: file }) => file);
  return { base, head: to, changedFiles: nameStatus.length, meaningfulFiles: [...changes.keys()], cosmeticFiles, flags, unaffectedLinks, offTopicLinks, tooLargeFiles };
}

/** What the change names of the memory's topic: one of its leading words, or at least TOPIC_MATCHES others. */
function topicWords(hunks: readonly Hunk[], words: ReadonlySet<string>, leading: ReadonlySet<string>): string | undefined {
  const named = new Set(hunks.flatMap((hunk) => hunk.lines.flatMap((line) => lineTokens(line).filter((token) => words.has(token)))));
  const lead = [...named].find((word) => leading.has(word));
  if (lead) return lead;
  return named.size >= TOPIC_MATCHES ? [...named].slice(0, TOPIC_MATCHES).join('", "') : undefined;
}

interface MemoryTopic {
  /** The memory's LEAD_WORDS top-ranked topic words. */
  readonly leading: ReadonlySet<string>;
  /** Per gated file-level link, the topic words a change there may name. */
  readonly files: ReadonlyMap<string, ReadonlySet<string>>;
}

/**
 * Per memory and file-level link, the words a change must name to concern the memory: its top
 * topic words (topicTokens.ts rankTopicWords: the words it uses most that few other memories use)
 * minus any word another memory linking the same file uses (on a registry several connectors
 * share, the words both flows use say nothing about which one changed). A file-level link is not
 * gated (any meaningful change counts) when the memory has no text, when no words are left, or when
 * the path names the memory's top word (facebook.go for the Facebook flow).
 */
function fileTopics(memories: readonly CodeLinkedMemory[]): Map<string, MemoryTopic> {
  const withText = memories.filter(({ text }) => text);
  const ranked = rankTopicWords(new Map(withText.map(({ memoryId, text }) => [memoryId, text!])));
  const words = new Map(withText.map(({ memoryId, text }) => [memoryId, distinctiveTokens(text!)]));
  const linkers = new Map<string, Set<string>>();
  for (const { memoryId, links } of memories) {
    for (const target of links.map(parseLink)) if (target) linkers.set(target.path, (linkers.get(target.path) ?? new Set()).add(memoryId));
  }
  const topics = new Map<string, MemoryTopic>();
  for (const { memoryId, links } of memories) {
    const [top, ...rest] = ranked.get(memoryId) ?? [];
    if (!top) continue;
    const leading = new Set([top, ...rest].slice(0, LEAD_WORDS));
    const files = new Map<string, ReadonlySet<string>>();
    for (const file of new Set(links.map(parseLink).filter((target) => target && !target.symbol).map((target) => target!.path))) {
      if (lineTokens(file).includes(top)) continue;
      const others = [...linkers.get(file)!].filter((other) => other !== memoryId).map((other) => words.get(other) ?? new Set<string>());
      const gate = new Set([top, ...rest].slice(0, TOPIC_WORDS).filter((word) => !others.some((set) => set.has(word))));
      if (gate.size > 0) files.set(file, gate);
    }
    topics.set(memoryId, { leading, files });
  }
  return topics;
}

async function mergeBase(repository: string, from: string, to: string, signal?: AbortSignal): Promise<string> {
  try {
    const base = (await git(repository, ['merge-base', '--end-of-options', from, to], signal)).trim();
    return COMMIT_ID.test(base) ? base : from;
  } catch (error) {
    if (signal?.aborted) throw error;
    return from;
  }
}

export function parseLink(link: string): { readonly path: string; readonly symbol?: string } | undefined {
  if (!link.startsWith('code:')) return undefined;
  const [file = '', symbol] = link.slice('code:'.length).split('#', 2);
  if (!file) return undefined;
  return symbol ? { path: file, symbol } : { path: file };
}

/** Hunks of a `-U0 -w --ignore-blank-lines` diff that change more than comments or formatting. */
export function meaningfulHunks(diff: string): Hunk[] {
  const hunks: Hunk[] = [];
  let current: { start: number; end: number; header: string; removed: string[]; added: string[] } | undefined;
  const close = () => {
    if (!current) return;
    const removed = current.removed.filter((line) => !COMMENT_LINE.test(line)).map(normalized).filter(Boolean).sort();
    const added = current.added.filter((line) => !COMMENT_LINE.test(line)).map(normalized).filter(Boolean).sort();
    if (removed.join('\n') !== added.join('\n')) {
      hunks.push({ start: current.start, end: current.end, header: current.header, lines: [...current.removed, ...current.added] });
    }
    current = undefined;
  };
  for (const line of diff.split('\n')) {
    const header = /^@@ -\d+(?:,\d+)? \+(\d+)(?:,(\d+))? @@(.*)$/.exec(line);
    if (header) {
      close();
      const start = Number(header[1]);
      const count = header[2] === undefined ? 1 : Number(header[2]);
      current = { start, end: start + Math.max(count, 1) - 1, header: header[3]?.trim() ?? '', removed: [], added: [] };
    } else if (current && line.startsWith('-') && !line.startsWith('---')) {
      current.removed.push(line.slice(1));
    } else if (current && line.startsWith('+') && !line.startsWith('+++')) {
      current.added.push(line.slice(1));
    }
  }
  close();
  return hunks;
}

/** Spaces, quote style and trailing separators are formatting. */
function normalized(line: string): string {
  return line.replace(/\s+/g, '').replace(/['`]/g, '"').replace(/[;,]+$/, '');
}

async function symbolTouched(symbol: string, hunks: readonly Hunk[], newSource: readonly string[]): Promise<boolean> {
  const name = symbol.split('.').pop()!;
  const word = new RegExp(`(?<![\\w$])${name.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}(?![\\w$])`);
  if (hunks.some((hunk) => word.test(hunk.header) || hunk.lines.some((line) => !COMMENT_LINE.test(line) && word.test(line)))) return true;
  const declared = newSource.findIndex((line) => word.test(line) && (DECLARATION.test(line) || /^\s*[\w$.]+\s*[:=(]/.test(line)));
  if (declared === -1) return true;
  // The declaration block: up to the next line at the same or lower indentation that starts a declaration.
  const indent = /^\s*/.exec(newSource[declared]!)![0].length;
  let last = newSource.length;
  for (let index = declared + 1; index < newSource.length; index += 1) {
    const line = newSource[index]!;
    if (line.trim() && /^\s*/.exec(line)![0].length <= indent && DECLARATION.test(line)) {
      last = index;
      break;
    }
  }
  const [from, to] = [declared + 1, last];
  return hunks.some((hunk) => hunk.start <= to && hunk.end >= from);
}
