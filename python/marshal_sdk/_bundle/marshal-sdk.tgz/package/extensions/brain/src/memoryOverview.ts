import type {
  CapabilityDescriptor,
  CapabilityProvider,
  InvocationContext,
} from '@marshal/agent-runtime-core';
import { PROTOCOL_VERSION, createProvider, result } from '@marshal/agent-runtime-provider-kit';
import {
  PROJECTION_ATTENTION_SCHEMA,
  type MemoryOverviewEntry,
  type MemoryScopeHandle,
  type PortableMemoryRuntime,
  type ProjectionAttention,
} from '@marshal/agent-runtime-provider-memory';
import { existsSync } from 'fs';
import type { LazyUserMemory } from './marshalMemoryStore.js';
import { CONFIRM_REVIEWED_DESCRIPTOR, confirmReviewed } from './memoryReviewConfirm.js';
import { DEFAULT_PROMPT_BUDGET_BYTES } from './promptSelection.js';
import { decodeUserMemoryFactKey, MARSHAL_MEMORY_CATEGORIES } from './userMemoryFactKey.js';

const PROVIDER_ID = 'marshal.memory-overview';
const DEFAULT_LIMIT = 200;
const MAX_LIMIT = 500;
const MAX_TEXT_CHARS = 500;
const SCOPE_FILTERS = ['user', 'project', 'workspace', 'session', 'run', 'agent'] as const;
type ScopeFilter = (typeof SCOPE_FILTERS)[number];

const nullableString = { type: ['string', 'null'] } as const;

const DESCRIPTOR: CapabilityDescriptor = {
  protocolVersion: PROTOCOL_VERSION,
  name: 'memory.overview',
  version: '1.0.0',
  description:
    'Use this, never the prompt alone (it lacks project notes and history), whenever the user asks what you remember or know about them or a project, or wants to see or review memories. '
    + 'Read-only table of what Marshal remembers for this session: one row per memory with scope, '
    + 'category, date, source, whether it is injected into this session\'s prompt, pending index work, '
    + 'lineage and the absolute path of its Markdown file. Newest first. Show it with runtimeShowUi '
    + 'component data-table; open a row\'s file with ui.document.open. needsReview says why a memory may be stale '
    + '(code it links changed, a review-by date passed, or an incident/context item went quiet); when the user '
    + 'confirms flagged memories still hold, record it with memory.review.confirm {ids} (a write). '
    + 'profile.path is the derived profile.md one-pager. attention lists what needs the user: a non-empty entry '
    + 'means memories whose Markdown files are missing are kept rather than deleted; show its message (e.g. '
    + '"N memories\' files are missing") before the table.',
  tags: ['memory', 'overview', 'read'],
  permissions: [{ permission: 'memory.read', scope: 'runtime', risk: 'low' }],
  inputSchema: {
    type: 'object',
    properties: {
      scope: { enum: [...SCOPE_FILTERS], description: 'Only memories of this scope kind.' },
      category: { enum: [...MARSHAL_MEMORY_CATEGORIES] },
      includeHistory: {
        type: 'boolean',
        default: false,
        description: 'Also list superseded, archived and promoted revisions (hidden by default).',
      },
      limit: { type: 'integer', minimum: 1, maximum: MAX_LIMIT, default: DEFAULT_LIMIT },
    },
    additionalProperties: false,
  },
  outputSchema: {
    type: 'object',
    required: ['rows', 'total', 'truncated', 'prompt'],
    properties: {
      rows: {
        type: 'array',
        maxItems: MAX_LIMIT,
        items: {
          type: 'object',
          required: ['id', 'scope', 'state', 'category', 'createdAt', 'source', 'appliesTo', 'blessed',
            'injected', 'backlog', 'backlogAttempts', 'supersedes', 'supersededBy', 'promotedFrom', 'file', 'text'],
          properties: {
            id: { type: 'string' },
            scope: { type: 'string' },
            state: { enum: ['active', 'superseded', 'archived', 'promoted'] },
            category: { enum: [...MARSHAL_MEMORY_CATEGORIES, null] },
            createdAt: { type: 'string' },
            source: nullableString,
            appliesTo: nullableString,
            blessed: { type: 'boolean' },
            injected: { type: 'boolean' },
            backlog: { enum: ['none', 'upsert', 'remove'] },
            backlogAttempts: { type: 'integer', minimum: 0 },
            supersedes: nullableString,
            supersededBy: nullableString,
            promotedFrom: nullableString,
            file: nullableString,
            text: { type: 'string', maxLength: MAX_TEXT_CHARS },
            needsReview: nullableString,
          },
          additionalProperties: false,
        },
      },
      total: { type: 'integer', minimum: 0 },
      profile: {
        type: 'object',
        required: ['path', 'exists'],
        properties: { path: { type: 'string' }, exists: { type: 'boolean' } },
        additionalProperties: false,
      },
      truncated: { type: 'boolean' },
      attention: PROJECTION_ATTENTION_SCHEMA,
      prompt: {
        type: 'object',
        required: ['budgetBytes', 'injected', 'omitted'],
        properties: {
          budgetBytes: { type: 'integer' },
          injected: { type: 'integer', minimum: 0 },
          omitted: { type: 'integer', minimum: 0 },
        },
        additionalProperties: false,
      },
    },
    additionalProperties: false,
  },
};

export interface MemoryOverviewRow {
  readonly id: string;
  /** `user`, `project:<projectId>`, `workspace`, `project:legacy`/`workspace:legacy`, or the scope kind. */
  readonly scope: string;
  readonly state: 'active' | 'superseded' | 'archived' | 'promoted';
  readonly category: (typeof MARSHAL_MEMORY_CATEGORIES)[number] | null;
  readonly createdAt: string;
  readonly source: string | null;
  /** User memories: their R9 appliesTo (`global` or a project id); project/workspace memories: the project id. */
  readonly appliesTo: string | null;
  readonly blessed: boolean;
  /** Selected into the prompt of a session in the caller's project (selectForPrompt, 8192 bytes). */
  readonly injected: boolean;
  readonly backlog: 'none' | 'upsert' | 'remove';
  readonly backlogAttempts: number;
  readonly supersedes: string | null;
  readonly supersededBy: string | null;
  readonly promotedFrom: string | null;
  readonly file: string | null;
  readonly text: string;
  /** Why the memory may be stale (memoryReview.ts); null when it is not flagged. */
  readonly needsReview?: string | null;
}

/**
 * Agent-facing read-only memory view (R10). Lists the user scope plus every scope the
 * calling session may read; `injected` reuses the store's own prompt selection.
 */
export function createMemoryOverviewProvider(
  memory: () => PortableMemoryRuntime,
  userMemory: LazyUserMemory,
): CapabilityProvider {
  return createProvider(PROVIDER_ID, [DESCRIPTOR, CONFIRM_REVIEWED_DESCRIPTOR], async (name, rawInput, context) => {
    if (name === CONFIRM_REVIEWED_DESCRIPTOR.name) {
      // Only memories this caller can see here may be confirmed.
      const visible = new Set(collectEntries(memory(), userMemory, context, false).entries.map(({ memory: entry }) => entry.id));
      return result(confirmReviewed(userMemory, visible, rawInput), PROVIDER_ID, name, rawInput, context);
    }
    if (name !== DESCRIPTOR.name) throw new Error(`Unsupported memory overview capability: ${name}`);
    const input = parseInput(rawInput);
    return result(readOverview(memory(), userMemory, context, input), PROVIDER_ID, name, rawInput, context);
  });
}

interface OverviewInput {
  readonly scope?: ScopeFilter;
  readonly category?: (typeof MARSHAL_MEMORY_CATEGORIES)[number];
  readonly includeHistory: boolean;
  readonly limit: number;
}

/** Every memory entry the caller may read: the user scope, then the session's readable scopes. */
function collectEntries(
  runtime: PortableMemoryRuntime,
  userMemory: LazyUserMemory,
  context: InvocationContext,
  includeHistory: boolean,
): { entries: MemoryOverviewEntry[]; truncated: boolean; attention: ProjectionAttention[] } {
  const userScopeId = userMemory.scopeId();
  const options = { includeHistory, limit: MAX_LIMIT * 4 };
  const entries: MemoryOverviewEntry[] = [];
  const attention: ProjectionAttention[] = [];
  let truncated = false;
  const read = (handles: readonly MemoryScopeHandle[], reader: InvocationContext) => {
    if (handles.length === 0) return;
    const overview = runtime.overview(handles, reader, options);
    entries.push(...overview.entries);
    attention.push(...(overview.attention ?? []));
    truncated ||= overview.truncated;
  };
  const userHandle = userScopeId ? handleFor(runtime, userScopeId) : undefined;
  if (userHandle) read([userHandle], userMemory.context);
  read(runtime.scopes.handlesForContext(context).filter(({ scopeId }) => scopeId !== userScopeId), context);
  return { entries, truncated, attention };
}

function readOverview(
  runtime: PortableMemoryRuntime,
  userMemory: LazyUserMemory,
  context: InvocationContext,
  input: OverviewInput,
) {
  const projectId = context.scope?.projectId;
  const workspacePath = sessionWorkspacePath(context);
  const userScopeId = userMemory.scopeId();
  const selection = userScopeId
    ? userMemory.store().selectForPrompt({
        budgetBytes: DEFAULT_PROMPT_BUDGET_BYTES,
        ...(projectId ? { projectId } : {}),
        ...(workspacePath ? { workspacePath } : {}),
      })
    : undefined;
  const injected = new Set(selection?.entries.map(({ id }) => id) ?? []);
  const { entries, truncated, attention } = collectEntries(runtime, userMemory, context, input.includeHistory);
  const rows = entries
    .map((entry) => toRow(entry, userScopeId, projectId, injected))
    .filter((row) => input.scope === undefined || scopeKind(row.scope) === input.scope)
    .filter((row) => input.category === undefined || row.category === input.category)
    .sort((left, right) => right.createdAt.localeCompare(left.createdAt) || left.id.localeCompare(right.id));
  const total = rows.length;
  const shown = rows.slice(0, input.limit);
  const reasons = reviewReasons(userMemory, shown.filter(({ state }) => state === 'active').map(({ id }) => id));
  return {
    rows: shown.map((row) => ({ ...row, source: row.source ?? provenanceSource(userMemory, row.id), needsReview: reasons.get(row.id) ?? null })),
    total,
    profile: { path: userMemory.profilePath, exists: existsSync(userMemory.profilePath) },
    truncated: truncated || total > input.limit,
    attention,
    prompt: {
      budgetBytes: DEFAULT_PROMPT_BUDGET_BYTES,
      injected: selection?.entries.length ?? 0,
      omitted: selection?.omitted.count ?? 0,
    },
  };
}

function toRow(
  entry: MemoryOverviewEntry,
  userScopeId: string | undefined,
  projectId: string | undefined,
  injected: ReadonlySet<string>,
): MemoryOverviewRow {
  const { memory } = entry;
  const user = memory.scopeId === userScopeId;
  const decoded = decodeUserMemoryFactKey(memory.factKey);
  const scope = user ? 'user' : scopeLabel(entry, projectId);
  return {
    id: memory.id,
    scope,
    state: memory.state as MemoryOverviewRow['state'],
    category: decoded.category ?? null,
    createdAt: entry.createdAt,
    source: decoded.source ?? (user ? 'brain' : null),
    appliesTo: user ? memory.appliesTo ?? 'global' : scopeKind(scope) === 'project' || scopeKind(scope) === 'workspace' ? projectId ?? null : null,
    blessed: memory.blessed,
    injected: user && memory.active && injected.has(memory.id),
    backlog: entry.backlog?.operation ?? 'none',
    backlogAttempts: entry.backlog?.attempts ?? 0,
    supersedes: memory.supersedes ?? null,
    supersededBy: memory.supersededBy ?? null,
    promotedFrom: entry.promotedFrom.length > 0 ? entry.promotedFrom.join(', ') : null,
    file: memory.documentPath ?? null,
    text: memory.content.replace(/\s+/g, ' ').trim().slice(0, MAX_TEXT_CHARS),
  };
}

/**
 * Built-in project/workspace scopes: the shared (R9) project scope is `project:<projectId>` and
 * the per-checkout one `workspace`; a pre-R9 principal-keyed one (emptied by the migration,
 * visible with includeHistory) is `project:legacy` / `workspace:legacy`. An issued project
 * scope is named by its scope id.
 */
function scopeLabel(entry: MemoryOverviewEntry, projectId: string | undefined): string {
  if (entry.scopeKind !== 'project' && entry.scopeKind !== 'workspace') return entry.scopeKind;
  if (entry.builtInScope && !entry.sharedProjectScope) return `${entry.scopeKind}:legacy`;
  if (entry.scopeKind === 'workspace') return 'workspace';
  return `project:${entry.builtInScope && projectId ? projectId : entry.memory.scopeId}`;
}

function reviewReasons(userMemory: LazyUserMemory, ids: readonly string[]): ReadonlyMap<string, string> {
  try {
    return userMemory.reviews.reasons(ids);
  } catch {
    return new Map();
  }
}

/** memory.link notes: the session they were stated in (memoryProvenance.ts); null when unrecorded. */
function provenanceSource(userMemory: LazyUserMemory, memoryId: string): string | null {
  try {
    return userMemory.provenance.get(memoryId)?.source ?? null;
  } catch {
    return null;
  }
}

function scopeKind(scope: string): string {
  return scope.split(':', 1)[0] ?? scope;
}

function handleFor(runtime: PortableMemoryRuntime, scopeId: string): MemoryScopeHandle | undefined {
  const scope = runtime.scopes.get(scopeId);
  return scope ? { scopeId: scope.scopeId, policyVersion: scope.policyVersion } : undefined;
}

function sessionWorkspacePath(context: InvocationContext): string | undefined {
  const fromScope = (context.scope as { readonly workspacePath?: unknown } | undefined)?.workspacePath;
  const fromMetadata = (context.metadata as { readonly workspacePath?: unknown } | undefined)?.workspacePath;
  const value = typeof fromScope === 'string' ? fromScope : fromMetadata;
  return typeof value === 'string' && value ? value : undefined;
}

function parseInput(rawInput: unknown): OverviewInput {
  const input = rawInput === undefined || rawInput === null ? {} : rawInput;
  if (typeof input !== 'object' || Array.isArray(input)) throw new Error('Input must be an object.');
  const record = input as Readonly<Record<string, unknown>>;
  for (const key of Object.keys(record)) {
    if (!['scope', 'category', 'includeHistory', 'limit'].includes(key)) {
      throw new Error(`Unknown memory.overview input: ${key}.`);
    }
  }
  if (record.scope !== undefined && !SCOPE_FILTERS.includes(record.scope as ScopeFilter)) {
    throw new Error(`scope must be one of ${SCOPE_FILTERS.join(', ')}.`);
  }
  if (record.category !== undefined
    && !MARSHAL_MEMORY_CATEGORIES.includes(record.category as (typeof MARSHAL_MEMORY_CATEGORIES)[number])) {
    throw new Error(`category must be one of ${MARSHAL_MEMORY_CATEGORIES.join(', ')}.`);
  }
  if (record.includeHistory !== undefined && typeof record.includeHistory !== 'boolean') {
    throw new Error('includeHistory must be a boolean.');
  }
  const limit = record.limit ?? DEFAULT_LIMIT;
  if (typeof limit !== 'number' || !Number.isInteger(limit) || limit < 1 || limit > MAX_LIMIT) {
    throw new Error(`limit must be an integer from 1 to ${MAX_LIMIT}.`);
  }
  return {
    ...(record.scope === undefined ? {} : { scope: record.scope as ScopeFilter }),
    ...(record.category === undefined
      ? {}
      : { category: record.category as (typeof MARSHAL_MEMORY_CATEGORIES)[number] }),
    includeHistory: record.includeHistory === true,
    limit,
  };
}

