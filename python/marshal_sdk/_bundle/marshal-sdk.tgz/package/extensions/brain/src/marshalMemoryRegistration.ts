import type { RuntimeServiceAccessor, RuntimeServiceToken } from '@marshal/agent-runtime-composer';
import type { BrainMarshalMemoryStore } from './marshalMemoryStore.js';

/** Marshal host service (electron/active-memory-store.ts); it prefers the provider id "@marshal/brain". */
interface MemoryProviderRegistry {
  register(provider: {
    readonly id: string;
    readonly store: unknown;
  }): Promise<{ dispose(): Promise<void> }>;
}

const MEMORY_PROVIDER_REGISTRY = Symbol.for(
  '@marshal/marshal:memory-provider-registry',
) as RuntimeServiceToken<MemoryProviderRegistry>;

export const BRAIN_MEMORY_PROVIDER_ID = '@marshal/brain';
const REGISTRATION_RETRY_MS = 2_000;
const REGISTRATION_ATTEMPTS = 60;

// A live update activates the new Brain before the old one is disposed, so the
// id stays taken until the old registration releases it.
async function registerWithRetry(
  registry: MemoryProviderRegistry,
  resolveStore: () => BrainMarshalMemoryStore,
  isDisposed: () => boolean,
): Promise<{ dispose(): Promise<void> }> {
  for (let attempt = 1; ; attempt += 1) {
    try {
      return await registry.register({ id: BRAIN_MEMORY_PROVIDER_ID, store: resolveStore() });
    } catch (error) {
      const taken = error instanceof Error && error.message.includes('already registered');
      if (!taken || isDisposed() || attempt >= REGISTRATION_ATTEMPTS) throw error;
      await new Promise((resolve) => setTimeout(resolve, REGISTRATION_RETRY_MS));
    }
  }
}

/**
 * Makes the Brain the host's active memory store when the host offers the
 * registry. Hosts without it keep their own store; registration failures leave
 * the host on its local store and never block Brain activation.
 */
export function registerBrainMemoryStore(
  services: RuntimeServiceAccessor,
  resolveStore: () => BrainMarshalMemoryStore,
): { dispose(): Promise<void> } {
  const registry = services.tryGet(MEMORY_PROVIDER_REGISTRY);
  if (!registry) return { dispose: async () => undefined };
  let disposed = false;
  const registration = registerWithRetry(registry, resolveStore, () => disposed)
    .then(async (handle) => {
      if (disposed) await handle.dispose();
      return handle;
    })
    .catch(() => undefined);
  return {
    async dispose() {
      disposed = true;
      await (await registration)?.dispose();
    },
  };
}
