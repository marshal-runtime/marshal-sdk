import type {
  RuntimeExtensionActivation,
  RuntimeExtensionActivationContext,
  RuntimeExtensionServiceContribution,
  RuntimeExtensionModule,
} from '@marshal/agent-runtime-extensions';
import {
  createInstalledBrainProviders,
  MEMORY_REASONER_SERVICE,
  RUNTIME_DELEGATION_CHILD_SCOPE_LINEAGE_SERVICE,
} from './brainProviders.js';
import type { IMemoryReasoner } from '@marshal/holographic-memory';
import type { RuntimeServiceAccessor, RuntimeServiceToken } from '@marshal/agent-runtime-composer';
import type {
  RuntimeBackgroundJobHandler,
} from '@marshal/agent-runtime-core';
import {
  createJevMemoryReasoner,
  type JevAskClient,
  type LocalMemoryPrincipal,
  type MemoryBrainJobEnqueuer,
} from '@marshal/agent-runtime-provider-memory';
import type { RuntimeProvidersLifecyclePort } from './lifecycleTypes.js';
import { registerBrainMemoryStore } from './marshalMemoryRegistration.js';
import { registerAfterStartupPromotion } from './userScopePromotionStartup.js';
import { gatedJevResolver, resolveMemoryReviewGate } from './memoryReviewGate.js';
import { cloudKnowledgeSetting, KNOWLEDGE_PROVIDER_ID, withCloudKnowledge } from './cloudKnowledge.js';
import { createUnionJudge } from './unionJudge.js';
import { createDemoBrainProvider, hiddenInNoBrainWorkspaces, parseBrainRoutes, parseNoBrainWorkspaces, withNoBrainPrompt, type BrainRoute } from './demoSurface.js';
import { createRemoteOnlyKnowledgeProvider } from './cloudKnowledgeRemoteOnly.js';
import { createCloudBrainClient } from './cloudBrain/client.js';
import { hostBrokerFetchSource } from './cloudBrain/orgBroker.js';
import type { MemoryBackend } from './memoryTools.js';
import { hasExperimentalBrainRouting, isLoopbackOrWildcardHost, parseBrandRemoteConfiguration } from './brandRemote/config.js';
import { createBrandRemoteClient } from './brandRemote/client.js';
import { createBrandRemoteProvider } from './brandRemote/provider.js';
import {
  createMetadataCallerCredentialSource,
  createUserIdTokenCredentialSource,
  type CallerCredentialSource,
} from './cloudBrain/googleCredentials.js';
import { isServiceCallerMode, parseCloudRouteConfiguration } from './cloudBrain/config.js';
import { createCompanyGraphProvider } from './companyGraph/provider.js';
import { BrainTraceRecorder } from './brainTrace.js';
import { parseAnswerCardMode, type HostExecute } from './brainAnswer.js';
import { answerCardApplication } from './answerCardApp.js';

type ExtendedActivationContext = RuntimeExtensionActivationContext & {
  readonly jobManager?: MemoryBrainJobEnqueuer;
};

type ExtendedActivation = RuntimeExtensionActivation & {
  readonly lifecycle?: RuntimeProvidersLifecyclePort;
  readonly jobHandlers?: readonly RuntimeBackgroundJobHandler[];
};

export async function activate(
  context: RuntimeExtensionActivationContext,
): Promise<RuntimeExtensionActivation> {
  const extendedContext = context as ExtendedActivationContext;
  const rawConfiguration = isConfigurationRecord(context.configuration) ? context.configuration : {};
  // The frozen company graph is code that stays; the provider exists only when the configuration switches it on.
  const companyGraph = rawConfiguration.companyGraphEnabled === true ? createCompanyGraphProvider(rawConfiguration) : undefined;
  const hasExperimentalConfiguration = hasExperimentalBrainRouting(rawConfiguration);
  const experimental = hasExperimentalConfiguration
    ? parseBrandRemoteConfiguration(context.configuration)
    : undefined;
  // Org caller mode: the desktop registers a host-side broker fetch (it adds the org bearer; the extension never sees the token).
  const orgDeps = { brokerFetch: hostBrokerFetchSource((token) => context.services.tryGet(token as unknown as RuntimeServiceToken<unknown>)) };
  const delegatedCloud = parseDelegatedCloudConfiguration(context.configuration);
  // The full surface is the default: local and cloud Brain together, as every deployment before the demo surface ran it.
  // brainSurface: 'demo' is exactly the cloud Brain tools: no brand.*, no local memory capabilities.
  const demoSurface = rawConfiguration.brainSurface === 'demo' && !experimental?.headlessRemoteOnly;
  const brandRemote = !demoSurface && experimental?.brand.enabled && experimental.brand.url
    ? createBrandRemoteRoute(experimental, rawConfiguration)
    : undefined;
  const experimentalCloud = brandRemote || experimental?.headlessRemoteOnly || delegatedCloud
    ? cloudKnowledgeSetting(context.configuration, orgDeps)
    : undefined;
  if (brandRemote && experimentalCloud?.state === 'on'
    && experimentalCloud.configuration.url === experimental?.brand.url) {
    brandRemote.client.dispose();
    throw new Error('The opt-in Brand Brain and Quillstone routes must use different remote origins.');
  }

  if (experimental?.headlessRemoteOnly) {
    const cloud = experimentalCloud ?? cloudKnowledgeSetting(context.configuration, orgDeps);
    if (cloud.state !== 'on' || !isServiceCallerMode(cloud.configuration.callerMode)) {
      brandRemote?.client.dispose();
      throw new Error('headlessRemoteOnly requires cloudEnabled and cloudCallerMode="delegated" or "service-key" for Quillstone.');
    }
    const cloudOrigin = new URL(cloud.configuration.url!);
    if (cloudOrigin.protocol !== 'https:' || isLoopbackOrWildcardHost(cloudOrigin.hostname)) {
      brandRemote?.client.dispose();
      throw new Error('headlessRemoteOnly requires a remote HTTPS Quillstone endpoint.');
    }
    if (!brandRemote) {
      throw new Error('headlessRemoteOnly requires brandRemoteEnabled and brandRemoteUrl.');
    }
    return {
      capabilityProviders: [createRemoteOnlyKnowledgeProvider(cloud), brandRemote.provider, ...(companyGraph ? [companyGraph] : [])],
      dispose: async () => {
        companyGraph?.dispose();
        brandRemote.client.dispose();
      },
    };
  }

  // A configure call that cannot work (an unedited placeholder URL) must fail before anything changes, so the host keeps the running instance.
  if (demoSurface && rawConfiguration.cloudEnabled === true) parseCloudRouteConfiguration(rawConfiguration);
  const brainRoutes = demoSurface ? validatedBrainRoutes(rawConfiguration) : [];

  const selected = createSelectedReasoner(context.services);
  // The Jev extension's client spends the user's personal key: never used for memory work.
  // With review off (no dedicated key) the reasoner goes straight to the selected fallback.
  const reasoner = createJevMemoryReasoner({
    resolveJev: gatedJevResolver(resolveMemoryReviewGate(), () => context.services.tryGet(JEV_CLIENT_SERVICE)),
    resolveFallback: () => selected,
  });
  const localPrincipal = localPrincipalOf(rawConfiguration);
  const brain = createInstalledBrainProviders({
    services: context.services,
    memoryReasoner: reasoner,
    brainJobs: extendedContext.jobManager,
    ...(localPrincipal ? { localPrincipal } : {}),
    execute: (request, invocationContext) => context.execute(request, invocationContext),
  });
  // Memories sessions wrote to their own agent scopes join the user scope (and host rows
  // get blessed) before the store is registered, so the first prompt already has them.
  // The demo surface leaves the host on its own memory store (brainHostMemory true registers the Brain's): the host's
  // recall, listMemories and remember carry no workspace, so only the prompt block can be kept out of a no-Brain workspace.
  const noBrainWorkspaces = parseNoBrainWorkspaces(rawConfiguration.noBrainWorkspaces);
  const memoryRegistration = demoSurface && rawConfiguration.brainHostMemory !== true
    ? { dispose: async () => undefined }
    : await registerAfterStartupPromotion(
      () => brain.userMemory.store().promoteAgentScopes(),
      () => registerBrainMemoryStore(
        context.services,
        () => (demoSurface ? withNoBrainPrompt(brain.userMemory.store(), noBrainWorkspaces) : brain.userMemory.store()),
      ),
    );
  const cloud = experimentalCloud ?? cloudKnowledgeSetting(context.configuration, orgDeps);
  if (cloud.state === 'on') cloud.route.warmUp();
  const routedClouds = new Map(brainRoutes.map((route) => [route.name, cloudKnowledgeSetting(brainRouteConfiguration(rawConfiguration, route), orgDeps)] as const));
  const memoryBackends = new Map<string, MemoryBackend>();
  for (const route of brainRoutes) {
    const routed = routedClouds.get(route.name);
    if (route.memory !== true || routed?.state !== 'on') continue;
    const reviewCredentials = createUserIdTokenCredentialSource(credentialOptions(rawConfiguration));
    memoryBackends.set(route.name, {
      route: routed.route,
      review: createCloudBrainClient({ url: new URL(route.cloudUrl).origin, credentials: reviewCredentials, sendCaller: false }),
      reviewCredentials,
      ...(route.memoryAnchorPath ? { anchorPath: route.memoryAnchorPath } : {}),
    });
  }
  const memoryRoute = parseMemoryRoute(rawConfiguration.memoryRoute, brainRoutes);
  const answerMode = parseAnswerCardMode(rawConfiguration.answerCard);
  const execute: HostExecute = async (request, invocationContext) =>
    (await context.execute(request as never, invocationContext)) as unknown as Record<string, unknown>;
  const activation: ExtendedActivation = {
    ...(demoSurface && answerMode !== 'off' ? { uiApplications: [answerCardApplication()] } : {}),
    capabilityProviders: demoSurface
      ? [
        createDemoBrainProvider(cloud, { noBrainWorkspaces, routes: routedClouds, prefixRoutes: new Set(brainRoutes.filter((route) => route.matchPrefix === true).map((route) => route.name)), memory: memoryBackends, ...(memoryRoute ? { memoryRoute } : {}), recorder: new BrainTraceRecorder(), execute, answerMode }),
        ...(companyGraph ? [hiddenInNoBrainWorkspaces(companyGraph, noBrainWorkspaces)] : []),
      ]
      : brain.providers.map((provider) =>
        (provider.id === KNOWLEDGE_PROVIDER_ID
          ? withCloudKnowledge(provider, cloud, { judge: createUnionJudge(() => context.services.tryGet(JEV_CLIENT_SERVICE)) })
          : provider))
        .concat(brandRemote ? [brandRemote.provider] : []).concat(companyGraph ? [companyGraph] : []),
    serviceContributions: [
      bindExtensionService(
        RUNTIME_DELEGATION_CHILD_SCOPE_LINEAGE_SERVICE,
        { useValue: { persistScopeInheritance: brain.persistScopeInheritance } },
      ),
    ],
    lifecycle: brain.lifecycle,
    jobHandlers: brain.jobHandlers,
    dispose: async () => {
      companyGraph?.dispose();
      if (cloud.state === 'on') cloud.route.dispose();
      for (const routed of routedClouds.values()) if (routed.state === 'on') routed.route.dispose();
      brandRemote?.client.dispose();
      await memoryRegistration.dispose();
      await brain.dispose();
    },
  };
  return activation;
}

/** The cloud configuration of one route: the default configuration with that route's instance (the audience stays the default's unless the route sets one). */
function brainRouteConfiguration(rawConfiguration: Record<string, unknown>, route: BrainRoute): Record<string, unknown> {
  return {
    ...rawConfiguration,
    cloudEnabled: true,
    cloudUrl: route.cloudUrl,
    ...(route.cloudAudience !== undefined ? { cloudAudience: route.cloudAudience } : {}),
  };
}

/** Parses brainRoutes and checks each route's cloud configuration, so an unusable one (an unedited placeholder) refuses activation by name. */
function validatedBrainRoutes(rawConfiguration: Record<string, unknown>): readonly BrainRoute[] {
  const routes = parseBrainRoutes(rawConfiguration.brainRoutes, parseNoBrainWorkspaces(rawConfiguration.noBrainWorkspaces));
  for (const route of routes) {
    try {
      parseCloudRouteConfiguration(brainRouteConfiguration(rawConfiguration, route));
    } catch (error) {
      throw new TypeError(`brainRoutes.${route.name}: ${(error as Error).message}`);
    }
  }
  return routes;
}

function createBrandRemoteRoute(
  experimental: ReturnType<typeof parseBrandRemoteConfiguration>,
  rawConfiguration: Record<string, unknown>,
) {
  const configuration = experimental.brand;
  // Headless (runtime host): the host service account asks for the person named by the invocation's trusted claims.
  // Desktop: the signed-in person's own Google credentials.
  const callerMode = experimental.headlessRemoteOnly ? 'delegated' : 'desktop';
  const credentials: CallerCredentialSource = callerMode === 'delegated'
    ? createMetadataCallerCredentialSource(configuration.audience)
    : createUserIdTokenCredentialSource(credentialOptions(rawConfiguration));
  const client = createBrandRemoteClient(configuration, { credentials, callerMode });
  return { client, provider: createBrandRemoteProvider(client) };
}

function credentialOptions(rawConfiguration: Record<string, unknown>) {
  const file = rawConfiguration.cloudCredentialsFile;
  const expected = rawConfiguration.cloudExpectedCaller;
  return {
    ...(typeof file === 'string' && file.trim() ? { credentialsFile: file.trim() } : {}),
    ...(typeof expected === 'string' && expected.trim() ? { expectedCaller: expected.trim().toLowerCase() } : {}),
  };
}

function parseDelegatedCloudConfiguration(rawConfiguration: unknown) {
  if (!isConfigurationRecord(rawConfiguration)
    || rawConfiguration.cloudEnabled !== true
    || (rawConfiguration.cloudCallerMode !== 'delegated' && rawConfiguration.cloudCallerMode !== 'service-key')) return undefined;
  try {
    const configuration = parseCloudRouteConfiguration(rawConfiguration);
    return configuration.enabled && configuration.url ? configuration : undefined;
  } catch {
    return undefined;
  }
}

/** The desktop host's statement of who the one local reader is: `localPrincipal: {"email": "me@zyg.com"}` (or `{}` for staff alone). Anything else, or no setting, leaves a call without an access claim reading nothing. */
function localPrincipalOf(rawConfiguration: Record<string, unknown>): LocalMemoryPrincipal | undefined {
  const given = rawConfiguration.localPrincipal;
  if (!isConfigurationRecord(given)) return undefined;
  return typeof given.email === 'string' && given.email.trim() ? { email: given.email.trim() } : {};
}

function isConfigurationRecord(value: unknown): value is Record<string, unknown> {
  return Boolean(value && typeof value === 'object' && !Array.isArray(value));
}

const JEV_CLIENT_SERVICE = Symbol.for('@marshal/jev:client') as RuntimeServiceToken<JevAskClient>;

function createSelectedReasoner(services: RuntimeServiceAccessor): IMemoryReasoner {
  return {
    get descriptor() {
      return services.tryGet(MEMORY_REASONER_SERVICE)?.descriptor ?? {
        id: 'runtime-selected-memory-reasoner',
        mode: 'unavailable',
        reason: 'No selected memory reasoner service is available.',
      };
    },
    reason(request) {
      const selected = services.tryGet(MEMORY_REASONER_SERVICE);
      if (!selected) {
        throw new Error('No selected memory reasoner service is available.');
      }
      return selected.reason(request);
    },
  };
}

const extension: RuntimeExtensionModule = { activate };
export default extension;

function bindExtensionService<T>(
  token: symbol,
  binding: { readonly useValue: T },
): RuntimeExtensionServiceContribution {
  return Object.freeze({ token, binding, mode: 'bind' as const });
}

/** The route whose memory tools every workspace gets (`memoryRoute`): it must name a brainRoutes entry with memory true. */
function parseMemoryRoute(value: unknown, routes: readonly { name: string; memory?: boolean }[]): string | undefined {
  if (value === undefined) return undefined;
  if (typeof value !== 'string' || !routes.some((route) => route.name.toLowerCase() === value.toLowerCase() && route.memory === true))
    throw new Error('memoryRoute must name a brainRoutes entry that has memory true.');
  return value;
}
