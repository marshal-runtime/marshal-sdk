import type { InvocationContext } from '@marshal/agent-runtime-core';

export interface TrustedRuntimeCaller {
  /** The person the runtime host is acting for. */
  readonly callerEmail: string;
  readonly conversationId: string;
}

export class RuntimeIdentityError extends Error {
  readonly code = 'runtime_identity_rejected';

  constructor() {
    super('The runtime host did not provide a trusted caller email and conversation for this invocation.');
    this.name = 'RuntimeIdentityError';
  }
}

const EMAIL = /^[a-z0-9][a-z0-9._+-]{0,63}@[a-z0-9][a-z0-9.-]{0,127}\.[a-z]{2,24}$/;
const IDENTIFIER = /^[\x21-\x7e]{1,512}$/;

/**
 * The asking person comes only from the host-set principal claims (`callerEmail`), never from capability input. The
 * conversation is `claims.conversationId`, else the invocation's session id.
 */
export function trustedRuntimeCaller(context: InvocationContext | undefined): TrustedRuntimeCaller {
  const claims = context?.principal?.claims;
  const callerEmail = claims?.callerEmail;
  const conversationId = claims?.conversationId ?? context?.scope?.sessionId;
  if (typeof callerEmail !== 'string' || !EMAIL.test(callerEmail)
    || typeof conversationId !== 'string' || !IDENTIFIER.test(conversationId)) {
    throw new RuntimeIdentityError();
  }
  return Object.freeze({ callerEmail, conversationId });
}
