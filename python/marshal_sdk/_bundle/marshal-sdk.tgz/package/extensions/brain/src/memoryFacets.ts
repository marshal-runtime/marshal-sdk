import type { InvocationContext } from '@marshal/agent-runtime-core';
import {
  authorizedReadScope,
  memoOf,
  type DurableMemoryRecord,
  type KnowledgeAuthorizationBatch,
  type KnowledgeNodeReference,
  type PortableMemoryRuntime,
} from '@marshal/agent-runtime-provider-memory';
import { decodeUserMemoryFactKey } from './userMemoryFactKey.js';

/**
 * Adds createdAt and category to an authorized memory search hit. The index's own values (from the
 * projection's frontmatter) win; Brain's SQLite row fills in what an older projection lacks, so the
 * knowledge.search createdAfter/createdBefore window also places memories indexed before `created`.
 */
export function withMemoryFacets(
  runtime: PortableMemoryRuntime,
  node: KnowledgeNodeReference,
  entry: DurableMemoryRecord,
): KnowledgeNodeReference {
  const createdAt = node.createdAt ?? runtime.createdAtOf(entry);
  const decoded = decodeUserMemoryFactKey(entry.factKey);
  const category = node.category ?? decoded.category;
  return {
    ...node,
    ...(createdAt ? { createdAt } : {}),
    ...(category ? { category } : {}),
    // A user memory's source is in its fact key, as remember and recall show it (src:<source>).
    ...(decoded.source ? { source: decoded.source, author: 'user' as const } : {}),
  };
}

/**
 * The memory hit if the caller may read it now, in the state the index claims; otherwise null. With
 * the `batch` of the page the hit belongs to, the scope and its read grant are resolved once per
 * scope and caller for the whole page; the decisions are the same.
 */
export async function authorizeMemoryNode(
  runtime: PortableMemoryRuntime,
  node: KnowledgeNodeReference,
  context: InvocationContext,
  batch?: KnowledgeAuthorizationBatch,
): Promise<KnowledgeNodeReference | null> {
  if (!node.memoryId || !node.scope) return null;
  const memo = memoOf(batch);
  let scope;
  if (memo?.scopes.has(node.scope)) scope = memo.scopes.get(node.scope);
  else {
    scope = runtime.scopes.get(node.scope);
    memo?.scopes.set(node.scope, scope);
  }
  if (!scope) return null;
  const handle = { scopeId: scope.scopeId, policyVersion: scope.policyVersion };
  try {
    authorizedReadScope(runtime.scopes, handle, context, memo);
    const entry = runtime.get(handle, node.memoryId, context, true, memo);
    if (!entry || !knowledgeStateMatches(node.state, entry.state, entry.active)) return null;
    return node.kind === 'memory'
      ? withMemoryFacets(runtime, { ...node, name: entry.content.slice(0, 2_000) }, entry)
      : node;
  } catch (error) {
    const code = error && typeof error === 'object' && 'code' in error
      ? String((error as { code?: unknown }).code)
      : '';
    if (code === 'memory_scope_denied' || code === 'memory_scope_unavailable') return null;
    if (error instanceof Error && error.message.includes('does not exist in the authorized scope')) {
      return null;
    }
    throw error;
  }
}

function knowledgeStateMatches(
  indexedState: KnowledgeNodeReference['state'],
  state: string,
  active: boolean,
): boolean {
  if (indexedState === 'active') return state === 'active' && active;
  if (indexedState === 'superseded') return state === 'superseded' && !active;
  if (indexedState === 'archived') return state === 'archived' && !active;
  return false;
}
