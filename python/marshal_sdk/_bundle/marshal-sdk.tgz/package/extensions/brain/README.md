# Marshal Brain

`@marshal/brain` is one optional Marshal Runtime extension for scoped durable
memory and repository-aware recall. It adds Brain recall and background
remembering, direct memory operations, unified knowledge queries, and bounded
session lifecycle capture.

This repository contains the extension and three supporting libraries:

| Package | Role |
| --- | --- |
| `@marshal/brain` | [Runtime extension](runtime-extension.json), activation, lifecycle, jobs, and selected-service integration |
| [`@marshal/agent-runtime-provider-memory`](packages/agent-runtime-provider-memory/) | Runtime memory, Brain, knowledge, scope, transcript, and durable-storage providers |
| [`@marshal/holographic-memory`](packages/holographic-memory/) | Lower-level SQLite memory, search, context, reasoning, and lifecycle services |
| [`@marshal/memory-retrieval-evals`](packages/memory-retrieval-evals/) | Brain-owned retrieval benchmarks, custom corpus, retrievers, metrics, and evidence-preserving evaluation tests |

## Demo surface (`brainSurface: "demo"`)

With `brainSurface` set to `"demo"` (this repository's manifest and the Marshal desktop install do) the extension exposes seven tools (the five cloud Brain tools plus `knowledge.refine` and `knowledge.feedback`), every one answered by the cloud Brain
behind `cloudUrl` (no local index, no local memory capability, no `brand.*`; the company graph is off unless `companyGraphEnabled`):

| Tool | Cloud Brain tool |
|---|---|
| `knowledge.schema` | schema |
| `knowledge.search` | search |
| `knowledge.context` | traverse |
| `knowledge.impact` | impact |
| `knowledge.path` | path |
| `knowledge.refine` | refine (narrows the candidates of a search you already ran, by kind, path, file or origin, with no new search) |
| `knowledge.feedback` | feedback (tells the cloud Brain how a search served you, by `cloud.searchId`) |

`knowledge.search` asks for candidate cards (`format: cards`, ten hits by default): each hit carries `why`, `links`, `next` and `top`, and the `cloud` report carries `searchId`, `drill` and `facets`. The cloud connection is kept alive for 110 s (`MARSHAL_BRAIN_CLOUD_KEEPALIVE=0` turns it off) and is opened ahead of a call that follows a pause.

Ranked `knowledge.search` asks the cloud again, with a short backoff, when it fails for a reason that passes
(starting, unavailable, busy, a failed call, a timeout), until a 45 s cap; then it fails with the cloud's error code.
Auth failures and rejections are not retried.

`agentGuidance` says when to use the Brain, to call `knowledge.schema` first, that what feeds, reads or breaks goes to
`knowledge.impact` or `knowledge.path` and not to ranked search, to confirm cheap facts with git, and that the Brain is
unavailable when no `knowledge.*` tool is available.

**No-Brain workspaces.** In a workspace whose directory (or a parent) is named in `noBrainWorkspaces` (default
`["zyg-nobrain"]`, compared case-insensitively on the path segments of the session's `workspacePath`), no Brain tool is
listed, found by `runtimeSearch` or answered; an invoke fails with `brain_unavailable`. Two chats can run side by side in
one Marshal: `zyg` with the Brain and `zyg-nobrain` without. The guidance is one block for the whole extension, so it
cannot change per workspace; it states the condition instead (no `knowledge.*` tool available means no Brain).

**Memory in the no-Brain workspace.** The host's `remember`, `recall` and `listMemories` tools go to whichever memory
store is registered with the host and carry no session or workspace, so a store cannot be scoped per workspace. The demo
surface therefore leaves the host on its own store (`brainHostMemory`, default `false`): the Brain registers no memory
store, and recall, listMemories, remember and the always-on memory prompt are the host's own and the same in `zyg` and
`zyg-nobrain`. The Brain's memories then reach a chat only through `knowledge.search` and `knowledge.context` (cloud
Brain), which `zyg-nobrain` does not list. With `brainHostMemory: true` the Brain registers its store again: the memory
prompt block is emptied for a session whose `workspacePath` is a no-Brain workspace (the host passes it to
`selectForPrompt`), but recall, listMemories and remember in `zyg-nobrain` still read and write the Brain's store.
`marshal.memory.recall` is not affected: the host only returns facts stored by the same session scope.

## Switching the Brain instance (no reinstall, no restart)

`runtimeConfigureExtension` on an enabled extension reloads it in place with the new configuration: the host prepares the
new activation first, then disposes the old one, and persists the configuration (it survives a Marshal restart). A
configuration that cannot be used (an unedited placeholder, a malformed URL) is refused before anything changes, and the
running instance stays. The configuration you pass **replaces** the stored one (defaults fill the rest), so each command
below carries the whole configuration. Use a **new** `idempotencyKey` on every call: a repeated key is treated as the same
operation and is not applied again, so switching back with an old key does nothing.

Only `cloudUrl` and `cloudAudience` differ between the two instances. Ready-made copies of both configurations are in the
kit's `switch/` directory (`demo.json`, `memstage.json`).

**Switch to the frozen demo, s8b-clone:**

```
runtimeConfigureExtension {
  identity: "@marshal/brain",
  idempotencyKey: "brain-switch-demo-<HHMM>",
  configuration: {
    "cloudUrl": "https://s8b-clone---quillstone-proxy-gfgred4s6a-uc.a.run.app",
    "cloudAudience": "https://quillstone-proxy-559219955260.us-central1.run.app",
    "cloudEnabled": true,
    "cloudCallerMode": "desktop",
    "cloudCallerServiceAccount": "brain-portal@zyg-ecom-meetings.iam.gserviceaccount.com",
    "cloudSearchBudgetMs": 20000,
    "cloudEvidenceBudgetMs": 20000,
    "cloudTimeoutMs": 30000,
    "cloudMaxConcurrent": 4,
    "cloudMaxResultChars": 200000,
    "cloudMemoryWrites": false,
    "cloudKeepWarmSeconds": 0
  }
}
```

**Switch to the memory staging instance, quillstone-memstage** (replace both placeholders first; if memstage is a revision
tag of the main proxy, `cloudAudience` stays `https://quillstone-proxy-559219955260.us-central1.run.app`):

```
runtimeConfigureExtension {
  identity: "@marshal/brain",
  idempotencyKey: "brain-switch-memstage-<HHMM>",
  configuration: {
    "cloudUrl": "<MEMSTAGE_URL>",
    "cloudAudience": "<MEMSTAGE_AUDIENCE>",
    "cloudEnabled": true,
    "cloudCallerMode": "desktop",
    "cloudCallerServiceAccount": "brain-portal@zyg-ecom-meetings.iam.gserviceaccount.com",
    "cloudSearchBudgetMs": 20000,
    "cloudEvidenceBudgetMs": 20000,
    "cloudTimeoutMs": 30000,
    "cloudMaxConcurrent": 4,
    "cloudMaxResultChars": 200000,
    "cloudMemoryWrites": false,
    "cloudKeepWarmSeconds": 0
  }
}
```

After a switch, the first Brain call can take 6 to 14 s (cold start); a wrong but well-formed URL is only detected by a
call, so run `knowledge.schema` once. `runtimeListExtensions` shows the stored `cloudUrl`. Keys not listed (`brainSurface`,
`noBrainWorkspaces`, `brainHostMemory`) come from the manifest defaults.

### Three workspaces at once: `brainRoutes`

`brainRoutes` (demo surface only) maps a workspace directory name to its own Brain instance, the same way `noBrainWorkspaces`
maps a name to no Brain. A session whose workspace path has a directory of that name (case-insensitive, the deepest match wins)
is answered by that instance; every other workspace uses `cloudUrl`. A no-Brain name always wins and cannot also be a route.
Each route has `cloudUrl` and optionally `cloudAudience` (default: the default `cloudAudience`); the caller, budgets and
service account are the default configuration's. The tools are the same seven.

A route with `"matchPrefix": true` also matches a directory `<name>-<suffix>`, such as a worktree `zygstinct-3e20e278`. An exact directory
name always wins over a prefix (even a deeper one), the longest prefix wins, and the hyphen is required, so `zyg` never matches
`zygstinct`. Routes without the flag match exact names only.

A key of the form `ws:<id>` (for example `"ws:zyg"`, matching `^ws:[a-z0-9][a-z0-9-]{0,62}$`; any other `ws:` key is refused at config
load) routes by org workspace id. When Marshal desktop's `org.workspaces` flag is on and the local workspace is linked, it passes
the invocation metadata `marshalOrgWorkspaceId` next to `marshalWorkspaceName`; a session whose id equals a `ws:` key uses that
route, ahead of every directory-name route. An unknown id, or no id at all, falls back to the directory-name match above, so
without the metadata routing is unchanged. Directory-name keys cannot contain `:`, so the two never collide.

| Workspace | Brain |
|---|---|
| `zyg-brain` | default `cloudUrl` (frozen demo, s8b-clone) |
| `zyg-memory` | `brainRoutes["zyg-memory"]` (memory staging) |
| `zyg-nobrain` | none |

All three work at the same time in one Marshal, with no switching. `switch/three-workspaces.json` is the demo configuration
plus the route; until the memstage URL exists the placeholders are refused (activation fails by route name, the running
instance stays), and `switch/demo.json` leaves `zyg-memory` on the demo instance.

```
runtimeConfigureExtension {
  identity: "@marshal/brain",
  idempotencyKey: "brain-routes-<HHMM>",
  configuration: {
    "cloudUrl": "https://s8b-clone---quillstone-proxy-gfgred4s6a-uc.a.run.app",
    "cloudAudience": "https://quillstone-proxy-559219955260.us-central1.run.app",
    "cloudEnabled": true,
    "cloudCallerMode": "desktop",
    "cloudCallerServiceAccount": "brain-portal@zyg-ecom-meetings.iam.gserviceaccount.com",
    "cloudSearchBudgetMs": 20000,
    "cloudEvidenceBudgetMs": 20000,
    "cloudTimeoutMs": 30000,
    "cloudMaxConcurrent": 4,
    "cloudMaxResultChars": 200000,
    "cloudMemoryWrites": false,
    "cloudKeepWarmSeconds": 0,
    "brainRoutes": {
      "zyg-memory": {
        "cloudUrl": "<MEMSTAGE_URL>",
        "cloudAudience": "<MEMSTAGE_AUDIENCE>",
        "memory": true,
        "memoryAnchorPath": "<MEMSTAGE_ANCHOR_FILE>"
      }
    }
  }
}
```

A route whose instance cannot be used leaves its workspace with no Brain; it never falls back to the default instance.

### Memory tools in the routed workspace

A route with `"memory": true` adds the memory tools to that route's workspaces and to no other: `zyg-brain`, `zyg-nobrain` and
every workspace on the default instance never list them and refuse a call to them (`brain_unavailable`).

**Graph memory (default).** Memories are nodes of the company Brain graph (typed-graph store `zyg/org`, partition
`@memory`), written at once, with no approval:

| Capability | Brain tool | Output |
| --- | --- | --- |
| `memory.create {content, category?, scope?, alwaysOn?, links?, supersedes?, sessionId?, audience?, key?, id?, createdAt?}` | `memory_create` | `{memory}` |
| `memory.update {id, scopes?, content?, category?, alwaysOn?, links?}` | `memory_update` | `{memory}` |
| `memory.link {id, scopes?, links}` | `memory_add_links` | `{memory}` |
| `memory.delete {id, scopes?}` | `memory_delete` | `{deleted}` |
| `memory.search {query, scopes?, limit?, category?}` | `memory_search` | `{memories, mode}` |
| `memory.list {scope?, scopePrefix?, alwaysOn?, since?, category?, limit?, offset?}` | `memory_list` | `{memories, mode, nextOffset?}` (200 a page) |

Calls go with the signed-in person's Google credentials, so the server records them as author; without user credentials they
go through the route's service account. The server derives the author itself (an `author` input is dropped). Search is
company-wide whatever `scopes` says; `audience: "me"` keeps a memory to its author, and so does a person scope
(`person:email=<you>` and the project scopes under it) unless `audience: "team"`; only that person writes it.
`memory.list {scopePrefix}` lists a scope and every scope under it. A migration passes `id` (the node id it
chooses, e.g. `desktop:<uuid>`) or `key` (the server derives the id): a create whose memory exists returns it unchanged. `memory.propose` writes the same way
(`memory_create`) and answers `approval_state: "approved"`. The approval flow below stays in code behind the memory
backend's `graph: false` (no route setting turns it on).

**Two homes (`memoryRoute` set).** Every workspace except a no-Brain one gets the memory tools, and a memory lives in one of
two homes (`home` input and output field):

| Home | Where | Scope written when none is named | Read in |
| --- | --- | --- | --- |
| `personal` | the `memoryRoute` Brain (the default, e.g. `zyg`) | `person:email=<signed-in person>`, private | every workspace |
| `workspace`, the workspace has its own route with `memory: true` (or is the `memoryRoute` workspace itself) | that route's Brain, the one that indexes the workspace's code, so a path link resolves to its code node | `workspace:<route name>` | that workspace |
| `workspace`, the workspace has no memory route | the `memoryRoute` Brain | `workspace:<route or directory name>` | that workspace |

- A scope the caller names is kept as given in either Brain, so one `scopePrefix` finds a workspace's memories wherever they landed.
- `memory.create` without `home`: a `person:` scope or `category: "preference"` is personal; a `workspace` or `workspace:...` scope is workspace;
  anything else is workspace when the workspace has a Brain of its own, otherwise personal. A personal memory with no scope
  needs the person's Google user credentials (`memory_needs_person` otherwise), so it is never written as the service account.
- `memory.search` reads both homes and merges them by rank (the workspace's first at each rank, each memory once);
  `memory.list` merges newest first, and a `scope`/`scopePrefix` reads only the home its family names (`person:` personal, `workspace`/`workspace:` workspace). `home` on any call uses that home only. `nextOffset` applies to
  each home. When one home fails the answer holds the other and names the failed one in `degraded`; both failing is an error.
  With both homes in one Brain (a workspace with no route) it is one call, and each memory's `home` comes from its scope.
- `memory.update`, `memory.link` and `memory.delete` by id look in the workspace Brain first and then the default one, moving
  on only when the first answers `not-found` (`CloudBrainError.toolStatus`); `home` names the one to use.
- `memory.propose` writes a workspace memory. `memory.review` stays on the default Brain.
- Set `memory: true` only on a route whose Brain serves graph memory (`memory_create`): a workspace memory there fails
  otherwise, it never falls back to the default Brain.

Without `memoryRoute` there is one home: each memory route's own workspaces get the tools and every call passes through
unchanged.

**Approval flow (`graph: false`).**

- `memory.propose {content, links?, key?, audience?, source?}` calls the server's `memory_link` with `state: "proposed"`. The
  memory is stored as a candidate only its proposer sees; it is not searchable until approved. The server records the caller
  service account as proposer, so Marshal also sends the signed-in person (from their Google user credentials) as
  `speaker {kind: "human", id, relayedBy: "marshal-agent"}` with `trust: "human-relayed"`; without user credentials it still
  proposes, as the service account only. `links` name indexed repository files (the server requires at least one; an unknown
  path answers `unresolved-link`). With no `links`, the route's `memoryAnchorPath` is used; set it to a file that exists in
  the memory instance's index (`<MEMSTAGE_ANCHOR_FILE>` is a placeholder), or the agent must name a file.
- `memory.review {action, key?, userSaid?, reason?}`: `list` returns the pending proposals (`memory_review_queue {proposed: true}`);
  `approve` and `reject` call `memory_review {key, outcome}`. Both need `userSaid`, the user's own words from the chat, and are
  refused without it. The tool description and the guidance tell the agent never to decide on its own.
- **Who can approve.** The server accepts approve and reject only from a person on its approvers list, using that person's own
  Google ID token. The service account can propose but cannot approve. Review calls therefore use the signed-in person's Google
  user credentials (`gcloud auth application-default login`, or `cloudCredentialsFile`), never the service account. If those
  are missing or the person is not an approver, the call fails with the server's reason.
- Needs on the server: `QUILLSTONE_MEMORY_APPROVAL=1` and `QUILLSTONE_MEMORY_APPROVERS` listing the approvers, built from
  `brain/memory-approval` (commit 95500b23 or later, so approving a service-account proposal works on the real runtime).
- Read-back: a proposal is hidden from search for everyone but its proposer, and the service account never finds it in search.
  Read it with `memory.review {action: "list"}`; after approval it appears in `knowledge.search`.

**Install order.** The stored configuration of build 6b7cd656 still holds `companyGraphDir` and `companyGraphFreezeSha`,
which this package's schema no longer allows, so `runtimeUpdateExtension` refuses it until they are gone. Run the demo
switch above once on the running build first (its schema accepts it), then `runtimeUpdateExtension`.

`brainSurface: "full"` (the code default when the key is absent) is the local plus cloud surface (`memory.*`, local `knowledge.*`, opt-in `brand.*`).
**Company graph.** The frozen company graph provider and its `graph.*` capabilities exist again but are created only when `companyGraphEnabled` is
true (default false). They read a frozen graph from `companyGraphDir`, verified against `companyGraphFreezeSha`. The demo-line removal of the
graph is archived at git branch `archive/company-graph`.

## Release bundle (single-file build)

`pnpm run build:extension` writes `release/extension.cjs`, the one-file bundle hosts that vendor Brain
(for example zyg-agents' `vendor/brain-extension`) load. It aliases `node:fs` to `src/nodeFs.ts`, the two
workspace packages to their sources, the code-intelligence package to the pinned runtime's
`dist/knowledge.js` (run `pnpm pin:runtime` first so `.runtime-pin/` exists) and
`@quillstone/marshal-memory-bridge` to `tools/shims/access.mjs`. `pnpm run build` uses the same aliases for `dist/extension.cjs` and `dist/index.*` (a plain build cannot bundle the Quillstone bridge at the current runtime pin), so `dist/extension.cjs` equals `release/extension.cjs` byte for byte; `tools/assert-runtime-pin.mjs` counts `tools/shims` as Brain's own source. A release is a `brain-vX.Y.Z` tag plus
`extension.cjs`, `runtime-extension.json` and a `SHA256SUMS` file attached to the GitHub release.

The runtime-side half of the page-wide memory authorization (`prime`, the batch argument and the search stage
marks in `agent-runtime-code-intelligence`'s `knowledge.ts`) is part of the pinned runtime from 4a49e39 on, so the
bundle needs no runtime patch. Against an older runtime pin Brain still works and authorizes hit by hit.

The pin's archives at 4a49e39 are the ones zyg-agents vendors under `vendor/runtime`; the pack set's own `manifest.json`
was not available when the pin was taken, so `tools/runtime-pin.json` has no `manifestSha256`.

## Requirements

- Node.js 24.14 or newer
- pnpm 10.32.1
- An accepted Marshal Runtime distribution providing
  `@marshal/agent-runtime-host:context` and
  `@marshal/agent-runtime-code-intelligence:service`
- The declared `@marshal/*` package dependencies from that release workspace or
  registry

This checkout is not standalone package-install proof. Do not assume its
unpublished dependencies can be resolved from a fresh clone.

## Build and enable

Place the checkout in Runtime's ignored extension directory:

```text
<runtime-root>\extensions\memory
```

After the accepted Runtime workspace or release registry has supplied the
declared dependencies, build all three packages:

```powershell
Set-Location <runtime-root>\extensions\memory
pnpm build
```

The root build emits `dist\index.mjs`, `dist\index.cjs`, and the CommonJS
extension entrypoint `dist\extension.cjs`.

The bundles inline runtime code (`@marshal/agent-runtime-core`,
`@marshal/agent-runtime-delegation`, `@marshal/runtime` and
`@marshal/agent-runtime-provider-kit`), so every `@marshal` runtime package
Brain links is pinned to the host's runtime pack set: `tools/runtime-pin.json`
names each archive and its sha256 (currently marshal-host-46, runtime source
628fd2d). Before building, link them:

```powershell
pnpm pin:runtime [<path>\.marshal-runtime-packs\archives]
```

This checks each archive's sha256 and extracts it into `.runtime-pin\` (ignored
by git). The build then fails (`tools/assert-runtime-pin.mjs`) if a pinned
package is not linked or its files changed, if a bundle inlines anything other
than Brain's own source and the pinned packages (from the build's esbuild
metafiles), or if the provider-kit lacks `purgeResults`, `resultRetentionMs` or
the purge epoch. A Brain that still runs on an older kit warns on each complete
forget and marks its daily heal line `lifecycleResultsPurge: "unavailable"`.
Refresh extension discovery, select
`@marshal/brain`, then explicitly install and enable it in the host. Discovery
only creates a catalog candidate; cloning or building does not execute
extension code.

## Use

Invoke `memory.brain.recall` for a repository or history question with:

```json
{
  "content": "Why does this project keep refresh tokens separate from access tokens?"
}
```

Use `memory.brain.remember` for an accepted durable fact, preference, decision,
or reusable discovery. Remembering is accepted as a background job; recall is
synchronous. For direct operations, use:

- `memory.search`, `memory.get`, `memory.correct`, `memory.delete`, and
  separately authorized `memory.purge`;
- `knowledge.search`, `knowledge.context`, `knowledge.impact`,
  `knowledge.detect_changes`, and `knowledge.status`.

Direct memory and Brain use the same durable memory runtime and host-issued
scope authority. Built-in durable scopes cover agent, workspace, and project;
session and run scopes are ephemeral. In the installed Brain the agent scope is
one shared user scope (`marshal-user-memory`): `scope: "agent"` from any session
reaches the same memories as the host's `remember`, `recall` and prompt. At
activation Brain promotes, once, active memories that sessions had written to
their own agent scopes into that user scope. Reads never change a memory, and
`knowledge.search`, `knowledge.context` and `knowledge.impact` accept
`includeHistory: true` to show superseded revisions. Corrections preserve
supersession lineage, deletion is reversible, and purge is a distinct high-risk
operation.

## Cloud Brain route

Brain can also read a remote Brain (for zyg, the cloud Brain behind the Quillstone proxy: pull requests, Linear
tickets, meetings, people, company memories and main-branch code). It is off by default; turning it on is one
configuration key and re-activates Brain without a restart:

```text
runtimeConfigureExtension {identity: "@marshal/brain", configuration: {cloudEnabled: true}}
```

With it on, `knowledge.search` asks the local index and the cloud at once. Every hit carries `source: "local"` or
`source: "cloud"` (cloud node ids start with `cloud:`), local and cloud hits alternate up to `limit`, and the cloud
copy of code the local index already returned is folded into that local hit (`cloudDuplicate`) and counted in
`cloud.duplicates`, never dropped silently; when every cloud hit repeats local code, the best one is listed as its own
`cloud` hit, so a search that reached the cloud never shows local hits alone. The answer has a `cloud` report: `ok`, `partial`,
`skipped` (`cloud: false`, or a `createdAfter`/`createdBefore` memory window), or why cloud hits are missing
(`timeout`, `starting`, `unavailable`, `busy`, `auth_failed`, `rejected`, `cancelled`, `failed`, `misconfigured`).
The cloud gets `cloudSearchBudgetMs` (30 s by default; a ranked search takes 1 to 25 s, and the first call after a quiet spell can answer `starting` while the caller's runtime boots, about 90 s)
from the start of the search, so local hits never wait longer. A search the cloud answers alone starts the local index
only after 2 s or on a cloud failure, so a slow cloud falls back to local hits that are already mostly computed.
The cloud Brain speaks seven tools: `search`, `traverse`, `impact`, `path`, `schema`, `refine` and `feedback`; the route calls nothing else.
`knowledge.search` is its `search` (an exact key, `#number`, URL or email ranks that node first); `kinds` and
`entityTypes` become a `kind` filter. A question that names a pull request (`#13901`), a ticket (`INF-5554`) or an
`@person`, or asks who or what changed, puts two cloud hits before each local one. A degraded lane makes the search
`partial`. If the local index fails and the cloud answered, the cloud hits come back with the local failure in
`routeFailures`. `cloud: "only"` searches the cloud alone (up to 20 hits, under `cloudTimeoutMs`, a failure thrown as
its coded error); `entityTypes` implies it. `scopeIds`, `scopeHops` and `scopeMatch` are refused: walk from a node
with `knowledge.context` instead.

`knowledge.context` and `knowledge.impact` send a `cloud:` id (or `source: "cloud"` or a code path or symbol) to the
cloud and return its answer in `result`, under `cloudTimeoutMs`. `knowledge.context` is `traverse` (neighbours, `maxDepth`
1 to 3, `since` as an `updatedAt` filter); `knowledge.impact` is `impact` (`inbound` is downstream, `outbound` upstream,
`both` both; `edgeTypes` are its `edges`). A code target with a path and a symbol is resolved to the symbol's id when
the cloud lists exactly one, else the file stands for it.

The cloud tools' own options pass through as given. `knowledge.search` takes `mode` (`ranked` or `exhaustive`),
`filters` (`[{field, op, value}]`; ops `eq`, `in`, `prefix`, `contains`, `range`, `exists`, `not_exists`, `matches`, `any`;
`edge:<kind>:in|out|both` filters by relation), `aggregate {count, groupBy}`, `sort`, `cursor`, `granularity` and
`group`, and `query` becomes optional. A plain ranked query (a `query`, `limit`, `kinds`) keeps the local and cloud merge.
With any of those options, or no query, the cloud's `search` is asked as given, never merged with local hits, and its
whole answer (`results`, `total`, `counts`, `cursor`) is in `result` (node ids carry the `cloud:` prefix), with `hits`
empty; `limit` is then the page size, up to 500. `createdAfter`/`createdBefore` and `cloud: false` are refused there.
Example, tickets completed in a two-minute window (21 on the live index): `{mode: "exhaustive", filters: [{field: "kind",
op: "eq", value: "ticket"}, {field: "state_type", op: "eq", value: "completed"}, {field: "completedAt", op: "range",
value: {gte: "2026-10-01T11:04:00Z", lte: "2026-10-01T11:06:00Z"}}]}`; add `aggregate: {count: true, groupBy: "team"}` for
counts. `knowledge.context` also takes `targets` (more start nodes), `match`, `edges` (`[{kind, direction}]`), `filters`
and `walkFilters`; `knowledge.impact` takes `edges`, `filters` and `cursor`. A cloud answer is also mapped into the declared fields, with `result` kept whole: `target` from `from[0]` (traverse) or
`target` (impact), `nodes` from `levels[].nodes` or `nodes` (other kinds are `entity` with `entityKind`; `fields` holds
`depth`, `via`, `props`, `edgeCounts`), and `paths` from each node's `chain` or `via` edge (up to 100 of each, with
`truncated` set when a list was cut). Traverse `edges` may be plain kind strings (both directions) or `{kind, direction}`.
These go to the cloud only: on a local target
they are refused, and a cloud failure is raised, never answered from the local index. The live schema's `aggregate` has
`count` and `groupBy` only.
Memory index leases are shared. The runtime allows one extension-owned index lease per owner id, so two chats on one
workspace (or two Brain lifetimes on one runtime) used to fail the second with "already has an active lease" and fall
back to file reads. Holders of one owner id with the same roots now share one lease, released when the last holder
disposes; a lease held with other roots is waited for (up to 5 s) before the error is raised. The cloud-only
capabilities (`knowledge.path`, `knowledge.schema`, `memory.cloud_search`, exhaustive and aggregate `knowledge.search`,
`knowledge.context`/`knowledge.impact` on a `cloud:` id) never call the local provider, so they never take a lease.
A replaced lifetime gives every lease back: dispose runs every step and frees the leases last even if an earlier step
fails, a failed earlier open no longer makes dispose throw, and a call that arrives after dispose fails instead of
opening a bundle nobody will dispose. Limit: a lease stranded by a lifetime older than the shared-lease build stays held
by that process until Marshal restarts; installing a new build does not clear it.
A lease the runtime refuses no longer fails the bundle. After a 1.5 s wait Brain serves the workspace without that
memory index (cloud search, memory reads and writes, `memory.overview` keep working), logs `[brain] memory index lease
held elsewhere` once with the likely holder, asks for the lease again every 30 s, and `knowledge.search` results carry
`localMemory: {status: 'skipped', skipped, reason, since}` while it is skipped. The local fallback of a ranked search
then comes from the workspace code index alone.
A ranked search whose cloud misses `cloudSearchBudgetMs` returns the local hits when there are any (and cancels the
cloud call). When the local fallback is unavailable, fails or has no hits, the cloud call is not cancelled: the search
keeps waiting for it up to 45 s (or the budget, if larger) and fails with the cloud's timeout only then.
A cloud that fails fast (starting, unavailable, busy, a failed call) while the local fallback cannot answer is asked
again, with a short backoff, until the same cap; the call then fails with the cloud's error code, never with the local
index's ("code index is uninitialized" and the like), which is only named as context. A cloud answer that came while the
local search had failed carries `localMemory: {status: 'skipped', skipped: ['local index'], reason}`. An uninitialized
local index therefore never fails a ranked search that the cloud can answer. Auth failures, rejections and
cancellations are not retried.

At activation the cloud route warms itself in the background: it mints the ID token and makes one cheap `schema` call
(logged as `[brain] cloud warm-up` with status and milliseconds). It never delays or fails activation, does nothing in
delegated mode, and concurrent first requests share that one token mint.
The cloud Brain goes cold after about 15 s without a call (measured: a `schema` call takes 0.5 s within 10 s of the
last one, 5.5 to 6.5 s after 20 s or more), whichever chat or bundle makes the call. `cloudKeepWarmSeconds` (default 0,
off; 5 to 120) sends one `schema` call per that interval while the route is in use (no real call for 10 minutes stops
it), skipping an interval in which any call happened or one is in flight.
Runbook limit: the cold start after about 15 s idle is the cloud Brain's, not this extension's, and the remote is not changed
for it; `cloudKeepWarmSeconds` stays off unless an operator turns it on. The first call after a quiet moment takes about
6 s longer.

Scripts: a `runtimeExecuteTypeScript` call that runs past 30 s is moved to the background, and neither its wake message
nor `inspectRunningTool` returns more than the first 4000 characters of its result (a Marshal host limit). Run several
queries with `Promise.all` in one script, and for a script that may run long write the full result to a file and
return a short summary plus the path.
Runbook limits (as of the `220eda6` install, frozen; none is fixed by installing a newer Brain build):

- A cloud outage longer than about 45 s (seen during a clone slot release switch) fails ranked search with
  `cloud_brain_timeout` after the 45 s cap, even when the local index cannot answer; the retry rides out blips of a few
  seconds, not a switch. Retry the call once the tag is back.

- A memory index lease stranded by a Brain lifetime older than the shared-lease build (before `c142154`) stays held by
  the Marshal process until Marshal restarts; an install does not clear it. Brain serves that workspace without the
  skipped index (cloud search, memory reads and writes, `memory.overview`; `knowledge.search` results carry
  `localMemory.status: 'skipped'`) and re-asks every 30 s. For the D-demo workspace (owner `a500f1ce...`) the holder was
  not proven; only a restart is known to clear it.
- The cloud Brain goes cold after about 15 s without a call: the first call after that takes about 6 s longer, whichever
  chat makes it. This is server side and the remote is not changed for it. `cloudKeepWarmSeconds` is off (0) and stays off.
- Under load (many chats, other evals on the same cloud or Mac) a ranked search takes 10 to 30 s. When the local fallback
  cannot answer, it waits for the cloud up to 45 s before failing with the cloud's timeout.
- The Marshal host moves a `runtimeExecuteTypeScript` call that runs past 30 s to the background and returns only the
  first 4000 characters of its result through `inspectRunningTool` and the wake message; the full result is lost. Brain's
  guidance tells agents to write full results to a file and return a summary plus path. The core fix is a patch, not
  installed (it needs a Marshal restart): `verification/zyg-agents-demo/brain/implementation/core-patch-background-result/inspectRunningTool-keep-full-result.patch`
  (changes `electron/external-operations/adapters/background-tool-adapter.ts` and its test).

Three capabilities exist only while the route is on, each one cloud tool:

| Capability | Cloud tool | What it answers |
| --- | --- | --- |
| `knowledge.path {from, to}` | `path` | The shortest paths between two cloud nodes (`cloud:` ids or refs) |
| `knowledge.schema {kind?}` | `schema` | Node kinds, fields, edge kinds and impact directions, filter operators, index generation |
| `memory.cloud_search {content}` | `search` | Company memories in the cloud Brain (a search filtered to kind `memory`) |

Beside those, the full surface keeps these capabilities, each one a tool the Quillstone service serves:

| Capability | Cloud tool | What it answers |
| --- | --- | --- |
| `knowledge.cloud_status {}` | `schema` | The cloud index (indexed commit and time, node counts, limits); a down or starting cloud is the answer, not an error |
| `memory.cloud_get {id}` | `memory_get` | One cloud memory |
| `memory.cloud_history {key}` | `memory_history` | Every revision of one cloud memory |
| `memory.cloud_link`, `memory.cloud_retire` | `memory_link`, `memory_retire` | Cloud memory writes (audience pinned to the caller); off unless `cloudMemoryWrites` is true |
| `sessions.cloud_search {query, workspace?, since?, until?, limit?}` | `session_search` | Sessions shared to the team Brain (Marshal shares and zyg-agents runs); also on the demo surface |
| `sessions.cloud_share {session, access}`, `sessions.cloud_unshare {sessionId}` | `session_ingest`, `session_unshare` | Share or stop sharing one session; called by Marshal's "Share to team Brain" menu action, write permission, not gated by `cloudMemoryWrites`; also on the demo surface |

The `brainSurface: "demo"` surface offers none of these; it is the five tools plus `knowledge.refine` and `knowledge.feedback`.

**Surfaces and defaults.** The code default of `brainSurface` is `full` (local and cloud Brain together, brand and the memory capabilities), so a host whose manifest has no `brainSurface` key, such as the zyg-agents vendored copy, runs as it always did. This repository's manifest sets `brainSurface` to `demo` for the Marshal desktop install, which also sets it explicitly. The frozen company graph (`graph.*`) is created only when `companyGraphEnabled` is true (default false); add `graph.` to `contributes.capabilities` when enabling it.

They declare the permission `knowledge.cloud.read`: the host accepts `knowledge.read` only for `knowledge.search`,
`knowledge.context` and `knowledge.status`. A routed or cloud-only call that fails throws a coded `cloud_brain_*`
error. The cloud has no memory write tool, so there are no cloud memory writes; `cloudMemoryWrites` is accepted and
ignored.

Desktop calls are made as the signed-in person: their Google user credentials (gcloud's application default
credentials by default; service account keys are refused) give an access token, Google's tokeninfo names their
verified email, and the access token mints an ID token of `cloudCallerServiceAccount` for the proxy. The email goes in
`x-brain-caller` and the cloud filters by it. Tokens live in memory only; nothing from the cloud is cached. Other keys:
`cloudUrl`, `cloudAudience` (the ID token's audience when `cloudUrl` is not the proxy's own URL, such as a Cloud Run
revision tag: set `cloudUrl` to the tag and `cloudAudience` to the main proxy URL), `cloudCredentialsFile`,
`cloudExpectedCaller`, `cloudMaxConcurrent` (2), `cloudMaxResultChars` and `cloudKeepWarmSeconds` (0).

The experimental runtime-host route is separately opt-in. Set `cloudCallerMode: "delegated"` for a process that runs
as a service (the Marshal runtime host on Cloud Run). It signs requests with the host service account's own ID token for
the service URL, read from the metadata server, and takes the asking person only from the invocation's trusted
principal claims: `callerEmail` (lower case) and `conversationId` (else the session id). Nothing in capability input
can name the caller, and a conversation is pinned to its first caller. For an explicitly headless deployment, also set
`headlessRemoteOnly: true`; this requires the delegated Quillstone route and an enabled Brand route, skips local Brain
providers, and never falls back to local knowledge when a remote call fails. The remote Runtime bootstrap must also set
its host config `codeIntelligence: false` before `startRuntimeSession` to keep the built-in local code index from
starting. When headless mode is off, the existing local-plus-cloud engineering route remains in place.

Stripes Brand Brain is a separate, default-off remote provider that serves `brand_*` MCP tools (search, context, impact,
paths, timeline, recipes, run, benchmark, entity_story) at `${brandRemoteUrl}/mcp`. Set `brandRemoteEnabled: true` and
`brandRemoteUrl: "https://<brand-brain-origin>"`; the extension lists the tools as `brand.*` capabilities using the
schemas the service publishes, so it duplicates none. `brandRemoteAudience` is optional and defaults to the URL origin.
There is one login scheme per mode and no service-account impersonation:

- Desktop: the signed-in person's own Google ID token, from the same `authorized_user` credentials file as the cloud
  route (`cloudCredentialsFile`, `cloudExpectedCaller`). Google cannot mint a user token for a custom audience, so the
  token's `aud` is the gcloud OAuth client id and the service accepts that audience for allow-listed staff. The
  token's verified email is the caller.
- Headless (`headlessRemoteOnly`): the host service account's metadata-server ID token for the Brand Brain URL, plus
  `x-marshal-caller-email` and `x-marshal-conversation-id` from the trusted claims.

Engineering remains on `knowledge.*`/`memory.*`; use `brand.*` only for Stripes brand data. `brand.memory_propose` is
not exposed. Brand remote calls use bounded `brandRemoteTimeoutMs` (30 s by default) and `brandRemoteMaxConcurrent` (2);
with Brand disabled, the provider makes no remote calls and does not change the runtime capability list.

## First use and intelligence

Runtime owns Quillstone configuration, embeddings, repository-index
maintenance, and the selected intelligence service. Semantic Brain reasoning
also requires a selected service registered at
`Symbol.for('@marshal/brain:memory-reasoner')` that implements the portable
`IMemoryReasoner` contract from `@marshal/holographic-memory`. Generic Runtime
does not ship a reasoning model. Without a selected reasoner, Brain reports an
honest degraded, abstained result while direct memory capabilities remain
available.

Brain resolves the selected reasoner and intelligence service at call time, uses
`forContext()` for the current host-authoritative workspace, and owns only
bounded project/profile memory-index leases.

When the optional `@marshal/jev:client` service (from `@marshal/jev`) is
active, Brain uses the Jev memory reasoner (`createJevMemoryReasoner`) in front
of the selected reasoner. Recall, remember, and observe then finish in one round:
Brain's own search tools run with the request text as the query, and one batched
Jev call per decision point rates candidates, gates observed turns, picks the
durable sentence, chooses scope and type, and classifies the relation to existing
memories (duplicate, supersedes, complements, unrelated). Stored content is
extractive, so no text is generated. Reflect, and any request where Jev fails
before a write, falls back to the selected reasoner. Jev receives memory text and
code references as request state, so enable it only where sending that content
to TypeSafe is acceptable.

If a Brain operation finds the current workspace index uninitialized, it
actively invokes `knowledge.workspace.ensure` with:

```json
{
  "mode": "create-if-missing"
}
```

The actual Runtime approval decision is propagated, including its approval ID,
reason, prompt, and expiry when supplied. After approval, accepted or running
initialization is returned as a degraded, abstained Brain result with the real
job status. Retry the original Brain call after that job completes. Brain does
not autoapprove, wait for a person, or automatically retry the call. Remote
workspace initialization and desktop-specific approval UI are not provided by
this extension.

## Lifecycle and storage

Normal extension activation returns its capability providers, lifecycle
delegate, and Memory Brain job handler. Runtime's job manager is used for
durable remember, reflection, recovery, and sealed-session review. The existing
durable lifecycle wrapper remains responsible for normalized event receipts.

Lifecycle handling records bounded deterministic turn evidence and queues one
idempotent review when a session is sealed. It does not globally capture
applications or run semantic Brain reasoning on every turn.

Durable memory is Markdown-authoritative with SQLite as a rebuildable cache;
session/run memory uses SQLite as temporary authority. Memory data and
projections live under host-selected protected Runtime roots, not silently in
the repository. Backup, WAL, snapshot, log, and external-provider retention
remain host responsibilities.

With default intelligence paths, the derived native project and profile indexes
live below
`<protectedLifecycleResultRoot>/bq/<24-character-profile-digest>/p-<24-character-project-digest>`
and the corresponding `u-<24-character-project-digest>` directory. Memory
SQLite and projection paths are unchanged, and a custom intelligence
`profileDataRoot` remains authoritative for these indexes. Existing derived
indexes at the previous default location are left untouched and rebuilt at the
new location; there is no silent migration.

On Windows, the native store permits a database path up to 244 characters so
its `.wal.checkpoint` path remains within the 259-character guard. Hosts with a
long protected root can configure a shorter absolute intelligence
`profileDataRoot`.

## Public API

The root package exports `activate()`, `createBrainProviders()`,
`createInstalledBrainProviders()`, `createBrainSource()`,
`createRuntimeMemoryLifecycle()`, `MEMORY_REASONER_SERVICE`,
`RUNTIME_DELEGATION_CHILD_SCOPE_LINEAGE_SERVICE`, the Runtime host/intelligence tokens,
lifecycle types, and `BRAIN_PACKAGE_DECLARATION`. Activation also contributes
the generic delegation child-scope-lineage service dynamically; it resolves the
active workspace bundle before persisting inherited durable memory scope through
`persistScopeInheritance(parentInvocation, childThreadId)`.

`@marshal/brain/lifecycle-runtime` exposes the same public root bundle for
hosts using the explicit memory lifecycle composition.

## Retrieval evaluation ownership

`@marshal/memory-retrieval-evals` is maintained here because its benchmark
loaders, label mapping, retrievers, custom Marshal corpus, metrics, replay
merge, probes, and evaluation evidence are Brain-domain assets rather than
generic Runtime infrastructure. Downloaded datasets and generated results are
ignored; the repository retains the loaders, source/label rules, tests, and
documentation needed to reproduce them. Run the dependency-light preservation
test with `pnpm --dir packages/memory-retrieval-evals test`; run the complete
suite with `pnpm --dir packages/memory-retrieval-evals test:all` after the
Runtime and Quillstone dependencies are available. Override local cache/output
locations with `MARSHAL_EMBEDDING_CACHE` and `MARSHAL_EVAL_OUTPUT`.

## Current validation limits

The source contracts and activation wiring are implemented, including
lifecycle/job registration and nested approval forwarding. Fresh-clone package
resolution, the accepted release package closure, and the complete
discover/install/enable/approval/background-completion/retry flow have not yet
been validated end to end.

## License

[MIT](LICENSE)

## Org caller mode (Marshal org broker)

`cloudCallerMode: "org"` sends the cloud Brain's MCP calls to the org's `/v1/broker/brain/mcp` through a host-side fetch.
The extension never sees, caches or stores the org access token: it has no token or API-base setting.

```json
{ "cloudEnabled": true, "cloudCallerMode": "org" }
```

The desktop registers two runtime services. `Symbol.for('@marshal/org:identity')` is
`() => Promise<{email, orgId, orgDisplayName} | undefined>`; an org session exists only when it resolves.
`Symbol.for('@marshal/org:broker-fetch')` is
`(path, init?: {method: 'GET'|'POST', headers (only accept, content-type, mcp-session-id), body ≤ 1 MiB}) => Promise<{status, headers (no set-cookie), body: string ≤ 8 MiB}>`.
`path` must be under `/v1/broker/` (else it throws with code `path-not-allowed`); the host adds the org bearer, follows
no redirects and times out after 60 s. Both are read on every call. The client sends no authorization, `x-brain-caller`
or `mcp-protocol-version` header and never a session DELETE: it echoes `mcp-session-id` from the previous response and,
on `404 unknown-session`, drops it and re-initializes. Event-stream answers arrive buffered as text. The org server takes
the caller from the verified token. There is no environment-variable token path; a headless server uses its own
`delegated` or `desktop` mode.

Fallback: when `cloudUrl` and `cloudCallerServiceAccount` are also set, they are the existing desktop route. It answers
instead when there is no org identity or the broker returns 401/403, 503
(`broker-unavailable`) or has no such route (404 other than `unknown-session`), or the host call itself fails (`path-not-allowed`,
timeout, oversize); the broker is then not retried for a minute. Without them an unusable broker is a `cloud_brain_auth_failed` error. `desktop` and `delegated` modes are
unchanged. Org mode never changes the Brain engine.
