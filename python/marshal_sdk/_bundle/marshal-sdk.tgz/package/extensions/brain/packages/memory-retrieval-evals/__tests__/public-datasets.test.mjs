import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

import { loadBeam100K } from '../src/datasets/beam.mjs';
import { loadLoCoMo } from '../src/datasets/locomo.mjs';
import {
  loadMemoryAgentBenchConflict,
} from '../src/datasets/memoryagentbench.mjs';
import {
  loadLongMemEvalV2Status,
} from '../src/datasets/longmemeval-v2.mjs';

const __dirname = dirname(fileURLToPath(import.meta.url));
const fixtures = join(__dirname, 'fixtures');

describe('LoCoMo adapter', () => {
  const path = join(fixtures, 'locomo.json');

  it('maps exact turns and keeps only validated category 1-4 evidence', () => {
    const { instances, metadata } = loadLoCoMo({ path });

    assert.equal(metadata.totalQaRows, 5);
    assert.equal(metadata.runnableIrInstances, 2);
    assert.equal(metadata.excludedNoValidatedEvidence, 2);
    assert.equal(metadata.adversarialStatusOnly, 1);
    assert.equal(instances.length, 2);

    const first = instances[0];
    assert.equal(first.corpusKey, 'locomo:fixture-conv');
    assert.deepEqual(
      first.corpus.map((record) => record.sessionId),
      ['D1:1', 'D1:2', 'D2:1']
    );
    assert.deepEqual(first.query.relevantSessionIds, ['D1:1', 'D2:1']);
    assert.equal(first.query.questionType, 'multi-hop');
    assert.match(first.corpus[1].markdown, /Image caption:/);

    assert.equal(instances[1].query.queryId, 'locomo:fixture-conv:qa:4');
    assert.deepEqual(instances[1].query.relevantSessionIds, ['D1:2']);
    assert.equal(instances[1].query.questionType, 'single-hop');
  });

  it('supports exact query IDs and deterministic slices', () => {
    const selected = loadLoCoMo({
      path,
      queryIds: ['locomo:fixture-conv:qa:4'],
    });
    assert.deepEqual(
      selected.instances.map((instance) => instance.query.queryId),
      ['locomo:fixture-conv:qa:4']
    );

    const sliced = loadLoCoMo({ path, slice: 1 });
    assert.equal(
      sliced.instances[0].query.queryId,
      'locomo:fixture-conv:qa:1'
    );

    assert.throws(
      () => loadLoCoMo({
        path,
        queryIds: ['locomo:fixture-conv:qa:5'],
      }),
      /not runnable/
    );
  });
});

describe('BEAM 100K adapter', () => {
  const directory = join(fixtures, 'beam', '100K');

  it('flattens exact message IDs and validates integer source leaves only', () => {
    const { instances, metadata } = loadBeam100K({
      directory,
      chatNumbers: [1],
    });

    assert.equal(metadata.totalMessages, 3);
    assert.equal(metadata.totalQuestions, 5);
    assert.equal(metadata.runnableIrInstances, 2);
    assert.equal(metadata.abstentionStatusOnly, 1);
    assert.equal(metadata.unlabeledStatusOnly, 2);
    assert.equal(metadata.excludedFromIr, 3);

    assert.deepEqual(
      instances[0].corpus.map((record) => record.sessionId),
      ['0', '1', '2']
    );
    assert.ok(instances[0].corpus.every(
      (record) => record.date === '2024-03-15T00:00:00.000Z'
    ));
    assert.equal(
      instances[0].query.queryId,
      'beam-100k:1:contradiction_resolution:1'
    );
    assert.deepEqual(instances[0].query.relevantSessionIds, ['2']);

    assert.equal(
      instances[1].query.queryId,
      'beam-100k:1:information_extraction:1'
    );
    assert.deepEqual(instances[1].query.relevantSessionIds, ['0', '1']);
    assert.equal(instances[1].query.answer, 'March 29.');
  });

  it('supports exact query IDs and slices in canonical category order', () => {
    const selected = loadBeam100K({
      directory,
      chatNumbers: [1],
      queryIds: ['beam-100k:1:information_extraction:1'],
    });
    assert.deepEqual(
      selected.instances.map((instance) => instance.query.queryId),
      ['beam-100k:1:information_extraction:1']
    );

    const sliced = loadBeam100K({
      directory,
      chatNumbers: [1],
      slice: 1,
    });
    assert.equal(
      sliced.instances[0].query.queryId,
      'beam-100k:1:contradiction_resolution:1'
    );

    assert.throws(
      () => loadBeam100K({
        directory,
        chatNumbers: [1],
        queryIds: ['beam-100k:1:abstention:1'],
      }),
      /not runnable/
    );
  });
});

describe('status-only datasets', () => {
  it('does not fabricate MemoryAgentBench IR instances', () => {
    const { instances, metadata } = loadMemoryAgentBenchConflict();
    assert.deepEqual(instances, []);
    assert.equal(metadata.status, 'status-only');
    assert.equal(metadata.license, 'MIT');
    assert.equal(metadata.totalQaCases, 800);
    assert.equal(metadata.fileSizeBytes, 1491588);
    assert.match(metadata.note, /Brain QA\/update/);
  });

  it('does not fabricate LongMemEval-V2 trajectory labels', () => {
    const { instances, metadata } = loadLongMemEvalV2Status();
    assert.deepEqual(instances, []);
    assert.equal(metadata.status, 'status-only');
    assert.equal(metadata.questions, 451);
    assert.equal(metadata.trajectories, 1870);
    assert.match(metadata.note, /No gold relevant trajectory IDs/);
  });
});
