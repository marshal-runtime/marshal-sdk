/**
 * Evaluation harness for the real Marshal and Quillstone retrieval paths.
 * Corpora with the same corpusKey share one ingest/index build across queries.
 */

import { rm } from 'node:fs/promises';
import { ingestCorpusAsync, searchRuntime } from './ingest.mjs';
import { aggregateMetrics } from './metrics.mjs';
import {
  initBridgeInstance,
  createBridgeBm25Retriever,
  createBridgeHybridRetriever,
  closeBridgeInstance,
} from './retrievers/quillstone-bridge.mjs';
import { createShuffledLabelRetriever } from './retrievers/broken.mjs';

/** Deterministic round-robin sample with representation across question types. */
export function stratifiedSample(instances, targetSize) {
  if (instances.length <= targetSize) return instances;

  const buckets = new Map();
  for (const instance of instances) {
    const key = instance.query.questionType ?? 'unknown';
    if (!buckets.has(key)) buckets.set(key, []);
    buckets.get(key).push(instance);
  }

  for (const items of buckets.values()) {
    items.sort((a, b) =>
      (a.query.queryId ?? '').localeCompare(b.query.queryId ?? '')
    );
  }

  const result = [];
  let remaining = targetSize;
  const perType = Math.max(1, Math.floor(targetSize / buckets.size));
  for (const items of buckets.values()) {
    const take = Math.min(items.length, perType, remaining);
    result.push(...items.slice(0, take));
    remaining -= take;
    if (remaining <= 0) break;
  }

  if (remaining > 0) {
    const unused = [...buckets.values()].flat()
      .filter((instance) => !result.includes(instance));
    result.push(...unused.slice(0, remaining));
  }
  return result;
}

/**
 * Run evaluation through a real runtime mode.
 * Each corpusKey is built, queried, and disposed before the next corpus starts.
 * Index build time is charged only to the first query for each corpusKey.
 */
export async function runEvaluation(
  instances,
  options = {},
  lifecycle = defaultEvaluationLifecycle
) {
  const {
    mode,
    limit = 20,
    onProgress,
    verbose,
    embeddingProvider,
  } = options;
  const startTime = performance.now();
  const queryResults = new Array(instances.length);
  let completed = 0;
  let corpusCount = 0;
  let bridgeInitError = null;

  for (const group of groupInstancesByCorpus(instances)) {
    let state = null;
    try {
      for (const { instance, originalIndex, corpusKey } of group) {
        const corpus = instance.corpus;
        if (!corpus || corpus.length === 0) {
          completed++;
          continue;
        }

        let indexBuildMs = 0;
        try {
          if (!state) {
            const indexStart = performance.now();
            state = await lifecycle.buildCorpusState(corpusKey, corpus, {
              mode,
              limit,
              verbose,
              embeddingProvider,
            });
            indexBuildMs = performance.now() - indexStart;
            corpusCount++;
            if (state.bridgeHandle?.error) {
              bridgeInitError ??= state.bridgeHandle.error;
            }
          } else {
            assertMatchingCorpus(corpusKey, corpus, state.scopeIds);
          }

          const query = instance.query;
          const queryStart = performance.now();
          const result = await lifecycle.retrieveForMode(
            state,
            query.question,
            {
              ...options,
              limit,
              mode,
            }
          );
          const queryLatencyMs = performance.now() - queryStart;
          const retrievedSessionIds = result.sessionIds ?? [];

          queryResults[originalIndex] = {
            queryId: query.queryId,
            corpusKey,
            question: query.question,
            questionType: query.questionType,
            isAbstention: query.isAbstention,
            mode,
            retrieved: retrievedSessionIds,
            scores: result.scores ?? [],
            relevant: query.relevantSessionIds ?? [],
            scopeIds: state.scopeIds,
            queryLatencyMs,
            latencyMs: queryLatencyMs,
            indexBuildMs,
            ...(result.error ? { error: result.error } : {}),
          };
        } catch (error) {
          queryResults[originalIndex] = {
            queryId: instance.query?.queryId,
            corpusKey,
            question: instance.query?.question,
            questionType: instance.query?.questionType,
            isAbstention: instance.query?.isAbstention,
            mode,
            retrieved: [],
            scores: [],
            relevant: instance.query?.relevantSessionIds ?? [],
            scopeIds: corpus.map((session) => session.sessionId),
            queryLatencyMs: 0,
            latencyMs: 0,
            indexBuildMs,
            error: error.message,
          };
        }

        completed++;
        onProgress?.({
          completed,
          total: instances.length,
          queryId: instance.query?.queryId,
        });
      }
    } finally {
      if (state) {
        await lifecycle.closeCorpusState(state);
      }
    }
  }

  const orderedQueryResults = queryResults.filter(Boolean);
  const totalDurationMs = performance.now() - startTime;
  const aggregate = aggregateMetrics(orderedQueryResults);
  const totalIndexBuildMs = orderedQueryResults
    .reduce((sum, result) => sum + result.indexBuildMs, 0);

  return {
    metadata: {
      retriever: mode,
      queryCount: orderedQueryResults.length,
      corpusCount,
      totalIndexBuildMs,
      totalDurationMs: Math.round(totalDurationMs),
      completedAt: new Date().toISOString(),
      ...(bridgeInitError ? { bridgeInitError } : {}),
    },
    aggregate,
    perQuery: orderedQueryResults,
  };
}

function groupInstancesByCorpus(instances) {
  const groups = new Map();
  instances.forEach((instance, originalIndex) => {
    const corpusKey = instance.corpusKey ?? instance.instanceId;
    const group = groups.get(corpusKey) ?? [];
    group.push({ instance, originalIndex, corpusKey });
    groups.set(corpusKey, group);
  });
  return groups.values();
}

async function buildCorpusState(corpusKey, corpus, options) {
  const state = {
    corpusKey,
    scopeIds: corpus.map((session) => session.sessionId),
    ingestHandle: null,
    bridgeHandle: null,
  };

  try {
    state.ingestHandle = await ingestCorpusAsync(corpus, {
      instanceId: corpusKey,
      verbose: options.verbose,
    });
    const { memoryMap } = state.ingestHandle;

    if (
      options.mode === 'quillstone-bridge-bm25'
      || options.mode === 'quillstone-bridge-hybrid'
    ) {
      state.bridgeHandle = await initBridgeInstance(corpus, memoryMap, {
        embeddingProvider: options.mode === 'quillstone-bridge-hybrid'
          ? options.embeddingProvider
          : null,
        verbose: options.verbose,
      });
    }
    return state;
  } catch (error) {
    await closeCorpusState(state);
    throw error;
  }
}

async function retrieveForMode(state, question, options) {
  const { mode, limit } = options;
  const { runtime, handles, ctx, memoryMap } = state.ingestHandle;

  if (mode === 'marshal-memory-v2') {
    return searchRuntime(runtime, handles, question, ctx, memoryMap, { limit });
  }
  if (mode === 'quillstone-bridge-bm25' || mode === 'quillstone-bridge-hybrid') {
    if (state.bridgeHandle?.error) {
      return {
        sessionIds: [],
        scores: [],
        latencyMs: 0,
        error: state.bridgeHandle.error,
      };
    }
    const retriever = mode === 'quillstone-bridge-hybrid'
      ? createBridgeHybridRetriever(state.bridgeHandle, { limit })
      : createBridgeBm25Retriever(state.bridgeHandle, { limit });
    return retriever.retrieve(question);
  }
  if (mode === 'broken') {
    return options.retriever.retrieve(question);
  }
  if (mode === 'shuffled-labels') {
    const baseRetriever = {
      requiresModelDownload: false,
      retrieve: (query) =>
        searchRuntime(runtime, handles, query, ctx, memoryMap, { limit }),
    };
    return createShuffledLabelRetriever(baseRetriever).retrieve(question);
  }
  throw new Error(`Unknown mode: ${mode}`);
}

async function closeCorpusState(state) {
  if (state.bridgeHandle) {
    await closeBridgeInstance(state.bridgeHandle).catch(() => {});
  }
  if (state.ingestHandle) {
    try { state.ingestHandle.db.close(); } catch { /* cleanup best effort */ }
    if (state.ingestHandle.tmpDir) {
      await rm(state.ingestHandle.tmpDir, {
        recursive: true,
        force: true,
      }).catch(() => {});
    }
  }
}

function assertMatchingCorpus(corpusKey, corpus, expectedIds) {
  const actualIds = corpus.map((session) => session.sessionId);
  if (
    actualIds.length !== expectedIds.length
    || actualIds.some((id, index) => id !== expectedIds[index])
  ) {
    throw new Error(`corpusKey ${corpusKey} was reused with a different corpus.`);
  }
}

const defaultEvaluationLifecycle = {
  buildCorpusState,
  retrieveForMode,
  closeCorpusState,
};

/** Format aggregate and separate query/index timing for console output. */
export function formatResults(results) {
  const m = results.metadata;
  const a = results.aggregate;
  const lines = [
    '\n═══ Retrieval Evaluation Results ═══',
    `Retriever: ${m.retriever}`,
    `Total queries: ${a.totalQueries} | Retrieval: ${a.evaluatedRetrievalQueries} | Corpora: ${m.corpusCount} | Wall: ${(m.totalDurationMs / 1000).toFixed(1)}s\n`,
    `Recall@1:  ${fmt(a['recall@1'])}`,
    `Recall@5:  ${fmt(a['recall@5'])}`,
    `Recall@10: ${fmt(a['recall@10'])}`,
    `Recall@20: ${fmt(a['recall@20'])}`,
    `MRR:       ${fmt(a.mrr)}`,
    `nDCG@10:   ${fmt(a['ndcg@10'])}`,
  ];
  if (a.abstention?.total > 0) {
    lines.push(`Abstention: ${a.abstention.correct}/${a.abstention.total} (precision: ${fmt(a.abstention.precision)})`);
  }
  if (a.zeroResults?.total > 0) {
    lines.push(`Zero-result: ${a.zeroResults.total}/${a.evaluatedRetrievalQueries} (${fmt(a.zeroResults.rate)})`);
  }
  if (a.errors?.total > 0) {
    lines.push(`Errors: ${a.errors.total}/${a.totalQueries}`);
  }
  if (a.queryLatency) {
    lines.push(`Query latency: p50=${a.queryLatency.p50}ms p95=${a.queryLatency.p95}ms`);
  }
  if (a.indexBuild) {
    lines.push(`Index build:   p50=${a.indexBuild.p50}ms p95=${a.indexBuild.p95}ms`);
  }
  if (m.bridgeInitError) {
    lines.push(`\n⚠ Bridge init error: ${m.bridgeInitError}`);
  }
  lines.push('');
  return lines.join('\n');
}

function fmt(value) {
  return value == null ? 'N/A' : `${(value * 100).toFixed(1)}%`;
}
