/**
 * Intentionally broken retriever for validation.
 * Always returns fabricated session IDs that never match ground truth.
 */

export function createBrokenRetriever() {
  let callCount = 0;
  return {
    name: 'broken',
    description: 'Intentionally broken retriever (validation)',
    requiresModelDownload: false,
    retrieve(query) {
      callCount++;
      const fakeIds = Array.from({ length: 5 }, (_, i) => `broken-fake-${callCount}-${i}`);
      return { sessionIds: fakeIds, scores: fakeIds.map((_, i) => 1 / (i + 1)), latencyMs: 0 };
    },
  };
}

/**
 * Shuffled-label/decoy control retriever.
 * Retrieves using real search but returns results with labels randomly permuted.
 * This verifies that high scores aren't just due to trivial label correlation.
 */
export function createShuffledLabelRetriever(baseRetriever) {
  return {
    name: 'shuffled-labels',
    description: 'Real retrieval with shuffled ground-truth labels (decoy control)',
    requiresModelDownload: baseRetriever.requiresModelDownload,
    async retrieve(query) {
      const result = await Promise.resolve(baseRetriever.retrieve(query));
      // Shuffle the returned session IDs randomly
      const shuffled = [...result.sessionIds];
      for (let i = shuffled.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
      }
      return { ...result, sessionIds: shuffled };
    },
  };
}
