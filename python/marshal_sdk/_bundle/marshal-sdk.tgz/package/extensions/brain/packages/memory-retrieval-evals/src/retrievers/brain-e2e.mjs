/**
 * Brain retriever — clearly unavailable without live LLM.
 *
 * Brain requires a live LLM reasoner (Luna) for orchestration.
 * Without it, this retriever explicitly fails and reports unavailability.
 * No facade over FTS is used.
 */

export function createBrainRetriever() {
  return {
    name: 'brain',
    description: 'Brain end-to-end (UNAVAILABLE — requires live Luna LLM reasoner)',
    requiresModelDownload: true,
    available: false,
    unavailableReason: 'Brain requires a live LLM reasoner (Luna) for memory orchestration. ' +
      'This eval harness does not have LLM access. Use marshal-memory-v2 or quillstone modes instead.',
    retrieve() {
      throw new Error(
        'Brain retriever is unavailable without a live LLM reasoner. ' +
        'This is not a facade — Brain genuinely requires Luna for orchestration.'
      );
    },
  };
}
