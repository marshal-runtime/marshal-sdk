# @marshal/memory-retrieval-evals

Relevance-labeled retrieval benchmarks runnable through the real Marshal
SQLite runtime and Quillstone paths, in lexical and embeddings-enabled modes.
Datasets without published retrieval labels remain QA/status-only and never
emit fabricated IR instances.

## Dataset status

| Dataset | Source | License | Official contents | IR status |
|---------|--------|---------|-------------------|-----------|
| LongMemEval-S | [Hugging Face](https://huggingface.co/datasets/xiaowu0162/longmemeval-cleaned) | MIT | 500 questions | Runnable |
| LoCoMo | [Official JSON](https://github.com/snap-research/locomo/blob/main/data/locomo10.json) | CC-BY-NC-4.0 | 10 conversations, 1,986 QA rows | Runnable: 1,536 category 1-4 queries; 4 without validated evidence excluded; 446 category 5 adversarial rows status-only |
| BEAM smallest tier | [Official `chats/100K` JSON](https://github.com/mohammadtavakoli78/BEAM/tree/main/chats/100K) | Data: CC-BY-SA-4.0; code: MIT | 20 chats, 5,732 messages, 400 questions | Runnable: 355 questions with validated source IDs; 40 abstention and 5 other unlabeled questions status-only |
| MemoryAgentBench Conflict_Resolution | [Hugging Face](https://huggingface.co/datasets/ai-hyz/MemoryAgentBench) | MIT | `config=default`, `split=Conflict_Resolution`; 8 rows × 100 = 800 QA cases; 1,491,588-byte parquet | Status-only: no question-to-fact relevance labels |
| LongMemEval-V2 | [Hugging Face](https://huggingface.co/datasets/xiaowu0162/longmemeval-v2) / [GitHub](https://github.com/xiaowu0162/LongMemEval-V2) | Apache-2.0 | 451 questions, 1,870 trajectories | Status-only: no gold relevant trajectory IDs |
| Marshal Custom | In-repo | Same as repository | 12 cases | Runnable custom validation corpus; not public benchmark evidence |

BEAM's paper and README call the smallest tier **128K**, while the actual
GitHub directory, Hugging Face split, and files are named **100K**.
`beam-100k` is the canonical CLI ID; `beam-128k` is an alias.

MemoryAgentBench Conflict_Resolution needs a separate Brain QA/update lane.
LongMemEval-V2 likewise remains outside this relevance-labeled IR harness: its
official metrics are answer accuracy plus memory query latency/LAFS. Its
question records contain `id`, `domain`, `environment`, `question_type`,
`question`, `image`, `answer`, and `eval_function`; trajectory records contain
`id`, `domain`, `environment`, `goal`, `outcome`, `start_url`, and `states`.
The small tier has 100 trajectory candidates per question and medium has mostly
500, but neither publishes gold relevant trajectory IDs.

## Quick start

```bash
# Download runnable public datasets into git-ignored eval-data/
node scripts/download.mjs

# Or download only the new official JSON lanes
node scripts/download.mjs --dataset locomo --dataset beam-100k

# Run deterministic slices through the real runtime paths
node src/run.mjs --dataset locomo --slice 10 --mode marshal-memory-v2
node src/run.mjs --dataset beam-100k --slice 10 --mode quillstone-bridge-bm25

# Run exact canonical query IDs
node src/run.mjs --dataset locomo --query-id locomo:conv-26:qa:1 --mode marshal-memory-v2
node src/run.mjs --dataset beam-100k --query-id beam-100k:1:information_extraction:1 --mode quillstone-bridge-bm25

# Run a stratified real Quillstone hybrid sample
node src/run.mjs --dataset longmemeval-s --mode quillstone-bridge-hybrid --slice 100 --stratified

# Legacy exact IDs and replay merge remain supported
node src/run.mjs --mode quillstone-bridge-bm25 --ids 1568498a,352ab8bd \
  --merge path/to/existing-results.json

# Verify the broken-retriever control
node src/run.mjs --dataset longmemeval-s --mode broken --slice 10
```

Slices use canonical upstream order after relevance validation. Repeated
`--query-id` options select exact IDs while preserving that order. Unknown or
status-only IDs fail instead of silently broadening selection. The legacy
`--ids` comma-separated form remains available for existing replay commands.

LoCoMo query IDs are
`locomo:<sample_id>:qa:<1-based upstream QA position>`. BEAM query IDs are
`beam-100k:<chat number>:<category>:<1-based category position>`.

## Corpus and label mapping

LoCoMo creates one corpus record per exact dialogue `dia_id`. Evidence strings
may contain multiple labels; only `D<number>:<number>` labels are extracted,
numeric components are normalized, and labels are retained only when they
resolve to a real turn in that conversation.

BEAM creates one corpus record per exact integer chat message ID.
`source_chat_ids` is traversed recursively, but only integer leaves from that
field are considered. IDs found in unrelated prose or metadata are never used
as relevance labels.

Selected queries execute corpus-by-corpus. Queries sharing a dataset
`corpusKey` reuse one real runtime/index build, which is disposed before the
next corpus starts. Result rows remain in canonical selected-query order.
`indexBuildMs` is charged to the first query for that corpus and is zero for
subsequent queries; `queryLatencyMs` measures only retrieval work.
LongMemEval-S instances have distinct corpora and retain per-query builds.

## Real modes

| Mode | Backend | Description | Model download |
|------|---------|-------------|----------------|
| `marshal-memory-v2` | PortableMemoryRuntime | Real SQLite `marshal_memories_v2` FTS5 | No |
| `quillstone-bridge-bm25` | MarshalMemoryBridge | Real production Markdown bridge with native BM25 | No |
| `quillstone-bridge-hybrid` | MarshalMemoryBridge | Real bridge + snowflake-arctic-embed-xs 384d RRF | Local cache only |
| `brain` | — | **Unavailable** — requires the live Brain reasoner | — |
| `broken` | — | Intentionally broken retriever validation control | No |
| `shuffled-labels` | PortableMemoryRuntime | Real retrieval with shuffled result labels | No |

## Metrics

- **Recall@1/5/10/20**: Fraction of relevant items in top-K, excluding abstention
- **MRR**: Mean reciprocal rank, excluding abstention
- **nDCG@10**: Normalized discounted cumulative gain
- **Abstention precision**: Correct empty results where labels support abstention
- **Zero-result rate**: Non-abstention queries returning nothing
- **Error rate**: Failed bridge/search operations
- **Query latency p50/p95**: Warm query execution only
- **Index build p50/p95**: Corpus materialization plus index/bridge build
- **Scope leakage**: Cross-scope contamination detection

## Projection synopsis caveat

The `## Retrieval` section in benchmark `.memory.md` projection files is
**mechanically derived** from each session's first assistant utterance or,
if absent, the first 300 characters of the session body. It is **not** a
Brain-authored production synopsis: no LLM reasoning, semantic extraction,
or knowledge-graph enrichment is applied. These results evaluate retrieval
primitives against raw conversational text, not the end-to-end Brain semantic
authoring pipeline that generates production projection synopses.

## Marshal Custom Corpus

The hand-crafted corpus tests code-memory links, scopes, supersession, and
blast radius. It is explicitly custom, not public benchmark evidence. Queries
use wording different from target memories, and decoys share obvious nouns to
avoid inflating scores through trivial keyword matching.
