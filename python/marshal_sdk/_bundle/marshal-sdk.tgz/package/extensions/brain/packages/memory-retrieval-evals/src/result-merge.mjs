import {
  mkdirSync,
  readFileSync,
  writeFileSync,
} from 'node:fs';
import { basename, extname, join } from 'node:path';

import { aggregateMetrics } from './metrics.mjs';

function artifactTimestamp(now) {
  return now.toISOString().replace(/[:.]/g, '-');
}

function indexRowsByQueryId(rows, label) {
  if (!Array.isArray(rows)) {
    throw new TypeError(`${label} perQuery must be an array.`);
  }
  const byQueryId = new Map();
  for (const row of rows) {
    const queryId = row?.queryId;
    if (typeof queryId !== 'string' || queryId.trim() === '') {
      throw new TypeError(`${label} perQuery rows must have nonempty queryId values.`);
    }
    if (byQueryId.has(queryId)) {
      throw new TypeError(`${label} contains duplicate queryId: ${queryId}`);
    }
    byQueryId.set(queryId, row);
  }
  return byQueryId;
}

function mergedMetadata(metadata, perQuery, completedAt) {
  const corpusKeys = new Set(
    perQuery
      .map((row) => row.corpusKey)
      .filter((corpusKey) => typeof corpusKey === 'string' && corpusKey.length > 0),
  );
  const totalIndexBuildMs = perQuery
    .filter((row) => Number.isFinite(row.indexBuildMs) && row.indexBuildMs > 0)
    .reduce((sum, row) => sum + row.indexBuildMs, 0);

  return {
    ...metadata,
    queryCount: perQuery.length,
    corpusCount: corpusKeys.size,
    totalIndexBuildMs,
    totalDurationMs: null,
    completedAt,
  };
}

/**
 * Merge replay rows into a new canonical artifact without modifying the source.
 */
export function mergeResultArtifacts({
  mergeTarget,
  replayResults,
  outputDir,
  modeName,
  now = new Date(),
}) {
  const existing = JSON.parse(readFileSync(mergeTarget, 'utf8'));
  const sourceByQueryId = indexRowsByQueryId(existing.perQuery, 'Merge source');
  const replayByQueryId = indexRowsByQueryId(
    replayResults.perQuery,
    'Replay artifact',
  );
  for (const queryId of replayByQueryId.keys()) {
    if (!sourceByQueryId.has(queryId)) {
      throw new TypeError(`Replay queryId is absent from merge source: ${queryId}`);
    }
  }

  let replaced = 0;
  const perQuery = existing.perQuery.map((row) => {
    if (!replayByQueryId.has(row.queryId)) return row;
    replaced += 1;
    return replayByQueryId.get(row.queryId);
  });
  if (replaced !== replayResults.perQuery.length) {
    throw new Error(
      `Expected to replace ${replayResults.perQuery.length} replay rows, replaced ${replaced}.`,
    );
  }
  const completedAt = now.toISOString();
  const merged = {
    ...existing,
    metadata: mergedMetadata(existing.metadata, perQuery, completedAt),
    aggregate: aggregateMetrics(perQuery),
    perQuery,
  };

  mkdirSync(outputDir, { recursive: true });
  const timestamp = artifactTimestamp(now);
  const extension = extname(mergeTarget);
  const sourceName = basename(mergeTarget, extension);
  const mergedFile = join(
    outputDir,
    `${sourceName}-merged-${timestamp}.json`,
  );
  const replayFile = join(
    outputDir,
    `eval-replay-${modeName}-${timestamp}.json`,
  );
  writeFileSync(mergedFile, JSON.stringify(merged, null, 2));
  writeFileSync(replayFile, JSON.stringify(replayResults, null, 2));

  return { merged, mergedFile, replayFile, replaced };
}
