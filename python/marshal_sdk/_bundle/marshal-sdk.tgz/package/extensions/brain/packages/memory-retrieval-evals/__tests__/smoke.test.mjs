/**
 * Tests for the memory retrieval eval harness using real runtime.
 */
import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { recallAtK, mrr, ndcgAtK, aggregateMetrics } from '../src/metrics.mjs';
import { ingestCorpusAsync, searchRuntime } from '../src/ingest.mjs';
import { loadMarshalCorpus } from '../src/marshal-corpus.mjs';
import { runEvaluation } from '../src/harness.mjs';
import { createBrokenRetriever, createShuffledLabelRetriever } from '../src/retrievers/broken.mjs';

describe('metrics', () => {
  it('recall@K', () => {
    assert.equal(recallAtK(['a', 'b', 'c'], ['a', 'c'], 1), 0.5);
    assert.equal(recallAtK(['a', 'b', 'c'], ['a', 'c'], 3), 1.0);
    assert.equal(recallAtK(['x'], ['a'], 1), 0);
  });
  it('MRR', () => {
    assert.equal(mrr(['a', 'b'], ['b']), 0.5);
    assert.equal(mrr(['a'], ['a']), 1.0);
    assert.equal(mrr(['x'], ['a']), 0);
  });
  it('nDCG@K', () => {
    assert.equal(ndcgAtK(['a', 'b'], ['a', 'b'], 2), 1.0);
    assert.equal(ndcgAtK(['x', 'y'], ['a'], 2), 0);
  });

  it('reports index latency over actual builds, not reused-query zeros', () => {
    const base = {
      retrieved: ['a'],
      relevant: ['a'],
      scopeIds: ['a'],
      isAbstention: false,
      queryLatencyMs: 2,
    };
    const aggregate = aggregateMetrics([
      { ...base, indexBuildMs: 100 },
      { ...base, indexBuildMs: 0 },
      { ...base, indexBuildMs: 300 },
    ]);

    assert.equal(aggregate.queryLatency.count, 3);
    assert.equal(aggregate.indexBuild.count, 2);
    assert.equal(aggregate.indexBuild.min, 100);
    assert.equal(aggregate.indexBuild.p50, 200);
    assert.equal(aggregate.indexBuild.max, 300);

    const empty = aggregateMetrics([]);
    assert.equal(empty.queryLatency.count, 0);
    assert.equal(empty.indexBuild.count, 0);
  });
});

describe('real runtime ingest and search', () => {
  it('ingests sessions and searches with real PortableMemoryRuntime', async () => {
    const sessions = [
      {
        sessionId: 'test-webpack',
        date: '2024-01-01',
        markdown: '# Session\n\n**User**: How to configure webpack?\n\n**Assistant**: Use a webpack.config.js file with entry and output fields.\n',
        turns: [
          { role: 'user', content: 'How to configure webpack?' },
          { role: 'assistant', content: 'Use a webpack.config.js file with entry and output fields.' },
        ],
      },
      {
        sessionId: 'test-database',
        date: '2024-01-02',
        markdown: '# Session\n\n**User**: Set up database migrations\n\n**Assistant**: Use knex.js for PostgreSQL migrations with timestamps.\n',
        turns: [
          { role: 'user', content: 'Set up database migrations' },
          { role: 'assistant', content: 'Use knex.js for PostgreSQL migrations with timestamps.' },
        ],
      },
    ];

    const { runtime, db, handles, ctx, memoryMap } = await ingestCorpusAsync(sessions, {
      instanceId: 'test-ingest',
    });

    assert.equal(memoryMap.size, 2);
    assert.ok(memoryMap.has('test-webpack'));
    assert.ok(memoryMap.has('test-database'));

    // Search for webpack content — real PortableMemoryRuntime.search()
    const result = searchRuntime(runtime, handles, 'webpack configuration', ctx, memoryMap);
    assert.ok(result.sessionIds.length > 0, 'Should find webpack memories');
    assert.equal(result.sessionIds[0], 'test-webpack');

    // Search for database content
    const dbResult = searchRuntime(runtime, handles, 'database migrations', ctx, memoryMap);
    assert.ok(dbResult.sessionIds.length > 0, 'Should find database memories');

    db.close();
  });
});

describe('broken and shuffled retrievers', () => {
  it('broken retriever returns zero-recall results', () => {
    const r = createBrokenRetriever();
    const result = r.retrieve('anything');
    assert.ok(result.sessionIds.every(id => id.startsWith('broken-fake')));
  });

  it('shuffled-label control permutes results', async () => {
    const base = { retrieve: () => ({ sessionIds: ['a', 'b', 'c', 'd', 'e'], scores: [1, 2, 3, 4, 5], latencyMs: 0 }) };
    const shuffled = createShuffledLabelRetriever(base);
    // Run many times to verify it's not always identical
    let different = false;
    for (let i = 0; i < 20; i++) {
      const r = await shuffled.retrieve('test');
      if (r.sessionIds.join(',') !== 'a,b,c,d,e') { different = true; break; }
    }
    assert.ok(different, 'Shuffled retriever should permute results');
  });
});

describe('marshal corpus quality', () => {
  it('verifies no query-text leakage in corpus', () => {
    const { instances } = loadMarshalCorpus();
    for (const inst of instances) {
      if (inst.query.isAbstention) continue;
      const queryWords = inst.query.question.toLowerCase().split(/\s+/).filter(w => w.length > 4);
      // Check that the query text itself is not used as a session ID or tag
      for (const session of inst.corpus) {
        assert.ok(
          !queryWords.every(w => session.sessionId.toLowerCase().includes(w)),
          `Session ID "${session.sessionId}" should not contain all query words`
        );
      }
    }
  });
});
describe('harness', () => {
  it('disposes each corpus before starting the next and preserves row order', async () => {
    const corpusA = [
      {
        sessionId: 'corpus-a-session',
        date: '2024-01-01',
        markdown: '# Corpus A',
        turns: [{ role: 'user', content: 'alpha' }],
      },
    ];
    const corpusB = [
      {
        sessionId: 'corpus-b-session',
        date: '2024-01-02',
        markdown: '# Corpus B',
        turns: [{ role: 'user', content: 'beta' }],
      },
    ];
    const instances = [
      {
        instanceId: 'query-a-1',
        corpusKey: 'corpus-a',
        corpus: corpusA,
        query: {
          queryId: 'query-a-1',
          questionType: 'label-a-1',
          question: 'alpha first',
          relevantSessionIds: ['corpus-a-session'],
          isAbstention: false,
        },
      },
      {
        instanceId: 'query-b-1',
        corpusKey: 'corpus-b',
        corpus: corpusB,
        query: {
          queryId: 'query-b-1',
          questionType: 'label-b-1',
          question: 'beta only',
          relevantSessionIds: ['corpus-b-session'],
          isAbstention: false,
        },
      },
      {
        instanceId: 'query-a-2',
        corpusKey: 'corpus-a',
        corpus: corpusA,
        query: {
          queryId: 'query-a-2',
          questionType: 'label-a-2',
          question: 'alpha second',
          relevantSessionIds: ['corpus-a-session'],
          isAbstention: false,
        },
      },
    ];
    const events = [];
    let liveCorpusCount = 0;
    let maxLiveCorpusCount = 0;

    const results = await runEvaluation(
      instances,
      { mode: 'deterministic-test', limit: 1 },
      {
        async buildCorpusState(corpusKey, corpus) {
          events.push(`build:${corpusKey}`);
          assert.equal(liveCorpusCount, 0);
          liveCorpusCount++;
          maxLiveCorpusCount = Math.max(
            maxLiveCorpusCount,
            liveCorpusCount
          );
          return {
            corpusKey,
            scopeIds: corpus.map((session) => session.sessionId),
          };
        },
        async retrieveForMode(state, question) {
          events.push(`query:${state.corpusKey}:${question}`);
          return {
            sessionIds: [state.scopeIds[0]],
            scores: [1],
          };
        },
        async closeCorpusState(state) {
          events.push(`close:${state.corpusKey}`);
          assert.equal(liveCorpusCount, 1);
          liveCorpusCount--;
        },
      }
    );

    assert.equal(maxLiveCorpusCount, 1);
    assert.equal(liveCorpusCount, 0);
    assert.deepEqual(events, [
      'build:corpus-a',
      'query:corpus-a:alpha first',
      'query:corpus-a:alpha second',
      'close:corpus-a',
      'build:corpus-b',
      'query:corpus-b:beta only',
      'close:corpus-b',
    ]);
    assert.deepEqual(
      results.perQuery.map((result) => ({
        queryId: result.queryId,
        questionType: result.questionType,
        relevant: result.relevant,
        retrieved: result.retrieved,
      })),
      [
        {
          queryId: 'query-a-1',
          questionType: 'label-a-1',
          relevant: ['corpus-a-session'],
          retrieved: ['corpus-a-session'],
        },
        {
          queryId: 'query-b-1',
          questionType: 'label-b-1',
          relevant: ['corpus-b-session'],
          retrieved: ['corpus-b-session'],
        },
        {
          queryId: 'query-a-2',
          questionType: 'label-a-2',
          relevant: ['corpus-a-session'],
          retrieved: ['corpus-a-session'],
        },
      ]
    );
    assert.equal(results.perQuery[2].indexBuildMs, 0);
    assert.equal(results.aggregate['recall@1'], 1);
    assert.equal(results.aggregate.mrr, 1);
    assert.equal(results.metadata.corpusCount, 2);
  });

  it('builds one real runtime index for queries sharing a corpusKey', async () => {
    const corpus = [
      {
        sessionId: 'shared-a',
        date: '2024-01-01',
        markdown: '# Message\n\nalpha',
        turns: [{ role: 'user', content: 'alpha' }],
      },
      {
        sessionId: 'shared-b',
        date: '2024-01-02',
        markdown: '# Message\n\nbeta',
        turns: [{ role: 'assistant', content: 'beta' }],
      },
    ];
    const instances = [
      {
        instanceId: 'shared-query-1',
        corpusKey: 'shared-corpus',
        corpus,
        query: {
          queryId: 'shared-query-1',
          questionType: 'fixture',
          question: 'alpha',
          relevantSessionIds: ['shared-a'],
          isAbstention: false,
        },
      },
      {
        instanceId: 'shared-query-2',
        corpusKey: 'shared-corpus',
        corpus,
        query: {
          queryId: 'shared-query-2',
          questionType: 'fixture',
          question: 'beta',
          relevantSessionIds: ['shared-b'],
          isAbstention: false,
        },
      },
    ];

    const results = await runEvaluation(instances, {
      mode: 'marshal-memory-v2',
      limit: 2,
    });

    assert.equal(results.metadata.corpusCount, 1);
    assert.ok(results.perQuery[0].indexBuildMs > 0);
    assert.equal(results.perQuery[1].indexBuildMs, 0);
    assert.ok(results.perQuery.every((result) => result.queryLatencyMs >= 0));
    assert.ok(results.perQuery.every((result) => Array.isArray(result.scores)));
  });
});
