import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import {
  existsSync,
  mkdtempSync,
  readFileSync,
  rmSync,
  writeFileSync,
} from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';

import { latencyStats } from '../src/metrics.mjs';
import { mergeResultArtifacts } from '../src/result-merge.mjs';

function row({
  queryId,
  corpusKey,
  retrieved,
  relevant,
  queryLatencyMs,
  indexBuildMs,
  error,
}) {
  return {
    queryId,
    corpusKey,
    isAbstention: false,
    retrieved,
    relevant,
    scopeIds: ['a', 'b', 'c'],
    scores: [],
    queryLatencyMs,
    latencyMs: queryLatencyMs,
    indexBuildMs,
    ...(error ? { error } : {}),
  };
}

describe('result artifact merge', () => {
  it('reports empty latency distributions with count zero', () => {
    assert.deepEqual(latencyStats([]), {
      count: 0,
      p50: 0,
      p95: 0,
      mean: 0,
      min: 0,
      max: 0,
    });
  });

  it('writes a full immutable merge with canonical rows and recomputed metadata', () => {
    const root = mkdtempSync(join(tmpdir(), 'memory-eval-merge-'));
    try {
      const mergeTarget = join(root, 'eval-source.json');
      const outputDir = join(root, 'output');
      const existing = {
        metadata: {
          retriever: 'marshal-memory-v2',
          queryCount: 99,
          corpusCount: 99,
          totalIndexBuildMs: 999,
          totalDurationMs: 999,
          completedAt: '2026-01-01T00:00:00.000Z',
        },
        aggregate: { totalQueries: 99 },
        perQuery: [
          row({
            queryId: 'q1',
            corpusKey: 'corpus-a',
            retrieved: ['a'],
            relevant: ['a'],
            queryLatencyMs: 10,
            indexBuildMs: 100,
          }),
          row({
            queryId: 'q2',
            corpusKey: 'corpus-a',
            retrieved: [],
            relevant: ['b'],
            queryLatencyMs: 20,
            indexBuildMs: 0,
            error: 'old error',
          }),
          row({
            queryId: 'q3',
            corpusKey: 'corpus-b',
            retrieved: ['c'],
            relevant: ['c'],
            queryLatencyMs: 30,
            indexBuildMs: 0,
          }),
        ],
      };
      writeFileSync(mergeTarget, JSON.stringify(existing, null, 2));
      const sourceBytes = readFileSync(mergeTarget);
      const replacement = row({
        queryId: 'q2',
        corpusKey: 'corpus-c',
        retrieved: ['b'],
        relevant: ['b'],
        queryLatencyMs: 40,
        indexBuildMs: 200,
      });
      const replayResults = {
        metadata: {},
        aggregate: {},
        perQuery: [replacement],
      };
      const now = new Date('2026-08-27T07:15:00.123Z');

      const result = mergeResultArtifacts({
        mergeTarget,
        replayResults,
        outputDir,
        modeName: 'marshal-memory-v2',
        now,
      });

      assert.deepEqual(readFileSync(mergeTarget), sourceBytes);
      assert.equal(
        result.mergedFile,
        join(outputDir, 'eval-source-merged-2026-08-27T07-15-00-123Z.json'),
      );
      assert.notEqual(result.mergedFile, mergeTarget);
      assert.equal(result.replaced, 1);
      assert.equal(result.replaced, replayResults.perQuery.length);
      assert.deepEqual(
        result.merged.perQuery.map(({ queryId }) => queryId),
        ['q1', 'q2', 'q3'],
      );
      assert.equal(new Set(
        result.merged.perQuery.map(({ queryId }) => queryId),
      ).size, 3);
      assert.deepEqual(result.merged.perQuery[0], existing.perQuery[0]);
      assert.deepEqual(result.merged.perQuery[1], replacement);
      assert.deepEqual(result.merged.perQuery[2], existing.perQuery[2]);
      assert.equal(result.merged.perQuery[2].indexBuildMs, 0);

      assert.equal(result.merged.metadata.queryCount, 3);
      assert.equal(result.merged.metadata.corpusCount, 3);
      assert.equal(result.merged.metadata.totalIndexBuildMs, 300);
      assert.equal(result.merged.metadata.totalDurationMs, null);
      assert.equal(result.merged.metadata.completedAt, now.toISOString());
      assert.equal(result.merged.aggregate.totalQueries, 3);
      assert.equal(result.merged.aggregate.errors.total, 0);
      assert.equal(result.merged.aggregate['recall@1'], 1);
      assert.deepEqual(result.merged.aggregate.queryLatency, {
        count: 3,
        p50: 30,
        p95: 39,
        mean: 26.6667,
        min: 10,
        max: 40,
      });
      assert.deepEqual(result.merged.aggregate.indexBuild, {
        count: 2,
        p50: 150,
        p95: 195,
        mean: 150,
        min: 100,
        max: 200,
      });
      assert.deepEqual(
        JSON.parse(readFileSync(result.mergedFile, 'utf8')),
        result.merged,
      );
      assert.deepEqual(
        JSON.parse(readFileSync(result.replayFile, 'utf8')),
        replayResults,
      );
    } finally {
      rmSync(root, { recursive: true, force: true });
    }
  });

  it('rejects unknown and duplicate query IDs before writing artifacts', () => {
    const cases = [
      {
        name: 'unknown replay ID',
        sourceIds: ['q1', 'q2'],
        replayIds: ['missing'],
        error: /absent from merge source: missing/,
      },
      {
        name: 'duplicate source ID',
        sourceIds: ['q1', 'q1'],
        replayIds: ['q1'],
        error: /Merge source contains duplicate queryId: q1/,
      },
      {
        name: 'duplicate replay ID',
        sourceIds: ['q1', 'q2'],
        replayIds: ['q1', 'q1'],
        error: /Replay artifact contains duplicate queryId: q1/,
      },
      {
        name: 'empty source ID',
        sourceIds: [''],
        replayIds: [],
        error: /Merge source perQuery rows must have nonempty queryId values/,
      },
      {
        name: 'empty replay ID',
        sourceIds: ['q1'],
        replayIds: [''],
        error: /Replay artifact perQuery rows must have nonempty queryId values/,
      },
    ];

    for (const testCase of cases) {
      const root = mkdtempSync(join(tmpdir(), 'memory-eval-merge-invalid-'));
      try {
        const mergeTarget = join(root, 'eval-source.json');
        const outputDir = join(root, 'output');
        const rows = testCase.sourceIds.map((queryId, index) => row({
          queryId,
          corpusKey: `corpus-${index}`,
          retrieved: ['a'],
          relevant: ['a'],
          queryLatencyMs: 10,
          indexBuildMs: index === 0 ? 100 : 0,
        }));
        writeFileSync(mergeTarget, JSON.stringify({
          metadata: {},
          aggregate: {},
          perQuery: rows,
        }, null, 2));
        const sourceBytes = readFileSync(mergeTarget);
        const replayRows = testCase.replayIds.map((queryId) => row({
          queryId,
          corpusKey: 'replay-corpus',
          retrieved: ['a'],
          relevant: ['a'],
          queryLatencyMs: 20,
          indexBuildMs: 200,
        }));

        assert.throws(
          () => mergeResultArtifacts({
            mergeTarget,
            replayResults: {
              metadata: {},
              aggregate: {},
              perQuery: replayRows,
            },
            outputDir,
            modeName: 'marshal-memory-v2',
          }),
          testCase.error,
          testCase.name,
        );
        assert.deepEqual(readFileSync(mergeTarget), sourceBytes);
        assert.equal(existsSync(outputDir), false);
      } finally {
        rmSync(root, { recursive: true, force: true });
      }
    }
  });
});
