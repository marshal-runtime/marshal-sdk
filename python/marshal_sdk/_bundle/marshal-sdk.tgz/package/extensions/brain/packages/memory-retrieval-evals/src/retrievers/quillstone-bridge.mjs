/**
 * Quillstone bridge retriever — real production Markdown-bridge path.
 *
 * Uses createMarshalMemoryBridge with:
 *   - Temporary projectionRoot with .memory.md files
 *   - Temporary dataRoot (never the live profile root)
 *   - Real rebuild() and search() through the native graph
 *   - Real SearchService BM25 or hybrid mode
 *
 * For hybrid: uses the real local snowflake-arctic-embed-xs provider
 * pointing to the certified pre-downloaded model cache.
 */

import { mkdtemp, mkdir, writeFile, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';

import {
  createMarshalMemoryBridge,
  MAX_MEMORY_DOCUMENT_BYTES,
} from '@quillstone/marshal-memory-bridge';

const MAX_PROJECTION_BYTES = MAX_MEMORY_DOCUMENT_BYTES - 1;
const MAX_PROJECTION_ID_LENGTH = 128;

function normalizeContent(content) {
  return content.replace(/\r\n/g, '\n').replace(/\r/g, '\n');
}

function safeProjectionId(sessionId) {
  return sessionId.replace(/[^a-zA-Z0-9_-]/g, '_');
}

function firstCodePoints(value, limit) {
  let end = 0;
  let count = 0;
  for (const character of value) {
    end += character.length;
    count += 1;
    if (count === limit) break;
  }
  return value.slice(0, end);
}

function sanitizeProjectionBody(content) {
  return content
    .split('\n')
    .filter(line => line !== '## Retrieval')
    .join('\n');
}

function renderMemoryMarkdown(projectionId, content, synopsis) {
  return [
    '---',
    `id: ${projectionId}`,
    'scope: project',
    'state: active',
    '---',
    `# ${projectionId}`,
    sanitizeProjectionBody(content),
    '',
    '## Retrieval',
    synopsis,
    '',
  ].join('\n');
}

function deriveChunkRetrievalSynopsis(content) {
  const flattened = content.replace(/\n/g, ' ').trim();
  const synopsis = firstCodePoints(flattened, 300)
    .replace(/^#+\s*/g, '')
    .trim();
  if (!synopsis) {
    throw new TypeError('Projection chunk must contain retrieval text.');
  }
  return synopsis;
}

/**
 * Format a corpus session as a valid .memory.md projection file.
 * Preserves the legacy unchunked projection format and synopsis behavior.
 */
export function formatMemoryMarkdown(sessionId, content, turns) {
  const safeId = safeProjectionId(sessionId);
  const lfContent = normalizeContent(content);
  const firstAssistant = turns?.find(turn => turn.role === 'assistant');
  let synopsis = firstAssistant
    ? firstAssistant.content.slice(0, 300).replace(/\r?\n/g, ' ').trim()
    : lfContent.slice(0, 300).replace(/\n/g, ' ').trim();
  if (!synopsis) synopsis = `Memory ${safeId}`;
  synopsis = synopsis.replace(/^#+\s*/g, '');
  if (!synopsis) synopsis = `Memory ${safeId}`;

  return renderMemoryMarkdown(safeId, lfContent, synopsis);
}

function formatChunkMemoryMarkdown(projectionId, content) {
  return renderMemoryMarkdown(
    projectionId,
    content,
    deriveChunkRetrievalSynopsis(content),
  );
}

function projectionFits(projectionId, content) {
  return Buffer.byteLength(
    formatChunkMemoryMarkdown(projectionId, content),
    'utf8',
  ) <= MAX_PROJECTION_BYTES;
}

function codePointBoundaries(content, start) {
  const boundaries = [];
  for (let index = start; index < content.length;) {
    const codePoint = content.codePointAt(index);
    index += codePoint > 0xffff ? 2 : 1;
    boundaries.push(index);
  }
  return boundaries;
}

function largestFittingEnd(content, start, projectionId) {
  const boundaries = codePointBoundaries(content, start);
  let low = 0;
  let high = boundaries.length - 1;
  let fittingEnd = start;

  while (low <= high) {
    const middle = Math.floor((low + high) / 2);
    const end = boundaries[middle];
    if (projectionFits(projectionId, content.slice(start, end))) {
      fittingEnd = end;
      low = middle + 1;
    } else {
      high = middle - 1;
    }
  }

  if (fittingEnd === start) {
    throw new RangeError(`Projection metadata leaves no room for ${projectionId} content.`);
  }
  return fittingEnd;
}

function preferredBoundary(content, start, fittingEnd) {
  const paragraphStart = content.lastIndexOf('\n\n', fittingEnd - 1);
  if (paragraphStart >= start) return paragraphStart + 2;

  const newline = content.lastIndexOf('\n', fittingEnd - 1);
  if (newline >= start) return newline + 1;

  return fittingEnd;
}

function allocateProjectionId(baseId, usedProjectionIds) {
  let projectionId = baseId.slice(0, MAX_PROJECTION_ID_LENGTH);
  let collision = 2;
  while (usedProjectionIds.has(projectionId)) {
    const suffix = `__${collision}`;
    projectionId = `${baseId.slice(0, MAX_PROJECTION_ID_LENGTH - suffix.length)}${suffix}`;
    collision += 1;
  }
  usedProjectionIds.add(projectionId);
  return projectionId;
}

function splitProjectionContent(content, sourceProjectionId, usedProjectionIds) {
  const chunks = [];
  let start = 0;
  let chunkNumber = 1;

  while (start < content.length) {
    const suffix = `__chunk_${String(chunkNumber).padStart(6, '0')}`;
    const chunkId = allocateProjectionId(
      `${sourceProjectionId.slice(0, MAX_PROJECTION_ID_LENGTH - suffix.length)}${suffix}`,
      usedProjectionIds,
    );
    const remaining = content.slice(start);
    let end = content.length;
    if (!projectionFits(chunkId, remaining)) {
      end = preferredBoundary(
        content,
        start,
        largestFittingEnd(content, start, chunkId),
      );
    }
    const chunkContent = content.slice(start, end);
    const markdown = formatChunkMemoryMarkdown(chunkId, chunkContent);
    if (Buffer.byteLength(markdown, 'utf8') > MAX_PROJECTION_BYTES) {
      throw new RangeError(`Projection ${chunkId} exceeds the bridge byte limit.`);
    }
    chunks.push({ projectionId: chunkId, content: chunkContent, markdown });
    start = end;
    chunkNumber += 1;
  }

  return chunks;
}

/**
 * Build deterministic bridge projections without opening the native bridge.
 */
export function buildMemoryProjections(sessions) {
  const projections = [];
  const sessionToSafeId = new Map();
  const projectionToSessionId = new Map();
  const usedProjectionIds = new Set();

  for (const session of sessions) {
    if (sessionToSafeId.has(session.sessionId)) continue;

    const sourceProjectionId = allocateProjectionId(
      safeProjectionId(session.sessionId),
      usedProjectionIds,
    );
    const content = normalizeContent(session.markdown);
    const unchunkedMarkdown = formatMemoryMarkdown(
      sourceProjectionId,
      content,
      session.turns,
    );
    const sourceProjections = Buffer.byteLength(unchunkedMarkdown, 'utf8')
      <= MAX_PROJECTION_BYTES
      ? [{
          projectionId: sourceProjectionId,
          content,
          markdown: unchunkedMarkdown,
        }]
      : splitProjectionContent(content, sourceProjectionId, usedProjectionIds);

    sessionToSafeId.set(session.sessionId, sourceProjections[0].projectionId);
    for (const projection of sourceProjections) {
      projections.push({ ...projection, sessionId: session.sessionId });
      projectionToSessionId.set(projection.projectionId, session.sessionId);
    }
  }

  return {
    projections,
    sessionToSafeId,
    projectionToSessionId,
    projectionOverhang: projections.length - sessionToSafeId.size,
  };
}

/**
 * Initialize a Quillstone bridge for one eval instance corpus.
 * Creates temp dirs, writes .memory.md files, opens bridge, rebuilds.
 */
export async function initBridgeInstance(sessions, memoryMap, options = {}) {
  const { embeddingProvider = null, verbose = false } = options;
  const root = await mkdtemp(join(tmpdir(), 'eval-bridge-'));
  const codeRoot = join(root, 'code');
  const projectionRoot = join(root, 'projections');
  const dataRoot = join(root, 'data');

  await mkdir(join(codeRoot, 'src'), { recursive: true });
  await mkdir(projectionRoot, { recursive: true });
  // Minimal code file required by bridge
  await writeFile(join(codeRoot, 'src', 'placeholder.ts'), 'export {};\n');

  const projection = buildMemoryProjections(sessions);
  for (const document of projection.projections) {
    await writeFile(
      join(projectionRoot, `${document.projectionId}.memory.md`),
      document.markdown,
    );
  }

  let bridge;
  try {
    bridge = await createMarshalMemoryBridge({
      codeRoot,
      projectionRoot,
      dataRoot,
      marshalProfileId: 'eval-profile',
      marshalProjectId: 'eval-project',
      branch: 'main',
      indexMode: 'memory-only',
      embeddingProvider,
    });
  } catch (error) {
    // CopyOnWrite unavailable on some filesystems — report explicitly
    if (error?.category === 'CAPABILITY_UNAVAILABLE') {
      await rm(root, { recursive: true, force: true });
      return { error: `Bridge init failed: ${error.message}`, root: null };
    }
    await rm(root, { recursive: true, force: true });
    throw error;
  }

  let rebuilt;
  try {
    rebuilt = await bridge.rebuild();
  } catch (error) {
    if (error?.category === 'CAPABILITY_UNAVAILABLE') {
      await bridge.close();
      await rm(root, { recursive: true, force: true });
      return { error: `Rebuild failed (copy-on-write): ${error.message}`, root: null };
    }
    await bridge.close();
    await rm(root, { recursive: true, force: true });
    throw error;
  }

  if (verbose) {
    process.stderr.write(`  Bridge rebuilt: ${rebuilt.memoryCount} memories\n`);
  }

  return { bridge, root, rebuilt, ...projection };
}

export function deduplicateProjectionHits(hits, projectionToSessionId, limit) {
  const sessionIds = [];
  const scores = [];
  const seenSessionIds = new Set();

  for (const hit of hits) {
    const projectionId = hit.node?.memoryId;
    const sessionId = projectionToSessionId.get(projectionId) ?? projectionId;
    if (!sessionId || seenSessionIds.has(sessionId)) continue;
    seenSessionIds.add(sessionId);
    sessionIds.push(sessionId);
    scores.push(hit.score);
    if (sessionIds.length >= limit) break;
  }

  return { sessionIds, scores };
}

function projectionSearchLimit(limit, projectionOverhang) {
  return projectionOverhang === 0 ? limit : limit + projectionOverhang;
}

/**
 * Create a Quillstone bridge BM25 retriever (real production path).
 */
export function createBridgeBm25Retriever(bridgeHandle, options = {}) {
  const {
    bridge,
    projectionToSessionId,
    projectionOverhang = 0,
  } = bridgeHandle;
  const limit = options.limit ?? 20;

  return {
    name: 'quillstone-bridge-bm25',
    description: 'Real Quillstone MarshalMemoryBridge BM25 (native, production path)',
    requiresModelDownload: false,
    async retrieve(query) {
      const start = performance.now();
      try {
        const result = await bridge.search({
          query,
          mode: 'bm25',
          kinds: ['memory'],
          limit: projectionSearchLimit(limit, projectionOverhang),
        });
        const latencyMs = performance.now() - start;
        const { sessionIds, scores } = deduplicateProjectionHits(
          result.hits,
          projectionToSessionId,
          limit,
        );

        return {
          sessionIds,
          scores,
          latencyMs,
          mode: 'bridge_bm25',
          hitCount: result.hits.length,
        };
      } catch (e) {
        const latencyMs = performance.now() - start;
        return { sessionIds: [], scores: [], latencyMs, error: e.message };
      }
    },
  };
}

/**
 * Create a Quillstone bridge hybrid retriever (real production path with embeddings).
 */
export function createBridgeHybridRetriever(bridgeHandle, options = {}) {
  const {
    bridge,
    projectionToSessionId,
    projectionOverhang = 0,
  } = bridgeHandle;
  const limit = options.limit ?? 20;

  return {
    name: 'quillstone-bridge-hybrid',
    description: 'Real Quillstone MarshalMemoryBridge hybrid (BM25 + snowflake-arctic-embed-xs RRF)',
    requiresModelDownload: true,
    async retrieve(query) {
      const start = performance.now();
      try {
        const result = await bridge.search({
          query,
          mode: 'hybrid',
          kinds: ['memory'],
          limit: projectionSearchLimit(limit, projectionOverhang),
        });
        const latencyMs = performance.now() - start;
        const { sessionIds, scores } = deduplicateProjectionHits(
          result.hits,
          projectionToSessionId,
          limit,
        );

        return {
          sessionIds,
          scores,
          latencyMs,
          mode: result.mode ?? 'bridge_hybrid',
          hitCount: result.hits.length,
        };
      } catch (e) {
        const latencyMs = performance.now() - start;
        return { sessionIds: [], scores: [], latencyMs, error: e.message };
      }
    },
  };
}

/**
 * Close a bridge instance and clean up temp dirs.
 */
export async function closeBridgeInstance(handle) {
  if (!handle || handle.error) return;
  try { await handle.bridge?.close(); } catch { /* best effort */ }
  if (handle.root) {
    try { await rm(handle.root, { recursive: true, force: true }); } catch { /* */ }
  }
}
