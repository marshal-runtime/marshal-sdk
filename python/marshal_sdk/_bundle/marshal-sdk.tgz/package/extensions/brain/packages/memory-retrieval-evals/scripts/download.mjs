/**
 * Download runnable public retrieval datasets into eval-data/.
 *
 * Re-running skips cached files. Use --force to replace them, and repeat
 * --dataset <id> to download only selected dataset groups.
 */

import { createHash } from 'node:crypto';
import { existsSync, mkdirSync, writeFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { get as httpsGet } from 'node:https';

const __dirname = dirname(fileURLToPath(import.meta.url));
const packageRoot = join(__dirname, '..');
const dataDir = join(packageRoot, 'eval-data');
const force = process.argv.includes('--force');

const DATASETS = [
  {
    id: 'longmemeval-s',
    description: 'LongMemEval-S: 500 relevance-labeled questions',
    license: 'MIT',
    files: [
      {
        url: 'https://huggingface.co/datasets/xiaowu0162/longmemeval-cleaned/resolve/main/longmemeval_s_cleaned.json',
        file: 'longmemeval/longmemeval_s_cleaned.json',
      },
    ],
  },
  {
    id: 'longmemeval-oracle',
    description: 'LongMemEval oracle evidence-only sessions',
    license: 'MIT',
    files: [
      {
        url: 'https://huggingface.co/datasets/xiaowu0162/longmemeval-cleaned/resolve/main/longmemeval_oracle.json',
        file: 'longmemeval/longmemeval_oracle.json',
      },
    ],
  },
  {
    id: 'locomo',
    description: 'LoCoMo official 10-conversation JSON',
    license: 'CC-BY-NC-4.0',
    files: [
      {
        url: 'https://raw.githubusercontent.com/snap-research/locomo/main/data/locomo10.json',
        file: 'locomo/locomo10.json',
      },
    ],
  },
  {
    id: 'beam-100k',
    description: 'BEAM smallest tier: 128K label, official 100K GitHub files',
    license: 'CC-BY-SA-4.0',
    files: Array.from({ length: 20 }, (_, index) => {
      const chatNumber = index + 1;
      const base = `https://raw.githubusercontent.com/mohammadtavakoli78/BEAM/main/chats/100K/${chatNumber}`;
      return [
        {
          url: `${base}/chat.json`,
          file: `beam/100K/${chatNumber}/chat.json`,
        },
        {
          url: `${base}/probing_questions/probing_questions.json`,
          file: `beam/100K/${chatNumber}/probing_questions/probing_questions.json`,
        },
      ];
    }).flat(),
  },
];

function fetch(url) {
  return new Promise((resolve, reject) => {
    function request(targetUrl, redirectCount = 0) {
      if (redirectCount > 5) {
        reject(new Error(`Too many redirects for ${url}`));
        return;
      }
      if (!targetUrl.startsWith('https:')) {
        reject(new Error(`Only HTTPS URLs are supported: ${targetUrl}`));
        return;
      }

      httpsGet(targetUrl, (response) => {
        if (
          response.statusCode >= 300
          && response.statusCode < 400
          && response.headers.location
        ) {
          response.resume();
          request(new URL(response.headers.location, targetUrl).href, redirectCount + 1);
          return;
        }
        if (response.statusCode !== 200) {
          response.resume();
          reject(new Error(`HTTP ${response.statusCode} for ${targetUrl}`));
          return;
        }

        const chunks = [];
        response.on('data', (chunk) => chunks.push(chunk));
        response.on('end', () => resolve(Buffer.concat(chunks)));
        response.on('error', reject);
      }).on('error', reject);
    }

    request(url);
  });
}

async function downloadFile(file) {
  const targetPath = join(dataDir, file.file);
  if (existsSync(targetPath) && !force) {
    return {
      file: file.file,
      status: 'cached',
      path: targetPath,
    };
  }

  const data = await fetch(file.url);
  mkdirSync(dirname(targetPath), { recursive: true });
  writeFileSync(targetPath, data);
  const sha256 = createHash('sha256').update(data).digest('hex');
  return {
    file: file.file,
    status: 'downloaded',
    path: targetPath,
    sizeBytes: data.length,
    sha256,
  };
}

async function downloadDataset(dataset) {
  console.log(`  ↓ ${dataset.id}: ${dataset.description}`);
  const files = [];
  for (const file of dataset.files) {
    files.push(await downloadFile(file));
  }

  const downloaded = files.filter((file) => file.status === 'downloaded');
  const downloadedBytes = downloaded
    .reduce((sum, file) => sum + file.sizeBytes, 0);
  console.log(
    `  ✓ ${dataset.id}: ${files.length} files`
    + `${downloaded.length ? `, downloaded ${downloadedBytes} bytes` : ', cached'}`
  );
  return {
    id: dataset.id,
    status: downloaded.length > 0 ? 'downloaded' : 'cached',
    files,
  };
}

function requestedDatasetIds() {
  const ids = [];
  for (let index = 0; index < process.argv.length; index++) {
    if (process.argv[index] !== '--dataset') continue;
    const id = process.argv[index + 1];
    if (!id || id.startsWith('--')) {
      throw new Error('--dataset requires a dataset ID.');
    }
    ids.push(id === 'beam-128k' ? 'beam-100k' : id);
    index++;
  }
  return ids;
}

async function main() {
  const requestedIds = requestedDatasetIds();
  const knownIds = new Set(DATASETS.map((dataset) => dataset.id));
  const unknownIds = requestedIds.filter((id) => !knownIds.has(id));
  if (unknownIds.length > 0) {
    throw new Error(
      `Unknown dataset ID(s): ${unknownIds.join(', ')}. Available: ${[...knownIds].join(', ')}`
    );
  }

  const requestedSet = new Set(requestedIds);
  const selected = requestedSet.size === 0
    ? DATASETS
    : DATASETS.filter((dataset) => requestedSet.has(dataset.id));

  console.log('Memory retrieval eval dataset download');
  console.log(`Target: ${dataDir}\n`);
  mkdirSync(dataDir, { recursive: true });

  const results = [];
  for (const dataset of selected) {
    try {
      results.push(await downloadDataset(dataset));
    } catch (error) {
      console.error(`  ✗ ${dataset.id}: ${error.message}`);
      results.push({
        id: dataset.id,
        status: 'error',
        error: error.message,
      });
    }
  }

  const manifest = {
    downloadedAt: new Date().toISOString(),
    datasets: results,
  };
  writeFileSync(
    join(dataDir, 'manifest.json'),
    JSON.stringify(manifest, null, 2)
  );

  const ok = results.filter((result) => result.status !== 'error').length;
  const failed = results.length - ok;
  console.log(`\nDone: ${ok} available, ${failed} failed.`);
  if (failed > 0) process.exitCode = 1;
}

main().catch((error) => {
  console.error(`Download failed: ${error.message}`);
  process.exitCode = 1;
});
