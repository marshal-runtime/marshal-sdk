/** Memory retrieval evaluation runner for the real Marshal runtime paths. */

import {
  existsSync,
  mkdirSync,
  writeFileSync,
} from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { parseArgs } from 'node:util';

import { loadLongMemEvalS } from './datasets/longmemeval.mjs';
import { loadLongMemEvalV2Status } from './datasets/longmemeval-v2.mjs';
import { loadLoCoMo } from './datasets/locomo.mjs';
import { loadMemoryAgentBenchConflict } from './datasets/memoryagentbench.mjs';
import { loadBeam100K } from './datasets/beam.mjs';
import { loadMarshalCorpus } from './marshal-corpus.mjs';
import { runEvaluation, formatResults, stratifiedSample } from './harness.mjs';
import { mergeResultArtifacts } from './result-merge.mjs';
import { createBrokenRetriever } from './retrievers/broken.mjs';
import { createBrainRetriever } from './retrievers/brain-e2e.mjs';

const __dirname = dirname(fileURLToPath(import.meta.url));
const packageRoot = join(__dirname, '..');
const EMBEDDING_CACHE_PATH = process.env.MARSHAL_EMBEDDING_CACHE
  ?? join(packageRoot, 'eval-cache', 'snowflake-arctic-embed-xs-cache');
const DEFAULT_OUTPUT = process.env.MARSHAL_EVAL_OUTPUT
  ?? join(packageRoot, 'results');

const { values: args } = parseArgs({
  options: {
    dataset: { type: 'string', default: 'longmemeval-s' },
    mode: { type: 'string', default: 'marshal-memory-v2' },
    slice: { type: 'string', default: '' },
    ids: { type: 'string', default: '' },
    'query-id': { type: 'string', multiple: true, default: [] },
    stratified: { type: 'boolean', default: false },
    merge: { type: 'string', default: '' },
    output: { type: 'string', default: DEFAULT_OUTPUT },
    verbose: { type: 'boolean', default: false },
    help: { type: 'boolean', default: false },
  },
});

const DATASET_LOADERS = {
  'longmemeval-s': loadLongMemEvalS,
  'longmemeval-v2': loadLongMemEvalV2Status,
  locomo: loadLoCoMo,
  memoryagentbench: loadMemoryAgentBenchConflict,
  'memoryagentbench-conflict': loadMemoryAgentBenchConflict,
  'beam-100k': loadBeam100K,
  'beam-128k': loadBeam100K,
  'marshal-custom': loadMarshalCorpus,
};

const VALID_MODES = [
  'marshal-memory-v2',
  'quillstone-bridge-bm25',
  'quillstone-bridge-hybrid',
  'brain',
  'broken',
  'shuffled-labels',
];

async function createEmbeddingProvider() {
  const {
    createLocalEmbeddingProvider,
    CERTIFIED_LOCAL_EMBEDDING_MODEL_REVISION,
  } = await import('@quillstone/embedding-runtime');
  const provider = createLocalEmbeddingProvider({
    configuration: {
      revision: CERTIFIED_LOCAL_EMBEDDING_MODEL_REVISION,
      cacheDirectory: EMBEDDING_CACHE_PATH,
      device: 'cpu',
      allowCpuFallback: false,
      localFilesOnly: true,
    },
  });
  console.log(`Embedding: ${provider.model} (${provider.dimensions}d, local cache)`);
  return provider;
}

async function main() {
  if (args.help) {
    printHelp();
    return;
  }

  const datasetName = args.dataset;
  const modeName = args.mode;
  const slice = args.slice ? Number(args.slice) : undefined;
  if (args.slice && (!Number.isInteger(slice) || slice <= 0)) {
    throw new Error(`--slice must be a positive integer, received: ${args.slice}`);
  }

  const legacyIds = args.ids
    ? args.ids.split(',').map((value) => value.trim()).filter(Boolean)
    : [];
  const requestedIds = [...new Set([...legacyIds, ...args['query-id']])];
  const mergeTarget = args.merge || '';
  const outputDir = args.output;

  console.log('Memory Retrieval Evaluation (real runtime)');
  console.log(
    `Dataset: ${datasetName} | Mode: ${modeName}`
    + `${slice ? ` | Slice: ${slice}` : ''}`
    + `${requestedIds.length ? ` | IDs: ${requestedIds.length}` : ''}\n`
  );

  if (!VALID_MODES.includes(modeName)) {
    console.error(`Unknown mode: ${modeName}\nAvailable: ${VALID_MODES.join(', ')}`);
    process.exitCode = 1;
    return;
  }

  if (modeName === 'brain') {
    const brain = createBrainRetriever();
    console.error(`ERROR: ${brain.unavailableReason}`);
    process.exitCode = 1;
    return;
  }

  const loader = DATASET_LOADERS[datasetName];
  if (!loader) {
    console.error(
      `Unknown dataset: ${datasetName}\nAvailable: ${Object.keys(DATASET_LOADERS).join(', ')}`
    );
    process.exitCode = 1;
    return;
  }

  const loaderSlice = args.stratified || requestedIds.length ? undefined : slice;
  let { instances, metadata: datasetMeta } = loader({
    slice: loaderSlice,
    queryIds: requestedIds.length ? requestedIds : undefined,
  });

  if (requestedIds.length) {
    const idSet = new Set(requestedIds);
    instances = instances.filter((instance) =>
      idSet.has(instance.instanceId) || idSet.has(instance.query?.queryId)
    );
    const found = new Set(instances.flatMap((instance) => [
      instance.instanceId,
      instance.query?.queryId,
    ]));
    const missing = requestedIds.filter((id) => !found.has(id));
    if (missing.length > 0) {
      throw new Error(`IDs not found or not runnable: ${missing.join(', ')}`);
    }
  }

  if (args.stratified && slice) {
    instances = stratifiedSample(instances, slice);
  } else if (slice && requestedIds.length) {
    instances = instances.slice(0, slice);
  }

  if (instances.length === 0) {
    console.error(`No instances loaded for dataset ${datasetName}.`);
    if (datasetMeta.status) console.error(`Status: ${datasetMeta.status}`);
    if (datasetMeta.note) console.error(datasetMeta.note);
    process.exitCode = 1;
    return;
  }

  console.log(
    `Loaded ${instances.length} instances from ${datasetName}`
    + `${args.stratified ? ' (stratified)' : ''}`
  );
  console.log(
    `Source: ${datasetMeta.source}`
    + ` | License: ${datasetMeta.license ?? datasetMeta.dataLicense}\n`
  );

  let retrieverOptions = {};
  let embeddingProvider = null;
  if (modeName === 'broken') {
    retrieverOptions = { retriever: createBrokenRetriever() };
  } else if (modeName === 'quillstone-bridge-hybrid') {
    try {
      embeddingProvider = await createEmbeddingProvider();
    } catch (error) {
      console.error(`ERROR: Cannot create embedding provider: ${error.message}`);
      console.error(`Hybrid mode requires model cache at: ${EMBEDDING_CACHE_PATH}`);
      process.exitCode = 1;
      return;
    }
  }

  let results;
  try {
    results = await runEvaluation(instances, {
      mode: modeName,
      limit: 20,
      verbose: args.verbose,
      embeddingProvider,
      ...retrieverOptions,
      onProgress: ({ completed, total, queryId }) => {
        if (args.verbose) {
          process.stdout.write(`  [${completed}/${total}] ${queryId}\r`);
        }
      },
    });
  } finally {
    await embeddingProvider?.dispose?.();
  }

  results.dataset = datasetMeta;
  console.log(formatResults(results));

  if (modeName === 'broken') {
    const recall1 = results.aggregate['recall@1'];
    const reciprocalRank = results.aggregate.mrr;
    if (recall1 > 0.05 || reciprocalRank > 0.05) {
      console.error(
        `ERROR: Broken retriever scored Recall@1=${recall1}, MRR=${reciprocalRank} — should be ~0`
      );
      process.exitCode = 1;
      return;
    }
    console.log('✓ Broken retriever correctly detected: all metrics near zero.');
  }

  if (mergeTarget && existsSync(mergeTarget)) {
    const merged = mergeResultArtifacts({
      mergeTarget,
      replayResults: results,
      outputDir,
      modeName,
    });
    console.log(`Merged ${merged.replaced} corrected rows into: ${merged.mergedFile}`);
    console.log(`Replay: ${merged.replayFile}`);
    return;
  }

  mkdirSync(outputDir, { recursive: true });
  const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
  const resultFile = join(
    outputDir,
    `eval-${datasetName}-${modeName}-${timestamp}.json`
  );
  writeFileSync(resultFile, JSON.stringify(results, null, 2));
  console.log(`Results: ${resultFile}`);
}

function printHelp() {
  console.log(`Memory Retrieval Evaluation (real runtime)

Usage:
  node src/run.mjs --dataset <name> --mode <mode> [options]

Runnable IR datasets:
  longmemeval-s
  locomo
  beam-100k       Canonical ID for the upstream 100K files
  beam-128k       Alias for the paper/README 128K tier label
  marshal-custom  In-repo custom corpus, not public benchmark evidence

Status-only in this IR harness:
  memoryagentbench-conflict
  longmemeval-v2

Real modes:
  marshal-memory-v2
  quillstone-bridge-bm25
  quillstone-bridge-hybrid
  broken
  shuffled-labels

Options:
  --slice <count>     Deterministic first N runnable queries
  --stratified        Stratify a bounded slice by question type
  --ids <id,...>      Legacy comma-separated exact instance IDs
  --query-id <id>     Exact canonical query ID; repeat for multiple IDs
  --merge <path>      Read an existing result and write a new merged artifact
  --output <path>     Results directory
  --verbose           Show per-query progress
  --help              Show this help
`);
}

main().catch((error) => {
  console.error('Fatal:', error);
  process.exitCode = 1;
});
