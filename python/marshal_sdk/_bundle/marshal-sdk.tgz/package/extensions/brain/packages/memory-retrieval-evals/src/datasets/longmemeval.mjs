/**
 * LongMemEval-S dataset adapter.
 *
 * Loads the 500-question LongMemEval-S dataset and normalizes it into
 * the common evaluation format: corpus sessions + benchmark queries
 * with relevance labels.
 *
 * Upstream format per instance:
 *   question_id, question_type, question, answer, question_date,
 *   haystack_session_ids, haystack_dates, haystack_sessions,
 *   answer_session_ids
 *
 * Each haystack_session is an array of turns {role, content, has_answer?}.
 */

import { readFileSync, existsSync } from 'node:fs';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = dirname(fileURLToPath(import.meta.url));
const packageRoot = join(__dirname, '..', '..');
const defaultPath = join(packageRoot, 'eval-data', 'longmemeval', 'longmemeval_s_cleaned.json');

/**
 * @typedef {Object} EvalSession
 * @property {string} sessionId
 * @property {string} date
 * @property {Array<{role: string, content: string}>} turns
 * @property {string} markdown - Markdown-formatted session content
 */

/**
 * @typedef {Object} EvalQuery
 * @property {string} queryId
 * @property {string} questionType
 * @property {string} question
 * @property {string} answer
 * @property {string} questionDate
 * @property {string[]} relevantSessionIds
 * @property {boolean} isAbstention
 */

/**
 * @typedef {Object} EvalInstance
 * @property {string} instanceId - question_id from upstream
 * @property {EvalQuery} query
 * @property {EvalSession[]} corpus - all haystack sessions
 */

/**
 * Convert a session's turns into Markdown, preserving upstream text.
 */
function sessionToMarkdown(turns, sessionId, date) {
  const lines = [`# Session: ${sessionId}`, `Date: ${date}`, ''];
  for (const turn of turns) {
    const role = turn.role === 'user' ? 'User' : 'Assistant';
    // Normalize CRLF to LF — bridge requires LF-only
    const text = turn.content.replace(/\r\n/g, '\n').replace(/\r/g, '\n');
    lines.push(`**${role}**: ${text}`, '');
  }
  return lines.join('\n');
}

/**
 * Load and normalize the LongMemEval-S dataset.
 * @param {Object} [options]
 * @param {string} [options.path] - Path to the JSON file
 * @param {number} [options.slice] - Limit to first N instances
 * @returns {{ instances: EvalInstance[], metadata: Object }}
 */
export function loadLongMemEvalS(options = {}) {
  const filePath = options.path ?? defaultPath;
  if (!existsSync(filePath)) {
    throw new Error(
      `LongMemEval-S data not found at ${filePath}. Run: node scripts/download.mjs`
    );
  }

  const raw = JSON.parse(readFileSync(filePath, 'utf8'));
  const items = Array.isArray(raw) ? raw : raw.data ?? raw.instances ?? [];

  let instances = items.map((item) => {
    const sessionIds = item.haystack_session_ids ?? [];
    const dates = item.haystack_dates ?? [];
    const sessions = item.haystack_sessions ?? [];
    const answerSessionIds = new Set(item.answer_session_ids ?? []);
    const questionId = item.question_id ?? item.id ?? '';
    const isAbstention = questionId.endsWith('_abs');

    const corpus = sessions.map((turns, idx) => {
      const sid = sessionIds[idx] ?? `session-${idx}`;
      const date = dates[idx] ?? '';
      return {
        sessionId: sid,
        date,
        turns: turns.map((t) => ({ role: t.role, content: t.content })),
        markdown: sessionToMarkdown(turns, sid, date),
      };
    });

    return {
      instanceId: questionId,
      query: {
        queryId: questionId,
        questionType: item.question_type ?? 'unknown',
        question: item.question,
        answer: item.answer,
        questionDate: item.question_date ?? '',
        relevantSessionIds: [...answerSessionIds],
        isAbstention,
      },
      corpus,
    };
  });

  if (options.slice && options.slice > 0) {
    instances = instances.slice(0, options.slice);
  }

  return {
    instances,
    metadata: {
      dataset: 'longmemeval-s',
      source: 'huggingface:xiaowu0162/longmemeval-cleaned',
      license: 'MIT',
      totalQuestions: items.length,
      loadedQuestions: instances.length,
      filePath,
    },
  };
}
