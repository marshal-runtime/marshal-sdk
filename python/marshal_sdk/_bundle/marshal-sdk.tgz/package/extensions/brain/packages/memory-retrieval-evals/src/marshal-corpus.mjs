/**
 * Marshal-specific custom evaluation corpus.
 *
 * CUSTOM CORPUS — NOT PUBLIC BENCHMARK EVIDENCE.
 *
 * A small hand-crafted corpus testing Marshal-specific capabilities:
 * - Code-memory links (memories linked to code symbols)
 * - Scope isolation (workspace vs project vs session memories)
 * - Supersession (newer memories replacing older ones)
 * - Blast radius (memories about code changes and their impact)
 *
 * Queries are phrased independently from memory text to avoid
 * leaking memory wording into retrieval queries.
 */

/**
 * Generate the Marshal custom corpus.
 * All content is clearly identified as custom, not public benchmark data.
 *
 * QUERY INTEGRITY: Queries use genuinely different wording and semantic
 * cues from the target memory text. Decoys share obvious nouns with
 * targets to prevent trivial keyword matching from succeeding.
 *
 * @returns {{ instances: Array, metadata: Object }}
 */
export function loadMarshalCorpus() {
  const instances = [
    // Code-memory links
    {
      instanceId: 'marshal-code-link-1',
      query: {
        queryId: 'marshal-code-link-1',
        questionType: 'code-memory-link',
        // Semantic paraphrase: asks about credential renewal without naming the function/file
        question: 'How does the system handle expired login credentials without losing the session?',
        answer: 'refreshAuthToken in auth-service.ts',
        relevantSessionIds: ['marshal-sess-auth-impl'],
        isAbstention: false,
      },
      corpus: [
        makeSession('marshal-sess-auth-impl', '2024-03-15', [
          ['user', 'I need to implement token refresh logic for our auth service'],
          ['assistant', 'I\'ll create the refreshAuthToken function in auth-service.ts that handles JWT token renewal with retry logic and expiry validation.'],
          ['user', 'Make sure it handles expired refresh tokens gracefully'],
          ['assistant', 'Added error handling for expired refresh tokens in refreshAuthToken — it now clears the session and redirects to login when the refresh token itself has expired.'],
        ]),
        // Decoy: shares "session" and "login" nouns but is about UI
        makeSession('marshal-sess-login-ui', '2024-03-16', [
          ['user', 'The login page session timer display is wrong'],
          ['assistant', 'Fixed the countdown timer on the login page — it now correctly shows remaining seconds before the session idle timeout expires.'],
        ]),
        makeSession('marshal-sess-css-fix', '2024-03-14', [
          ['user', 'The sidebar menu is overlapping on mobile'],
          ['assistant', 'Fixed the z-index and added a media query breakpoint at 768px for the sidebar navigation.'],
        ]),
      ],
    },

    // Scope isolation
    {
      instanceId: 'marshal-scope-1',
      query: {
        queryId: 'marshal-scope-1',
        questionType: 'scope-isolation',
        // Semantic paraphrase: asks about tracking purchase lifecycle without naming table/column
        question: 'How do we record the lifecycle of a purchase from placement through fulfillment?',
        answer: 'Adding a status_history JSONB column',
        relevantSessionIds: ['marshal-sess-orders-db'],
        isAbstention: false,
      },
      corpus: [
        makeSession('marshal-sess-orders-db', '2024-04-01', [
          ['user', 'We need to track order status changes over time'],
          ['assistant', 'I recommend adding a status_history JSONB column to the orders table with a migration that backfills existing records from the audit log.'],
        ]),
        // Decoy: shares "orders" and "table" nouns but is about display
        makeSession('marshal-sess-orders-ui', '2024-04-03', [
          ['user', 'The orders table in the admin dashboard is too slow to render'],
          ['assistant', 'Added virtual scrolling to the orders table component so only visible rows render. Pagination now loads 50 rows at a time.'],
        ]),
        makeSession('marshal-sess-users-db', '2024-04-02', [
          ['user', 'Add email verification to user signup'],
          ['assistant', 'Added an email_verified boolean column to the users table and created the verification token flow.'],
        ]),
      ],
    },

    // Supersession
    {
      instanceId: 'marshal-supersession-1',
      query: {
        queryId: 'marshal-supersession-1',
        questionType: 'supersession',
        // Semantic paraphrase: asks about shared-state strategy without naming Redis/cache/TTL
        question: 'After scaling horizontally, what strategy keeps frequently-accessed data consistent across replicas?',
        answer: 'Redis with TTL-based invalidation',
        relevantSessionIds: ['marshal-sess-cache-v2'],
        isAbstention: false,
      },
      corpus: [
        makeSession('marshal-sess-cache-v1', '2024-02-10', [
          ['user', 'How should we cache API responses?'],
          ['assistant', 'For API response caching, I recommend using in-memory LRU cache with a 5-minute TTL. This avoids external dependencies.'],
        ]),
        makeSession('marshal-sess-cache-v2', '2024-05-20', [
          ['user', 'The in-memory cache is causing issues at scale with multiple pods'],
          ['assistant', 'For multi-pod deployments, switch to Redis with TTL-based invalidation. This replaces the earlier in-memory LRU approach and provides consistent cache state across all instances.'],
        ]),
        // Decoy: shares "scale" and "pods" nouns but is about monitoring
        makeSession('marshal-sess-scaling-monitor', '2024-05-22', [
          ['user', 'We need to monitor pod scaling events'],
          ['assistant', 'Set up Prometheus alerts for horizontal pod autoscaler events so the team gets notified when replicas scale beyond the configured threshold.'],
        ]),
      ],
    },

    // Blast radius
    {
      instanceId: 'marshal-blast-1',
      query: {
        queryId: 'marshal-blast-1',
        questionType: 'blast-radius',
        // Semantic paraphrase: asks about downstream breakage without naming the interface
        question: 'Which services needed updates after the billing contract was restructured?',
        answer: 'checkout, subscription-renewal, and refund-processor services',
        relevantSessionIds: ['marshal-sess-payment-refactor'],
        isAbstention: false,
      },
      corpus: [
        makeSession('marshal-sess-payment-refactor', '2024-06-01', [
          ['user', 'I\'m refactoring the payment processing interface'],
          ['assistant', 'Changing the PaymentProcessor interface will affect three downstream services: checkout-service (processOrder calls), subscription-renewal (handleRecurring calls), and refund-processor (initiateRefund calls). Each needs adapter updates.'],
        ]),
        // Decoy: shares "service" and "checkout" nouns but is about analytics
        makeSession('marshal-sess-checkout-analytics', '2024-06-03', [
          ['user', 'Track checkout funnel conversion rates'],
          ['assistant', 'Added analytics events at each checkout step so the service can report conversion rates from cart to completed purchase.'],
        ]),
        makeSession('marshal-sess-logging', '2024-06-02', [
          ['user', 'Add structured logging to the API gateway'],
          ['assistant', 'Added structured JSON logging with correlation IDs to the gateway middleware.'],
        ]),
      ],
    },

    // Abstention case — query about something not in any session
    {
      instanceId: 'marshal-abstention-1',
      query: {
        queryId: 'marshal-abstention-1',
        questionType: 'abstention',
        question: 'What throughput did the GraphQL gateway achieve under synthetic load?',
        answer: '',
        relevantSessionIds: [],
        isAbstention: true,
      },
      corpus: [
        // Decoy: shares "performance" and "benchmarks" but is REST, not GraphQL
        makeSession('marshal-sess-rest-perf', '2024-07-01', [
          ['user', 'Run performance benchmarks on the REST API'],
          ['assistant', 'REST API benchmarks complete: p50=12ms, p95=45ms, p99=120ms under 1000 RPS.'],
        ]),
      ],
    },

    // Code-memory link with linked elements
    {
      instanceId: 'marshal-code-link-2',
      query: {
        queryId: 'marshal-code-link-2',
        questionType: 'code-memory-link',
        // Semantic paraphrase: asks about resilient persistent-store access without naming pool/pg
        question: 'How does the app maintain resilient access to the persistent store when individual connections drop?',
        answer: 'Singleton connection pool with health-check pings',
        relevantSessionIds: ['marshal-sess-db-pool'],
        isAbstention: false,
      },
      corpus: [
        makeSession('marshal-sess-db-pool', '2024-08-10', [
          ['user', 'We need a robust database connection pool'],
          ['assistant', 'Implemented a singleton connection pool in db-pool.ts using pg-pool with health-check pings every 30 seconds and automatic reconnection. Max pool size is configured via environment variable DB_POOL_MAX.'],
        ]),
        // Decoy: shares "database" and "connection" nouns but is about migration tooling
        makeSession('marshal-sess-db-migrate-tool', '2024-08-12', [
          ['user', 'The database migration tool keeps losing its connection mid-run'],
          ['assistant', 'Wrapped the migration runner in a retry loop with exponential backoff. Each migration step now opens its own short-lived connection instead of reusing one long-lived handle.'],
        ]),
        makeSession('marshal-sess-unrelated', '2024-08-11', [
          ['user', 'Update the footer copyright year'],
          ['assistant', 'Updated the footer component to show 2024 copyright.'],
        ]),
      ],
    },

    // Scope isolation — cross-project
    {
      instanceId: 'marshal-scope-2',
      query: {
        queryId: 'marshal-scope-2',
        questionType: 'scope-isolation',
        // Semantic paraphrase: asks about unit-level verification tooling without naming Vitest/MSW
        question: 'What toolchain was adopted for isolated unit-level verification of distributed service logic?',
        answer: 'Vitest with MSW for API mocking',
        relevantSessionIds: ['marshal-sess-test-setup'],
        isAbstention: false,
      },
      corpus: [
        makeSession('marshal-sess-test-setup', '2024-09-01', [
          ['user', 'Choose a testing framework for our microservices'],
          ['assistant', 'For the microservices project, Vitest with MSW for API mocking provides the best combination of speed and realistic HTTP interception. Setting up shared test utilities in packages/test-utils.'],
        ]),
        // Decoy: shares "testing" and "services" nouns but is about E2E
        makeSession('marshal-sess-e2e', '2024-09-05', [
          ['user', 'Set up end-to-end testing for the services'],
          ['assistant', 'Configured Playwright for E2E tests with Docker Compose for service orchestration.'],
        ]),
      ],
    },

    // Supersession — config change
    {
      instanceId: 'marshal-supersession-2',
      query: {
        queryId: 'marshal-supersession-2',
        questionType: 'supersession',
        // Semantic paraphrase: asks about automated build orchestration without naming GitHub Actions/CI
        question: 'What does the team\'s current automated build and verification orchestration look like?',
        answer: 'GitHub Actions with reusable workflows',
        relevantSessionIds: ['marshal-sess-ci-v2'],
        isAbstention: false,
      },
      corpus: [
        makeSession('marshal-sess-ci-v1', '2024-01-15', [
          ['user', 'Set up CI for the project'],
          ['assistant', 'Configured CircleCI with parallel test runners and artifact caching.'],
        ]),
        makeSession('marshal-sess-ci-v2', '2024-07-20', [
          ['user', 'We\'re migrating from CircleCI to reduce costs'],
          ['assistant', 'Migrated the CI pipeline to GitHub Actions with reusable workflows. The new setup uses matrix builds for multi-platform testing and composite actions for shared steps. This replaces the CircleCI configuration.'],
        ]),
        // Decoy: shares "build" and "pipeline" nouns but is about artifact storage
        makeSession('marshal-sess-artifact-store', '2024-07-22', [
          ['user', 'Our build artifacts are filling up the pipeline storage'],
          ['assistant', 'Added a retention policy that expires build artifacts after 14 days. Nightly cleanup job removes orphaned blobs from the artifact store.'],
        ]),
      ],
    },

    // Blast radius — schema change
    {
      instanceId: 'marshal-blast-2',
      query: {
        queryId: 'marshal-blast-2',
        questionType: 'blast-radius',
        // Semantic paraphrase: asks about routes impacted by a data-model revision
        question: 'Which server routes had to be rewritten after the account data model was revised?',
        answer: '/api/profile, /api/settings, and /api/export endpoints',
        relevantSessionIds: ['marshal-sess-profile-schema'],
        isAbstention: false,
      },
      corpus: [
        makeSession('marshal-sess-profile-schema', '2024-10-01', [
          ['user', 'Update the user profile to include display preferences'],
          ['assistant', 'Updated the UserProfile schema to include displayPreferences. This change required updates to three API endpoints: /api/profile (GET/PUT), /api/settings (PATCH), and /api/export (GET) which all serialize the profile object.'],
        ]),
        // Decoy: shares "API" and "schema" nouns but is about a different schema
        makeSession('marshal-sess-product-schema', '2024-10-03', [
          ['user', 'The product API schema needs versioning'],
          ['assistant', 'Added Accept-Version header support to the product API so clients can pin to v1 while we roll out v2 schema changes gradually.'],
        ]),
        makeSession('marshal-sess-notification', '2024-10-02', [
          ['user', 'Add push notification support'],
          ['assistant', 'Implemented push notifications using Firebase Cloud Messaging with topic-based subscription.'],
        ]),
      ],
    },

    // Multi-session reasoning
    {
      instanceId: 'marshal-multi-1',
      query: {
        queryId: 'marshal-multi-1',
        questionType: 'multi-session',
        // Semantic paraphrase: asks about evolution of failure-recovery philosophy
        question: 'How has the team\'s philosophy for surfacing and recovering from unexpected failures evolved?',
        answer: 'Started with try-catch, moved to Result types, then added error boundaries',
        relevantSessionIds: ['marshal-sess-err-v1', 'marshal-sess-err-v2', 'marshal-sess-err-v3'],
        isAbstention: false,
      },
      corpus: [
        makeSession('marshal-sess-err-v1', '2024-03-01', [
          ['user', 'How should we handle errors in the service layer?'],
          ['assistant', 'Using try-catch blocks with a centralized error logger. Each service method catches exceptions and logs them before re-throwing.'],
        ]),
        makeSession('marshal-sess-err-v2', '2024-05-15', [
          ['user', 'The try-catch approach makes error flow hard to follow'],
          ['assistant', 'Migrated to Result types (Ok/Err pattern) for explicit error handling. Functions now return Result<T, E> instead of throwing, making error paths visible in the type system.'],
        ]),
        makeSession('marshal-sess-err-v3', '2024-08-01', [
          ['user', 'We still need to handle unexpected errors at the component level'],
          ['assistant', 'Added React error boundaries as a safety net for unexpected rendering errors. These complement the Result types used in the service layer by catching errors that escape the typed error handling.'],
        ]),
        // Decoy: shares "error" and "handling" nouns but is about logging config
        makeSession('marshal-sess-err-logging', '2024-08-03', [
          ['user', 'Configure error log levels for different environments'],
          ['assistant', 'Set error logging to verbose in development and warning-only in production. Sentry captures unhandled exceptions regardless of log level.'],
        ]),
      ],
    },

    // Abstention — related but not matching
    {
      instanceId: 'marshal-abstention-2',
      query: {
        queryId: 'marshal-abstention-2',
        questionType: 'abstention',
        question: 'Was there a decision to switch the primary datastore from relational to document-oriented?',
        answer: '',
        relevantSessionIds: [],
        isAbstention: true,
      },
      corpus: [
        // Decoy: shares "PostgreSQL" and "queries" nouns but is about optimization, not migration
        makeSession('marshal-sess-pg-optimize', '2024-04-10', [
          ['user', 'Our PostgreSQL queries are slow'],
          ['assistant', 'Added composite indexes on the orders table and rewrote the analytics queries to use materialized views. Query time dropped from 2s to 50ms.'],
        ]),
      ],
    },

    // Temporal reasoning
    {
      instanceId: 'marshal-temporal-1',
      query: {
        queryId: 'marshal-temporal-1',
        questionType: 'temporal',
        // Semantic paraphrase: asks about the original container orchestration before the cluster shift
        question: 'What container orchestration approach was in place before the team adopted a cluster scheduler?',
        answer: 'Docker Compose with Nginx reverse proxy',
        relevantSessionIds: ['marshal-sess-deploy-old'],
        isAbstention: false,
      },
      corpus: [
        makeSession('marshal-sess-deploy-old', '2024-01-10', [
          ['user', 'Set up the deployment configuration'],
          ['assistant', 'Created Docker Compose configuration with Nginx as reverse proxy, handling SSL termination and load balancing across two app containers.'],
        ]),
        // Decoy: shares "deployment" and "container" nouns but is about a different topic
        makeSession('marshal-sess-container-registry', '2024-06-14', [
          ['user', 'Our container images are too large for deployment'],
          ['assistant', 'Switched to multi-stage builds with Alpine base images. Container deployment size dropped from 1.2GB to 180MB.'],
        ]),
        makeSession('marshal-sess-k8s-migration', '2024-06-15', [
          ['user', 'Migrate to Kubernetes'],
          ['assistant', 'Migrated from Docker Compose to Kubernetes with Helm charts. The Nginx reverse proxy is replaced by an Ingress controller.'],
        ]),
      ],
    },
  ];

  return {
    instances,
    metadata: {
      dataset: 'marshal-custom',
      source: 'in-repo (custom, not public benchmark evidence)',
      license: 'Same as repository',
      totalQuestions: instances.length,
      categories: ['code-memory-link', 'scope-isolation', 'supersession', 'blast-radius', 'abstention', 'multi-session', 'temporal'],
      note: 'CUSTOM CORPUS — queries phrased independently from memory text. Not public benchmark evidence.',
    },
  };
}

function makeSession(sessionId, date, turns) {
  const formattedTurns = turns.map(([role, content]) => ({ role, content }));
  const lines = [`# Session: ${sessionId}`, `Date: ${date}`, ''];
  for (const [role, content] of turns) {
    const label = role === 'user' ? 'User' : 'Assistant';
    lines.push(`**${label}**: ${content}`, '');
  }
  return {
    sessionId,
    date,
    turns: formattedTurns,
    markdown: lines.join('\n'),
  };
}
