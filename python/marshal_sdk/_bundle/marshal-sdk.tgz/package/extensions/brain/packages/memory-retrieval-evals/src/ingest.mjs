/**
 * Memory ingestion using the real PortableMemoryRuntime.
 *
 * Ingests corpus sessions as Markdown-authoritative durable memories
 * into the actual marshal_memories_v2 schema with real scope handles
 * and authorization.
 */

import { DatabaseSync } from 'node:sqlite';
import { mkdtempSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { PortableMemoryRuntime } from '@marshal/agent-runtime-provider-memory';

/**
 * Create a minimal InvocationContext for eval use.
 * Provides real scope identities so authorization paths are exercised.
 */
export function makeEvalContext(instanceId = 'eval-default') {
  return {
    principal: { kind: 'user', id: `eval-principal-${instanceId}` },
    executionId: `eval-exec-${instanceId}-${Date.now()}`,
    scope: {
      workspaceId: `eval-ws-${instanceId}`,
      sessionId: `eval-sess-${instanceId}`,
      projectId: `eval-proj-${instanceId}`,
      runId: `eval-run-${instanceId}`,
      threadId: `eval-thread-${instanceId}`,
    },
    identity: { harnessId: 'memory-retrieval-evals' },
  };
}

/**
 * Ingest corpus sessions into a real PortableMemoryRuntime.
 *
 * Each session becomes a durable memory with:
 * - content: full Markdown text
 * - retrievalSynopsis: first assistant utterance (from corpus, no query leak)
 * - scope: workspace (via authorized handles)
 *
 * Returns the live runtime, handles, context for subsequent search calls.
 */
export async function ingestCorpusAsync(sessions, options = {}) {
  const instanceId = options.instanceId ?? `inst-${Date.now()}`;
  const db = new DatabaseSync(':memory:');
  const tmpDir = mkdtempSync(join(tmpdir(), `eval-mem-`));

  const runtime = new PortableMemoryRuntime(db, { rootDirectory: tmpDir });
  const ctx = makeEvalContext(instanceId);

  runtime.scopes.ensureBuiltInScopes(ctx);
  const handles = runtime.scopes.handlesForContext(ctx);

  // Explicitly select workspace handle (index 3: session=0, run=1, agent=2, workspace=3, project=4)
  // Workspace scope has the broadest retrieval visibility for eval purposes.
  const workspaceHandle = handles[3];

  const memoryMap = new Map(); // sessionId → memoryId

  for (const session of sessions) {
    const firstAssistant = session.turns?.find(t => t.role === 'assistant');
    const synopsis = firstAssistant
      ? firstAssistant.content.slice(0, 200)
      : session.markdown.slice(0, 200);

    try {
      const result = await runtime.remember({
        handle: workspaceHandle,
        content: session.markdown,
        retrievalSynopsis: synopsis,
      }, ctx);
      memoryMap.set(session.sessionId, result.memory.id);
    } catch (error) {
      if (options.verbose) {
        process.stderr.write(`  Ingest failed for ${session.sessionId}: ${error.message}\n`);
      }
    }
  }

  return { runtime, db, handles, ctx, memoryMap, tmpDir };
}

/**
 * Search using the real PortableMemoryRuntime.search() method.
 * Returns matched memory IDs mapped back to session IDs.
 */
export function searchRuntime(runtime, handles, query, ctx, memoryMap, options = {}) {
  const limit = options.limit ?? 20;
  const start = performance.now();
  const result = runtime.search({ handles, query, limit }, ctx);
  const latencyMs = performance.now() - start;

  // Map memory IDs back to session IDs
  const reverseMap = new Map();
  for (const [sessionId, memoryId] of memoryMap) {
    reverseMap.set(memoryId, sessionId);
  }

  const sessionIds = result.matches
    .map(m => reverseMap.get(m.memory.id))
    .filter(Boolean);

  return {
    sessionIds,
    scores: result.matches.map(m => m.score),
    latencyMs,
    matchCount: result.matches.length,
    searchedScopes: result.searchedScopeIds.length,
    truncated: result.truncated,
  };
}
