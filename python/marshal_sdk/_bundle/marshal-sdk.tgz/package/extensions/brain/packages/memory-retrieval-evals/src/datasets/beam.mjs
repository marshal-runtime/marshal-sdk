/**
 * BEAM official GitHub JSON adapter for the smallest upstream tier.
 *
 * The paper and README call this tier 128K. The GitHub directory, Hugging
 * Face split, and files are named 100K, so beam-100k is the canonical CLI ID
 * and beam-128k is retained as an alias.
 */

import { existsSync, readFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

import { selectInstances } from './selection.mjs';

const __dirname = dirname(fileURLToPath(import.meta.url));
const packageRoot = join(__dirname, '..', '..');
const defaultDirectory = join(packageRoot, 'eval-data', 'beam', '100K');
const DEFAULT_CHAT_NUMBERS = Array.from({ length: 20 }, (_, index) => index + 1);

const QUESTION_CATEGORIES = [
  'abstention',
  'contradiction_resolution',
  'event_ordering',
  'information_extraction',
  'instruction_following',
  'knowledge_update',
  'multi_session_reasoning',
  'preference_following',
  'summarization',
  'temporal_reasoning',
];

export function loadBeam100K(options = {}) {
  const directory = options.directory ?? defaultDirectory;
  const chatNumbers = normalizeChatNumbers(
    options.chatNumbers ?? DEFAULT_CHAT_NUMBERS
  );
  const runnable = [];
  let totalMessages = 0;
  let totalQuestions = 0;
  let abstentionStatusOnly = 0;
  let unlabeledStatusOnly = 0;

  for (const chatNumber of chatNumbers) {
    const chatPath = join(directory, String(chatNumber), 'chat.json');
    const questionsPath = join(
      directory,
      String(chatNumber),
      'probing_questions',
      'probing_questions.json'
    );
    assertFile(chatPath, 'BEAM chat');
    assertFile(questionsPath, 'BEAM probing questions');

    const chat = JSON.parse(readFileSync(chatPath, 'utf8'));
    const probingQuestions = JSON.parse(readFileSync(questionsPath, 'utf8'));
    const corpus = buildCorpus(chat, chatNumber);
    const corpusIds = new Set(corpus.map((record) => record.sessionId));
    const corpusKey = `beam-100k:${chatNumber}`;
    totalMessages += corpus.length;

    for (const category of QUESTION_CATEGORIES) {
      const questions = probingQuestions[category];
      if (!Array.isArray(questions)) {
        throw new Error(
          `BEAM chat ${chatNumber} category ${category} must be an array.`
        );
      }

      questions.forEach((question, index) => {
        totalQuestions++;
        const queryId = `beam-100k:${chatNumber}:${category}:${index + 1}`;
        const relevantSessionIds = collectValidatedSourceIds(
          question.source_chat_ids,
          corpusIds
        );

        if (category === 'abstention') {
          abstentionStatusOnly++;
          return;
        }
        if (relevantSessionIds.length === 0) {
          unlabeledStatusOnly++;
          return;
        }

        runnable.push({
          instanceId: queryId,
          corpusKey,
          query: {
            queryId,
            questionType: category.replaceAll('_', '-'),
            question: String(question.question ?? ''),
            answer: getAnswer(question),
            relevantSessionIds,
            isAbstention: false,
          },
          corpus,
        });
      });
    }
  }

  const instances = selectInstances(runnable, options, 'BEAM 100K');
  return {
    instances,
    metadata: {
      dataset: 'beam-100k',
      source: 'https://github.com/mohammadtavakoli78/BEAM/tree/main/chats/100K',
      dataLicense: 'CC-BY-SA-4.0',
      codeLicense: 'MIT',
      paperTierLabel: '128K',
      upstreamDirectory: '100K',
      chats: chatNumbers.length,
      totalMessages,
      totalQuestions,
      runnableIrInstances: runnable.length,
      excludedFromIr: abstentionStatusOnly + unlabeledStatusOnly,
      abstentionStatusOnly,
      unlabeledStatusOnly,
      loadedQuestions: instances.length,
      directory,
    },
  };
}

export function loadBeam128K(options = {}) {
  return loadBeam100K(options);
}

function buildCorpus(batches, chatNumber) {
  if (!Array.isArray(batches)) {
    throw new Error(`BEAM chat ${chatNumber} payload must be a Batch array.`);
  }

  const corpus = [];
  const seenIds = new Set();
  for (const batch of batches) {
    if (!Array.isArray(batch.turns)) {
      throw new Error(`BEAM chat ${chatNumber} batch is missing turns.`);
    }
    const batchTimeAnchor = batch.time_anchor
      ?? batch.turns.flat().find((message) => message?.time_anchor)?.time_anchor
      ?? '';

    for (const turn of batch.turns) {
      if (!Array.isArray(turn)) {
        throw new Error(`BEAM chat ${chatNumber} turn must be a Message array.`);
      }
      for (const message of turn) {
        if (!Number.isInteger(message.id)) {
          throw new Error(
            `BEAM chat ${chatNumber} message ID must be an integer: ${message.id}`
          );
        }
        const sessionId = String(message.id);
        if (seenIds.has(sessionId)) {
          throw new Error(
            `BEAM chat ${chatNumber} has duplicate message ID: ${sessionId}`
          );
        }
        seenIds.add(sessionId);
        corpus.push(messageToCorpusRecord(message, batchTimeAnchor));
      }
    }
  }
  return corpus;
}

function messageToCorpusRecord(message, batchTimeAnchor) {
  const sourceDate = String(message.time_anchor ?? batchTimeAnchor);
  const date = normalizeDate(sourceDate);
  const role = String(message.role ?? 'unknown');
  const content = String(message.content ?? '');
  const sessionId = String(message.id);
  const lines = [`# Message: ${sessionId}`];
  if (sourceDate) lines.push(`Time anchor: ${sourceDate}`);
  lines.push('', `**${role}**: ${content}`, '');

  return {
    sessionId,
    date,
    turns: [{ role, content }],
    markdown: lines.join('\n'),
  };
}

function collectValidatedSourceIds(sourceChatIds, corpusIds) {
  const integers = [];
  collectIntegerLeaves(sourceChatIds, integers);
  const validated = [];
  const seen = new Set();
  for (const id of integers) {
    const sessionId = String(id);
    if (corpusIds.has(sessionId) && !seen.has(sessionId)) {
      seen.add(sessionId);
      validated.push(sessionId);
    }
  }
  return validated;
}

function collectIntegerLeaves(value, output) {
  if (Number.isInteger(value)) {
    output.push(value);
    return;
  }
  if (Array.isArray(value)) {
    for (const item of value) collectIntegerLeaves(item, output);
    return;
  }
  if (value && typeof value === 'object') {
    for (const item of Object.values(value)) {
      collectIntegerLeaves(item, output);
    }
  }
}

function getAnswer(question) {
  return question.answer
    ?? question.ideal_answer
    ?? question.ideal_response
    ?? question.expected_compliance
    ?? '';
}

function normalizeDate(value) {
  if (!value) return '';
  const match = /^([A-Za-z]+)-(\d{1,2})-(\d{4})$/.exec(value.trim());
  if (!match) return '';

  const months = {
    january: 0,
    february: 1,
    march: 2,
    april: 3,
    may: 4,
    june: 5,
    july: 6,
    august: 7,
    september: 8,
    october: 9,
    november: 10,
    december: 11,
  };
  const month = months[match[1].toLowerCase()];
  if (month === undefined) return '';
  return new Date(Date.UTC(Number(match[3]), month, Number(match[2])))
    .toISOString();
}

function normalizeChatNumbers(chatNumbers) {
  if (!Array.isArray(chatNumbers) || chatNumbers.length === 0) {
    throw new Error('BEAM chatNumbers must be a non-empty array.');
  }
  const normalized = chatNumbers.map((value) => Number(value));
  if (normalized.some((value) => !Number.isInteger(value) || value <= 0)) {
    throw new Error('BEAM chatNumbers must contain positive integers.');
  }
  if (new Set(normalized).size !== normalized.length) {
    throw new Error('BEAM chatNumbers must be unique.');
  }
  return [...normalized].sort((a, b) => a - b);
}

function assertFile(filePath, label) {
  if (!existsSync(filePath)) {
    throw new Error(
      `${label} not found at ${filePath}. Run: node scripts/download.mjs --dataset beam-100k`
    );
  }
}

export function getBeamManifest() {
  return {
    id: 'beam-100k',
    aliases: ['beam-128k'],
    name: 'BEAM smallest tier (128K label, 100K upstream files)',
    source: 'https://github.com/mohammadtavakoli78/BEAM/tree/main/chats/100K',
    dataLicense: 'CC-BY-SA-4.0',
    codeLicense: 'MIT',
    format: 'official GitHub JSON',
    status: 'runnable-ir',
    officialCounts: {
      chats: 20,
      messages: 5732,
      questions: 400,
      runnableIrInstances: 355,
      excludedFromIr: 45,
      abstentionStatusOnly: 40,
      unlabeledStatusOnly: 5,
    },
  };
}

export const getManifest = getBeamManifest;
