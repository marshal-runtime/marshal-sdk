/**
 * LongMemEval-V2 status manifest.
 *
 * The official benchmark evaluates answer accuracy and memory query
 * latency/LAFS. It does not publish gold relevant trajectory IDs, so it is
 * not runnable in this relevance-labeled IR harness.
 */

export function loadLongMemEvalV2Status() {
  return {
    instances: [],
    metadata: getLongMemEvalV2Manifest(),
  };
}

export function getLongMemEvalV2Manifest() {
  return {
    dataset: 'longmemeval-v2',
    name: 'LongMemEval-V2',
    source: 'https://huggingface.co/datasets/xiaowu0162/longmemeval-v2',
    repository: 'https://github.com/xiaowu0162/LongMemEval-V2',
    license: 'Apache-2.0',
    questions: 451,
    trajectories: 1870,
    questionFields: [
      'id',
      'domain',
      'environment',
      'question_type',
      'question',
      'image',
      'answer',
      'eval_function',
    ],
    trajectoryFields: [
      'id',
      'domain',
      'environment',
      'goal',
      'outcome',
      'start_url',
      'states',
    ],
    candidateTiers: {
      small: '100 trajectory candidates per question',
      medium: 'mostly 500 trajectory candidates per question',
    },
    officialMetrics: ['answer accuracy', 'memory query latency', 'LAFS'],
    status: 'status-only',
    note: 'No gold relevant trajectory IDs are published, so this dataset cannot emit honest IR instances.',
  };
}
