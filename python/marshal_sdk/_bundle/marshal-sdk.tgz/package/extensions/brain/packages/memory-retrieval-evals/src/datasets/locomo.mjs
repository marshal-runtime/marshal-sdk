/**
 * LoCoMo official JSON adapter.
 *
 * Each dialogue turn is one retrieval corpus record keyed by its canonical
 * dia_id. Category 5 is status-only, and category 1-4 questions are runnable
 * only when at least one evidence ID resolves to a real turn.
 */

import { existsSync, readFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

import { selectInstances } from './selection.mjs';

const __dirname = dirname(fileURLToPath(import.meta.url));
const packageRoot = join(__dirname, '..', '..');
const defaultPath = join(packageRoot, 'eval-data', 'locomo', 'locomo10.json');

const CATEGORY_NAMES = {
  1: 'multi-hop',
  2: 'temporal',
  3: 'open-domain',
  4: 'single-hop',
  5: 'adversarial',
};

export function loadLoCoMo(options = {}) {
  const filePath = options.path ?? defaultPath;
  if (!existsSync(filePath)) {
    throw new Error(
      `LoCoMo data not found at ${filePath}. Run: node scripts/download.mjs --dataset locomo`
    );
  }

  const raw = JSON.parse(readFileSync(filePath, 'utf8'));
  if (!Array.isArray(raw)) {
    throw new Error('LoCoMo payload must be an array of conversation samples.');
  }

  const runnable = [];
  const categoryCounts = {};
  let totalTurns = 0;
  let excludedNoValidatedEvidence = 0;
  let adversarialStatusOnly = 0;

  for (const sample of raw) {
    const sampleId = String(sample.sample_id ?? '');
    if (!sampleId) throw new Error('LoCoMo sample is missing sample_id.');

    const corpus = buildCorpus(sample);
    const corpusIds = new Set(corpus.map((record) => record.sessionId));
    const corpusKey = `locomo:${sampleId}`;
    totalTurns += corpus.length;

    const questions = Array.isArray(sample.qa) ? sample.qa : [];
    questions.forEach((qa, index) => {
      const category = Number(qa.category);
      categoryCounts[category] = (categoryCounts[category] ?? 0) + 1;
      const queryId = `locomo:${sampleId}:qa:${index + 1}`;

      if (category === 5) {
        adversarialStatusOnly++;
        return;
      }
      if (!CATEGORY_NAMES[category]) {
        throw new Error(
          `LoCoMo query ${queryId} has unknown category: ${qa.category}`
        );
      }

      const relevantSessionIds = extractValidatedEvidenceIds(
        qa.evidence,
        corpusIds
      );
      if (relevantSessionIds.length === 0) {
        excludedNoValidatedEvidence++;
        return;
      }

      runnable.push({
        instanceId: queryId,
        corpusKey,
        query: {
          queryId,
          questionType: CATEGORY_NAMES[category],
          question: String(qa.question ?? ''),
          answer: qa.answer ?? '',
          relevantSessionIds,
          isAbstention: false,
        },
        corpus,
      });
    });
  }

  const instances = selectInstances(runnable, options, 'LoCoMo');
  const totalQaRows = Object.values(categoryCounts)
    .reduce((sum, count) => sum + count, 0);

  return {
    instances,
    metadata: {
      dataset: 'locomo',
      source: 'https://github.com/snap-research/locomo/blob/main/data/locomo10.json',
      license: 'CC-BY-NC-4.0',
      conversations: raw.length,
      totalTurns,
      totalQaRows,
      categoryCounts,
      runnableIrInstances: runnable.length,
      excludedNoValidatedEvidence,
      adversarialStatusOnly,
      loadedQuestions: instances.length,
      filePath,
    },
  };
}

function buildCorpus(sample) {
  const conversation = sample.conversation;
  if (!conversation || typeof conversation !== 'object') {
    throw new Error(`LoCoMo sample ${sample.sample_id} is missing conversation.`);
  }

  const sessionKeys = Object.keys(conversation)
    .map((key) => {
      const match = /^session_(\d+)$/.exec(key);
      return match ? { key, number: Number(match[1]) } : null;
    })
    .filter(Boolean)
    .sort((a, b) => a.number - b.number);

  const seenIds = new Set();
  const corpus = [];
  for (const { key, number } of sessionKeys) {
    const sourceDate = String(
      conversation[`session_${number}_date_time`] ?? ''
    );
    const date = normalizeDate(sourceDate);
    const turns = conversation[key];
    if (!Array.isArray(turns)) {
      throw new Error(`LoCoMo ${sample.sample_id} ${key} must be an array.`);
    }

    for (const turn of turns) {
      const sessionId = normalizeDialogueId(turn.dia_id);
      if (!sessionId) {
        throw new Error(
          `LoCoMo ${sample.sample_id} ${key} has invalid dia_id: ${turn.dia_id}`
        );
      }
      if (seenIds.has(sessionId)) {
        throw new Error(
          `LoCoMo ${sample.sample_id} has duplicate dia_id: ${sessionId}`
        );
      }
      seenIds.add(sessionId);
      corpus.push(turnToCorpusRecord(turn, sessionId, date, sourceDate));
    }
  }
  return corpus;
}

function turnToCorpusRecord(turn, sessionId, date, sourceDate) {
  const speaker = String(turn.speaker ?? 'Unknown');
  const text = String(turn.text ?? '');
  const caption = typeof turn.blip_caption === 'string'
    ? turn.blip_caption.trim()
    : '';
  const lines = [`# Turn: ${sessionId}`];
  if (sourceDate) lines.push(`Date: ${sourceDate}`);
  lines.push('', `**${speaker}**: ${text}`);
  if (caption) lines.push('', `Image caption: ${caption}`);
  lines.push('');

  return {
    sessionId,
    date,
    turns: [{ role: speaker, content: text }],
    markdown: lines.join('\n'),
  };
}

function extractValidatedEvidenceIds(evidence, corpusIds) {
  const entries = Array.isArray(evidence) ? evidence : [evidence];
  const validated = [];
  const seen = new Set();

  for (const entry of entries) {
    if (typeof entry !== 'string') continue;
    for (const match of entry.matchAll(/D(\d+):(\d+)/gi)) {
      const candidate = `D${Number(match[1])}:${Number(match[2])}`;
      if (corpusIds.has(candidate) && !seen.has(candidate)) {
        seen.add(candidate);
        validated.push(candidate);
      }
    }
  }
  return validated;
}

function normalizeDialogueId(value) {
  const match = /^D(\d+):(\d+)$/i.exec(String(value ?? '').trim());
  if (!match) return null;
  return `D${Number(match[1])}:${Number(match[2])}`;
}

function normalizeDate(value) {
  if (!value) return '';
  const match = /^(\d{1,2}):(\d{2})\s+(am|pm)\s+on\s+(\d{1,2})\s+([A-Za-z]+),\s+(\d{4})$/i
    .exec(value.trim());
  if (!match) return '';

  const months = {
    january: 0,
    february: 1,
    march: 2,
    april: 3,
    may: 4,
    june: 5,
    july: 6,
    august: 7,
    september: 8,
    october: 9,
    november: 10,
    december: 11,
  };
  const month = months[match[5].toLowerCase()];
  if (month === undefined) return '';

  const hour12 = Number(match[1]);
  if (hour12 < 1 || hour12 > 12) return '';
  const hour = (hour12 % 12) + (match[3].toLowerCase() === 'pm' ? 12 : 0);
  return new Date(Date.UTC(
    Number(match[6]),
    month,
    Number(match[4]),
    hour,
    Number(match[2])
  )).toISOString();
}

export function getLoCoMoManifest() {
  return {
    id: 'locomo',
    name: 'LoCoMo',
    source: 'https://github.com/snap-research/locomo/blob/main/data/locomo10.json',
    license: 'CC-BY-NC-4.0',
    format: 'official GitHub JSON',
    status: 'runnable-ir',
    officialCounts: {
      conversations: 10,
      qaRows: 1986,
      runnableIrInstances: 1536,
      excludedNoValidatedEvidence: 4,
      adversarialStatusOnly: 446,
    },
  };
}
