export function selectInstances(instances, options, datasetName) {
  const requested = normalizeQueryIds(options.queryIds);
  let selected = instances;

  if (requested.length > 0) {
    const available = new Set(instances.map((instance) => instance.query.queryId));
    const unknown = requested.filter((queryId) => !available.has(queryId));
    if (unknown.length > 0) {
      throw new Error(
        `${datasetName} query ID(s) are not runnable: ${unknown.join(', ')}`
      );
    }

    const requestedSet = new Set(requested);
    selected = instances.filter((instance) =>
      requestedSet.has(instance.query.queryId)
    );
  }

  const slice = normalizeSlice(options.slice);
  return slice === undefined ? selected : selected.slice(0, slice);
}

function normalizeQueryIds(queryIds) {
  if (queryIds === undefined) return [];
  const values = Array.isArray(queryIds) ? queryIds : [queryIds];
  const normalized = values.map((value) => String(value));
  if (new Set(normalized).size !== normalized.length) {
    throw new Error('Query IDs must be unique.');
  }
  return normalized;
}

function normalizeSlice(slice) {
  if (slice === undefined || slice === null || slice === '') return undefined;
  if (!Number.isInteger(slice) || slice <= 0) {
    throw new Error(`Slice must be a positive integer, received: ${slice}`);
  }
  return slice;
}
