/**
 * MemoryAgentBench Conflict_Resolution status manifest.
 *
 * This split has QA/update targets but no question-to-fact relevance labels,
 * so it cannot emit honest instances for this IR harness.
 */

export function loadMemoryAgentBenchConflict() {
  return {
    instances: [],
    metadata: getMemoryAgentBenchManifest(),
  };
}

export function getMemoryAgentBenchManifest() {
  return {
    dataset: 'memoryagentbench-conflict',
    name: 'MemoryAgentBench Conflict_Resolution',
    source: 'https://huggingface.co/datasets/ai-hyz/MemoryAgentBench',
    license: 'MIT',
    config: 'default',
    split: 'Conflict_Resolution',
    rows: 8,
    qaCasesPerRow: 100,
    totalQaCases: 800,
    fileSizeBytes: 1491588,
    status: 'status-only',
    note: 'No question-to-fact relevance labels are published. This split needs a separate Brain QA/update evaluation lane and is not runnable as IR.',
  };
}

export const getManifest = getMemoryAgentBenchManifest;
