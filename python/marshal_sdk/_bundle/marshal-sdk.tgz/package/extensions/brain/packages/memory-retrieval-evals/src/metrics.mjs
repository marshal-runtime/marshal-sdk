/**
 * Retrieval evaluation metrics.
 *
 * Standard IR metrics computed from ranked results vs ground-truth labels.
 * Abstention instances (no relevant documents) are excluded from retrieval
 * metrics and scored separately for abstention precision.
 */

export function recallAtK(retrieved, relevant, k) {
  if (relevant.length === 0) return null; // abstention — not a retrieval query
  const topK = new Set(retrieved.slice(0, k));
  return relevant.filter(id => topK.has(id)).length / relevant.length;
}

export function mrr(retrieved, relevant) {
  if (relevant.length === 0) return null; // abstention
  const relevantSet = new Set(relevant);
  for (let i = 0; i < retrieved.length; i++) {
    if (relevantSet.has(retrieved[i])) return 1 / (i + 1);
  }
  return 0;
}

export function ndcgAtK(retrieved, relevant, k) {
  if (relevant.length === 0) return null; // abstention
  const relevantSet = new Set(relevant);
  let dcg = 0;
  for (let i = 0; i < Math.min(retrieved.length, k); i++) {
    if (relevantSet.has(retrieved[i])) dcg += 1 / Math.log2(i + 2);
  }
  const idealCount = Math.min(relevant.length, k);
  let idcg = 0;
  for (let i = 0; i < idealCount; i++) idcg += 1 / Math.log2(i + 2);
  return idcg === 0 ? 0 : dcg / idcg;
}

export function scopeLeakage(retrieved, allowedScope) {
  const allowed = new Set(allowedScope);
  const leaked = retrieved.filter(id => !allowed.has(id));
  return { leaked, leakCount: leaked.length };
}

function percentile(sorted, p) {
  if (sorted.length === 0) return 0;
  const idx = (p / 100) * (sorted.length - 1);
  const lo = Math.floor(idx), hi = Math.ceil(idx);
  return lo === hi ? sorted[lo] : sorted[lo] + (sorted[hi] - sorted[lo]) * (idx - lo);
}

export function latencyStats(latencies) {
  if (latencies.length === 0) {
    return { count: 0, p50: 0, p95: 0, mean: 0, min: 0, max: 0 };
  }
  const sorted = [...latencies].sort((a, b) => a - b);
  const sum = sorted.reduce((a, b) => a + b, 0);
  return {
    count: sorted.length,
    p50: round(percentile(sorted, 50)),
    p95: round(percentile(sorted, 95)),
    mean: round(sum / sorted.length),
    min: round(sorted[0]),
    max: round(sorted[sorted.length - 1]),
  };
}

/**
 * Aggregate metrics from per-query results.
 *
 * - Retrieval metrics (Recall, MRR, nDCG) EXCLUDE abstention queries.
 * - Abstention precision is reported separately.
 * - Error and zero-result rates track failed/empty non-abstention queries.
 */
export function aggregateMetrics(results) {
  // Separate retrieval queries (have relevant docs) from abstention queries
  const retrievalResults = results.filter(r => !r.isAbstention && r.relevant?.length > 0);
  const abstentionResults = results.filter(r => r.isAbstention || r.relevant?.length === 0);
  const errorResults = results.filter(r => r.error);
  const zeroResults = retrievalResults.filter(r => !r.error && r.retrieved?.length === 0);

  const recallCutoffs = [1, 5, 10, 20];
  const recalls = {};
  for (const k of recallCutoffs) {
    const values = retrievalResults.map(r => recallAtK(r.retrieved, r.relevant, k)).filter(v => v !== null);
    recalls[`recall@${k}`] = values.length > 0 ? round(mean(values)) : null;
  }

  const mrrValues = retrievalResults.map(r => mrr(r.retrieved, r.relevant)).filter(v => v !== null);
  const ndcg10 = retrievalResults.map(r => ndcgAtK(r.retrieved, r.relevant, 10)).filter(v => v !== null);

  // Abstention precision: correct if (abstention AND empty) or (non-abstention AND non-empty)
  const abstentionCorrect = abstentionResults.filter(r => r.retrieved?.length === 0).length;

  const leakages = results.filter(r => r.scopeIds?.length > 0)
    .map(r => scopeLeakage(r.retrieved ?? [], r.scopeIds));

  const queryLatencies = results.filter(r => r.queryLatencyMs >= 0).map(r => r.queryLatencyMs);
  // Reused corpus rows intentionally carry zero; build percentiles describe
  // actual builds, while per-query rows preserve the zero amortization signal.
  const indexLatencies = results.filter(r => r.indexBuildMs > 0).map(r => r.indexBuildMs);

  return {
    ...recalls,
    mrr: mrrValues.length > 0 ? round(mean(mrrValues)) : null,
    'ndcg@10': ndcg10.length > 0 ? round(mean(ndcg10)) : null,
    evaluatedRetrievalQueries: retrievalResults.length,
    abstention: {
      total: abstentionResults.length,
      correct: abstentionCorrect,
      precision: abstentionResults.length > 0 ? round(abstentionCorrect / abstentionResults.length) : null,
    },
    errors: { total: errorResults.length, rate: results.length > 0 ? round(errorResults.length / results.length) : 0 },
    zeroResults: {
      total: zeroResults.length,
      rate: retrievalResults.length > 0 ? round(zeroResults.length / retrievalResults.length) : 0,
    },
    scopeLeakage: { totalLeaked: leakages.reduce((s, l) => s + l.leakCount, 0), queriesChecked: leakages.length },
    queryLatency: latencyStats(queryLatencies),
    indexBuild: latencyStats(indexLatencies),
    totalQueries: results.length,
  };
}

function mean(values) { return values.length === 0 ? 0 : values.reduce((a, b) => a + b, 0) / values.length; }
function round(v, d = 4) { const s = 10 ** d; return Math.round(v * s) / s; }
