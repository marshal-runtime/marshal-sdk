import { describe, it } from 'node:test';
import assert from 'node:assert/strict';

import { MAX_MEMORY_DOCUMENT_BYTES } from '@quillstone/marshal-memory-bridge';
import {
  buildMemoryProjections,
  createBridgeBm25Retriever,
  deduplicateProjectionHits,
  formatMemoryMarkdown,
} from '../src/retrievers/quillstone-bridge.mjs';

function session(sessionId, markdown, turns = []) {
  return { sessionId, markdown, turns };
}

describe('Quillstone bridge projection chunking', () => {
  it('preserves legacy unchunked synopsis and body sanitation behavior', () => {
    const markdown = '# Message: 97\r\n## Retrieval\r\nsource body\r\n';
    const turns = [
      { role: 'user', content: 'ignored question' },
      { role: 'assistant', content: '## Assistant synopsis\r\nsecond line' },
    ];
    const expected = [
      '---',
      'id: source_97',
      'scope: project',
      'state: active',
      '---',
      '# source_97',
      '# Message: 97',
      'source body',
      '',
      '',
      '## Retrieval',
      'Assistant synopsis second line',
      '',
    ].join('\n');

    assert.equal(
      formatMemoryMarkdown('source/97', markdown, turns),
      expected,
    );

    const result = buildMemoryProjections([
      session('source/97', markdown, turns),
    ]);
    assert.equal(result.projections[0].markdown, expected);
    assert.equal(
      result.projections[0].content,
      '# Message: 97\n## Retrieval\nsource body\n',
    );
    assert.match(
      formatMemoryMarkdown('fallback', '\r\n', []),
      /\n## Retrieval\nMemory fallback\n$/,
    );
    assert.match(
      formatMemoryMarkdown('content', '# Heading\r\nbody', []),
      /\n## Retrieval\nHeading body\n$/,
    );
  });

  it('keeps normal sources unchunked with their stable projection IDs', () => {
    const result = buildMemoryProjections([
      session('source/97', 'small upstream content'),
    ]);

    assert.equal(result.projections.length, 1);
    assert.equal(result.projections[0].projectionId, 'source_97');
    assert.equal(result.projections[0].content, 'small upstream content');
    assert.equal(result.projectionToSessionId.get('source_97'), 'source/97');
    assert.equal(result.projectionOverhang, 0);
  });

  it('splits oversized UTF-8 content losslessly at stable bounded projections', () => {
    const paragraph = 'Quillstone paragraph 😀 with source-native text.\n\n';
    const sourceContent = `${paragraph.repeat(2_000)}## Retrieval\n${paragraph.repeat(6_000)}`;
    const first = buildMemoryProjections([session('97', sourceContent)]);
    const second = buildMemoryProjections([session('97', sourceContent)]);

    assert.ok(first.projections.length > 1);
    assert.deepEqual(
      first.projections.map(({ projectionId }) => projectionId),
      second.projections.map(({ projectionId }) => projectionId),
    );
    assert.equal(
      first.projections.map(({ content: chunk }) => chunk).join(''),
      sourceContent,
    );
    for (const [index, projection] of first.projections.entries()) {
      assert.equal(
        projection.projectionId,
        `97__chunk_${String(index + 1).padStart(6, '0')}`,
      );
      assert.equal(first.projectionToSessionId.get(projection.projectionId), '97');
      assert.ok(
        Buffer.byteLength(projection.markdown, 'utf8')
          < MAX_MEMORY_DOCUMENT_BYTES,
      );
      assert.equal(
        projection.markdown.match(/^## Retrieval$/gm)?.length,
        1,
      );
    }
    assert.equal(
      first.projectionOverhang,
      first.projections.length - 1,
    );
  });

  it('derives each retrieval synopsis only from that chunk content', () => {
    const content = Array.from(
      { length: 8_000 },
      (_, index) => `# Message: ${index}\nDetailed upstream chunk text ${index}`,
    ).join('\n\n');
    const result = buildMemoryProjections([
      session('synopsis-source', content, [
        { role: 'assistant', content: 'query-answer-gold-id-leak' },
      ]),
    ]);

    assert.ok(result.projections.length > 1);
    const laterChunk = result.projections[1];
    const retrieval = laterChunk.markdown.split('\n## Retrieval\n').at(-1).trim();
    const expected = Array.from(
      laterChunk.content.replace(/\n/g, ' ').trim(),
    ).slice(0, 300).join('').replace(/^#+\s*/g, '').trim();

    assert.equal(retrieval, expected);
    assert.match(retrieval, /Detailed upstream chunk text/);
    assert.ok(!retrieval.includes('query-answer-gold-id-leak'));
  });

  it('falls back to code-point boundaries without splitting surrogate pairs', () => {
    const content = '😀source'.repeat(12_000);
    const result = buildMemoryProjections([session('code-points', content)]);

    assert.ok(result.projections.length > 1);
    assert.equal(
      result.projections.map(({ content: chunk }) => chunk).join(''),
      content,
    );
    for (const projection of result.projections) {
      const first = projection.content.charCodeAt(0);
      const last = projection.content.charCodeAt(projection.content.length - 1);
      assert.ok(first < 0xdc00 || first > 0xdfff);
      assert.ok(last < 0xd800 || last > 0xdbff);
    }
  });
});

describe('Quillstone bridge source result projection', () => {
  it('deduplicates chunk hits in rank order and retains first scores', () => {
    const projectionToSessionId = new Map([
      ['a__chunk_000001', 'a'],
      ['a__chunk_000002', 'a'],
      ['b', 'b'],
      ['c', 'c'],
    ]);
    const result = deduplicateProjectionHits([
      { node: { memoryId: 'a__chunk_000001' }, score: 0.9 },
      { node: { memoryId: 'a__chunk_000002' }, score: 0.8 },
      { node: { memoryId: 'b' }, score: 0.7 },
      { node: { memoryId: 'c' }, score: 0.6 },
    ], projectionToSessionId, 2);

    assert.deepEqual(result.sessionIds, ['a', 'b']);
    assert.deepEqual(result.scores, [0.9, 0.7]);
  });

  it('uses exact projection overhang and preserves unchunked search limits', async () => {
    const requestedLimits = [];
    const bridge = {
      async search({ limit }) {
        requestedLimits.push(limit);
        return {
          hits: [
            { node: { memoryId: 'a__chunk_000001' }, score: 0.9 },
            { node: { memoryId: 'a__chunk_000002' }, score: 0.8 },
            { node: { memoryId: 'b' }, score: 0.7 },
          ],
        };
      },
    };
    const projectionToSessionId = new Map([
      ['a__chunk_000001', 'a'],
      ['a__chunk_000002', 'a'],
      ['b', 'b'],
    ]);

    const chunked = createBridgeBm25Retriever({
      bridge,
      projectionToSessionId,
      projectionOverhang: 1,
    }, { limit: 2 });
    const unchunked = createBridgeBm25Retriever({
      bridge,
      projectionToSessionId,
      projectionOverhang: 0,
    }, { limit: 2 });

    const result = await chunked.retrieve('upstream terms');
    await unchunked.retrieve('upstream terms');

    assert.deepEqual(requestedLimits, [3, 2]);
    assert.deepEqual(result.sessionIds, ['a', 'b']);
    assert.deepEqual(result.scores, [0.9, 0.7]);
  });
});
