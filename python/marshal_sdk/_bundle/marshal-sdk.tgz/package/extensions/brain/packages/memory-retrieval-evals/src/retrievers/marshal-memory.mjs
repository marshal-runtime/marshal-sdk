/**
 * Retriever using real PortableMemoryRuntime.search().
 *
 * This exercises the actual marshal_memories_v2 multi-scope search
 * with substring-based scoring on content, retrieval_synopsis, and fact_key.
 */

import { searchRuntime } from '../ingest.mjs';

export function createMarshalMemoryRetriever(runtime, handles, ctx, memoryMap, options = {}) {
  const limit = options.limit ?? 20;
  return {
    name: 'marshal-memory-v2',
    description: 'Real PortableMemoryRuntime.search() on marshal_memories_v2',
    requiresModelDownload: false,
    retrieve(query) {
      return searchRuntime(runtime, handles, query, ctx, memoryMap, { limit });
    },
  };
}
