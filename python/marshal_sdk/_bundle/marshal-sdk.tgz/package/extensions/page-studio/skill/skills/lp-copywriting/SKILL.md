---
name: lp-copywriting
description: Strategy-first conversion copy for a DTC landing page from the input's brief, facts and positioning. Use before writing any page copy - to split the strategy into requirements, build the fact sheet, and write headlines, body, proof, FAQ and CTAs that sell with real claims only, in the brand voice. references/craft.md holds the full craft, CRO rules, self-check and anti-pattern examples.
---

# Landing-page copy: strategy first, facts only

The copy has one job: the visitor buys the product. If a line does not help sell, cut it. Read
`references/craft.md` before writing the first section, and run its self-check before every render. The
role-specific rules (hero, benefits, reviews…) live in the `lp-roles` skill.

## 1. Read the strategy first

The strategy is `input/page/brief.json → positioning`: `page_name`, `brief_markdown` (the positioning brief),
`structured` (the same positioning as fields, when the run has one), `content_guidelines`, `visual_guidelines`,
`audience`. Empty fields are allowed. Split it into requirements,
one per instruction, each with an id and a kind:

| kind              | Examples                                                                                                                                      |
| ----------------- | --------------------------------------------------------------------------------------------------------------------------------------------- |
| `product`         | which product the page sells; a bundle or upsell to show                                                                                      |
| `primary_message` | "Primary message — must lead the hero: …" → the hero headline says it, near verbatim                                                          |
| `structure`       | "five-reasons page", "funnel progression: promise → education → product → proof → routine → reassurance", "upsell component for the X bundle" |
| `audience`        | who reads, what they notice, what they want                                                                                                   |
| `tone`            | honesty rules, "no age-shaming", forbidden promises                                                                                           |
| `message`         | a key message, a positioning line, a comparison target ("against injectables, never a named brand")                                           |
| `objection`       | research complaints the page must answer                                                                                                      |
| `visual`          | imagery and look instructions (hand them to the design work)                                                                                  |

Read `input/page/brief.json → angles` and `grounding_digest` as context for the angle and the persona. They are not a fact
source either.

**The strategy's instructions are never a fact source.** A fact the positioning states itself is a fact of
source `input` (the input README's source order). For each requirement, check that the facts (`input/products/<id>/facts.md`,
`input/page/facts.md`, `product.json`, `brand.json`) can support it. If
the strategy asks for a number, an ingredient, a study, a price or a bundle the facts do not hold, the
requirement is `dropped` with a one-line reason (or met with a clearly marked placeholder when the section
must exist, for example a bundle price). Record every requirement in `plan.json → strategy`.

## 2. Build the fact sheet from the brand facts

The facts are `input/products/<id>/facts.md` (one id per fact, with its source tag; a fact marked `excluded` is
never stated), `input/page/facts.md` (the operator's facts), `input/page/page-grounding.json`,
`input/products/<id>/product.json` (with `excluded_claims`) and `input/brand/brand.json` (`usps`, `voice`
with `forbidden_words`, `personas`, `testimonials`). When two sources disagree, the higher source wins:
operator > input > db > site > picture.

- `input/brand/brand.json → claims` — exact wording and numbers. Keep the study length and sample size beside each
  number ("in 28 days"). Never round, merge or upgrade a claim ("visibly" stays "visibly").
- Qualifiers are part of the fact and stay word for word ("tends to", "may", "up to", "in a study of N",
  "results may vary", "individual experience", "ingredient-level"). A figure from an ingredient study names
  the ingredient in the same line as the claim, headline included, never only in a footnote. A quote or
  story with a disclaimer in the source keeps it beside the quote. One statistic is never reused for a
  different result.
- `input/brand/brand.json → usps`, `positioning` (differentiation, creative messages), `villains` / competitors, the
  guarantee and commercial terms, `testimonials` (real quotes only, with the name as given).
- `input/brand/brand.json → personas` — pains, desires, objections; research complaints become FAQ answers and
  reassurance lines next to the buy box.
- `input/brand/brand.json → voice` — `dos`, `donts`, `forbidden_words`, copy patterns. Treat each forbidden item as a
  hard rule, including whole forbidden themes (e.g. age-shaming).
- `input/products/<id>/product.json` — only when it describes the product the strategy sells. When it describes another
  product, use brand-level facts and say so in `notes.md`.
- No fact for something the page needs (rating, review count, price, shipping) → a marked placeholder:
  `[PLACEHOLDER: price]`, styled visibly, listed in `notes.md`. Never a plausible-looking invention.

## 3. Write the argument before the HTML

Answer in a scratch note: who reads, what they already believe, the one thing they must believe after the
first screen, what proves it, what they do next. Then list the page as claims, one per section, each with
its proof (an asset, a number, a quote, a demonstration). A section with no claim is filler; cut it. The
role plan decides the sections (see `lp-roles`, "Role plan from evidence"). The strategy's structure
hints are preferences: "five reasons" becomes five numbered reasons only when the facts hold five distinct,
provable ones, each one claim with its proof; otherwise use fewer or another page type and say why.

## 4. Headlines and lines

- Hero headline: the strategy's primary message when there is one. Otherwise one claim in 8 words or fewer,
  at most 3 lines on a 390 px phone. The line under it names the product and its category.
- Section headings: one claim, 8 words or fewer, sentence case, no full stop. The heading and its first
  line read as one thought.
- Supporting line: one concrete sentence, at most ~15 words, never a reword of the headline.
- Body: short paragraphs of plain statements with the real number and the specific noun. If another brand
  could print the sentence unchanged, sharpen it or cut it.
- Buttons: 3 short words at most, naming the value of acting ("Get My Lift", "Shop Now"). One primary
  action name for the whole page. A second action is a text link.

## 5. Proof without inventing it

Real before/after pairs, real customer quotes from the brand data, real clinical numbers with the study
length. No invented reviews, star rows, review counts, press logos, user counts or "as seen in". If the
strategy asks for proof the data lacks, show the product itself, explain how it works, and drop or
placeholder the rest.

## 6. Honesty and tone

- Promise what the claims say, not more: "softens the look of lines", not "erases wrinkles"; no Botox or
  filler equivalence unless a claim says exactly that.
- No age-shaming and no fear copy: change is natural, not a flaw to fix. No "anti-aging" framing of the
  reader's face as a problem when the voice forbids it.
- Compare against a category ("injectables", "creams that sit on the surface"), never a named brand unless
  the facts name it.

## 7. Phrases that read as generated

Cut: unlock, elevate, transform your…, seamless, effortless, game-changer, revolutionary, "not just X,
it's Y", tricolon slogans ("Lift. Firm. Glow."), questions nobody asked, "Meet …", step labels like
"Step 01". **No em dashes or en dashes anywhere in the copy** (write ranges as "3 to 5"). Use curly quotes
and a non-breaking space between a number and its unit. The full list is in `references/craft.md` §6.
