# Staying on brand: source order, tokens, style-fit checklist

Adapted from the ZyG kit's `zyg-section-design/references/style-fit.md`. The Shopify and theme-settings parts are
removed; on this page the tokens go into one `:root` block.

## Who wins when sources disagree

A reference page gives the layout (which sections, their order, each composition, the effects), never the
look. Colours, fonts, type, buttons, radius, surfaces and pictures are always the brand's, rebuilt from
levels 2 and 3 below.

1. **The operator's instructions:** for the layout, the reference pages the operator names and what the
   operator says to take from each; for the look, only the operator's own visual direction in their words.
2. **The brand design plan** (`input/brand/design-plan.md` and `design-plan.json`): `must` rules are hard, `should` rules are
   strong defaults. A layout or effect item of its avoid list yields where a reference does it; its look
   rules never yield to a reference.
3. **The brand site** in `input/brand/site/` (`site-profile.json`, the colour report, the screenshots), then the
   `input/brand/brand.json → visual` tokens (fonts, colours). Sections already on this page count here: a new section
   must read as the same site.
4. **The style defaults of every skill:** the taste rules (`references/taste.md`, `references/tells.md`) and
   the bans and limits of the pinned skills. They raise the floor; they never override 1–3. When the brand's
   own palette is a "default" palette (cream, brass, near-black), the brand wins.

Facts keep their own order (operator > input > db > site > picture) and never yield to a reference. The
claims rules, accessibility and the output contract never yield to any level.

## Turn the brand into tokens before any section

Write the tokens into `visual_world.json` and one `:root` block:

- **Colour roles:** ground, second ground, dark band, text, muted text, hairline, the proof accent, the
  CTA-only colour. Write down the **usage ratio** the design plan measured (for example cream 6 of 12 bands,
  white 2, dark 4). Count bands as you build to keep it.
- **Type roles:** the heading face and weight, the body face and weights, the CTA style, the scale (for
  example display 40/56, h2 30/40, body 16/18 for mobile/desktop).
- **Shape:** one radius scale (square, soft or pill), chosen once; hairline weight and colour.
- **Rhythm:** section padding (for example 64 mobile / 112 desktop), heading → content 24–40, title → text
  8–12, card padding at least 24.

## Style-fit checklist (run on every section and on the whole page)

**Colour**

- Only tokens. One accent per section. The CTA colour appears only on CTAs.
- The grounds follow the measured ratio across the page; count light and dark bands after adding each
  section, and never two dark bands in a row unless the plan says so.
- Text contrast passes (body ≥ 4.5:1, large ≥ 3:1). Mid-tone grounds carry ink text.

**Type**

- Headlines use the brand's face and scale step. Hierarchy comes from weight and size: a card title is one
  step heavier than its body, never lighter. Light display weights only at display sizes.
- Body 16–18 px, line height about 1.5, measure 65ch or less (intros 46ch or less).

**Space and alignment**

- One left spine: the section heading, the first column and the footnote share the same x.
- Content never touches an edge or a hairline: at least 24 px inside tiles and columns.
- Related items close (title → text 8–12 px), groups apart.
- One radius scale; pills are pills everywhere.

**Imagery**

- Real product photography leads. Check every crop at 390 and 1440: no product cut in half, no label cut, no
  bottle peeking from an edge.
- Image tiles fill their track exactly (match the height of the neighbouring column).

**Mobile**

- Every multi-column section states its phone behaviour: stack, swipe (with a visible peek of the next card)
  or tabs.
- No horizontal page scroll; tap targets 44 px or more; nothing clipped.

**Neighbours**

- Look at each section between the sections above and below it. If it looks like another site, adjust the
  ground, radius or type until it reads as one page.
