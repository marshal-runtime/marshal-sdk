# closing

## Job

The visitor thinks: "OK, I'm trying it." This is the final ask, for readers who scrolled past the buy box.

## Use when / needs

Always, as the last section before the footer. It needs the main message and the strongest risk remover
(the guarantee).

## Write

- Restate the core promise in fresh words. It can echo the primary message, but not copy the hero line for
  line.
- Give one true reason to act now (the guarantee, the subscription gift when real), remove the last barrier,
  and end on the outcome the customer gets, not the transaction.
- One CTA, the same action name as the main button.

## Build

- **Image banner:** a full-width product or lifestyle picture with a quiet area, with the heading, the line
  and the CTA on a panel or scrim.
- **Statement:** a large heading on a dark or colour band with the CTA. Pick whichever differs from the
  section above.

## Pictures

A credible product moment, the product in a clean scene, or a customer already shown on the page. Never a
new unrelated picture.

## Examples

- Bad: "Don't miss out! Buy now before it's too late!" (fake urgency).
- Good (OKOA): "Start with five minutes." / "The lift you can see today, the firmness that builds over 28
  days, and 90 days to decide." / button "Get My Lift".
- Good (feature explorer page): "Tonight, choose the setting" / one line that the product adapts, plus the
  guarantee / one button. It closes on the page's own idea, not on a count of reasons.

## Checks

It is not a copy of the hero. There is one CTA. The guarantee is visible.
