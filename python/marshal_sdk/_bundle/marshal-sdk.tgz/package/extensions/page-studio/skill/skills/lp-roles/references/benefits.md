# benefits

## Job

The visitor thinks: "I have enough good reasons to choose this product, and to choose it now."

## Use when / needs

USPs, claims with numbers, ingredient jobs, real customer results. Choose the frame by what the facts hold:

| Frame            | Use when                                                                                              |
| ---------------- | ----------------------------------------------------------------------------------------------------- |
| `reason_to_buy`  | Several distinct, provable reasons; numbered reasons, reason cards, an icon row, "X reasons why"      |
| `specs`          | The full factual detail (complete ingredients, size, nutrition, free-from) that a careful buyer needs |
| `whats_included` | What arrives: pack contents, size, count, supply length, extras that ship with it                     |

## Write (reason_to_buy)

- **Outcome first, mechanism as proof.** The headline promises a concrete result the buyer cares about; the
  body proves exactly that promise with one fact, in the customer's words. The ingredient is never the
  headline.
- **One idea per reason.** The body proves its headline; it does not add four more claims.
- **Pick reasons, not features.** A fact earns a slot only when it answers "why this instead of what I use
  now?" for this buyer.
- **Distinct.** Two reasons that settle the same doubt are one reason; replace the weaker with another doubt
  (ease, trust, value, feel, speed).
- **Order** from the strongest to the weakest. The last reason makes acting now feel easy (the guarantee,
  the ease).
- **Proof chip:** land each reason with its real number or result ("86% said skin felt instantly firmer"),
  with the study length beside it when the facts give it.
- **Count:** when the strategy sets a count, honour it only with that many distinct, provable reasons; with
  fewer, use fewer and say why in `notes.md`. Never split one reason into two.

## Write (specs and whats_included)

Here a complete, plain list is the job, and the rule against spec lists does not apply. Copy every figure,
unit and name exactly. Never convert, round, total or estimate. Use neutral labels ("Ingredients",
"Net contents", "Free from"). Name an extra only when the facts say it ships.

## Build

- **Numbered reasons:** alternating picture and text, each with its number (when the plan chose numbered
  reasons for cause), a headline, two or three lines, and a proof chip. On mobile the picture comes first, then the
  text.
- **Reason cards** in a horizontal scroll or a 2×2 grid. **Icon row:** an inline SVG icon and one line each.
- **Product orbit:** the product photo in the centre, short benefits around it (a 2×3 grid on mobile).
- **Specs:** a table or an accordion. **What's included:** a short list with the count first ("30 capsules").

## Pictures

Each reason's picture proves that reason: its before/after, its texture, its moment of use. Never the same
picture twice. No packshot on every card.

## Examples

- Bad (spec sheet): "Non-nano zinc oxide, no chemical filters, reef-safe, non-comedogenic, patented Argania
  Active Complex." It answers no "why should I care?".
- Good (contrast hook): "Most SPFs block sun damage. This one reverses it." / "The Argania Active Complex
  repairs UV-damaged skin while you wear it. Not after. While."
- Good (kill an objection): "100% mineral. Zero white cast." / "Non-nano zinc oxide protects without the
  chalky residue mineral SPF is known for."
- Good (OKOA): "A visible lift in five minutes" / "A film-forming complex tightens the look of skin as it
  dries." / chip "86% said skin felt instantly firmer".
- Good (feature explorer, not a list): "Pick the setting for tonight" over a row of mode cards, each a
  mode name, what it feels like in one line and who it suits, with the product photo beside the row.
- Bad: "Hydrates where lotions can't. Ectoine + Squalane improve moisture at the cellular level." It leads
  with jargon. Better: "Hydration that actually lasts. Most lotions fade by midday; this one helps skin hold
  moisture far longer."

## Checks

Every reason is distinct and proved. Headlines are 8 words or fewer. No reason repeats the hero. The
pictures match their reasons. No index labels as decoration.
