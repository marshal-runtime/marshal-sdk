# how_to_use

## Job

The visitor thinks: "This is easy, I can do it every day." Ease is the persuasive point; brevity is how you
show it.

## Use when / needs

The real usage steps (`product_context.content.how_to_use` or brand facts). Also when a research complaint
comes from wrong use (for example a white film when applied on bare skin).

## Write

- 2–4 steps, each one action in the imperative, in the order performed. Cut any step the customer would not
  think about.
- Start each with a plain verb ("Apply", "Press", "Leave on"), and tie it to what the step gives ("Press in,
  jaw to temple, so it sets evenly").
- Add an ease cue only when true ("takes a minute").
- Turn the usage complaint into a clear tip ("Always over moisturizer: on bare skin it can leave a white
  film").

## Build

Steps with a picture each (on mobile, a picture then text, stacked; on desktop, 3 columns), or a routine
list with our step highlighted (for example "Cleanser · Serum · Moisturizer · **Lifting Cream** · SPF").
The tip goes in a small callout after the steps.

## Pictures

Hands doing the actual step with our product. A frame cut from a UGC or how-to video works well. Never
abstract concepts.

## Examples

- Bad: "Step 01: Prepare your skin for optimal absorption."
- Good: "Moisturize first" / "Your usual moisturizer, then the Lifting Cream on top."

## Checks

The steps match the facts. No decorative step numbers. Each picture shows its step.
