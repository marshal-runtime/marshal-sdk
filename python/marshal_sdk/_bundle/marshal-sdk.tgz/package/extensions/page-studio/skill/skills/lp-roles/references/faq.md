# faq

## Job

The visitor thinks: "My last doubt is answered, honestly." A straight answer to a hard question makes the
rest of the page believable.

## Use when / needs

`product_context.faq`, commercial terms (returns, cancelling, shipping), claims, and the research
complaints and objections. It always exists when the facts hold at least three real answers.

## Write

- Ask the questions that block the purchase, not the comfortable ones: "Will it leave a white film?", "Is
  this like Botox?", "How do I cancel?", "What if it doesn't work for me?", "When will I see results?".
- Lead each answer with the direct answer, then the reason. Two or three sentences.
- Answer hard questions honestly. If it does not erase deep wrinkles, say what it does do.
- 5–8 questions, ordered by how much each blocks the buy.

## Build

An accordion (`<details>` and `<summary>`) with the first item open. On desktop, the heading sits in a left
column and the questions on the right. The tap target is the full row, 44 px or more.

## Pictures

None, unless one answer is clearer with a product detail.

## Examples

- Bad: "Is it amazing? Yes! Our customers love it."
- Good: "Why do I see a white film?" / "On bare, dry skin the lifting film can show. Apply it over your
  moisturizer and let it set for two minutes."

## Checks

Every answer traces to a fact. The research complaints are covered. Questions are no longer than 2 lines on
mobile.
