---
name: lp-assets
description: Choose, look at and cut a brand's existing pictures for a landing page, and write image briefs when nothing fits. Use before picking any image, when cutting a before/after or a crop, and when a slot has no usable asset.
---

# Assets: look before you choose, cut deterministically

## 1. Filter the catalogue

The product's folder has one entry per brand picture in `input/products/<id>/pictures.json`, and the file itself in
`input/products/<id>/pictures/`:
`key`, `file`, `asset_id`, `set_id` (one set = one photo in several crops), `scope` (product or brand-wide),
`width`, `height`, and the inventory model's reading: `description`, `category`, `roles`, `readiness`,
`text_in_image`, `includes_person`, `includes_product`, `products_shown`, `shows_other_product`, `is_ugc`,
`background`, `tags`. `input/products/<id>/picture-facts.json` lists what the pictures state (labels, panels, badges), with
the pictures that show each fact. The run already left out unread and unusable pictures.

- `as_is` — use directly. `needs_adjust` — usable after a crop/resize/frame. `needs_edit` — needs pixel
  work (text removal, background); in phase 1 use only if a crop avoids the problem, else brief it.
  `reference_only` — never on the page.
- Check `products_shown` / `shows_other_product`: on a single-product page never show another product as if
  it were this one (a bundle section may show the bundle).
- `text_in_image`: baked-in text competes with your copy and may contradict it. Prefer clean images; crop the
  text out when you can; never place an image with someone else's headline in it.
- Use each picture at most once, and each picture set (`set_id`) at most once.

The picture search command in your prompt lists candidates in one line each: `--role hero`, `--text before`,
`--readiness as_is,needs_adjust`, `--scope product`, `--ugc`, `--person`, `--product`.

## 2. Look

Make contact sheets of the candidates with the contact sheet command in your prompt (up to ~25 keys a
sheet), read each sheet and choose from the sheets. Read a picture at full size only when the page uses it
and you must check a crop, a label or printed text. The description can be wrong: the picture wins. Look for the page idea here: a striking
before/after, a hands-on-product moment, a texture, a lifestyle frame that matches the persona.

## 3. Cut deterministically (phase 1)

Allowed edits: crop, resize, split, convert. Write every output to `out/assets/` with a descriptive name,
and record each cut in `plan.json → sections[].cuts`.

```bash
# crop (x y w h) and resize with Python + Pillow
python3 -c "from PIL import Image; im=Image.open('input/products/<id>/pictures/X.jpg'); im.crop((0,120,1080,1470)).resize((900,1125)).save('out/assets/hero.jpg', quality=86)"
# split a side-by-side before/after into halves
python3 -c "from PIL import Image; im=Image.open('input/products/<id>/pictures/X.jpg'); w,h=im.size; im.crop((0,0,w//2,h)).save('out/assets/before.jpg'); im.crop((w//2,0,w,h)).save('out/assets/after.jpg')"
# convert webp/png to jpg
python3 -c "from PIL import Image; Image.open('input/products/<id>/pictures/X.webp').convert('RGB').save('out/assets/x.jpg', quality=86)"
```

Rules for cuts:

- Never crop through a product label, a logo, a face or a hand holding the product.
- A before/after pair must be the same person, same angle, similar light and the same crop. Read both halves
  after splitting; if they do not match, choose another pair. Label them in HTML, not with baked text.
- Keep the long edge ≤ 1600 px and files reasonably small; keep the original aspect unless the slot needs a
  crop.
- Check the logo: transparent PNG logos (`has_alpha`) may vanish on a dark or same-colour ground. Use it on a
  ground it contrasts with, or set the wordmark in the heading font.

## 4. When nothing fits: an image brief

Phase 1 has no generation or pixel editing. When a slot has no usable asset, keep the slot and show a
visible placeholder in the page: a block with the slot's aspect ratio, a neutral tone from the palette, and
the brief text inside, marked "Image brief". Record the brief in `plan.json → sections[].briefs`. Format:

```
Use: <section and slot>, <aspect ratio>, <size on mobile / desktop>
Subject: <what is shown; the real product with its real packaging — name the colour and shape>
Scene: <setting, props, persona match>
Composition: <framing, where the subject sits, empty space for text>
Light and colour: <light, palette tied to the brand tokens>
Product truth: keep the pack shot exactly as in <asset key>; no invented labels, no other products
Text: none in the image (copy is HTML)
Avoid: social media UI, screenshot, watermark, messy background, distorted text, phone frame, app interface
```

For an edit brief (an existing asset that needs pixel work), name the source key and list the invariants:
"change only X; keep the product, the label and the hands unchanged".

## 5. Phase-2 tools

remove_text, remove_background, composite and generate are planned as tools and are **not available** in
this run. Do not try to emulate them with Pillow tricks (no geometric masks pretending to be cut-outs).

## 6. Customer pictures are proof

- A UGC picture (`is_ugc`) of a real customer applying or showing the product is proof on its own. When the
  input has them, build at least one proof section on them.
- The input holds pictures only, no videos, so there are no loops to cut in this run.

## 7. Real words beside the assets

- Real customer quotes are in `input/products/<id>/product.json → testimonials` and `input/brand/brand.json → testimonials` (the brand's own customers only). Quote them
  verbatim with the name as given, cite the source in `plan.json → quotes`, and keep rating stars only when
  the source shows them.
- Product shots from the site may carry baked text; crop it away or brief a clean version.
