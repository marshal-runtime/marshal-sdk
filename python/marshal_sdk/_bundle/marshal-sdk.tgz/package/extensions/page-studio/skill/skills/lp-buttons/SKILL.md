---
name: lp-buttons
description: What each page button does on the store, the same as zyg-shop's zyg-new-button - add to cart, buy now (empties the cart first), upsell, scroll to the buy box or shop, open a dialog, go to a page - with its exact markup, states and events. Use when a change adds or edits a button.
---

# Buttons that behave like zyg-new-button

zyg-shop's `zyg-new-button` block is the reference for every button of a page. A section button gets the same
behaviour from the ZyG events bridge that the page carries: write the marker and its data, and the bridge does
the cart calls, the states and the tracking. Never write your own cart script for a button the bridge handles.

## Add to cart

```liquid
<button type="button" data-zyg-atc
  data-variant-id="{{ product.selected_or_first_available_variant.id }}"
  data-product-id="{{ product.id }}"
  data-available="{{ product.selected_or_first_available_variant.available }}">Add to cart</button>
```

On click the bridge:

1. Tracks `cta_click` with `action`, `variantId`, `productId`, `quantity`, `sellingPlanId`, `purchase_type`
   (`otp` or `subscription`) and `upsell_type` (`product` or `upsell`).
2. Sets `data-zyg-state="loading"` and disables the button, so a second click adds nothing.
3. Posts one line to `/cart/add.js` with the line properties `_line_item_id`, `_source` (`cta-button`),
   `_initial_offer`, and `_subscription` with a selling plan. On a zyg-shop theme it uses the theme's cart.
4. Fires `cart:add` (the theme's cart drawer may open) and tracks `cta_add_to_cart` with `success: true`.
5. Sets `data-zyg-state="added"` for 2 seconds, then clears the state.

When the add fails, the bridge tracks `cta_add_to_cart_error`, clears the state and enables the button again.

- Quantity: `data-quantity="2"`. Without it the quantity is 1.
- Subscription: `data-selling-plan-id="{{ plan.id }}"` from the product's selling plans. A plan picker on the
  page sets it on the button before the click.
- Never type an id as digits in an attribute; use Liquid. A chosen variant's id appears only in the Liquid
  comparison that selects it (see "A chosen variant or a pack").

## Buy now

The same markup with `data-zyg-checkout` in place of `data-zyg-atc`. A buy-now empties the cart first:
the bridge posts `/cart/clear.js`, then `/cart/add.js`, then goes to `/checkout`. The button stays in its
loading state while the browser leaves. The shopper pays for this product only, never for what an earlier
visit left in the cart.

## Upsell (another product)

`data-zyg-atc data-upsell` with the ids of the other product:
`{{ all_products['<handle>'].selected_or_first_available_variant.id }}` and `{{ all_products['<handle>'].id }}`.
The line gets `_source: upsell` and `_upsell: true`, and the events carry `upsell_type: upsell`.

## A chosen variant or a pack

A pack is a variant ("3-Pack") or several units of one variant. Select the chosen variant in Liquid, so the button
falls back to the first available variant when the store removes it, and its price and stock read that variant:

```liquid
{%- liquid
  assign item = all_products['<handle>']
  assign item_variant = item.selected_or_first_available_variant
  for variant in item.variants
    if variant.id == <variant id>
      assign item_variant = variant
    endif
  endfor
-%}
<button type="button" data-zyg-atc data-upsell
  data-product-id="{{ item.id }}"
  data-variant-id="{{ item_variant.id }}"
  data-quantity="<quantity>"
  data-available="{{ item_variant.available }}">
  {{ item_variant.price | times: <quantity> | money }}
</button>
```

- For the page's own product, assign `item = product` and read `product.variants`; the button stays
  `data-zyg-atc data-upsell` when it sells more of the page's product next to the main buy button.
- `data-quantity` is the number of units, and the price shown is the unit price times that number. Leave
  `data-quantity="1"` for one unit.
- Write a saving, a pack price or a "free" unit only when the operator states it.
- `data-available` reads the chosen variant, so a sold-out pack shows as sold out (next section).
- A main buy button for a chosen variant is the same markup without `data-upsell`, and `data-zyg-checkout` for buy
  now.

## Sold out

`data-available` prints `false` for a sold-out variant. The bridge then sets `data-zyg-state="sold-out"`,
disables the button and never adds. Show the state in the section's CSS:

```css
[data-zyg-state="loading"] {
  opacity: 0.6;
  cursor: progress;
}
[data-zyg-state="added"]::after {
  content: " ✓";
}
[data-zyg-state="sold-out"] {
  opacity: 0.5;
  cursor: not-allowed;
}
```

Change the button text with Liquid when the page must say "Sold out":
`{% if product.selected_or_first_available_variant.available %}Add to cart{% else %}Sold out{% endif %}`.

## Scroll, dialog and page buttons

| Button                     | Markup                                                                              | What happens                                       |
| -------------------------- | ----------------------------------------------------------------------------------- | -------------------------------------------------- |
| Scroll to the buy box      | `<a href="#zyg-buybox-1" data-zyg-cta>` on a root `id` with `zyg-buybox`            | native scroll; `cta_click`, `cta_scroll_to_buybox` |
| Scroll to the shop section | `<a href="#<id>" data-zyg-cta>` on a target inside `[id*="zyg-shop-section"]`       | native scroll; `cta_scroll_to_shop`                |
| Scroll to another section  | `<a href="#<id>" data-zyg-cta>`                                                     | native scroll; `cta_click`, `cta_scroll`           |
| Open a dialog              | `<button type="button" data-zyg-cta data-zs-open="<dialog id>">`                    | the page opens the dialog; `cta_open_modal`        |
| Go to a page               | `<a href="/pages/…" data-zyg-cta>` (`target="_blank" rel="noopener"` for a new tab) | `cta_navigate`, then the browser goes              |

- A scroll target needs an element with that `id` on the page. zyg-new-button puts the target at the top of the
  screen with no header offset; give the target `scroll-margin-top` when the theme has a sticky header.
- A dialog needs a `<dialog>` with that `id`, and a click handler in the section that opens it.

## A button whose own script does the cart call

Mark it `data-zyg-atc="track"` or `data-zyg-checkout="track"`: the bridge then only tracks `cta_click`, and the
script must do what the bridge would. A buy-now script posts `/cart/clear.js` before `/cart/add.js`. The
`events --runtime` check fails a buy-now that adds without clearing (`events.checkout_cart`). Prefer the plain
markers; use `track` only for a picker or a bundle the markers cannot describe.

## Not available in a section

zyg-new-button also adds cart-logic milestone rewards and free gifts, redirects through a free-shipping
discount code, follows the buy box's variant picker, shows a live stock count and sticks to the screen. A
section button does none of these: never claim a reward, a gift or a discount on the button.
