---
name: lp-design
description: Art direction and HTML/CSS craft for a long, mobile-first DTC landing page. Use when planning the page idea, the section sequence and compositions, the design tokens, and when writing the HTML and CSS. references/design-moves.md lists proven compositions per role, references/style-fit.md the brand-token method and checklist, references/taste.md the anti-default rules; read references/tells.md before the first render.
---

# Landing-page design

Read these before planning:

- `references/style-fit.md`: who wins when sources disagree, the token method, the style-fit checklist.
- `references/design-moves.md`: proven compositions per role, with their phone behaviour.
- `references/taste.md`: the design read, the dials, layout discipline, typography, colour, motion, the
  accessibility gate, and the critique and polish passes.
- `references/tells.md`: the banned devices (before the first render).

## 1. Idea first

One idea taken from the subject and the strategy, not from the category. The strongest asset often gives
it: a before/after minutes apart can become the hero and the thread of the page; a texture shot can become
the ground of the ingredient section. Write the idea in one sentence in `plan.json → page_idea`. Every
section should carry it, including the FAQ and the buy box.

## 2. The section sequence is the argument

The roles and how to build each one are in the `lp-roles` skill (a checklist, not an order). Follow the
strategy's structure hints first. When the operator names a reference page, its section order and
compositions come first (`references/style-fit.md`, level 1).
Use as many sections as the argument has claims; a long page is expected, filler is not.

Per section choose a **composition** (a move from `references/design-moves.md`) for its content and assets, and
name it in `plan.json`: full-bleed image
with overlaid title; split image/text (left or right anchored); stacked statement on a colour field;
before/after pair with a labelled divider; comparison table; stat row with study footnote; timeline rail;
step sequence with images; ingredient grid with cut-outs; quote wall; single large quote over an image;
offer cards; accordion FAQ; closing scene. **No two neighbours share a composition**, unless the operator's
reference does it. Alternate dense and
empty, image and type, light and dark grounds, so the scroll has rhythm. Break the system once, on purpose.

## 3. Design system once

- Fonts and colours from `input/brand/brand.json → visual` (heading font, body font, primary, accent, background,
  text). Load the real fonts (Google Fonts `<link>` with `display=swap`), never a system fallback as the
  voice. Check colours against the product photos; take one accent from the packaging if the tokens are
  thin.
- One `:root` block of tokens: colours, 5 type sizes far apart (`clamp()` for display), spacing scale, one
  radius decision (square or fully round, chosen once), max content width.
- Colour roles: ground 70–90% of the page, ink for text, accent under 5% of any screen (the action and one
  recurring mark). Tint secondary text from the ground, never mid grey on colour.
- Sections are told apart by their ground (tone steps, a full colour field, an image), not by boxes,
  borders or shadows.

## 4. Mobile first, then desktop

Write for 390 px first: 20–24 px gutters, one column, images full-bleed or edge-to-edge where they carry the
section, tap targets ≥ 44 px, a sticky buy bar only if it never covers content. Then compose 1440 px as a
second layout, not a stretched phone: splits, a 12-column measure, images that hold their crop, body
measure 60–75ch.

## 5. HTML, not pictures of HTML

Numbers, stat rows, tables, timelines, icons (inline SVG, one stroke weight), offer and bundle cards,
badges, ratings and guarantees are HTML. Images are photographs or real product shots. Video: a muted,
looping, `playsinline` clip with a `poster` frame, never autoplay with sound.

## 6. Craft floor (check on every render)

- Contrast: body ≥ 4.5:1, large text ≥ 3:1, including text over images (add a scrim or move the text).
- Type: headings ≤ 2 lines at 390 px, `text-wrap: balance` on headings, `pretty` on paragraphs, no text
  under 13 px, tabular figures for numbers, no clipped numerals (line-height ≥ 1 on big digits; check the
  descenders and the top of the glyphs).
- No horizontal overflow at 390 px. Long words and stats wrap or shrink with `clamp()`.
- Images: `object-fit: cover` with a deliberate `object-position`; never crop through a product label or a
  face; width/height or `aspect-ratio` set so nothing jumps.
- Selection colour, focus rings and link underline offset themed from the palette.
- Motion gives the page life: a hero entrance, scroll reveals, moving proof, responsive carousels and
  press feedback, each with a job and varied by section (taste.md §7). Build every effect an operator
  reference has as well. All of it starts from a visible state and runs only under
  `prefers-reduced-motion: no-preference`. Nothing may leave blank bands in a static screenshot.

## 7. Before the first render

Read `references/tells.md` and remove every banned device. Removing tells is not enough: the idea, the
compositions and the real pictures must fill the space they leave.

## 8. Lessons from the reference run

The hand-made run had to fix: a broken logo (check that the logo file renders and has contrast on its
ground), clipped numerals in a stat, stats overflowing a phone row, a label inside a product photo cut by a
crop, and a before/after pair that did not match (different person, light or angle). Look for each one.

## 9. The visual world comes first

When `visual_world.json` exists, it overrides section 3: its palette roles, type, band rhythm, button and
card styles and photography direction are the design system. The brand design plan's `must` rules are hard
constraints, and only an operator reference ranks above them (`references/style-fit.md`); do not swap the
proof accent for another brand colour because it looks livelier.

## 10. References

`references/template-sections-catalog.txt` (and `references/handmade-patterns.md`, patterns from a page the user rated highly) lists the sections of 17 production templates with their
roles, and `handmade-patterns.md` lists the patterns of a page the user rated highly. Read both before you
plan; take compositions from them where the content fits, never as a fixed order. An operator reference
page is different: its order and compositions lead.

## 11. Mobile first

Compose and check at 390 px first. The first screen (390 × 844) must show a readable headline, the CTA and
the product, not cut through the bottle. Body text at least 16 px, tap targets at least 44 px, headings at
most 3 lines, no horizontal scroll except an intended reel.

## 12. Render

The render command in your prompt (`<render command> out/index.html out/shots/rounds/r<n>`) renders with
the runner's Chromium and writes `first-screen.png` (390×844 at 2×), `mobile-NN.png` tiles (one phone screen each, 2×),
`desktop-NN.png` tiles, `mobile.png` / `desktop.png` full pages and `gates.json` (overflow, tap targets,
body text size, heading lines, first-screen checks, before/after framing), and prints the gate summary.

## 13. Page structure rules

- **No long text-only stretches.** A visitor never scrolls through more than two sections in a row without
  a picture, a video or a visual proof element (a real before/after, a product shot, a UGC still, a stat
  band with a real number). Text-only cards count as text-only. When the evidence has no picture for a
  role, merge that role into a neighbouring section that has one, or pair it with a fitting picture from
  `pictures.json`. Never fill the gap with decoration or invented images.
- **A customer-video section whenever the input has usable UGC video.** Build a reel or grid of muted
  autoplay loops with posters, at least 2 clips when 2 or more are usable. A how-to clip does not count.
  With only one usable clip, place it beside the reviews. Record `video_proof: {available, used, why_not}`
  in `plan.json`.
