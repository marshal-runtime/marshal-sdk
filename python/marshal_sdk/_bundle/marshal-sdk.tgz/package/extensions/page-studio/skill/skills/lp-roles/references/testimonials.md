# testimonials

## Job

The visitor thinks: "I can see people using it, and they like it." Customer media is proof on its own.

## Use when / needs

UGC video or customer photos in the pictures (`is_ugc`). A video
needs no quote to count as proof. Whenever UGC video exists, plan this section.

## Write

- The heading invites watching: "Watch it work", "See it on real skin" (but never "real X" as a trust
  claim), "Customers show their routine".
- A card caption is the reviewer's own line when the inventory or the live page gives one with the credit,
  copied exactly. Without a quote, the caption describes what the clip shows ("Pump, press, done", "Over
  moisturizer, every morning") and never invents praise or a name.
- The same rules as `reviews` apply to any quote: verbatim, credited as given, diverse.

## Build

- **Video reel:** a horizontal scroll of 9:16 cards, each a muted, looping, `playsinline` `<video>` with a
  `poster` frame cut from the clip. Clips of 5 seconds at most, scaled to about 360 px wide. The next card
  peeks at the edge so the scroll is obvious, but its caption is not cut off.
- **Grid:** 2 columns on mobile with photos and short captions.
- Check that each clip shows our product (the right bottle) or no product. Judge each one by its frames.

## Pictures

Customer videos first, then customer photos and review screenshots. No studio or model shoots. Never the
same person twice on the page, and never a picture already used above.

## Examples

- Bad: a carousel of stills from the brand's studio shoot, captioned "Loved by thousands".
- Good (OKOA round 2): a 7-clip reel of customers pumping and pressing the cream, with posters, and captions
  from the site quotes where the source gave them.

## Checks

At least one video plays when UGC video exists. The posters render in static screenshots. The captions are
not clipped. No invented quotes.
