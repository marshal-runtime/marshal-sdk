---
name: lp-visual-world
description: Build the page's visual world from the brand's own site - the design plan, the measured snapshot and the site screenshots - and write visual_world.json. Use before planning sections, whenever the input has a design plan or a site/ folder.
---

# The visual world: from the brand's own site

## 1. Read

1. `input/brand/design-plan.md` and `input/brand/design-plan.json` — `summary`, `rules` (each with `id`, `priority`, `area`,
   `rule`, `why`), `surfaces`, `accents`, `avoid`. **`must` rules are hard constraints**; `should` rules are
   the default unless the content gives a stated reason; `may` rules are permissions with limits.
2. `input/brand/site/`: the site profile (`site-profile.json`) and the colour report for measured colours and
   fonts.
3. The site screenshots in `input/brand/site/` — the brand's live pages. Look at them in order: band rhythm, type scale, buttons, cards,
   photography, how proof and price are shown. Note prices and real reviews for the fact sheet as you go.
4. The operator's reference pages, when the operator names any (their shots in `out/reference/<n>/`). They
   rank above the design plan (`lp-design/references/style-fit.md`). Take from them what the operator's
   words ask for; when the words do not say, take the compositions and the effects (write the effects into
   `motion`), and keep the brand's colours and fonts.

## 2. Write `visual_world.json`

```json
{
  "summary": "two or three sentences: the world in words",
  "palette": [
    {
      "name": "",
      "hex": "",
      "role": "canvas | ink | dark band | proof accent | strip | ...",
      "limits": ""
    }
  ],
  "type": {
    "heading": { "family": "", "weight": 0, "case": "", "tracking": "" },
    "body": { "family": "", "weight": 0 },
    "scale_px_mobile": {
      "display": 0,
      "h2": 0,
      "h3": 0,
      "body": 16,
      "small": 0
    },
    "scale_px_desktop": {
      "display": 0,
      "h2": 0,
      "h3": 0,
      "body": 0,
      "small": 0
    },
    "numbers": "how stats are set"
  },
  "surfaces": {
    "rhythm": "e.g. cream, white, dark, cream ... never two dark in a row",
    "dark_share": "",
    "bands": [{ "name": "", "hex": "", "use": "" }]
  },
  "buttons": {
    "radius_px": 0,
    "primary": "",
    "on_dark": "",
    "accent_offer": "",
    "label": ""
  },
  "cards": "",
  "rules": "",
  "photography": {
    "backdrop": "",
    "light": "",
    "crop": "",
    "subjects": [],
    "never": []
  },
  "spacing_mobile_px": { "gutter": 0, "section": 0, "block": 0, "tight": 0 },
  "motion": "",
  "do": [],
  "dont": [],
  "design_plan_rules": [
    { "id": "", "priority": "", "how_this_page_applies_it": "" }
  ]
}
```

- Take every hex value from the design plan or the colour reports, never from a reference page; never pick a
  colour by taste.
- Name one proof accent and its limits (what it may colour, what it never fills).
- The rhythm line decides each band's ground before you write sections; count dark bands against the plan.
- Photography: say what the product shots look like on the site (backdrop, light, crop) and what never to
  show (clutter, other products, a crop through the label).

## 3. Apply it

- The CSS `:root` tokens come straight from `visual_world.json`.
- Each section in `plan.json` gets its band from the rhythm.
- Before each render, check the page against every `must` rule; record each rule as `held` or `broke` with a
  note in `plan.json → design_rules`. A broken `must` rule is a blocker to fix, not a note.
