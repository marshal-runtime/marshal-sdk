# Tells: devices that make a page read as generated

Condensed from the taste-skill tells registry. "Banned" means remove it; "warned" means keep it only with a
reason you can state. A surface, structure or motion device that an operator reference page uses (glass or
backdrop blur, eyebrows, a repeated composition, index numbers, more motion) is not a tell on that page:
keep it where the reference has it (`style-fit.md`, level 1). The proof and copy tells always hold.

## Surface

| Tell                                                                             | Status                                          | Do instead                                    |
| -------------------------------------------------------------------------------- | ----------------------------------------------- | --------------------------------------------- |
| Violet / indigo gradients, gradient headline text, glowing gradient buttons      | banned                                          | Flat brand colour, solid ink                  |
| Glass panels, backdrop blur, translucent cards                                   | warned (2+)                                     | Opaque surfaces one tone step from the ground |
| Soft grey drop shadow under every card                                           | banned                                          | A tone step, or no box                        |
| Near-black ground with one neon accent and a glow                                | banned                                          | The brand palette, no glow                    |
| Yellow-cream ground with terracotta / rust accent as a "warm editorial" shortcut | banned unless the brand tokens are exactly that | The brand's own tokens and the product photos |
| Hairline dividers, ruled grids, 1 px outlined boxes everywhere                   | banned (3+ boxes)                               | Space, tone steps, filled shapes              |
| One medium radius (12–16 px) on everything                                       | warned                                          | Square or fully round, chosen once            |
| Coloured `border-left` stripes on cards and callouts                             | banned                                          | Weight, size, or a filled shape               |

## Structure

| Tell                                                                    | Status                 | Do instead                                                                  |
| ----------------------------------------------------------------------- | ---------------------- | --------------------------------------------------------------------------- |
| Three identical feature cards with an icon in a rounded square          | banned                 | A composed section built for its content                                    |
| Emoji or Unicode glyphs as icons or bullets                             | banned                 | Inline SVG in one stroke, or words                                          |
| Eyebrow / kicker: tiny tracked uppercase label above every heading      | banned                 | Fold it into the heading or delete                                          |
| Pill badge above the hero headline ("New", "Clinically proven")         | banned                 | Say it in the supporting line                                               |
| Index numbering as decoration (01 / 02 / 03, "Step 02")                 | banned                 | Order by position and scale; `<ol>` for a true list                         |
| Headline as a full sentence over three or four lines                    | banned                 | About five words; the rest goes below                                       |
| Stock order: hero, logos, features, testimonial, pricing, CTA           | warned                 | The order of the argument                                                   |
| Every section the same layout family; everything centred                | warned (> 70% centred) | A different composition per section, left-anchored text, one centred moment |
| Nine nearly equal font sizes                                            | warned                 | Five sizes, far apart                                                       |
| Hero-metric template: giant number, small label, three supporting stats | warned                 | A stat only with its study, placed where it proves a claim                  |
| Bento grid of rounded tiles as the benefits section                     | warned                 | A composed section                                                          |
| Text or a CSS box where a picture belongs                               | banned                 | A real picture, or a brief placeholder                                      |
| Monospace micro-labels, tiny letter-spaced captions scattered around    | banned                 | Sentence case at a readable size                                            |

## Proof and copy

| Tell                                                                       | Status | Do instead                              |
| -------------------------------------------------------------------------- | ------ | --------------------------------------- |
| Invented social proof: star rows, "10,000+ happy customers", press logos   | banned | Real proof from the brand data, or none |
| Genre verbs: unlock, elevate, supercharge, seamless, effortless, transform | banned | The specific verb and noun              |
| "Not just X, it's Y"; tricolon slogans; "Meet …"; questions nobody asked   | banned | A plain claim                           |
| More than two em dashes on the page                                        | warned | Full stops                              |
| "Get started", "Learn more" as button labels                               | banned | The action, named                       |

## Motion

Identical fade-up on every block, hover lift on every card, bounce easing: banned, unless an operator
reference does it. A static page is not the fix: give each section a varied move with a job (`taste.md` §7).
Reveals that leave blank bands in a screenshot: always banned.

## Why removal is not enough

A page with every tell removed and nothing in its place is an empty page with good manners. The tells fill
the gap where an idea should be: fill it first with the idea, the compositions and the real pictures.
