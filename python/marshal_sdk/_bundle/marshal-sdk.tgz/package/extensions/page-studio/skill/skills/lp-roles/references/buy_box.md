# buy_box

## Job

The visitor thinks: "I know exactly what I get, what it costs, and that I can't lose." Every word removes
friction or gives a reason to buy now.

## Use when / needs

Always. Prices, plans and bundle terms come from the facts (cite the fact id) or the commercial
terms. A missing price is a visible `[PLACEHOLDER: price]`.

## Write

- The product name and one line on what it is and does. The size when the facts give it.
- **Offer tiers** exactly as the live page shows them (one-time, subscribe and save, the bundle): the label,
  the price, the compare-at price and the saving only when shown. Never calculate a discount or invent a
  shipping term.
- One primary CTA, 3 short words ("Get My Lift", "Add to Cart").
- **Reassurance next to the button:** the real guarantee and terms, and the research complaints answered
  ("Cancel online in one click", "No return fees").
- **Upsell or bundle** (when the strategy asks): a separate card or band after the main box, with what it
  contains and why the pair works together, plus its real price.

## Build

- **Mobile:** the product picture (or a small gallery), the name, the rating line when real, the tiers as
  selectable cards (one pre-selected and marked "Most popular" only when the site says so), the CTA at full
  width, then 2–4 reassurance items with small icons.
- **Desktop:** a two-column layout, with a sticky gallery on the left.
- Details (ingredients, how to use) go in an accordion under the box, short.

## Pictures

The exact product and package on offer, clean on white or cream. The bundle shows both products together.

## Examples

- Bad: "Only $29.99 today! 50% off, free shipping worldwide" (invented offer).
- Good (OKOA, from the live tile): "Subscribe & Save · $44.88 (was $61.90, save 28%)" / "One-time · $61.90"
  / button "Get My Lift" / "90-day money-back guarantee · Cancel online, no calls".

## Checks

Every price is cited in `plan.json → prices`. The tiers are tappable (44 px or more). The guarantee sits
next to the button. No invented terms.
