# problem

## Job

The visitor thinks: "That is my situation, and what I tried did not fix it." It builds the tension the
sections below resolve.

## Use when / needs

The persona's pains, what they already tried, or a documented problem fact, plus the brand's villains or
the category's failures. Place it early, after the hero or the hook.

## Write

- Get the reader to recognise themselves first ("If you've tried every firming cream on the shelf…"), then
  name the frustration precisely: the exact struggle, the time or money it wastes, how it wears on the day.
- Name what they tried and what the alternatives get wrong, plainly, without insulting the reader for
  having used them. Compare against a category, never a named brand.
- Raise the tension and stop. Do not pitch the product yet, or pitch it in one closing line at most.
- No age-shaming and no fear copy: change is natural, not a flaw. Follow the brand's forbidden themes.

## Build

- **Statement and pain cards:** a heading and a short paragraph, then 2–3 cards, each a short pain title and
  one line. Use an image or an icon only when it shows the pain.
- **Image and empathy copy:** one documentary picture of the problem, with the heading and 2–3 short
  paragraphs.
- **Scale of the problem:** one big documented figure about how common the problem is, then the line that
  bridges it to the product.

## Pictures

The real problem or "before" state: a documentary close-up, a frustrated moment, a before image. Never a
happy outcome picture here, and never the product as the hero of the picture.

## Examples

- Bad: "Aging skin is a problem for many women." This is distant, and it frames the reader's face as the
  problem.
- Good (OKOA): "Skin changes. Your skincare should too." / "After 35, most creams only sit on the surface,
  so the jawline softens and creases settle in."
- Good: "Botox worked, until it didn't." This is the brand's own villain line, and it names the failed
  alternative.
- Good (problem → solution page): the persona's own pain from the brand data in one line, then the
  failed alternatives as a short list the next section answers one by one.

## Checks

The visitor's pain is concrete. No product pitch yet. No insult and no shaming. No named competitor.
