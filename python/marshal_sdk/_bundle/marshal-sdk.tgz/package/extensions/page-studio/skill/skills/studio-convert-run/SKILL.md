---
name: studio-convert-run
description: Convert a page imported from a page agent run into Shopify theme sections with ZyG events, product Liquid and per-section styles. Use when the message says "Convert this page, imported from page agent run N, into Shopify sections".
---

# Convert an imported agent run into studio sections

The page was built as one standalone HTML file and imported section by section. Its page-wide CSS sits in
`run-styles` sections, its one script in `run-script`, and its sections are the page agent's. Make every
section stand on its own as a theme section: scoped styles, theme fonts, ZyG event markers, product data from
Liquid. Keep the design, the copy and the order. Do not redesign.

`<assemble>` below is the command your instructions use for `list`, `check` and `turn`.

## Steps

1. **Split the styles.** Run `<assemble> split-styles`. It moves every rule of the `run-styles*` sections into
   the sections that use it, scoped with `[data-zyg-section="<id>"]`, writes those sections to `sections/` and
   puts a `remove` operation for each `run-styles*` section, and for `run-script` when the page has one, in
   `turn.json`. Read its summary: dropped rules,
   sections over 50,000 bytes (split those into two sections), and rules it could not scope (fix them by hand).
   A rule on a class the page script sets on `<html>` or `<body>` (`html.js .rv{…}`) lands on each section root
   (`[data-zyg-section="<id>"].js .rv{…}`); the summary names those classes, and step 3 sets them on the root.
   Rules on `html` and `body` (margins, `scroll-behavior`) land on the section roots; that is harmless, leave them.
   A class counts as used by the script only when the script selects it or sets it (`'.name'`, `classList`,
   `className`), so a rule it dropped as unused is dead.
   Do not run it twice by hand-editing the output; edit the section files it wrote.
2. **Use the theme fonts.** Run `<assemble> tokens`. Replace each web font in the section CSS with the theme's
   font variable or family from that list. Never add Google Fonts, `<link>`, `@import` or `@font-face`.
3. **Move the script.** If a `run-script` section exists, read it, move each piece of code into the section it
   drives and remove the section. In a section, find the root with
   `document.currentScript.closest('[data-zyg-section]')` and touch only elements inside it. No
   `window.addEventListener` or `document.addEventListener`. The `remove` of `run-script` goes in the
   `operations` of `turn.json` if `split-styles` did not already (it reads "nothing to split" when the page has no
   `run-styles`). Where the script sets a class on `<html>` or `<body>`
   (`html.classList.add('js')`), set the classes `split-styles` named on the section root instead. Replace a
   `window` or `document` listener (scroll, resize) with an `IntersectionObserver` or a listener on the root.
4. **Wire every link, button and form** with one ZyG event marker (table below). Cart buttons use Liquid ids.
5. **Write product data as Liquid** (examples below). Page copy stays typed.
6. **Label every section root** with `data-zyg-section-label="<human name>"` (for example `Hero`, `Reviews`).
   Keep `data-zyg-section` and `data-zyg-label` on the root unchanged.
7. **Check.** Run `<assemble> turn --reply "<draft>"`: it adds the `replace` operations of the sections you
   changed and checks them. Fix every problem it prints. Run `<assemble> events` (the static rules) after each turn
   until it passes. Run `<assemble> events --runtime` (clicks every marker in a browser) once, before the final
   reply, and fix what it reports. Finish with `<assemble> turn --reply "<what you converted, in two or three sentences>"`.

Work section by section: `<assemble> extract <id>` copies a section to `sections/<id>.html` (split-styles has
done it for the sections whose styles it changed), edit that file in place, and keep its Liquid and its
pictures as they are. Render the preview (`preview` command and the render tool of your instructions) once at the
end and compare it with the original on a phone and a desktop width.

## Event markers

One marker per element. Every `<a href>`, `<button>` and `<form>` carries one.

| Element                                        | Marker                                                                                     | Tracker calls on click                           |
| ---------------------------------------------- | ------------------------------------------------------------------------------------------ | ------------------------------------------------ |
| Link to a page, a store path or an anchor      | `data-zyg-cta` on the `<a>`                                                                | `cta_click`, then navigate, scroll or open modal |
| Button that opens a dialog                     | `data-zyg-cta data-zs-open="<dialog id>"` (or `aria-haspopup="dialog"`)                    | `cta_click`, `cta_open_modal`                    |
| Add to cart                                    | `data-zyg-atc data-variant-id="{{ … }}" data-product-id="{{ … }}"`                         | `cta_click`, cart add, `cta_add_to_cart`         |
| Buy now                                        | `data-zyg-checkout` with the same data                                                     | as add to cart, then checkout                    |
| Button whose own script adds to the cart       | `data-zyg-atc="track"`                                                                     | `cta_click` only                                 |
| Option pill (a group of 2 or more)             | `data-zyg-pill`, group in `data-zyg-pills`                                                 | `pill_select`                                    |
| Carousel arrow or dot                          | `data-zyg-carousel-nav="prev"`, `"next"` or `"dot"`                                        | `carousel_nav`                                   |
| Form (newsletter, contact)                     | `data-zyg-form="<name>"` on the `<form>`, `action="/…"` store path, `type="submit"` button | `cta_submit_form`                                |
| Plan or frequency choice                       | `data-zyg-plan` / `data-zyg-frequency`                                                     | `plan_selected` / `frequency_selected`           |
| Pure UI control (accordion toggle, close, tab) | `data-zyg-no-track`                                                                        | nothing, on purpose                              |

- A `<summary>` accordion toggle needs no marker; only `<a href>`, `<button>` and `<form>` do.
- A plan choice sets `data-selling-plan-id` on the add-to-cart button (or a `selling_plan` input in its form)
  before the click; the bridge reads the plan there.
- A link to `#id` needs an element with that `id` on the page (any section). A `data-zs-open` needs a dialog
  with that `id`.
- A `<button data-zyg-cta>` that opens no dialog sends nothing: make it a link, give it `data-zs-open`, or mark it
  `data-zyg-no-track`.
- Never put a marker inside a `<zyg-*>` element or a `[data-zyg-block-id]` subtree; those track themselves.
- Never call `trackEvent`, `safeTrackEvent`, `rawdogZyg.` or `zygEvents.` from a section script.
- The run's own buy box: give its root an `id` that contains `zyg-buybox` (`id="zyg-buybox-1"`) and point every buy
  link at it, `<a href="#zyg-buybox-1" data-zyg-cta>`; the bridge then sends `cta_scroll_to_buybox`.
- A `[PLACEHOLDER …]` the run left in a section is unfinished: fill it from Liquid (`product`) or remove it. The
  `turn` check names it.

## Product data

Liquid in the section file, on the page's product (`product`) and on other products
(`all_products['<handle>']`). Keep every `{{ … }}` and `{% … %}` exactly as written.

```liquid
<h1>{{ product.title }}</h1>
<span>{{ product.selected_or_first_available_variant.price | money }}</span>
<s>{{ product.selected_or_first_available_variant.compare_at_price | money }}</s>
<img src="{{ product.featured_image | image_url: width: 900 }}" width="900" height="900" alt="{{ product.featured_image.alt | escape }}">
<button data-zyg-atc
  data-variant-id="{{ product.selected_or_first_available_variant.id }}"
  data-product-id="{{ product.id }}">Add to cart</button>
<a href="{{ all_products['other-handle'].url }}" data-zyg-cta>{{ all_products['other-handle'].title }}</a>
{% for group in product.selling_plan_groups %}
  {% for plan in group.selling_plans %}
    <button data-zyg-plan data-selling-plan-id="{{ plan.id }}">{{ plan.name }}</button>
  {% endfor %}
{% endfor %}
```

- Titles, prices, compare-at prices, plan prices, ids and product pictures are Liquid. Reviews, benefits,
  headlines and other copy stay typed; do not invent copy or facts.
- Product pictures are the ones that must change with the product: the buy box gallery and plain product shots.
  Art-directed pictures (cut-outs, scenes, before and after) keep their URLs.
- Never type a variant, product or selling-plan id as digits; use Liquid.
- A sale badge or a "save N%" that the page computes from two prices stays Liquid arithmetic or a typed claim
  the page already made; do not add one.

## Done when

`check`, `events` and `events --runtime` all print OK, no `run-styles*` or `run-script` section is left, no section loads fonts or
external scripts, and `turn --reply` succeeded. The reply says what changed and names anything you could not
convert.
