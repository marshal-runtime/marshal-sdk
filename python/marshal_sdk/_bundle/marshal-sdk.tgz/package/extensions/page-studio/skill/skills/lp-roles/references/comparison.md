# comparison

## Job

The visitor thinks: "This is the better choice than what I would do instead," or "I can see what it does."

## Use when / needs

Two frames:

| Frame          | Needs                                                                                                   |
| -------------- | ------------------------------------------------------------------------------------------------------- |
| `us_vs_them`   | Documented differences against a generic alternative (the category, or a treatment such as injectables) |
| `before_after` | A real before/after pair of one case from the inventory, with its stated time points                    |

## Write (us_vs_them)

- Start from the buyer's real decision friction (effort, speed, risk, cost, comfort, how natural it looks),
  not generic benefits.
- Compare against a generic mainstream alternative. Never name or imply a competitor brand or product.
- Never invent claims, prices or outcomes for the alternative. Be specific on our side and fair to theirs.
- Order the rows strongest first; never lead with a weak or disputable row.
- Labels are short: "Visible lift in minutes", "No needles, no downtime".

## Write (before_after)

- The sides are the two states of one case: "Before" and "After", or the case's own time points ("9:00 AM" /
  "9:05 AM", "Day 1" / "Day 28"). Write a duration only when a fact states it.
- Keep the results disclaimer ("Results vary"). Never call it "real", "verified" or "same person"; the
  picture shows that.

## Build

- **Table:** an HTML table with our column highlighted (proof accent at low opacity). On mobile, 3 columns at
  most, with short headers, and the first column wrapping.
- **Two cards:** our product against "a typical cream", with 3 short lines each.
- **Before/after slider:** split the pair into halves, stack them, and add a drag handle (pointer events).
  Both halves have the same framing. A labelled pair side by side is the static alternative.

## Pictures

Ours: the product. The alternative: no branded product, or a neutral scene. Before/after: the two halves of
one case, aligned. Never put a customer's before picture under the alternative's label.

## Examples

- Bad: a row "Better results" (vague) or "Brand X: expensive" (names a competitor and invents a claim).
- Good (OKOA): columns "OKOA", "Injectables", "Surface creams"; rows "Visible lift in minutes", "Supports
  elastin over weeks", "No needles, no downtime", "Expressions still move".

## Checks

No named competitor. Every row on our side is backed by a fact. The before/after halves match in framing.
The table fits at 390 px with no sideways scroll.
