# timeline

## Job

The visitor thinks: "I know what to expect and when, so I will stick with it." An honest timeline converts
better than a fast one that leads to refunds.

## Use when / needs

Dated results: `product_context.timeline`, or claims with a timeframe ("in minutes", "after one week",
"after 28 days"). Never invent a stage.

## Write

- 3 or 4 stages, from first use to the outcome the page promises. Each stage has a time label, one short
  title and one line about what the customer notices.
- Match the evidence: a stage states only what a fact with that time states. A stage with no fact behind it
  is dropped, not padded.
- It answers the "I saw nothing after a month" fear with honest pacing.

## Build

A vertical rail on mobile (a dot and a line, with the time as a pill), and 3–4 columns on desktop. A
progress bar per stage is optional. The final stage gets the proof accent.

## Pictures

Optional. When used, show each stage's state, and never the same picture twice.

## Examples

- Bad: "Week 2: Dramatic transformation" (no fact says it).
- Good (OKOA): "5 minutes: skin feels tighter" / "Week 1: 90% said skin felt healthier and more resilient" /
  "Day 28: 93% said skin looked tighter".

## Checks

Every stage traces to a fact with that time. The labels are consistent (all minutes, days and weeks, written
the same way).
