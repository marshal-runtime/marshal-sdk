# hero

## Job

The visitor thinks: "I know what this is, it is for me, and it is worth a scroll." The hero is the only
section that is certainly read.

## Use when / needs

Always the first section. It needs the main message (the strategy's primary message when there is one),
the product name and category, and one proof point.

## Write

It has three jobs, in this order:

1. **Hook.** The heading gives a concrete reason to keep scrolling: a payoff, a number promise or a pointed
   question that names the pain. One claim, 8 words or fewer.
2. **Say what it is.** The next line names the product and its category in plain words, and says what it
   does in one sentence, using real USPs. A visitor who reads only the hero can say what is sold and why.
3. **Make it worth buying.** One line with the core promise and how it delivers the heading's payoff.

- **Chain the lines, never stack them.** The heading states the payoff, the next line names the product,
  the body explains how. Parallel claims fight each other and leave nothing.
- A reassurance row (rating, review count, guarantee) states only what the facts or the live page hold.
  Copy credentials word for word.
- The primary CTA: 3 short words.
- Before you finish, check that the product's actual name is in the hero and its category is in plain
  words. A strong hook with no product fails.

## Build

- **Mobile:** the first 390×844 screen shows the heading, the product line, the CTA and the product
  picture, not cut through the bottle.
- **Stacked thesis:** proof line (stars and review count when real), heading, product line, lede, CTA,
  reassurance row (2–3 terms), then the product picture. The picture must still land inside the first
  screen, so keep the lede short.
- **Product with proof:** a short heading over a split (product photo plus a before/after strip, or a
  timestamp badge like "9:00 → 9:05") when the strongest proof is visual.
- **Image overlay:** the heading on a lifestyle photo only when the photo has a quiet area for the text,
  with a scrim for contrast.
- **Desktop:** a two-column split (text and picture). The picture holds its crop.

## Pictures

The product itself, clearly (a packshot with its carton, or in hand), or the single strongest visual proof
with the product near it. Never an ingredient macro alone, never a logo tile, never another product.

## Examples

- Bad: title "Goodbye, Dry Skin" / subtitle "Reef-Safe Mineral Protection". The subtitle pivots to a second
  USP and never says what the product is.
- Good: title "Goodbye, Dry Skin" / subtitle "HydraGlow Daily Moisturizer, 24-hour hydration in one step".
- Good (numbered page): title "5 Reasons You'll Never Go Back To Foundation" / subtitle "GLOW ME+ Tinted
  Moisturizer Mineral SPF 30" / line "The tinted moisturizer with mineral SPF that covers, protects and
  treats your skin, in one step."
- Good (OKOA): title "Lifts in minutes. Transforms for the long run." (the strategy's primary message) /
  line "Dual Action Lifting Cream: a visible lift on face and neck in minutes, and IDEALIFT™ peptides that
  support elastin for weeks." / reassurance "90-day money-back guarantee · Cancel online, no calls".
- Good (results-led, not a list): title "Six weeks, one routine" over the brand's own before/after pair /
  line names the product and what changed / reassurance row. The proof is the picture, not a count.
- Good (founder story): title in the founder's own words from the brand data / line "Why she made
  <product>, and what it does" / the founder photo beside the product.
- Bad: "Meet the Glow Keeper." A category word ("glow") that any brand could claim, and no product.

## Checks

The product name and category are on the first screen. The heading is at most 3 lines at 390 px. The CTA is
visible without scrolling. The product picture is visible and uncut. The heading, product line and body
chain into one thought.
