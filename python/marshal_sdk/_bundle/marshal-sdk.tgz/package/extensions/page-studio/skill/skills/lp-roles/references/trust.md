# trust

## Job

The visitor thinks: "This brand is credible, the product is high quality, and I can try it without risk."
Each trust section removes the next likely doubt on the way to the buy.

## Use when / needs

At least one documented proof fact. Choose the frame by what the facts hold:

| Frame                  | Use when                                                                                     | Shape                                                                                          |
| ---------------------- | -------------------------------------------------------------------------------------------- | ---------------------------------------------------------------------------------------------- |
| `evidence_spotlight`   | Decisive figures: clinical results, study counts, how common the problem is                  | A big number or a row of 3–4 stats on a dark band, each with a one-line label and a study note |
| `ingredient_spotlight` | Ingredients are a buying reason, and the facts give each a job, amount or source             | One hero ingredient, or 3–4 "name: job" items, with texture pictures or an accordion           |
| `expert_endorsement`   | A named expert with a credential and attributed words, or a professional approval            | A quote card with a portrait, name and credential; or a credential row                         |
| `founder_story`        | Who started the brand and why                                                                | Problem → turning point → the standard kept today; or a signed letter                          |
| `press_mentions`       | The brand has real press logos                                                               | A logo strip with "As seen in". With no logos, use `reassurance_ticker` or nothing             |
| `reassurance_ticker`   | At least two short backed terms (guarantee, returns, shipping, certifications, review total) | A thin strip of 2–5 word items, risk removers first                                            |

## Write

- Start from the buyer's likely objection, then give the strongest evidence that removes it, in plain human
  language: a knowledgeable friend explaining why it works, not a lab report.
- Lead with the conclusion the evidence earns, then the detail that makes it credible: what was measured,
  what changed, over what time.
- Give each proof point one job: efficacy, authority, quality or risk reversal.
- **Numbers:** copy them exactly, with the unit and qualifier ("93% said skin looked tighter after 28 days",
  "in a consumer perception study" when the facts say so). Never round up or upgrade "said" to "proven".
- **Ingredients:** pair each with its job in the visitor's words ("Sodium Hyaluronate: holds water in skin,
  so lines look plumper"). Never list every ingredient; the full list belongs to `benefits.specs`.
- **Experts:** keep the quote in the expert's register, trim it but never extend it, and attribute the
  name and credential exactly. No invented experts. A photo is not an expert.
- **Headings:** name what the evidence proves. Bad: "Science-backed", "Our Story", "Experts Love It".
  Good: "93% saw tighter skin in 28 days", "Made because nothing else worked".
- Keep trust separate from `reviews`: customer voices go there.

## Build

Stats as large HTML numerals in the proof accent of the visual world, each with a one-line caption.
Ingredient grids with real texture macros from the inventory. Expert cards with a portrait only when the
inventory has that person. Ticker items as one line, never wrapped onto two lines on mobile.

## Pictures

Texture and ingredient macros, the evidenced expert or founder, certification marks from the brand assets.
Never stock-looking people as "experts".

## Examples

- Bad: "Clinically proven results." It names the idea of proof without any.
- Good (OKOA evidence band): "93%" / "said their skin looked tighter after 28 days"; "86%" / "said skin felt
  instantly firmer"; footnote "Consumer perception study, 28 days".
- Good (reassurance ticker): "90-day money-back guarantee · No return fees · Cancel online in one click ·
  Free shipping on subscription".

## Checks

Every figure matches the facts word for word. Each item has one job. No invented authority. The ticker has
backed terms only.
