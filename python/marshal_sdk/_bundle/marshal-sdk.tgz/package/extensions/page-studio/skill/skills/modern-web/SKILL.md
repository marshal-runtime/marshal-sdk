---
name: modern-web
description: Chrome's modern web platform guidance for landing pages (GoogleChrome/modern-web-guidance, Apache-2.0) - accordions, carousels and sliders, scroll-driven entry/exit and progress effects, parallax, physics-based easing, animating to intrinsic sizes, motion, typography, text legibility and image priority. Use when building or polishing a page section with any of these, before hand-rolling the behaviour in script.
---

# Modern web guidance

Twelve guides from Chrome's modern web guidance, copied unchanged (see `NOTICE.txt`). Each one says which native
platform feature to use for a common page pattern and how to do it accessibly and fast. Read the guide that matches
the section you are working on:

| Guide | Use it for |
| --- | --- |
| `accordion.md` | FAQ and spec lists that open and close |
| `carousel.md`, `slider.md` | Picture rows, review rows, before/after sliders |
| `scroll-entry-exit-effects.md` | Sections that animate as they enter or leave the screen |
| `scroll-progress-indicator.md` | Reading or page progress bars |
| `parallax-scroll-effects.md` | Depth effects tied to scrolling |
| `physics-based-easing.md`, `motion.md` | Easing curves, durations and reduced-motion rules |
| `animate-to-intrinsic-sizes.md` | Expanding to `auto` height without measuring in script |
| `typography.md`, `improve-text-layout-and-legibility.md` | Type scale, line length, wrapping and contrast on phones |
| `optimize-image-priority.md` | Which pictures load first (hero LCP) and which wait |

Prefer the platform feature the guide names over a script, and always honour `prefers-reduced-motion`.
