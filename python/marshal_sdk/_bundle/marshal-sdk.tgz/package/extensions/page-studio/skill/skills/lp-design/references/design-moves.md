# Design moves: proven compositions per role

These are compositions that work on real converting pages. Sources:

- the ZyG component library (as patterns, not components);
- the 17 production templates (`references/template-sections-catalog.txt` in this skill);
- the hand-made reference page;
- the best POC runs.

Take the **move** (skeleton, density, where the image sits, what is big or small, how mobile behaves). Never
take the colours, fonts or copy of these sources; an operator reference page follows `style-fit.md`. Name the move in `plan.json → sections[].composition`.

| Move                                          | Fits roles                                          | Mobile behaviour                                                                          | Notes                                                                                           |
| --------------------------------------------- | --------------------------------------------------- | ----------------------------------------------------------------------------------------- | ----------------------------------------------------------------------------------------------- |
| Full-bleed photo with copy over it            | hero (overlay variant), statement, founder, closing | Text on a scrim or a panel in the photo's quiet area                                      | Team preference: photo sections are full-bleed, not a timid 50/50 box. Check the scrim contrast |
| Stacked thesis + product                      | hero                                                | Proof line, headline, product line, CTA, then the product picture inside the first screen | The default hero when the strongest proof is the product                                        |
| Split: image and text                         | problem, a reason, how it works, founder            | Image first, then text                                                                    | At most two in a row. Alternate the side                                                        |
| Bento: one photo tile anchors 2–4 small tiles | benefits, ingredient spotlight                      | Photo full width, tiles 2×2                                                               | Cells = items. At least two tiles carry an image or a distinct ground                           |
| N cards in a row                              | reasons, ingredients, steps                         | Swipe with a visible peek, or stack                                                       | Equal heights. Pin the last line to the bottom                                                  |
| Icon + title + line items                     | benefits (icon row), reassurance                    | 2 columns or a list                                                                       | Inline SVG, one stroke weight. Never icons as decoration only                                   |
| Product orbit                                 | benefits                                            | Product, then a 2×3 grid                                                                  | The product photo in the centre, 4–6 short benefits around it                                   |
| Stat band                                     | trust.evidence_spotlight                            | 2×2 numbers                                                                               | Big HTML numerals in the proof accent, a one-line caption each, a study footnote                |
| Stats over a photo (collage)                  | trust, results                                      | Stats stack under the photo                                                               | Use when one strong picture and 2–3 numbers prove the same thing                                |
| Comparison table                              | comparison.us_vs_them                               | 3 columns at most, short headers                                                          | Our column tinted. The strongest rows first                                                     |
| Before/after slider                           | comparison.before_after                             | Full width, a draggable handle                                                            | Halves of one pair, framed alike                                                                |
| Horizontal timeline / rail                    | timeline                                            | Vertical rail                                                                             | 3–4 stages, the time as a pill                                                                  |
| Steps with pictures                           | how_to_use                                          | Stacked                                                                                   | 2–4 steps; the usage tip in a callout                                                           |
| Reviews carousel / quote cards                | reviews                                             | Swipe with a peek                                                                         | Stars only when real. The pulled line large, the credit small                                   |
| UGC video reel                                | testimonials                                        | 9:16 cards, swipe with a peek                                                             | Muted loops with posters                                                                        |
| Logo / press marquee                          | trust.press_mentions                                | A single scrolling row                                                                    | Only with real logos                                                                            |
| Reassurance ticker                            | trust.reassurance_ticker                            | One line, scrolling or wrapped into 2 rows                                                | Risk removers first                                                                             |
| Accordion, split heading + items              | faq, ingredient details                             | Heading on top, items below                                                               | The first item open                                                                             |
| Tabs                                          | specs, variants, routines (AM/PM)                   | Tabs or segmented control                                                                 | Only when the items are parallel                                                                |
| Buy box with offer tiers                      | buy_box                                             | Gallery, name, tiers as cards, CTA full width, reassurance                                | The tiers exactly as on the live page                                                           |
| Bundle / upsell band                          | buy_box (upsell)                                    | Stacked card                                                                              | Both products in one shot, the real bundle price                                                |
| Sticky mobile buy bar                         | buy_box support                                     | A bottom bar with the price and the CTA after the hero                                    | Never covers content. Hidden when the buy box is on screen                                      |
| Statement band                                | hook, closing                                       | A large line on a colour or dark field                                                    | Short by design                                                                                 |

## Choosing between moves

1. Start from the section's job and its content (count the items, note the longest string, check which assets
   exist).
2. Shortlist two moves that fit, and pick the one that differs most from the neighbours and suits the
   assets.
3. Write the phone behaviour before the desktop layout.
4. The 17 production templates show which moves converted for similar products. Use
   `references/template-sections-catalog.txt` to see how often a role used a move, and favour proven
   moves for the hero, the buy box and the proof sections.
