# hook

## Job

The visitor thinks: "That is exactly what I want, or what I fear." It turns attention into interest right
after the hero, and opens the argument rather than closing it.

## Use when / needs

When the persona has one sharp tension or desire, or the brand has one surprising point. It is optional;
skip it when the hero and the problem already carry the tension.

## Write

- Name the specific tension or desire the visitor came with, in their own words, so it feels recognised,
  not diagnosed.
- One idea, short and concrete, pointed at the single thing they most want or most fear.
- It sets up the sections below. It does not resolve the tension.
- Take the vocabulary from the persona's pains and the brand voice.

## Build

A statement band: one large line, and at most one short supporting line, on a colour or dark field. Or one
strong picture with one line beside it. It is short by design; it must not look like a second hero.

## Pictures

A product moment or a credible person that matches the line. Never an ingredient macro alone.

## Examples

- Bad: "Skincare that works." It names nothing the visitor feels.
- Good (OKOA): "You love the lift. You just don't love the needle." This is the brand's own words, and it
  names the exact tension of the persona.
- Good: "Your eyes are the first thing people read." It names the desire behind an eye cream without
  shaming.

## Checks

One line carries the section. It does not repeat the hero's claim. No age-shaming or fear copy.
