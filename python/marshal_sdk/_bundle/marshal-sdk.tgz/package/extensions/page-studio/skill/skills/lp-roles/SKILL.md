---
name: lp-roles
description: The section roles a converting DTC landing page is built from (hero, hook, problem, benefits, trust, comparison, reviews, testimonials, timeline, how to use, buy box, FAQ, closing) - the job of each, when to use it, how to write and build it on a phone, its pictures, worked examples and checks. Use when planning the page's sections and before writing each section.
---

# Landing-page roles

A page is one buying argument told in sections. Each section has one **role**: the job it does in the
argument. Pick the roles from the facts and the strategy, give each one a composition, then write it from
its reference file.

## 1. The argument the roles serve

Hook → credibility → reasons to believe → objections removed → action.

| Stage                            | Typical roles                                                                   |
| -------------------------------- | ------------------------------------------------------------------------------- |
| Hook: what it is, why care       | `hero`, `hook`, `problem`                                                       |
| Credibility: why trust the claim | `trust` (evidence, expert, founder, press), `comparison` (before/after)         |
| Reasons to believe               | `benefits`, `trust.ingredient_spotlight`, `comparison` (us vs them), `timeline` |
| Objections removed               | `reviews`, `testimonials`, `how_to_use`, `faq`, `trust.reassurance_ticker`      |
| Action                           | `buy_box` (with an upsell or bundle when asked), `closing`                      |

The strategy's structure hints are preferences, not orders. A "five-reasons page" is a hero that
promises five reasons, five `benefits.reason_to_buy` sections (each one reason with its proof), then the
product, proof, routine and reassurance, but only when the brand data holds five distinct, provable
reasons. With fewer, use fewer, or another page type, and say why in `notes.md`.

## Role plan from evidence

Before you write any section, list the candidate roles and cite, for each one, the evidence that earns it:
an input file and field (`input/products/<id>/product.json → testimonials`, `input/products/<id>/facts.md` id `F3`,
`input/brand/site/`) or a picture key from `input/products/<id>/pictures.json`. A role with no evidence is dropped. Write it to `plan.json → role_plan` as
`[{role, evidence: [...], why}]`.

With an operator reference page, map each reference section to a role first. In strict mode (every
component, same order), a reference section our evidence cannot fill keeps its slot with our nearest real
content or a marked placeholder; otherwise drop it. Record either in `plan.json → reference_fidelity`.

| Evidence in the brand data                               | Earns                                             |
| -------------------------------------------------------- | ------------------------------------------------- |
| Before/after assets                                      | results (`comparison.before_after`)               |
| Real UGC pictures, verified reviews                      | `reviews`, `testimonials` (reel)                  |
| A founder or expert story                                | `trust.founder_story`, `trust.expert_endorsement` |
| Named actives with study numbers                         | `trust.ingredient_spotlight` (ingredients)        |
| A bundle or set on the live page                         | `buy_box` with the bundle or set offer            |
| Research complaints, objections                          | `faq`, `trust.reassurance_ticker`                 |
| A multi-mode or multi-use product                        | feature explorer, "which mode for you"            |
| A routine product (steps, morning and night, a sequence) | `how_to_use`, routine                             |

Then choose the page type the evidence supports and record it with its reason in `plan.json → page_type`:

| Page type          | Choose it when the evidence holds                                                  |
| ------------------ | ---------------------------------------------------------------------------------- |
| Numbered reasons   | that many distinct, provable reasons (a count in the strategy alone is not enough) |
| Founder story      | a real founder or expert story with its own proof                                  |
| Problem → solution | a sharp, documented pain and the failed alternatives                               |
| Results-led        | strong before/after pictures or dated, measured results                            |
| Comparison-led     | documented differences against the buyer's current option                          |
| Feature explorer   | several modes, uses or settings the buyer chooses between                          |
| Routine            | a product used in steps or as part of a daily ritual                               |

## 2. Choosing roles

- **A role needs facts.** Each reference says what it needs. A role with nothing real behind it is left
  out. The exception is `buy_box`, which always exists, with a marked placeholder where a price is missing.
- **A role needs a reason to be there.** Ask what the visitor learns in it that they did not know from the
  sections above. If the answer is nothing, cut it or give it a new angle.
- **One role can appear twice** when each appearance does a different job: `trust.evidence_spotlight` for
  clinical numbers, and `trust.reassurance_ticker` for terms near the buy box.
- **Proof lives near its claim.** Put the quote that kills a fear right after the section that raises it.
  Put the guarantee next to every buy button.
- **Customer proof:** when the pictures hold UGC, plan a `testimonials` section built on it.

## 3. The reference files

Read the role's file before you write its section:

| File                         | Role                                                                                                                                        |
| ---------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------- |
| `references/hero.md`         | `hero`                                                                                                                                      |
| `references/hook.md`         | `hook`                                                                                                                                      |
| `references/problem.md`      | `problem`                                                                                                                                   |
| `references/benefits.md`     | `benefits`, frames `reason_to_buy`, `specs`, `whats_included`                                                                               |
| `references/trust.md`        | `trust`, frames `evidence_spotlight`, `ingredient_spotlight`, `expert_endorsement`, `founder_story`, `press_mentions`, `reassurance_ticker` |
| `references/comparison.md`   | `comparison`, frames `us_vs_them`, `before_after`                                                                                           |
| `references/reviews.md`      | `reviews`                                                                                                                                   |
| `references/testimonials.md` | `testimonials`                                                                                                                              |
| `references/timeline.md`     | `timeline`                                                                                                                                  |
| `references/how_to_use.md`   | `how_to_use`                                                                                                                                |
| `references/buy_box.md`      | `buy_box`, including upsell and bundle                                                                                                      |
| `references/faq.md`          | `faq`                                                                                                                                       |
| `references/closing.md`      | `closing`                                                                                                                                   |

Each file has the same parts:

- **Job:** what the visitor must think after the section.
- **Use when / needs:** the facts it requires.
- **Write:** the copy rules for this role.
- **Build:** compositions that work on a 390 px phone, and their HTML.
- **Pictures:** which assets fit, and which never do.
- **Examples:** bad and good pairs with the reason.
- **Checks:** what to verify on the render.

## 4. Composition rules across roles

- No two neighbouring sections share a composition, unless the operator's reference does it. Alternate
  image-led and type-led sections, light and dark grounds, dense and open.
- Numbers, tables, timelines, icons, ratings, offer cards and badges are HTML, never images.
- Every image sits in a deliberate frame (`aspect-ratio`, `object-fit`, `object-position`) and is never
  cropped through a product label or a face.
- A section's heading and its first line read as one thought.
- Numbering: number the reasons only when the plan chose numbered reasons for cause (the data holds that
  many distinct, provable reasons); then the number is content. Never use "Step 01" or "01 /" labels as
  decoration, unless the operator's reference does it.

## 5. Page structure rules

- **No long text-only stretches.** A visitor never scrolls through more than two sections in a row without
  a picture, a video or a visual proof element (a real before/after, a product shot, a UGC still, a stat
  band with a real number). Text-only cards count as text-only. When the evidence has no picture for a
  role, merge that role into a neighbouring section that has one, or pair it with a fitting picture from
  `pictures.json`. Never fill the gap with decoration or invented images.
- **A customer-video section whenever the input has usable UGC video.** Build a reel or grid of muted
  autoplay loops with posters, at least 2 clips when 2 or more are usable. A how-to clip does not count.
  With only one usable clip, place it beside the reviews. Record `video_proof: {available, used, why_not}`
  in `plan.json`.
