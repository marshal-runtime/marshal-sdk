# reviews

## Job

The visitor thinks: "People like me bought it, and it worked for them." Each quote answers one objection.

## Use when / needs

Real customer reviews: `input/brand/brand.json → testimonials`, `input/products/<id>/product.json → testimonials`
(verified-buyer quotes with names), or reviews visible on the site screenshots. With none, leave the role
out, or show a marked placeholder when the strategy requires it.

## Write

- **Choose before you write.** Pick the best five-star reviews that show the product's strengths and align
  with the page's key messages. Each card comes from a different reviewer, and the set covers different
  results and objections.
- **Pick quotes with weight:** a specific result ("the fine lines between my eyebrows are almost gone"), a
  before-and-after contrast ("I used to…, now…"), and who the person is. Skip "Great product!", "Love it!"
  and anything any brand could print.
- **The customer's own words.** Choose the line and trim it to fit; never add a word, fix the voice or merge
  two reviews.
- **Credit** each quote exactly as the source tags it ("Yulia B., verified buyer"). No source name means no
  invented name; credit "Verified buyer" only when the source says so.
- A card carries only what its review carries: no outcome, time, date, star count or "Verified" label the
  source does not state.
- **A rating header** (e.g. "4.9 · 171 reviews") only when the live page or the facts show it, copied
  exactly, and cited in `plan.json`.
- **Headings:** never "Real customers, real results" or any "real X". Good: "See why customers keep it",
  "Goodbye to {pain}", "Join thousands of happy customers" (the count only when it is real).

## Build

Quote cards in a horizontal scroll on mobile or a 3-column grid on desktop. Each card has the stars (only
when real), a short pulled line in larger type, the full trimmed quote, then the credit. Avatars only from
the inventory's profile images of customers, never the same face twice.

## Pictures

Customer avatars or photos from the inventory. Never the product as an avatar, never a model shoot.

## Examples

- Bad: "Real women. Real results." / "Amazing!! – Sarah" (invented name, generic rave).
- Good (OKOA, from the site copy): "It lifts and tightens and the effects last through the day." Credit:
  Sue S., verified buyer.

## Checks

Every quote is traceable to its source in `plan.json → quotes`. No invented names or ratings. The quotes are
diverse. Each sits near the objection it answers.
