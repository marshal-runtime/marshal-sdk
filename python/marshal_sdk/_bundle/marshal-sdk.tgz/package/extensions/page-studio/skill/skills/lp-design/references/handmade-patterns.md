# Section patterns from a hand-made reference page

These patterns come from a page that the user rated highly. They are inspiration for composition, not a
menu or an order. Choose per section what its content and assets need.

- **Hero:** a stacked thesis (proof line, headline, lede, CTA, reassurance row) with a product image that is
  visible within the first mobile screen.
- **Before/after:** a drag slider built from one before/after pair split into halves.
- **Stats band:** 3–4 measured claims, a big number plus one line each, on a dark band.
- **UGC video reel:** horizontal scroll, 9:16 cards, muted loops.
- **Numbered reasons:** alternating image and text, one claim chip each.
- **Ingredients accordion:** texture images beside it.
- **Comparison table:** the product against injectables against surface creams.
- **Milestone timeline:** minutes, week 1, day 28, month 3.
- **How-to steps:** with the "over moisturizer" warning.
- **Buy box:** gallery and offer tiers. **FAQ** accordion. **Closing:** an image banner or a statement with a
  CTA.
