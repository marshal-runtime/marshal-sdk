---
name: lp-review
description: Rubric for critiquing a rendered landing page from screenshot tiles - strategy coverage, claims, craft defects and generated-looking tells - with one verdict line per defect. Use when reviewing a page render, as the critic or before calling the critic.
---

# Reviewing a rendered landing page

Judge what the screenshots show, not what the HTML intends. Read every mobile tile in order, then the
desktop tiles. Compare the craft with the reference tile when you have one; never compare content.

## 1. Strategy coverage (page level)

For each requirement in `plan.json → strategy`:

- `met`: find the named sections in the tiles. Is the requirement visibly met there? The primary message
  must be the hero headline (first screen at 390 px). A structure hint ("bundle upsell") must be
  recognisable in the page, not just named in the plan. A count ("five reasons") is checked only when
  `plan.json → page_type` chose numbered reasons for cause; a smaller count or another page type with a
  real reason in `notes.md` is not a defect.
- `dropped`: the reason must be real (the facts truly cannot support it), and the page must not use the
  dropped line anyway.
- Requirements in the strategy (`input/page/brief.json → positioning`) that the plan does not list at all are a `fix`.

Report `strategy: <met>/<total> met, missing: <ids or none>`.

## 2. Truth (page level)

- Every number and claim appears in `plan.json → fact_sheet.claims` (check doubtful ones in
  `input/products/<id>/facts.md`, `input/page/facts.md` and `input/products/<id>/product.json`), with its study length when the brand gives one. An invented number, review, rating,
  review count, price or ingredient is a `blocker`.
- Qualifiers: compare each claim with its fact word for word. A health or medical claim, quote or story
  that lost the source's disclaimer ("results may vary", "individual experience"), or an ingredient-study
  figure presented as a product result (the ingredient not named in the same line, headline included), is a
  `blocker`. A dropped hedge ("tends to", "may", "up to", "in a study of N") is a `fix`. One statistic used
  for two different results is a `fix`.
- Forbidden words and themes from the voice (age-shaming, fear, overpromising such as Botox or filler
  equivalence) are a `blocker`.
- Placeholders must look like placeholders, not like real data.

## 3. Defects per tile

| Defect                                                                                                                   | Severity                        |
| ------------------------------------------------------------------------------------------------------------------------ | ------------------------------- |
| Broken or missing image, logo invisible on its ground                                                                    | blocker                         |
| Text clipped, overlapping or overflowing the viewport; numerals cut at the top or bottom                                 | blocker                         |
| Hero headline over two lines at 390 px, or the first screen without the product                                          | fix                             |
| A product label, face or hand cut by a crop; baked-in text from another ad that competes with the copy                   | fix                             |
| Before/after pair that does not match (person, angle, light, crop), or unlabeled                                         | fix                             |
| Another product shown as this one                                                                                        | blocker                         |
| Two neighbouring sections with the same composition                                                                      | fix                             |
| A tell from the design skill (eyebrow labels, icon-card trio, emoji icons, invented proof, gradient text, index numbers) | fix                             |
| Low contrast text, especially over images                                                                                | fix                             |
| Tap targets under 44 px, a sticky bar covering content                                                                   | fix                             |
| Desktop: stretched phone layout, tiny images in wide columns, line length over ~80ch                                     | fix                             |
| Generic copy another brand could print unchanged, genre verbs                                                            | nit, or fix when it is the hero |
| Spacing rhythm, small alignment issues                                                                                   | nit                             |

A composition or a tell that the operator's reference uses is not a defect here (section 11).

## 4. Verdict format

One line per defect, most severe first:

`<blocker|fix|nit> | <section id or tile file> | <what is wrong, concretely> | <the fix>`

Then the strategy line, then `verdict: clean` (no blocker and no fix left) or `verdict: needs-work`.
Be concrete: "stat '87%' clipped at the top in mobile-04.png, line-height 0.8" beats "typography issues".
Do not praise. Do not list more than ~20 lines; merge repeats.

## 5. Mobile first (judge in this order)

1. `gates.json` — every failing mobile gate is at least a `fix`: horizontal overflow, tap targets under 44 px,
   body text under 16 px, headings over 3 lines, before/after halves framed differently, broken images.
2. `first-screen.png` (390 × 844) on its own: the headline is readable, the CTA is visible, the product image
   appears and is not cut through the product. A failure here is a `blocker`.
3. The `mobile-*.png` tiles at full resolution, one phone screen each: look closely at every crop (product
   bottle, label, face, hands), every label inside an image, every number. Then the desktop tiles.

## 6. The visual world and the design plan

- Check the page against `visual_world.json`: palette roles (the proof accent only where it is allowed),
  band rhythm (count dark bands; never two dark in a row when the plan says so), type families and weights,
  button radius, card style, photography direction.
- Every `must` rule of `input/brand/design-plan.md` that the page breaks is a `blocker`; a
  broken `should` rule is a `fix` unless `plan.json → design_rules` gives a reason. A rule broken where the
  operator's reference does the thing, with the `design_rules` note naming the reference item, is not a
  defect (section 11).

## 7. Proof

- A quote must match its cited source word for word, with the name as given. A quote with no source is a
  `blocker`. Prices must match the cited fact.
- When the pictures hold UGC (`is_ugc`) and the page shows none, that is a `fix`.

## 8. Style fit and taste

Run the style-fit checklist in `lp-design/references/style-fit.md` and the layout-discipline rules
in `lp-design/references/taste.md` §3:

- no layout family twice, and no more than two image-and-text splits in a row;
- eyebrow restraint;
- grid cells equal the content;
- an explicit mobile collapse;
- one accent, one radius scale;
- the one bold element, with everything else quiet.

Each of these yields where the operator's reference does the thing (section 11).

## 9. Roles and conversion copy

For each section, read its role in `plan.json` and the **Checks** part of that role's file in the
`lp-roles` skill (`references/<role>.md`), and judge the section against them.

At page level, check these:

- **The role plan:** open the evidence each `plan.json → role_plan` entry cites. A role with no real
  evidence is a `fix`; a section that shows invented proof is a `blocker`. The `page_type` must fit the
  evidence (numbered reasons only with that many distinct, provable reasons).
- **The argument:** hook, credibility, reasons, objections removed, action. Is a stage missing? Does any
  section teach nothing new?
- **The hero:** names the product and its category in the first screen, and its lines chain into one
  thought.
- **Headlines:** 8 words or fewer, with one claim each.
- **CTAs:** 3 words or fewer, with one action name for the page.
- **The guarantee** sits next to every button.
- **Banned:**
  - em or en dashes in the copy;
  - "real X" trust lines;
  - "not just X, it's Y";
  - the beauty bingo words in `lp-copywriting/references/craft.md` §6;
  - a data field (rating, count, price) turned into a slogan.

## 10. Page structure (blocking)

- **Text-only runs:** count the longest run of consecutive sections with no picture, video or visual proof
  element (a real before/after, a product shot, a UGC still, a stat band with a real number). Text-only
  cards count as text-only. A run longer than two is a `blocker`.
- **Video proof:** when the input has usable UGC video, a missing customer-video section (a reel or grid of
  muted autoplay loops with posters, at least 2 clips when 2 or more are usable, a how-to clip not
  counted, a single clip beside the reviews) is a `blocker`, and so is a `plan.json → video_proof` that does
  not match the input.

Report `structure: longest text-only run <n>; video proof <ok|missing|n/a>`.

## 11. Operator reference pages

The source order is in `lp-design/references/style-fit.md`: a reference ranks first for the layout (sections,
order, compositions, effects), and the style defaults of every skill, this rubric's taste checks included,
rank last. The look (colours, fonts, type, buttons, surfaces, pictures) is always the brand's. Claims,
accessibility and the output contract never yield to a reference.

For each `used` entry of `plan.json → references`, read its `instructions`, then walk its shots in
`out/reference/<n>/shots/` from the top beside the page tiles. Use `capture.md` there for a captured page,
and `input/page/reference/<n>/template.json` (the exact section order) for an input page.

| Finding                                                                                                            | Severity |
| ------------------------------------------------------------------------------------------------------------------ | -------- |
| Strict mode (every component, same order, same layout): a reference section missing from the page, or out of order | blocker  |
| Text, claims, numbers, names, a logo or a picture copied from the other brand                                      | blocker  |
| A reference effect missing from the page with no real reason in `reference_fidelity`                               | fix      |
| Colours, fonts or type taken from the reference instead of the brand                                               | fix      |
| A `reference_fidelity` entry the page does not match (`kept` but absent, or a reason that does not hold)           | fix      |
| An `unreachable` reference without a real reason (bot wall, password or login page, a README warning)              | fix      |

- A strict slot kept with our nearest real content or a marked placeholder, recorded as `changed`, is not
  missing.
- A composition or effect the reference uses is not a tell and not a taste break: do not flag it.

Report `references: missing sections <ids or none>; missing effects <ids or none>` (or `references: none`).
