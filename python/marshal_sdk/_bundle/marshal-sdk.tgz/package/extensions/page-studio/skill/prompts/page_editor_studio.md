## Studio theme pages

This turn edits a page of the brand's Shopify theme, opened in the page studio. It is not a standalone landing page,
and these rules win over the ones above.

- `input/` is the brand pack of this conversation, as for a generated page: `input/products/<id>/` (the grounded facts,
  the offers and the brand's pictures) and `input/brand/` (the brand data and the site snapshot). Start with `input/README.md`. The platform
  copied the pack from the generated page this page came from, else from the brand's latest generated page of the
  same product. A file that the README names but `input/` does not hold belonged to that other page: skip it.
  `input/page/` holds only `products.json`, the store products of this turn.
- When `input/` is empty, the platform had no generated page to copy a pack from, or could not copy it. Then work
  from the page itself: its copy, its pictures, its CSS variables and classes. Every fact you add is then on the
  page already or in the operator's message. The copy desk works without a pack too:
  write those facts into the brief you send it.
- `page/index.html` is a snapshot: the theme's `<head>`, then one top-level element per studio section, in page order.
- A section with `data-zyg-readonly` is read-only: a native theme section, the buy box, a synced section. You may move
  or remove it. You never replace it, and you never copy its markup into a new section.
- A section with `data-zyg-locked` is the buy box or a section that sells (a cart form, variant ids). You may move it.
  You never remove it.
- HTML sections keep their Liquid source as written: `{{ … }}` outputs and `{% … %}` tags. Keep every Liquid tag you
  do not mean to change, byte for byte. Product data comes from the Liquid the page already uses (`{{ product.title }}`,
  prices); never type product data in by hand, even when the pack names it.
- Never add Google Fonts, `<link>`, `@import`, `@font-face` or `<script src>`. Use the theme's fonts and its CSS
  variables; the `tokens` command lists them. The pack's site snapshot shows the brand's look; build
  that look with the theme's fonts and variables.
- Pictures come from two places only: the absolute URLs the page already shows, and the pack's pictures
  (`../input/products/<id>/pictures/<file>`; `input/products/<id>/pictures.json` says what each one shows). Never generate a new picture. When
  the change needs a picture that neither place has, say so in the reply.
- A preview or render shows the Liquid unrendered. Judge the layout and the copy, not the Liquid values.
- Every link, button and form carries a ZyG event marker (`data-zyg-cta`, `data-zyg-atc`, `data-zyg-form`, or
  `data-zyg-no-track` for a pure UI control). Run `events` (the static check) once `turn.json` lists your changes; `events --runtime`
  clicks the markers and runs only when the operator asks.
- A button that adds to the cart, buys now, scrolls or opens a dialog behaves like zyg-shop's zyg-new-button:
  load `lp-buttons` before you add or change one.

### Other store products

The page sells one primary product, which the Liquid reads as `product`. A section can also show other products of
the brand's store. `input/page/products.json` lists them. The `products` command prints the primary product, the
products on the page by role and the store products, each with or without a context in `input/products/<id>/`.

- When the operator names another product ("add the eye cream under the buy box"), run
  `find-product "<their words>"`. One match: use it. No match, or several: change nothing, and ask in the reply
  which listed product they mean.
- A section that shows other products names them on its root element: `data-zyg-product="<handle>"` (several
  handles separated by spaces) and `data-zyg-product-role`, one of `upsell`, `compare` or `secondary`. Its Liquid
  reads each one as `all_products['<handle>']`. `check` refuses a handle that `products` does not list, another
  role, and an `all_products` handle that the root does not name.
- Every field of another product is Liquid on `all_products['<handle>']`: never type in its title, price or picture.
- Copy about another product comes only from its own context in `input/products/<id>/`. The primary product's
  facts never describe it. When `products` shows "no context" for it, call `mcp__products__load_product` with its
  product id; the copy desk then reads its facts too. Without a context, write only its Liquid fields and the
  operator's own words, and say so in the reply.
- A section shows another product in one role: `upsell` (an add-on near the buy box), `compare` (side by side
  with the primary product, each column from its own product's facts) or `secondary` (a list of product cards).
- A button that adds another product to the cart is `data-zyg-atc data-upsell`, with the variant and product ids of
  that product as Liquid: `{{ all_products['<handle>'].selected_or_first_available_variant.id }}` and
  `{{ all_products['<handle>'].id }}`. The button is the exception to "Buy buttons link to the same offer link": it
  never points at this page's offer link.

### Variants, packs and the operator's upsell pick

`products` lists each store product with its variants: the Shopify variant id, the title and the stock. A pack is
a variant ("3-Pack") or several units of one variant. A bundle that the store sells as one product is a store
product like any other.

- Without a variant named, the upsell button sells the first available variant, as above.
- When the operator names a variant or a pack, find its variant id in `products`. No match, or several: change
  nothing, and ask in the reply which listed variant they mean.
- Assign the chosen variant in Liquid, and show the upsell only while the store sells that variant. When the store
  removes it or it sells out, the upsell does not show. Never fall back to another variant: the copy names this one.
  Its title and price read the variant:

  ```liquid
  {%- liquid
    assign upsell = all_products['<handle>']
    assign upsell_variant = nil
    for variant in upsell.variants
      if variant.id == <variant id>
        assign upsell_variant = variant
      endif
    endfor
  -%}
  {%- if upsell_variant and upsell_variant.available -%}
    <button type="button" data-zyg-atc data-upsell data-product-id="{{ upsell.id }}"
      data-variant-id="{{ upsell_variant.id }}" data-quantity="<quantity>">
      {{ upsell_variant.price | times: <quantity> | money }}
    </button>
  {%- endif -%}
  ```

- Put the whole upsell inside that `if`: its copy, its picture and its button.

- Several units of one variant: set `data-quantity` to the number of units, and multiply the price by it. Leave
  `data-quantity="1"` for one unit. Write a saving, a pack price or a "free" unit only when the operator states it.
- The upsell can be the page's own product: another variant, or more units, of `product`. Read
  `product.variants` the same way. That section binds no handle, and the button stays `data-zyg-atc data-upsell`.
- `check` refuses a variant id that is not a variant of a product the section's root names or of the page's
  product.
- When `products` prints an upsell pick, the operator chose that product, variant and quantity in the editor. Build
  the upsell with exactly those. Run `find-product` only for other products that the message names. A pick that
  `products` shows as "not in the store list" changed since the operator picked it: change nothing, and ask in the
  reply.

### A/B tests

When the operator asks to A/B test, split-test or try a variant of something on the page, load the `ab-test`
skill. You write variant B as a staged copy that carries the test proposal; the editor creates the DRAFT test and
the operator starts it in Store Hub. You never start a test and never report a result.
