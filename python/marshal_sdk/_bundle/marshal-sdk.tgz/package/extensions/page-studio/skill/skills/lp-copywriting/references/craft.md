# Conversion copy craft

This file is adapted from the production page builder's copywriter prompt (`lp_text_agent/prompt_current.py`).
The template-specific parts are removed. Role-specific guidance lives in the `lp-roles` skill.

## Contents

1. Copywriting principles
2. Headlines
3. CTAs
4. CRO principles
5. Self-check
6. AI writing tells and word-level cuts
7. Anti-pattern examples

## 1. Copywriting principles

1. **Clarity over cleverness.** If you must choose, choose clear.
2. **Write so an 8th-grader can read it.** Use the shopper's vocabulary, not chemistry-class terms. Save a
   technical term for when it IS the proof point (see 7).
   - Bad: "Improves moisture at the cellular level with biomimetic peptides."
   - Good: "Sinks in and helps skin hold moisture far longer."
3. **Benefits over features (the big one).** A feature is what the product has; a benefit is what that does
   for the reader. After each feature, ask "which means…?" and write the answer.
4. **One clear idea per slot.** The body backs the headline; it does not add four more claims. Read the body
   aloud: if it sounds like a list, strip it back to the one point the headline promises.
5. **Specificity over vagueness.** Trade adjectives for concrete detail: "Saves time" becomes "Cut weekly
   reporting from 4 hours to 15 minutes".
6. **Customer language over company language.** Mirror the words customers use in the reviews and quotes.
7. **Name the unfamiliar.** When an ingredient, term or acronym stays because it is the proof, add a
   one-clause plain-English expansion on first mention. "A daily HA booster" becomes "A daily hyaluronic
   acid booster".
8. **Be direct.** "Our tint can help provide coverage many customers find suitable" becomes "Natural
   coverage you can wear every day."
9. **Show, don't tell. Active voice. Honest, not sensational.**
10. **Never fabricate** offers, prices, discounts, shipping claims, credentials or endorsements. Use a price
    only when the facts or a site screenshot show it, exactly. Never calculate a discounted price. Copy a
    credential word for word ("Dermatologist recommended", not "Parent and dermatologist recommended").
    Name a patented ingredient, never a patent number.
11. **Data and display fields stay data.** A rating ("4.9/5"), a review count, a price, a guarantee or a
    shipping term keeps its shape and is filled with the real value. It is never turned into a slogan or a
    benefit line. With no real value, show a marked placeholder.

## 2. Headlines

- Proven shapes:
  - **Outcome:** "{Outcome} without {pain}", "Turn {input} into {outcome}".
  - **Problem:** "Never {unpleasant event} again", "Stop {pain}. Start {pleasure}."
  - **Audience:** "{Key feature} for {audience}", "You don't have to {skill} to {outcome}".
  - **Differentiation:** "The {opposite of usual} way to {outcome}", "The {category} that {differentiator}".
  - **Proof:** "{Number} {people} use {product} to {outcome}".
  - **Simple:** "Finally, {category} that {benefit}".
- One claim, **8 words or fewer**. The headline carries the slot's one idea; the body proves it. A reader
  understands the section's role from its headline.
- No second claim in parentheses.
- No patronising audience labels ("Real Women", "Real Moms") and no "Real X" trust lines ("Real Customers.
  Real Results."): selling with "real" implies the alternative was fake. A customer may say "real" inside
  their own quote.
- When you have a hard differentiator (a number, a named mechanism, a "world's first" the facts state), put
  it inside the headline.

## 3. CTAs

- Name the value of acting, not the mechanics. Weak: "Submit", "Learn More". Strong: "Get My Glow", "Shop
  the Tint".
- A generic CTA that already sells ("Shop Now", "Add to Cart") is fine.
- **3 words at most, every word short.** Never "Discover", "Experience", "Revolutionary".
- One action name for the whole page; any second action is a text link.

## 4. CRO principles

1. **Five-second value proposition.** A visitor knows what the product is and why to care within five
   seconds. Every section answers "so what?".
2. **Trust and zero risk.** Each section removes the barrier the visitor feels at that point, with a concrete
   signal: a quote that answers the fear, a certification, the guarantee, a clear "what happens next".
   Take them only from the facts. Surface the guarantee next to every CTA.
3. **The page moves forward.** Each section continues the story above it. Never repeat a claim, headline or
   proof point an earlier section already made, unless you add new proof, a new angle or a sharper
   objection.

## 5. Self-check (run on every section before rendering, and on the whole page before the critic)

1. **Clarity:** understood instantly. No jargon, no unclear pronoun, no buried point.
2. **Voice and tone:** consistent with the brand. Forbidden words and themes are absent.
3. **So what:** every claim answers "why should I care?". "Made with non-nano zinc oxide" fails; "Made with
   non-nano zinc oxide, so it protects without sinking in" passes.
4. **Prove it:** proof with teeth. A specific number, a named time, a quoted customer, a named guarantee.
   "Clinically tested", "proven results" or "patented formula" alone fail: upgrade to the fact or soften the
   claim.
5. **Specificity:** no "improve", "enhance" or "long-lasting" without a number or a concrete detail.
6. **Emotion:** the line makes the reader feel relief, desire, confidence or urgency.
7. **Zero risk:** a barrier remover sits near every CTA.
8. **Redundancy:** read all the section headlines as one list. Every section teaches something new.
9. **Length:** headlines 8 words or fewer, CTAs 3 words or fewer, and bodies short enough to fit the
   composition at 390 px without crowding.

## 6. AI writing tells and word-level cuts

- **No em dashes (—), en dashes (–) or "--" in the page copy (hard rule).** Use a period, a comma or a colon.
  Before you finish, search the HTML for both characters.
- No forced rule of three. Use the natural count.
- No "It's not just X, it's Y". Say what it is.
- No tricolon slogans ("Lift. Firm. Glow."), no questions nobody asked, no "Meet …" headlines.
- Cut: very, really, just, actually, basically, in order to.
- Replace: utilize → use, leverage → use, facilitate → help, innovative → new, seamless → smooth.
- **Beauty and wellness bingo, cut on sight:** elevated, redefined, revolutionary, premium, luxurious,
  transformative, next-generation, advanced, unparalleled, game-changer, unlock. Replace with the specific
  claim or delete the line.

## 7. Anti-pattern examples (from production)

1. **A slogan instead of a claim.** Intent: lead with the strongest proof (100% saw improvement).
   - Bad: "The proof is in the skin."
   - Good: "100% is a high bar. We cleared it."
   - Why: the bad line claims "we have proof" without showing it. Put the number inside the headline.
2. **Vague sensory adjectives instead of a concrete moment.** Intent: this oil is not greasy.
   - Bad: "Oil that doesn't feel like oil. Nothing sticky, nothing heavy."
   - Good: "Yes, it's an oil. No, it's not oily. It sinks right in. No waiting around before you get
     dressed."
   - Why: any oil can deny "sticky". The fix names the moment the customer worries about.
3. **A differentiator buried in a feature list.** Intent: the SPF repairs existing damage.
   - Bad: "The patented Argania Active Complex repairs UV-damaged skin, restores natural radiance, and locks
     in moisture all day."
   - Good: "Your SPF prevents tomorrow's damage. GLOW ME+ is also undoing yesterday's."
   - Why: position the differentiator against the category default; do not bury it among siblings.
4. **A light tagline with an unexplained acronym.** Intent: the first serum built on pure Cordyceps that
   extends Botox and filler results.
   - Bad: "A daily HA booster built on pure Cordyceps."
   - Good: "The first high-performance serum built on pure Cordyceps, formulated to support and extend your
     Botox and filler results."
   - Why: the bad line hides the strongest position behind an acronym.
5. **Category-generic instead of specific.** Intent: what the serum does for treatment patients.
   - Bad: "Meet the Glow Keeper."
   - Good: "Your peak treatment results, extended."
   - Why: "glow" belongs to every brand. Use the exact noun the customer uses.
6. **Ingredient-first jargon instead of benefit-first.** Intent: hydrates better than regular lotion.
   - Bad: "Hydrates where lotions can't. Ectoine + Squalane improve moisture at the cellular level."
   - Good: "Hydration that actually lasts. Most lotions sit on top and fade by midday. This sinks in and
     helps skin hold moisture far longer."
   - Why: outcome first, the alternative's failure second, the ingredient (if at all) as proof.
7. **A claim that lost its qualifier.** Intent: headline from an ingredient-level study figure.
   - Bad: "Lines look shallower in seven days" (footnote: "measured at the ingredient level").
   - Good: "Peptide-X: lines look shallower in seven days in a lab study" (the ingredient named in the line).
   - Why: the hedge is part of the fact. Trimming it turns an ingredient result into a product result. The
     same goes for "tends to", "may", "up to" and "results may vary" beside a story or quote.
