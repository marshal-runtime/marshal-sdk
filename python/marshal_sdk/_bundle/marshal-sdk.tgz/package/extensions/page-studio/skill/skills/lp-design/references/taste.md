# Taste: reach past the defaults

This file condenses the design skills from the ZyG kit's `design/` folder for a long DTC product page in plain
HTML and CSS:

- `design-taste-frontend`
- `frontend-design`
- `high-end-visual-design`
- `minimalist-ui`
- `impeccable`
- `ui-ux-pro-max`

Their React, Tailwind and image-generation instructions do not apply here. These rules are level 4 of the
source order in `references/style-fit.md`: brand tokens and the design plan win over them, and so does an
operator reference page wherever it does the thing.

## 1. Design read and dials (before planning)

Write one line in `notes.md`: "Reading this as: a premium-consumer product page for {audience}, in {the
brand's visual language}, leaning toward {direction}." Then set three dials:

- **Variance** (1 = symmetric, 10 = artsy): 6–7. Composition varies section by section; nothing is chaotic.
- **Motion** (1 = static, 10 = cinematic): 5–6. Lively: every section has a purposeful move (§7), plus
  muted video loops. An operator reference with more effects raises it.
- **Density** (1 = airy, 10 = packed): 3–4. Generous space and short copy blocks.

A clinical or trust-first brand moves variance and motion down by one. A playful brand moves variance up.

## 2. Spend boldness in one place

Let one element per page be the memorable thing: the hero proof, a stat band, a full-bleed photo. Keep
everything around it quiet, unless an operator reference spends boldness in more places. Before finishing, remove one accessory (the Chanel rule): one badge, one
divider, one label you do not need.

## 3. Layout discipline (hard rules)

- **The hero fits the first screen:** headline at most 3 lines at 390 px, subtext 20 words or fewer, the CTA
  visible, the product visible. At most 4 text elements in the hero (proof line or eyebrow, headline,
  subtext, CTAs), plus one reassurance row.
- **No layout family twice.** A composition (3 image cards, a full-width quote, a split image and text) is
  used once per page. Two sections in a row with an image-and-text split at most; a third in a row is a
  fail, unless an operator reference does it.
- **Eyebrow restraint:** small uppercase labels above headings at most once every three sections, and only
  when they carry information, unless an operator reference does more. Usually drop them.
- **No split-header default** (a big headline left, a small paragraph floating right) unless the content asks
  for it.
- **Grids hold exactly the cells you have content for.** Three items make three cells (1+2 or asymmetric),
  never a 2×2 with an empty cell. At least two cells in a multi-cell grid carry a real image or a distinct
  ground, not white-on-white text boxes.
- **Long lists change shape.** More than 5 items become a 2-column grid, an accordion, a swipe row or grouped
  chunks, not a long ruled list.
- **Mobile collapse is explicit** for every multi-column section.

## 4. Typography

- Use the brand's fonts. When a choice is open, use one family or two clearly distinct ones, a deliberate
  scale and intentional weights.
- No single accented word in a headline (one word in italic, bold or another colour, such as an italic serif
  accent word) unless the brand or an operator reference does it.
- No all-caps labels as decoration. Sentence case.
- Line length under 80 characters; serif body gets a little more line height.
- Italic display with descenders needs line height of at least 1.1. Big numerals need line height of at
  least 1, and their tops and descenders must be checked.

## 5. Colour and materials

- One accent, used consistently on the whole page; never a new colour in section 7.
- Cards only when elevation means hierarchy; otherwise group with space and tone steps. Shadows, when used,
  are tinted to the ground, never black.
- One radius scale.
- The generated-page palettes are defaults, not choices: cream with clay or brass and espresso text; near
  black with one neon accent; the SaaS card kit with the same grey shadow everywhere. Use them only when the
  brand's own plan says so, and then on purpose.

## 6. Content density

- Default section shape: a headline of 8 words or fewer, a sub-paragraph of 25 words or fewer, and one visual
  or one CTA. Anything more needs the section's job to justify it.
- Quotes: 3 lines of body at most; typographic quotes; the name with what makes it credible.
- No fake-precise numbers. Every figure comes from the facts or is a marked placeholder.
- Copy self-audit: re-read every visible string (headlines, buttons, captions, alt text, footer). Rewrite
  anything broken, unclear or cute.

## 7. Motion

Motion makes the page feel alive. Give each section a move with a job: a hero entrance, a rise-in as a
section scrolls into view, proof that moves (a claims or logo marquee, a count-up on a real number), a
carousel or before/after slider that answers touch, press and hover feedback on buttons. Vary the moves by
section: the same fade-up on every block, hover lift on every card and bounce easing are tells. A design-plan
rule against motion makes the moves subtle, not absent. Build every effect an operator reference has as well.
Easing `cubic-bezier(.16, 1, .3, 1)`, never linear. Honour `prefers-reduced-motion`. Nothing may leave a
blank band in a static screenshot, also with a reference.

## 8. The generated-page tells (remove on sight)

- an ALL-CAPS eyebrow above every heading;
- meta strings joined with middle dots used as decoration;
- labels like "WORD — fragment";
- 01 / 02 / 03 markers as decoration;
- three identical icon cards;
- gradient text;
- glass panels;
- a soft grey shadow under every card;
- hairline-ruled broadsheet grids;
- a centred hero over a gradient blob;
- div-built fake screenshots.

A device an operator reference uses (glass panels, eyebrows, a repeated composition) is not a tell on that
page. See also `tells.md`.

## 9. Accessibility gate (before the critic)

- Contrast ≥ 4.5:1 for body and 3:1 for large text, including on buttons and text over images.
- Tap targets ≥ 44 px, 8 px or more apart.
- Visible focus states. `alt` text on every content image.
- Reduced motion honoured.
- No content hidden behind hover.

## 10. Critique and polish passes

Look at the render at the size it ships (390 first). Batch the checks: one look, one fix pass, one confirm. Do
not screenshot after every tweak. Fix rhythm and alignment (one left spine, consistent gaps), the type
hierarchy, and then the details (orphans, widows, clipped glyphs).
