---
name: ab-test
description: Propose an A/B test of one element on a studio page - write variant B as a staged copy that carries the test proposal, and know when to say no. Use when the operator asks to A/B test, split-test, try a variant of, or compare two versions of something on the page.
---

# A/B testing one element

You write variant B into the section. When your turn lands, the editor reads your proposal, creates a DRAFT test
in the brand's A/B system with the operator's own session, and shows the test in the chat. The operator starts the
test in Store Hub.

You never start, stop or pause a test, never set traffic, and never say that a test is live, running, winning or
done. You have no results and you never invent one.

## When to propose a test

- **One variable.** One element changes: a headline, a button label, a picture, a badge, one short block. Two
  changes are two tests: propose the one the operator named first, and say that the next one can follow.
- **A clear hypothesis.** One sentence: what changes, what visitors then do, and why. "A shorter headline lifts
  add-to-cart, because visitors on a phone read it in one glance."
- **The element is on this page, in a section you may edit.** The copy goes into the same section.

## When to say no

Reply, write no markup, and say what to do instead:

- **The whole page, or a new layout of several sections.** That is a page split test. Tell the operator to use
  "Split-test this page" in the editor.
- **Several elements at once that are not one block.** Ask which one to test first.
- **A read-only or locked section.** Say why you cannot change it.
- **An element that keeps a theme block id** (`data-zyg-block-id="template--…"`). Say that Store Hub tests theme
  blocks.
- **Start, stop, traffic or results.** Store Hub does that; point the operator there.

A test runs only on a store whose live theme turns on the ZyG app embed. You cannot see that setting. Say once, in
the reply, that the test runs when the store has the ZyG app embed.

## How to write variant B

1. **Give the original an element id** when it has none: `data-zyg-block-id="zel-"` plus 10 random characters
   from `0-9` and `a-z`, for example `zel-k3x9q2m7ab`. Keep an id that is already there.
2. **Copy the element right after the original**, in the same parent. Change only the variable under test. Give
   the copy, and every element inside it that has an element id, a new id.
3. **Mark the copy as the proposal**, with all five attributes:
   - `data-zyg-ab-hidden="true"`: visitors see the copy only in variant B.
   - `data-zyg-ab-variant-of="<the original's id>"`
   - `data-zyg-ab-name="<page> · <element>: <the change>"`: at most 200 characters.
   - `data-zyg-ab-hypothesis="<one sentence>"`: at most 300 characters.
4. **Leave the original as it is.** Never stage the original as hidden.
5. **One proposal per turn.** `check` refuses a second new one, a missing flag, a duplicate id, an original that
   is not in the same section, and an empty or long name or hypothesis.

```html
<h1 data-zyg-block-id="zel-k3x9q2m7ab" class="hero__title">
  Glow in five days, without the sting
</h1>
<h1
  data-zyg-block-id="zel-p0q1r2s3t4"
  data-zyg-ab-hidden="true"
  data-zyg-ab-variant-of="zel-k3x9q2m7ab"
  data-zyg-ab-name="Eye cream LP · hero headline: shorter"
  data-zyg-ab-hypothesis="A shorter headline lifts add-to-cart, because visitors on a phone read it in one glance."
  class="hero__title"
>
  Glow in five days
</h1>
```

Both elements keep the same classes and styles, so variant B differs only in the variable under test. The editor
shows the original and the copy one under the other; its Original / A / B switch shows each variant alone.

## The reply

- Say what variant B changes and the hypothesis, in one or two sentences.
- Say that the editor creates a DRAFT test and that the operator starts it in Store Hub.
- Never write "the test is live", "running", "B wins" or a traffic share.
