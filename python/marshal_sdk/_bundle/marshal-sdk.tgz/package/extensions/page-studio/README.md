# Page Studio (`@zyg/page-studio`)

ZyG landing pages, edited by people and Marshal agents together, on a desktop frame and a 390 px phone frame.

- **Page model and edits:** Bar Topper's ZyG Page Editor. The six section operations, the Liquid canvas engine and the shoppable rules are vendored from `zyg-edge/zyg` at `ac1bdfba9db` (`src/shared/vendor`, `src/shared/liquid`).
- **Agent rules:** Ido Miller's page-editor prompt and the seven page skills are pinned in `skill/`; see `skill/skills.json` for sources and licences.
- **Brand settings:** Achva's CRO-1261 list, mapped onto the page's `--ds-*` design tokens (`src/shared/tokens.ts`).

## Instant mode

| Speed | What handles it |
|---|---|
| Direct | Typing on the page, sliders and the section list apply locally in under 16 ms, then save. |
| Quick | A plain request. OpenAI Decisions (`gpt-6-luna`) picks the path, the section and, for a look change, one concrete change from options Page Studio generated. Without a confident pick, a fast model writes small targeted edits. |
| Big | New sections, redesigns, copy across sections and "Fix my notes" go to the page-editor model with Ido's rules. |

Every request's timings are appended to `~/.marshal/page-studio/timings.jsonl`.

## Capabilities for agents

| Capability | What it does |
|---|---|
| `pagestudio.snapshot {keys?}` | Reads the page: outline, design variables, open notes and the person's selection. |
| `pagestudio.applyOps {ops}` | Edits the page. Prefer `replace_text` and `set_var` for small edits. |
| `pagestudio.notes` | Lists, adds, updates and deletes review notes. |
| `pagestudio.notes.fix` | Fixes every open note. |
| `pagestudio.ask {text}` | Takes a plain request through instant mode. |
| `pagestudio.render` | Writes the page to an HTML file you can look at. |
| `pagestudio.open` | Opens the tab. |

## Build

```bash
npm install
node build.mjs     # dist/runtime.cjs + out/package
npm test
```

Install `out/package` with `runtimeInstallLocalExtension`.

Data lives in `~/.marshal/page-studio`, or in `PAGE_STUDIO_DIR` if it is set. Publish only writes an export after a confirm; it never writes to a live store.
