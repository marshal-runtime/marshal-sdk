import { SESSION_ROLES, type SessionRole } from './model.js';
import { readUserPrincipal, type UserPrincipal } from './principals.js';
import { fail, readArray, readObject, readOptionalString, readString, type Reader } from './validate.js';

const RESPONSE: Reader = { code: 'invalid-response' };
const REQUEST: Reader = { code: 'invalid-request' };

/** Most bytes of text one message carries; a longer text answers 413 `too-large`. */
export const MAX_MESSAGE_TEXT_BYTES = 64 * 1024;
/** Most messages of one session that wait to run or are being run (the server counts `queued` and `claimed` together); the next post answers 429 `queue-full`. */
export const MAX_QUEUED_MESSAGES = 10;
/** Most `held` messages one author keeps in one session; the next post of that author answers 429 `queue-full`. */
export const MAX_HELD_PER_AUTHOR = 10;
/** Largest `position` a post can answer: the server counts queued and claimed messages ahead of it, so the value stays below `MAX_QUEUED_MESSAGES`; the parser allows twice that so a stricter or looser server does not break a client. */
export const MAX_MESSAGE_POSITION = 2 * MAX_QUEUED_MESSAGES;
/** Most messages one list returns. */
export const MAX_MESSAGE_LIST = 100;
/** Default size of a list of messages. */
export const DEFAULT_MESSAGE_LIST = 50;

/**
 * Error codes the message routes add to the shared set: `queue-full` (429), `not-in-cloud` (409, a post to a session whose home is not the
 * cloud) and `turn-budget-spent` (429, a participant of a live session started their daily budget of turns).
 */
export const MESSAGE_ERROR_CODES = ['queue-full', 'not-in-cloud', 'turn-budget-spent'] as const;

export const MESSAGE_SOURCES = ['desktop', 'slack', 'web', 'api'] as const;
/** Where a message was written. The server sets it from the verified caller; a client may only claim `desktop` or `web`, anything else is recorded as `api`. */
export type OrgMessageSource = (typeof MESSAGE_SOURCES)[number];
/** The sources a client may claim with the `x-marshal-source` header. */
export const CLIENT_MESSAGE_SOURCES = ['desktop', 'web'] as const;
export const MESSAGE_SOURCE_HEADER = 'x-marshal-source';

/** What a message is: an instruction can start a turn, a comment never does. */
export const MESSAGE_KINDS = ['instruction', 'comment'] as const;
export type OrgMessageKind = (typeof MESSAGE_KINDS)[number];
/** Most `comment` messages one author keeps in one session; the next answers 429 `queue-full`. */
export const MAX_COMMENTS_PER_AUTHOR = 50;

export const MESSAGE_STATUSES = ['queued', 'claimed', 'done', 'cancelled', 'held', 'rejected'] as const;
export type OrgMessageStatus = (typeof MESSAGE_STATUSES)[number];

export const EXECUTOR_STATES = ['none', 'queued', 'starting', 'running', 'hot', 'stalled'] as const;
export type OrgExecutorState = (typeof EXECUTOR_STATES)[number];

/** One message of a session's inbox, for a cloud executor to run in order. */
export type OrgSessionMessage = {
  id: string;
  /** Position in the session's inbox, from 1; list with `after` to page. */
  seq: number;
  /** The id the writer picked; posting the same one again returns the stored message. */
  clientMsgId: string;
  author: UserPrincipal;
  source: OrgMessageSource;
  /** The author's role when the message was written. A `collaborator`'s message is `held` until the owner runs it. */
  roleAtSend: SessionRole;
  text: string;
  status: OrgMessageStatus;
  /** Present only on a comment (a note for the owner; stored `held`, never run). Absent means an instruction. Needs the `multiUser` feature. */
  kind?: 'comment';
  at: string;
  /** The turn that ran it, once it is `done`. */
  turnId?: string;
  /** For a message the owner made by running a held one: the id of the held message. */
  quotes?: string;
  slack?: { channel: string; ts: string };
};

export const EXECUTOR_HOST_KINDS = ['cloud', 'desktop'] as const;
/** Where the executor runs: a cloud worker, or the owner's desktop for a live session. Absent means `cloud`. */
export type OrgExecutorHostKind = (typeof EXECUTOR_HOST_KINDS)[number];

/** What runs the session now. */
export type OrgExecutorInfo = {
  state: OrgExecutorState;
  hostLabel?: string;
  estimatedStartSeconds?: number;
  /** Needs the `liveSessions` feature; absent from older servers, which means `cloud`. */
  hostKind?: OrgExecutorHostKind;
};

/** The answer of a post, and of running a held message. */
export type OrgPostedMessage = {
  id: string;
  seq: number;
  status: OrgMessageStatus;
  /** How many queued or claimed messages run before this one; 0 when it is next or is not queued. */
  position: number;
  executor: OrgExecutorInfo;
};

/** `GET /v1/sessions/:id/messages`. The owner sees every message, anyone else their own. */
export type OrgSessionMessagePage = {
  messages: OrgSessionMessage[];
  executor: OrgExecutorInfo;
};

/** Body of `POST /v1/sessions/:id/messages`. */
/** `kind: 'comment'` needs the `multiUser` feature and may be sent by any role, a viewer included; absent means an instruction. */
export type OrgPostMessageRequest = { clientMsgId: string; text: string; kind?: OrgMessageKind };

/** Body of `POST /v1/sessions/:id/messages/:messageId/run`. */
export type OrgRunHeldMessageRequest = { clientMsgId: string };

const CLIENT_MSG_ID_PATTERN = /^[A-Za-z0-9][A-Za-z0-9._:-]{0,127}$/;
const MESSAGE_ID_PATTERN = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/;
const ISO_PATTERN = /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(\.\d{1,9})?(Z|[+-]\d{2}:\d{2})$/;
const MAX_TURN_ID = 128;
const MAX_ESTIMATE_SECONDS = 24 * 3600;

export function isMessageId(value: unknown): value is string {
  return typeof value === 'string' && MESSAGE_ID_PATTERN.test(value);
}

export function isClientMessageId(value: unknown): value is string {
  return typeof value === 'string' && CLIENT_MSG_ID_PATTERN.test(value);
}

function utf8Bytes(text: string): number {
  return new TextEncoder().encode(text).length;
}

function readEnum<T extends string>(reader: Reader, value: unknown, path: string, allowed: readonly T[]): T {
  if (typeof value !== 'string' || !(allowed as readonly string[]).includes(value)) fail(reader, path, `must be one of ${allowed.join(', ')}`);
  return value as T;
}

function readIso(reader: Reader, value: unknown, path: string): string {
  const text = readString(reader, value, path, { max: 40 });
  if (!ISO_PATTERN.test(text) || Number.isNaN(Date.parse(text))) fail(reader, path, 'must be an ISO 8601 timestamp');
  return text;
}

function readCount(reader: Reader, value: unknown, path: string, min: number, max: number): number {
  if (typeof value !== 'number' || !Number.isInteger(value) || value < min || value > max) fail(reader, path, `must be an integer from ${min} to ${max}`);
  return value;
}

export function parseOrgExecutorInfo(value: unknown, path = 'executor'): OrgExecutorInfo {
  const root = readObject(RESPONSE, value, path);
  const info: OrgExecutorInfo = { state: readEnum(RESPONSE, root.state, `${path}.state`, EXECUTOR_STATES) };
  const hostLabel = readOptionalString(RESPONSE, root.hostLabel, `${path}.hostLabel`, { max: 128 });
  if (hostLabel !== undefined) info.hostLabel = hostLabel;
  // A host kind this client does not know (a newer server) is dropped, not an error: it is display only.
  if (typeof root.hostKind === 'string' && (EXECUTOR_HOST_KINDS as readonly string[]).includes(root.hostKind)) info.hostKind = root.hostKind as OrgExecutorHostKind;
  if (root.estimatedStartSeconds !== undefined && root.estimatedStartSeconds !== null) {
    info.estimatedStartSeconds = readCount(RESPONSE, root.estimatedStartSeconds, `${path}.estimatedStartSeconds`, 0, MAX_ESTIMATE_SECONDS);
  }
  return info;
}

export function parseOrgSessionMessage(value: unknown, path = 'message'): OrgSessionMessage {
  const root = readObject(RESPONSE, value, path);
  const message: OrgSessionMessage = {
    id: readString(RESPONSE, root.id, `${path}.id`, { max: 36, pattern: MESSAGE_ID_PATTERN }),
    seq: readCount(RESPONSE, root.seq, `${path}.seq`, 1, Number.MAX_SAFE_INTEGER),
    clientMsgId: readString(RESPONSE, root.clientMsgId, `${path}.clientMsgId`, { max: 128, pattern: CLIENT_MSG_ID_PATTERN }),
    author: readUserPrincipal(RESPONSE, root.author, `${path}.author`),
    source: readEnum(RESPONSE, root.source, `${path}.source`, MESSAGE_SOURCES),
    roleAtSend: readEnum(RESPONSE, root.roleAtSend, `${path}.roleAtSend`, SESSION_ROLES),
    text: readString(RESPONSE, root.text, `${path}.text`, { max: MAX_MESSAGE_TEXT_BYTES, min: 0 }),
    status: readEnum(RESPONSE, root.status, `${path}.status`, MESSAGE_STATUSES),
    at: readIso(RESPONSE, root.at, `${path}.at`),
  };
  if (root.kind !== undefined && root.kind !== null && root.kind !== 'instruction') message.kind = 'comment';
  const turnId = readOptionalString(RESPONSE, root.turnId, `${path}.turnId`, { max: MAX_TURN_ID });
  if (turnId !== undefined) message.turnId = turnId;
  const quotes = readOptionalString(RESPONSE, root.quotes, `${path}.quotes`, { max: 36, pattern: MESSAGE_ID_PATTERN });
  if (quotes !== undefined) message.quotes = quotes;
  if (root.slack !== undefined && root.slack !== null) {
    const slack = readObject(RESPONSE, root.slack, `${path}.slack`);
    message.slack = {
      channel: readString(RESPONSE, slack.channel, `${path}.slack.channel`, { max: 64 }),
      ts: readString(RESPONSE, slack.ts, `${path}.slack.ts`, { max: 64 }),
    };
  }
  return message;
}

export function parseOrgSessionMessages(value: unknown, path = 'messages'): OrgSessionMessage[] {
  return readArray(RESPONSE, value, path, MAX_MESSAGE_LIST, (entry, entryPath) => parseOrgSessionMessage(entry, entryPath));
}

export function parseOrgSessionMessagePage(value: unknown): OrgSessionMessagePage {
  const root = readObject(RESPONSE, value, 'messagePage');
  return { messages: parseOrgSessionMessages(root.messages, 'messagePage.messages'), executor: parseOrgExecutorInfo(root.executor, 'messagePage.executor') };
}

export function parseOrgPostedMessage(value: unknown): OrgPostedMessage {
  const root = readObject(RESPONSE, value, 'postedMessage');
  return {
    id: readString(RESPONSE, root.id, 'postedMessage.id', { max: 36, pattern: MESSAGE_ID_PATTERN }),
    seq: readCount(RESPONSE, root.seq, 'postedMessage.seq', 1, Number.MAX_SAFE_INTEGER),
    status: readEnum(RESPONSE, root.status, 'postedMessage.status', MESSAGE_STATUSES),
    position: readCount(RESPONSE, root.position, 'postedMessage.position', 0, MAX_MESSAGE_POSITION),
    executor: parseOrgExecutorInfo(root.executor, 'postedMessage.executor'),
  };
}

export function parseOrgPostMessageRequest(value: unknown): OrgPostMessageRequest {
  const root = readObject(REQUEST, value, 'message');
  const clientMsgId = readString(REQUEST, root.clientMsgId, 'message.clientMsgId', { max: 128, pattern: CLIENT_MSG_ID_PATTERN });
  const text = readString(REQUEST, root.text, 'message.text', { max: MAX_MESSAGE_TEXT_BYTES });
  if (text.trim() === '') fail(REQUEST, 'message.text', 'must not be empty');
  if (utf8Bytes(text) > MAX_MESSAGE_TEXT_BYTES) fail(REQUEST, 'message.text', `must be at most ${MAX_MESSAGE_TEXT_BYTES} bytes`);
  if (root.kind === undefined) return { clientMsgId, text };
  const kind = readEnum(REQUEST, root.kind, 'message.kind', MESSAGE_KINDS);
  return kind === 'instruction' ? { clientMsgId, text } : { clientMsgId, text, kind };
}

export function parseOrgRunHeldMessageRequest(value: unknown): OrgRunHeldMessageRequest {
  const root = readObject(REQUEST, value, 'run');
  return { clientMsgId: readString(REQUEST, root.clientMsgId, 'run.clientMsgId', { max: 128, pattern: CLIENT_MSG_ID_PATTERN }) };
}

/** Reads the optional `returnedMessages` of a lease acquire answer: the messages a desktop had written that the cloud executor had not run and gave back. */
export function parseOrgReturnedMessages(value: unknown, path: string): OrgSessionMessage[] | undefined {
  if (value === undefined || value === null) return undefined;
  return parseOrgSessionMessages(value, path);
}
