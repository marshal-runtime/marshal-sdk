import { isOrgWorkspaceId, type OrgWorkspaceId } from './model.js';
import {
  MAX_LONG_TEXT,
  MAX_SHORT_TEXT,
  fail,
  readArray,
  readObject,
  readOptionalString,
  readString,
  readUrl,
  type Reader,
} from './validate.js';

const RESPONSE: Reader = { code: 'invalid-response' };

export const MAX_ROUTINES = 64;
const MAX_TRIGGERS = 64;
const MAX_CHANNELS = 256;
const ROUTINE_ID_PATTERN = /^[a-z0-9][a-z0-9._-]{0,94}$/;
const WORKFLOW_PATTERN = /^[a-z0-9][a-z0-9._-]{0,63}$/;
const CHANNEL_PATTERN = /^[CGD][A-Z0-9]{8,14}$/;

/** What mainly starts a routine. */
export type OrgRoutineKind = 'event' | 'schedule' | 'manual';
const ROUTINE_KINDS: readonly OrgRoutineKind[] = ['event', 'schedule', 'manual'];

/** What starts a routine: what mainly starts it (`kind`; a server that predates it is read as event/schedule/manual from the triggers), cron schedules (UTC), whether a person starting it is meaningful, and the other events by name. */
export type OrgRoutineTriggers = {
  kind: OrgRoutineKind;
  schedules: string[];
  manual: boolean;
  events: string[];
};

/** A file of the organization's repositories, with a link to read it. */
export type OrgRoutineFile = {
  repository?: string;
  path: string;
  url: string;
};

/** An agent workflow that runs for a workspace on a schedule or an event. Its runs are the run index's with `workflow` (`listRuns({workspace, workflow})`). */
export type OrgRoutine = {
  id: string;
  workspaceId: OrgWorkspaceId;
  title: string;
  description?: string;
  workflow: string;
  triggers: OrgRoutineTriggers;
  /** Whether its workflow is on; absent when the server does not say. */
  enabled?: boolean;
  definition: OrgRoutineFile;
  doc?: OrgRoutineFile;
  /** The Slack channel ids the routine posts in or answers from. */
  channels: string[];
};

function parseFile(value: unknown, path: string): OrgRoutineFile {
  const root = readObject(RESPONSE, value, path);
  const file: OrgRoutineFile = {
    path: readString(RESPONSE, root.path, `${path}.path`, { max: 512 }),
    url: readUrl(RESPONSE, root.url, `${path}.url`),
  };
  const repository = readOptionalString(RESPONSE, root.repository, `${path}.repository`, { max: 512 });
  if (repository !== undefined) file.repository = repository;
  return file;
}

export function parseOrgRoutine(value: unknown, path = 'routine'): OrgRoutine {
  const root = readObject(RESPONSE, value, path);
  const workspaceId = readString(RESPONSE, root.workspaceId, `${path}.workspaceId`, { max: 66 });
  if (!isOrgWorkspaceId(workspaceId)) fail(RESPONSE, `${path}.workspaceId`, 'must look like ws:<lowercase-name>');
  const triggers = readObject(RESPONSE, root.triggers, `${path}.triggers`);
  if (typeof triggers.manual !== 'boolean') fail(RESPONSE, `${path}.triggers.manual`, 'must be a boolean');
  const schedules = readArray(RESPONSE, triggers.schedules ?? [], `${path}.triggers.schedules`, MAX_TRIGGERS, (entry, entryPath) =>
    readString(RESPONSE, entry, entryPath, { max: 128 }),
  );
  const events = readArray(RESPONSE, triggers.events ?? [], `${path}.triggers.events`, MAX_TRIGGERS, (entry, entryPath) =>
    readString(RESPONSE, entry, entryPath, { max: 128 }),
  );
  if (triggers.kind !== undefined && !(ROUTINE_KINDS as readonly unknown[]).includes(triggers.kind)) {
    fail(RESPONSE, `${path}.triggers.kind`, 'must be event, schedule or manual');
  }
  const kind: OrgRoutineKind =
    (triggers.kind as OrgRoutineKind | undefined) ?? (events.length > 0 ? 'event' : schedules.length > 0 ? 'schedule' : 'manual');
  if (root.enabled !== undefined && typeof root.enabled !== 'boolean') fail(RESPONSE, `${path}.enabled`, 'must be a boolean');
  const routine: OrgRoutine = {
    id: readString(RESPONSE, root.id, `${path}.id`, { pattern: ROUTINE_ID_PATTERN }),
    workspaceId,
    title: readString(RESPONSE, root.title, `${path}.title`, { max: MAX_SHORT_TEXT }),
    workflow: readString(RESPONSE, root.workflow, `${path}.workflow`, { pattern: WORKFLOW_PATTERN }),
    triggers: { kind, schedules, manual: triggers.manual && kind !== 'event', events },
    definition: parseFile(root.definition, `${path}.definition`),
    channels: readArray(RESPONSE, root.channels ?? [], `${path}.channels`, MAX_CHANNELS, (entry, entryPath) =>
      readString(RESPONSE, entry, entryPath, { pattern: CHANNEL_PATTERN }),
    ),
  };
  const description = readOptionalString(RESPONSE, root.description, `${path}.description`, { max: MAX_LONG_TEXT });
  if (description !== undefined) routine.description = description;
  if (typeof root.enabled === 'boolean') routine.enabled = root.enabled;
  if (root.doc !== undefined && root.doc !== null) routine.doc = parseFile(root.doc, `${path}.doc`);
  return routine;
}

/** Whether a routine dealt with an event: `unhandled` is a run that failed, was refused or only drafted. */
export type OrgRoutineEventStatus = 'handled' | 'unhandled';
/** How bad an event's outcome was. */
export type OrgRoutineEventSeverity = 'error' | 'warning' | 'info';
const EVENT_STATUSES: readonly OrgRoutineEventStatus[] = ['handled', 'unhandled'];
const EVENT_SEVERITIES: readonly OrgRoutineEventSeverity[] = ['error', 'warning', 'info'];
const RUN_STATUSES = ['running', 'succeeded', 'failed'] as const;
const RUN_ID_PATTERN = /^[A-Za-z0-9][A-Za-z0-9._-]{0,119}$/;
const ISO_PATTERN = /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(\.\d{1,9})?(Z|[+-]\d{2}:\d{2})$/;
export const MAX_ROUTINE_EVENTS_PAGE = 100;

/** One event that woke a routine: the run it started is its id. */
export type OrgRoutineEvent = {
  id: string;
  at: string;
  title: string;
  source: { kind: string; key: string };
  channel?: string;
  severity: OrgRoutineEventSeverity;
  role?: string;
  status: OrgRoutineEventStatus;
  runStatus: (typeof RUN_STATUSES)[number];
  dryRun: boolean;
  githubUrl?: string;
};

/** The filters of `listRoutineEvents`; every one is optional. */
export type OrgRoutineEventFilters = {
  since?: string;
  until?: string;
  channel?: string;
  role?: string;
  q?: string;
  severity?: OrgRoutineEventSeverity;
  status?: OrgRoutineEventStatus;
  limit?: number;
  cursor?: string;
};

export type OrgRoutineEventPage = { events: OrgRoutineEvent[]; nextCursor?: string };

function readChoice<T extends string>(value: unknown, path: string, allowed: readonly T[]): T {
  if (typeof value !== 'string' || !(allowed as readonly string[]).includes(value)) fail(RESPONSE, path, `must be one of ${allowed.join(', ')}`);
  return value as T;
}

export function parseOrgRoutineEvent(value: unknown, path = 'event'): OrgRoutineEvent {
  const root = readObject(RESPONSE, value, path);
  const source = readObject(RESPONSE, root.source, `${path}.source`);
  const at = readString(RESPONSE, root.at, `${path}.at`, { max: 40 });
  if (!ISO_PATTERN.test(at)) fail(RESPONSE, `${path}.at`, 'must be an ISO 8601 time');
  if (typeof root.dryRun !== 'boolean') fail(RESPONSE, `${path}.dryRun`, 'must be a boolean');
  const event: OrgRoutineEvent = {
    id: readString(RESPONSE, root.id, `${path}.id`, { pattern: RUN_ID_PATTERN }),
    at,
    title: readString(RESPONSE, root.title, `${path}.title`, { max: MAX_SHORT_TEXT, min: 0 }),
    source: {
      kind: readString(RESPONSE, source.kind, `${path}.source.kind`, { max: 64 }),
      key: readString(RESPONSE, source.key, `${path}.source.key`, { max: 256 }),
    },
    severity: readChoice(root.severity, `${path}.severity`, EVENT_SEVERITIES),
    status: readChoice(root.status, `${path}.status`, EVENT_STATUSES),
    runStatus: readChoice(root.runStatus, `${path}.runStatus`, RUN_STATUSES),
    dryRun: root.dryRun,
  };
  const channel = readOptionalString(RESPONSE, root.channel, `${path}.channel`, { max: 32 });
  if (channel !== undefined) event.channel = channel;
  const role = readOptionalString(RESPONSE, root.role, `${path}.role`, { max: 64 });
  if (role !== undefined) event.role = role;
  if (root.githubUrl !== undefined && root.githubUrl !== null) event.githubUrl = readUrl(RESPONSE, root.githubUrl, `${path}.githubUrl`);
  return event;
}

/** Parses `GET /v1/workspaces/:id/routines/:routine/events`. */
export function parseOrgRoutineEventPage(value: unknown): OrgRoutineEventPage {
  const root = readObject(RESPONSE, value, 'events');
  const page: OrgRoutineEventPage = {
    events: readArray(RESPONSE, root.events, 'events.events', MAX_ROUTINE_EVENTS_PAGE, (entry, path) => parseOrgRoutineEvent(entry, path)),
  };
  const nextCursor = readOptionalString(RESPONSE, root.nextCursor, 'events.nextCursor', { max: 64 });
  if (nextCursor !== undefined) page.nextCursor = nextCursor;
  return page;
}

/** What `dispatchRoutine` answers: the run was asked for; `replayOf` names the event it replays. */
export type OrgRoutineDispatch = { started: true; replayOf?: string };

export function parseOrgRoutineDispatch(value: unknown): OrgRoutineDispatch {
  const root = readObject(RESPONSE, value, 'dispatch');
  if (root.started !== true) fail(RESPONSE, 'dispatch.started', 'must be true');
  const replayOf = readOptionalString(RESPONSE, root.replayOf, 'dispatch.replayOf', { pattern: RUN_ID_PATTERN });
  return replayOf === undefined ? { started: true } : { started: true, replayOf };
}

const TEST_ID_PATTERN = /^rt[a-z0-9]{10}$/;
/** The id of a routine that Marshal defines (its file name without the extension). */
export const ORG_DEFINED_ROUTINE_ID_PATTERN = /^[a-z0-9][a-z0-9._-]{0,63}$/;
const BRANCH_PATTERN = /^routine\/[a-z0-9][a-z0-9._-]{0,63}$/;

/** What `testRoutine` answers: the test started; its run is listed by `GET /v1/runs` with `runs` as the filters once indexed. */
export type OrgRoutineTest = {
  testId: string;
  title: string;
  runs: { workspace: OrgWorkspaceId; workflow: string; q: string };
};

export function parseOrgRoutineTest(value: unknown): OrgRoutineTest {
  const root = readObject(RESPONSE, value, 'test');
  const testId = readString(RESPONSE, root.testId, 'test.testId', { pattern: TEST_ID_PATTERN });
  const runs = readObject(RESPONSE, root.runs, 'test.runs');
  const workspace = readString(RESPONSE, runs.workspace, 'test.runs.workspace', { max: MAX_SHORT_TEXT });
  if (!isOrgWorkspaceId(workspace)) fail(RESPONSE, 'test.runs.workspace', 'must be a workspace id');
  if (runs.q !== testId) fail(RESPONSE, 'test.runs.q', 'must be the test id');
  return {
    testId,
    title: readString(RESPONSE, root.title, 'test.title', { max: MAX_LONG_TEXT }),
    runs: { workspace, workflow: readString(RESPONSE, runs.workflow, 'test.runs.workflow', { pattern: WORKFLOW_PATTERN }), q: testId },
  };
}

/** A pull request that promotes a routine to the cloud. */
export type OrgRoutinePullRequest = { number: number; url: string; branch: string };

export function parseOrgRoutinePullRequest(value: unknown, path: string): OrgRoutinePullRequest {
  const root = readObject(RESPONSE, value, path);
  if (typeof root.number !== 'number' || !Number.isInteger(root.number) || root.number < 1) fail(RESPONSE, `${path}.number`, 'must be a positive integer');
  return {
    number: root.number,
    url: readUrl(RESPONSE, root.url, `${path}.url`),
    branch: readString(RESPONSE, root.branch, `${path}.branch`, { pattern: BRANCH_PATTERN }),
  };
}

/** What `promoteRoutine` answers: the pull request a person reviews and merges. */
export function parseOrgRoutinePromotion(value: unknown): { pullRequest: OrgRoutinePullRequest } {
  const root = readObject(RESPONSE, value, 'promotion');
  return { pullRequest: parseOrgRoutinePullRequest(root.pullRequest, 'promotion.pullRequest') };
}

export function parseOrgRoutineEnabled(value: unknown): { enabled: boolean } {
  const root = readObject(RESPONSE, value, 'enabled');
  if (typeof root.enabled !== 'boolean') fail(RESPONSE, 'enabled.enabled', 'must be a boolean');
  return { enabled: root.enabled };
}

/** Parses `GET /v1/workspaces/:id/routines`; every routine must belong to the workspace asked for. */
export function parseOrgRoutineList(value: unknown, workspaceId: OrgWorkspaceId): OrgRoutine[] {
  const root = readObject(RESPONSE, value, 'routines');
  if (root.workspaceId !== workspaceId) fail(RESPONSE, 'routines.workspaceId', 'does not match the requested workspace');
  const routines = readArray(RESPONSE, root.routines, 'routines.routines', MAX_ROUTINES, (entry, path) => parseOrgRoutine(entry, path));
  routines.forEach((routine, index) => {
    if (routine.workspaceId !== workspaceId) fail(RESPONSE, `routines.routines[${index}].workspaceId`, 'does not match the requested workspace');
  });
  return routines;
}
