export class OrgContractError extends Error {
  readonly code: 'invalid-document' | 'invalid-response' | 'invalid-request';
  readonly path: string;

  constructor(code: OrgContractError['code'], path: string, message: string) {
    super(`${path}: ${message}`);
    this.name = 'OrgContractError';
    this.code = code;
    this.path = path;
  }
}

export type Reader = {
  readonly code: OrgContractError['code'];
};

export const MAX_SHORT_TEXT = 256;
export const MAX_LONG_TEXT = 4096;
export const MAX_URL = 2048;

export function fail(reader: Reader, path: string, message: string): never {
  throw new OrgContractError(reader.code, path, message);
}

export function readObject(reader: Reader, value: unknown, path: string): Record<string, unknown> {
  if (typeof value !== 'object' || value === null || Array.isArray(value)) fail(reader, path, 'must be an object');
  return value as Record<string, unknown>;
}

export function readString(
  reader: Reader,
  value: unknown,
  path: string,
  options: { max?: number; min?: number; pattern?: RegExp } = {},
): string {
  if (typeof value !== 'string') fail(reader, path, 'must be a string');
  const max = options.max ?? MAX_SHORT_TEXT;
  const min = options.min ?? 1;
  if (value.length < min) fail(reader, path, `must be at least ${min} characters`);
  if (value.length > max) fail(reader, path, `must be at most ${max} characters`);
  if (options.pattern && !options.pattern.test(value)) fail(reader, path, `must match ${options.pattern}`);
  return value;
}

export function readOptionalString(
  reader: Reader,
  value: unknown,
  path: string,
  options: { max?: number; pattern?: RegExp } = {},
): string | undefined {
  if (value === undefined || value === null) return undefined;
  return readString(reader, value, path, options);
}

export function readArray<T>(
  reader: Reader,
  value: unknown,
  path: string,
  max: number,
  item: (entry: unknown, path: string) => T,
): T[] {
  if (!Array.isArray(value)) fail(reader, path, 'must be an array');
  if (value.length > max) fail(reader, path, `must have at most ${max} entries`);
  return value.map((entry, index) => item(entry, `${path}[${index}]`));
}

export function readUrl(reader: Reader, value: unknown, path: string, options: { allowLoopbackHttp?: boolean } = {}): string {
  const text = readString(reader, value, path, { max: MAX_URL });
  let parsed: URL;
  try {
    parsed = new URL(text);
  } catch {
    fail(reader, path, 'must be an absolute URL');
  }
  if (parsed.protocol === 'https:') return text;
  if (parsed.protocol === 'http:' && options.allowLoopbackHttp && isLoopbackHost(parsed.hostname)) return text;
  fail(reader, path, options.allowLoopbackHttp ? 'must be https, or http on a loopback host' : 'must be https');
}

export function isLoopbackHost(hostname: string): boolean {
  return hostname === '127.0.0.1' || hostname === 'localhost' || hostname === '[::1]' || hostname === '::1';
}
