import { MAX_LONG_TEXT, fail, readObject, readOptionalString, readString, readUrl, type Reader } from './validate.js';

const RESPONSE: Reader = { code: 'invalid-response' };

export type OidcProviderMetadata = {
  issuer: string;
  authorizationEndpoint: string;
  tokenEndpoint: string;
  jwksUri?: string;
  revocationEndpoint?: string;
};

export type PkcePair = {
  verifier: string;
  challenge: string;
  method: 'S256';
};

export type TokenSet = {
  accessToken: string;
  tokenType: string;
  /** Absolute expiry in epoch milliseconds, when the provider stated a lifetime. */
  expiresAt?: number;
  refreshToken?: string;
  idToken?: string;
  scope?: string;
};

export type FetchLike = (input: string, init?: RequestInit) => Promise<Response>;

export function oidcConfigurationUrl(issuer: string): string {
  return `${issuer.replace(/\/+$/, '')}/.well-known/openid-configuration`;
}

export function parseOidcProviderMetadata(value: unknown, expectedIssuer?: string): OidcProviderMetadata {
  const root = readObject(RESPONSE, value, 'oidc');
  const issuer = readUrl(RESPONSE, root.issuer, 'oidc.issuer');
  if (expectedIssuer !== undefined && trimSlash(issuer) !== trimSlash(expectedIssuer)) {
    fail(RESPONSE, 'oidc.issuer', 'does not match the issuer the organization declared');
  }
  const metadata: OidcProviderMetadata = {
    issuer,
    authorizationEndpoint: readUrl(RESPONSE, root.authorization_endpoint, 'oidc.authorization_endpoint'),
    tokenEndpoint: readUrl(RESPONSE, root.token_endpoint, 'oidc.token_endpoint'),
  };
  if (root.jwks_uri !== undefined) metadata.jwksUri = readUrl(RESPONSE, root.jwks_uri, 'oidc.jwks_uri');
  if (root.revocation_endpoint !== undefined) {
    metadata.revocationEndpoint = readUrl(RESPONSE, root.revocation_endpoint, 'oidc.revocation_endpoint');
  }
  return metadata;
}

export function base64UrlEncode(bytes: Uint8Array): string {
  let binary = '';
  for (const byte of bytes) binary += String.fromCharCode(byte);
  return btoa(binary).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}

export function randomUrlSafe(byteLength = 32): string {
  const bytes = new Uint8Array(byteLength);
  globalThis.crypto.getRandomValues(bytes);
  return base64UrlEncode(bytes);
}

export async function pkceChallenge(verifier: string): Promise<string> {
  const digest = await globalThis.crypto.subtle.digest('SHA-256', new TextEncoder().encode(verifier));
  return base64UrlEncode(new Uint8Array(digest));
}

export async function createPkcePair(): Promise<PkcePair> {
  const verifier = randomUrlSafe(32);
  return { verifier, challenge: await pkceChallenge(verifier), method: 'S256' };
}

export function buildAuthorizationUrl(input: {
  authorizationEndpoint: string;
  clientId: string;
  redirectUri: string;
  scopes: string[];
  state: string;
  codeChallenge: string;
  nonce?: string;
}): string {
  const url = new URL(input.authorizationEndpoint);
  url.searchParams.set('response_type', 'code');
  url.searchParams.set('client_id', input.clientId);
  url.searchParams.set('redirect_uri', input.redirectUri);
  url.searchParams.set('scope', input.scopes.join(' '));
  url.searchParams.set('state', input.state);
  url.searchParams.set('code_challenge', input.codeChallenge);
  url.searchParams.set('code_challenge_method', 'S256');
  if (input.nonce) url.searchParams.set('nonce', input.nonce);
  return url.toString();
}

export function parseTokenResponse(value: unknown, now = Date.now()): TokenSet {
  const root = readObject(RESPONSE, value, 'token');
  const tokens: TokenSet = {
    accessToken: readString(RESPONSE, root.access_token, 'token.access_token', { max: 16384 }),
    tokenType: readString(RESPONSE, root.token_type ?? 'Bearer', 'token.token_type', { max: 32 }),
  };
  if (root.expires_in !== undefined) {
    const seconds = Number(root.expires_in);
    if (!Number.isFinite(seconds) || seconds <= 0) fail(RESPONSE, 'token.expires_in', 'must be a positive number');
    tokens.expiresAt = now + seconds * 1000;
  }
  const refreshToken = readOptionalString(RESPONSE, root.refresh_token, 'token.refresh_token', { max: 16384 });
  if (refreshToken !== undefined) tokens.refreshToken = refreshToken;
  const idToken = readOptionalString(RESPONSE, root.id_token, 'token.id_token', { max: 16384 });
  if (idToken !== undefined) tokens.idToken = idToken;
  const scope = readOptionalString(RESPONSE, root.scope, 'token.scope', { max: MAX_LONG_TEXT });
  if (scope !== undefined) tokens.scope = scope;
  return tokens;
}

export async function exchangeAuthorizationCode(
  input: { tokenEndpoint: string; clientId: string; code: string; redirectUri: string; codeVerifier: string },
  fetchImpl: FetchLike = fetch,
): Promise<TokenSet> {
  return postTokenRequest(
    input.tokenEndpoint,
    {
      grant_type: 'authorization_code',
      client_id: input.clientId,
      code: input.code,
      redirect_uri: input.redirectUri,
      code_verifier: input.codeVerifier,
    },
    fetchImpl,
  );
}

export async function refreshAccessToken(
  input: { tokenEndpoint: string; clientId: string; refreshToken: string },
  fetchImpl: FetchLike = fetch,
): Promise<TokenSet> {
  const tokens = await postTokenRequest(
    input.tokenEndpoint,
    { grant_type: 'refresh_token', client_id: input.clientId, refresh_token: input.refreshToken },
    fetchImpl,
  );
  return tokens.refreshToken ? tokens : { ...tokens, refreshToken: input.refreshToken };
}

export class OidcTokenError extends Error {
  readonly status: number;
  readonly error: string | undefined;

  constructor(status: number, error: string | undefined) {
    super(`token endpoint answered ${status}${error ? ` (${error})` : ''}`);
    this.name = 'OidcTokenError';
    this.status = status;
    this.error = error;
  }
}

async function postTokenRequest(endpoint: string, form: Record<string, string>, fetchImpl: FetchLike): Promise<TokenSet> {
  const response = await fetchImpl(endpoint, {
    method: 'POST',
    headers: { 'content-type': 'application/x-www-form-urlencoded', accept: 'application/json' },
    body: new URLSearchParams(form).toString(),
  });
  const body: unknown = await response.json().catch(() => undefined);
  if (!response.ok) {
    const error =
      typeof body === 'object' && body !== null && typeof (body as { error?: unknown }).error === 'string'
        ? ((body as { error: string }).error.slice(0, 64))
        : undefined;
    throw new OidcTokenError(response.status, error);
  }
  return parseTokenResponse(body);
}

function trimSlash(value: string): string {
  return value.replace(/\/+$/, '');
}
