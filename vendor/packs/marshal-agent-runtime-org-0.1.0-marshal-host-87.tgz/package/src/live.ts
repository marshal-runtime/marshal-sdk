import { isLeaseHostId } from './leases.js';
import { parseOrgSessionMessage, type OrgSessionMessage } from './messages.js';
import { isSessionId } from './sessions.js';
import { fail, readArray, readObject, readString, type Reader } from './validate.js';

const RESPONSE: Reader = { code: 'invalid-response' };
const REQUEST: Reader = { code: 'invalid-request' };

/**
 * Live sessions (feature `liveSessions`): a session that stays on its owner's desktop and that collaborators and drivers
 * instruct through the inbox. The owner's desktop is the only executor: it claims the waiting messages of every author in
 * `seq` order, runs one turn at a time, and appends each committed message to the transcript.
 */

/** Most messages one claim returns (the server also caps their text at `MAX_CLAIM_BYTES`, always returning at least one). */
export const MAX_CLAIM_MESSAGES = 5;
/** Most bytes of message text one claim returns. */
export const MAX_CLAIM_BYTES = 16 * 1024;
/** Most characters of the final answer a `done` carries. */
export const MAX_COMPLETE_FINAL_CHARS = 32_000;
/** Most queued instructions one author other than the owner keeps in one live session; the next post answers 429 `queue-full`. */
export const MAX_LIVE_QUEUED_PER_AUTHOR = 5;
/** Most sessions one pending answer lists. */
export const MAX_LIVE_PENDING = 50;
/** Participant turns one author may start in one live session per rolling day unless the owner sets another budget. */
export const DEFAULT_PARTICIPANT_TURNS_PER_DAY = 20;
/** The largest participant-turn budget an owner may set. */
export const MAX_PARTICIPANT_TURNS_PER_DAY = 500;
/** How often a desktop asks for pending work unless the server says otherwise, in seconds. */
export const DEFAULT_LIVE_POLL_SECONDS = 4;
/** The longest poll interval a server may ask for, in seconds. */
export const MAX_LIVE_POLL_SECONDS = 300;
/** A desktop is online while it asked for pending work within this many poll intervals. */
export const LIVE_PRESENCE_POLLS = 3;

const TURN_ID_PATTERN = /^[A-Za-z0-9][A-Za-z0-9._:-]{0,127}$/;
const MAX_PENDING_QUEUED = 1_000;

/**
 * `GET` and `PUT /v1/sessions/:id/live`. `host` is the executor: the owner's desktop that runs the session (only that host is
 * told about pending work and only it claims other authors' messages); it is shown to the owner only.
 */
export type OrgSessionLive = { enabled: boolean; participantTurnsPerDay: number; host?: string };
/** Body of `PUT /v1/sessions/:id/live`. Turning it on needs the executor `host`. */
export type OrgSessionLiveRequest = { enabled: boolean; host?: string; participantTurnsPerDay?: number };

/** Body of `POST /v1/sessions/:id/messages/claim`. `max` defaults to `MAX_CLAIM_MESSAGES`. */
export type OrgClaimMessagesRequest = { host: string; max?: number };
/** Answer of a claim: the messages now `claimed` by the caller's lease tenure, oldest first. */
export type OrgClaimedMessages = { messages: OrgSessionMessage[] };

/** Body of `POST /v1/sessions/:id/messages/done`: the turn that ran the claimed messages ended. */
export type OrgCompleteMessagesRequest = { host: string; turnId: string; final?: string };
/** Answer of a done: how many messages became `done`, and how many are still queued. */
export type OrgCompletedMessages = { done: number; more: number };

/** One of the caller's live sessions with queued instructions. */
export type OrgLivePendingSession = { id: string; queued: number };
/** `GET /v1/live-sessions/pending?host=`: the caller's live desktop sessions with work, oldest waiting first, and how often to ask again. */
export type OrgLivePending = { sessions: OrgLivePendingSession[]; pollSeconds: number };

export function isTurnId(value: unknown): value is string {
  return typeof value === 'string' && TURN_ID_PATTERN.test(value);
}

function readInteger(reader: Reader, value: unknown, path: string, min: number, max: number): number {
  if (typeof value !== 'number' || !Number.isInteger(value) || value < min || value > max) fail(reader, path, `must be an integer from ${min} to ${max}`);
  return value;
}


function readHost(reader: Reader, value: unknown, path: string): string {
  if (!isLeaseHostId(value)) fail(reader, path, 'must be 1 to 128 letters, digits, dot, dash, colon or underscore');
  return value;
}

export function parseOrgSessionLive(value: unknown): OrgSessionLive {
  const root = readObject(RESPONSE, value, 'live');
  if (typeof root.enabled !== 'boolean') fail(RESPONSE, 'live.enabled', 'must be a boolean');
  const live: OrgSessionLive = {
    enabled: root.enabled,
    participantTurnsPerDay:
      root.participantTurnsPerDay === undefined || root.participantTurnsPerDay === null
        ? DEFAULT_PARTICIPANT_TURNS_PER_DAY
        : readInteger(RESPONSE, root.participantTurnsPerDay, 'live.participantTurnsPerDay', 0, MAX_PARTICIPANT_TURNS_PER_DAY),
  };
  if (root.host !== undefined && root.host !== null) live.host = readHost(RESPONSE, root.host, 'live.host');
  return live;
}

export function parseOrgSessionLiveRequest(value: unknown): OrgSessionLiveRequest {
  const root = readObject(REQUEST, value, 'live');
  if (typeof root.enabled !== 'boolean') fail(REQUEST, 'live.enabled', 'must be a boolean');
  const request: OrgSessionLiveRequest = { enabled: root.enabled };
  if (root.host !== undefined && root.host !== null) request.host = readHost(REQUEST, root.host, 'live.host');
  if (request.enabled && request.host === undefined) fail(REQUEST, 'live.host', 'is required to turn live on');
  if (root.participantTurnsPerDay !== undefined && root.participantTurnsPerDay !== null) {
    request.participantTurnsPerDay = readInteger(REQUEST, root.participantTurnsPerDay, 'live.participantTurnsPerDay', 1, MAX_PARTICIPANT_TURNS_PER_DAY);
  }
  return request;
}

export function parseOrgClaimMessagesRequest(value: unknown): Required<OrgClaimMessagesRequest> {
  const root = readObject(REQUEST, value, 'claim');
  const host = readHost(REQUEST, root.host, 'claim.host');
  const max = root.max === undefined || root.max === null ? MAX_CLAIM_MESSAGES : readInteger(REQUEST, root.max, 'claim.max', 1, MAX_CLAIM_MESSAGES);
  return { host, max };
}

export function parseOrgClaimedMessages(value: unknown): OrgClaimedMessages {
  const root = readObject(RESPONSE, value, 'claimed');
  return { messages: readArray(RESPONSE, root.messages, 'claimed.messages', MAX_CLAIM_MESSAGES, (entry, path) => parseOrgSessionMessage(entry, path)) };
}

export function parseOrgCompleteMessagesRequest(value: unknown): OrgCompleteMessagesRequest {
  const root = readObject(REQUEST, value, 'done');
  const request: OrgCompleteMessagesRequest = {
    host: readHost(REQUEST, root.host, 'done.host'),
    turnId: readString(REQUEST, root.turnId, 'done.turnId', { max: 128, pattern: TURN_ID_PATTERN }),
  };
  if (root.final !== undefined && root.final !== null) {
    const final = readString(REQUEST, root.final, 'done.final', { min: 0, max: MAX_COMPLETE_FINAL_CHARS });
    if (final !== '') request.final = final;
  }
  return request;
}

export function parseOrgCompletedMessages(value: unknown): OrgCompletedMessages {
  const root = readObject(RESPONSE, value, 'completed');
  return {
    done: readInteger(RESPONSE, root.done, 'completed.done', 0, MAX_CLAIM_MESSAGES * 4),
    more: readInteger(RESPONSE, root.more, 'completed.more', 0, MAX_PENDING_QUEUED),
  };
}

export function parseOrgLivePending(value: unknown): OrgLivePending {
  const root = readObject(RESPONSE, value, 'livePending');
  const sessions = readArray(RESPONSE, root.sessions, 'livePending.sessions', MAX_LIVE_PENDING, (entry, path) => {
    const session = readObject(RESPONSE, entry, path);
    if (!isSessionId(session.id)) fail(RESPONSE, `${path}.id`, 'must be a session id');
    return { id: session.id, queued: readInteger(RESPONSE, session.queued, `${path}.queued`, 1, MAX_PENDING_QUEUED) };
  });
  const pollSeconds =
    root.pollSeconds === undefined || root.pollSeconds === null
      ? DEFAULT_LIVE_POLL_SECONDS
      : readInteger(RESPONSE, root.pollSeconds, 'livePending.pollSeconds', 1, MAX_LIVE_POLL_SECONDS);
  return { sessions, pollSeconds };
}
