import { isOrgWorkspaceId, type OrgWorkspaceId } from './model.js';
import { readUserPrincipal, type UserPrincipal } from './principals.js';
import { utf8Length, MAX_CURSOR, MAX_TRANSCRIPT_MESSAGE_BYTES, MAX_TRANSCRIPT_PAGE_BYTES } from './sessions.js';
import {
  MAX_LONG_TEXT,
  MAX_SHORT_TEXT,
  fail,
  readArray,
  readObject,
  readOptionalString,
  readString,
  type Reader,
} from './validate.js';

const RESPONSE: Reader = { code: 'invalid-response' };
const REQUEST: Reader = { code: 'invalid-request' };

export const MAX_RUN_PAGE = 100;
export const DEFAULT_RUN_PAGE = 50;
export const MAX_RUN_EVENTS_PAGE = 200;
export const MAX_RUN_MESSAGES_PAGE = 200;
export const MAX_RUN_LINKS = 32;
export const MAX_RUN_SESSIONS = 64;
export const MAX_RUN_FLAGS = 16;
export const MAX_GREP_RUNS = 20;
export const MAX_GREP_HITS = 100;
export const MAX_GREP_PATTERN = 200;
export const MAX_GREP_EXCERPT = 240;
export const MAX_RUN_EVENT_TEXT = 2000;
export const MAX_RUN_TOOL_INPUT = 2048;
export const MAX_AUDIT_PAGE = 100;

/** Where a run came from. */
export const RUN_SOURCES = ['slack', 'github', 'review', 'investigation', 'implement', 'chat', 'other'] as const;
export type OrgRunSource = (typeof RUN_SOURCES)[number];

export const RUN_STATUSES = ['running', 'succeeded', 'failed'] as const;
export type OrgRunStatus = (typeof RUN_STATUSES)[number];

export const RUN_SESSION_STATES = ['running', 'succeeded', 'failed', 'refused'] as const;
export type OrgRunSessionState = (typeof RUN_SESSION_STATES)[number];

/** Flags the server computes without a model, so a reader can find the runs worth opening. */
export const RUN_FLAGS = ['failed', 'refused', 'tool-errors', 'expensive', 'slow', 'retried', 'publication-failed'] as const;
export type OrgRunFlag = (typeof RUN_FLAGS)[number];

export const RUN_OUTCOMES = ['refused', 'dry-run', 'live'] as const;
export type OrgRunOutcome = (typeof RUN_OUTCOMES)[number];

export const RUN_SORTS = ['started', 'cost', 'toolErrors'] as const;
export type OrgRunSort = (typeof RUN_SORTS)[number];

export const RUN_LINK_KINDS = ['slack', 'pr', 'datadog', 'pagerduty', 'monitor', 'root-cause', 'linear', 'wake', 'chat', 'session'] as const;
export type OrgRunLinkKind = (typeof RUN_LINK_KINDS)[number];

export const RUN_LINK_ROLES = ['origin', 'output', 'related'] as const;
export type OrgRunLinkRole = (typeof RUN_LINK_ROLES)[number];

/** Why a session of a run has no transcript to serve. */
export const RUN_UNAVAILABLE_REASONS = ['withheld', 'too-large', 'missing'] as const;
export type OrgRunUnavailableReason = (typeof RUN_UNAVAILABLE_REASONS)[number];

export const RUN_MESSAGE_ROLES = ['user', 'assistant', 'tool'] as const;
export type OrgRunMessageRole = (typeof RUN_MESSAGE_ROLES)[number];

/** A run belongs to exactly one workspace, or to `unassigned` when two signals pointed at different ones. Auditors never see `unassigned`. */
export type OrgRunWorkspace = OrgWorkspaceId | 'unassigned';

export const AUDIT_BASES = ['requester', 'auditor', 'admin'] as const;
export type OrgAuditBasis = (typeof AUDIT_BASES)[number];

export const AUDIT_ACTIONS = ['list', 'get', 'events', 'messages', 'envelope', 'grep'] as const;
export type OrgAuditAction = (typeof AUDIT_ACTIONS)[number];

export type OrgRunLink = {
  kind: OrgRunLinkKind;
  /** Canonical per kind: `C123:1792.123` for a Slack thread, `owner/repo#12` for a pull request, the id for the rest. */
  key: string;
  role: OrgRunLinkRole;
};

export type OrgRunSessionBrief = {
  role: string;
  status: OrgRunSessionState;
  turns?: number;
};

/** One run as a list shows it, about 300 bytes. `type` is always `run`, so a merged list can tell runs from org sessions. */
export type OrgRunRow = {
  id: string;
  type: 'run';
  workspace: OrgRunWorkspace;
  workflow: string;
  source: OrgRunSource;
  title: string;
  status: OrgRunStatus;
  startedAt: string;
  durationMs?: number;
  costUsd: number;
  /** The person the run acted for, when the server could resolve one. */
  requester?: UserPrincipal;
  dryRun: boolean;
  links: OrgRunLink[];
  toolErrors: number;
  flags: OrgRunFlag[];
  sessions: OrgRunSessionBrief[];
  githubUrl?: string;
  /** The GitHub event that started the run (e.g. `repository_dispatch`, `schedule`). */
  trigger?: string;
  /** The run's final answer, clipped and screened; served only to people who read the run in full. */
  answer?: string;
  hasTranscript: boolean;
  hasEnvelope: boolean;
};

export type OrgRunPage = {
  runs: OrgRunRow[];
  nextCursor?: string;
  /** Everything the index read up to this time is searchable; a newer run may not be listed yet. */
  indexedThrough?: string;
};

export type OrgRunSessionDetail = {
  /** The name of the session inside the run; the path segment of the messages and envelope routes. */
  session: string;
  role: string;
  model?: string;
  status: OrgRunSessionState;
  startedAt: string;
  finishedAt?: string;
  costUsd?: number;
  turns?: number;
  toolCalls: number;
  toolErrors: number;
  error?: string;
  hasTranscript: boolean;
  hasEnvelope: boolean;
  unavailableReason?: OrgRunUnavailableReason;
};

export type OrgRunCounts = {
  events: number;
  toolCalls: number;
  toolErrors: number;
  evidenceCalls: number;
  publications: number;
  failedPublications: number;
};

export type OrgRunDetail = {
  run: OrgRunRow;
  counts: OrgRunCounts;
  error?: string;
  sessions: OrgRunSessionDetail[];
};

/** One event of a run's record. The server redacts credentials before it stores an event and again before it serves one. */
export type OrgRunEvent = {
  n: number;
  at: string;
  type: string;
  text?: string;
};

export type OrgRunEventPage = {
  events: OrgRunEvent[];
  total: number;
  nextCursor?: string;
};

export type OrgRunToolCall = {
  name: string;
  isError: boolean;
  /** The input, clipped. */
  input?: string;
};

/** One message of a session of a run. A message that matched a credential rule is served with `withheld` and no text. */
export type OrgRunMessage = {
  n: number;
  role: OrgRunMessageRole;
  at?: string;
  text?: string;
  tool?: OrgRunToolCall;
  withheld?: boolean;
};

export type OrgRunMessagesPage = {
  messages: OrgRunMessage[];
  total: number;
  /** The `from` of the next page, absent at the end. */
  nextFrom?: number;
};

export type OrgRunGrepRequest = {
  runIds: string[];
  /** A literal, matched case-insensitively. Never a regular expression. */
  pattern: string;
};

export type OrgRunGrepHit = {
  runId: string;
  session: string;
  n: number;
  role: OrgRunMessageRole;
  excerpt: string;
};

export type OrgRunGrepResult = {
  hits: OrgRunGrepHit[];
  /** Runs that were searched; a run the caller cannot read is not counted and not named. */
  searched: number;
  truncated: boolean;
};

export type OrgAuditRow = {
  at: string;
  actor: UserPrincipal;
  basis: OrgAuditBasis;
  action: OrgAuditAction;
  workspace: OrgRunWorkspace;
  runId?: string;
  /** For a list or grep: a hash of the filter set, never the filters. */
  filterHash?: string;
  resultCount?: number;
};

export type OrgAuditPage = {
  rows: OrgAuditRow[];
  nextCursor?: string;
};

/** The filters of `GET /v1/runs`. Every one is optional and they combine. */
export type OrgRunQuery = {
  workspace?: OrgWorkspaceId;
  source?: OrgRunSource;
  workflow?: string;
  role?: string;
  channel?: string;
  thread?: string;
  repo?: string;
  pr?: number;
  issue?: string;
  trigger?: string;
  status?: OrgRunStatus;
  outcome?: OrgRunOutcome;
  flag?: OrgRunFlag;
  /** `me` or a user principal. Without auditor rights only `me` (or the caller's own principal) is accepted. */
  requester?: 'me' | UserPrincipal;
  since?: string;
  until?: string;
  costMin?: number;
  costMax?: number;
  q?: string;
  sort?: OrgRunSort;
  limit?: number;
  cursor?: string;
};

export type OrgRunEventsQuery = { type?: string; after?: number; limit?: number };
export type OrgRunMessagesQuery = { from?: number; limit?: number };
export type OrgAuditQuery = { target: 'me' | `run:${string}`; actor?: 'me' | UserPrincipal; since?: string; limit?: number; cursor?: string };

const ISO_PATTERN = /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(\.\d{1,9})?(Z|[+-]\d{2}:\d{2})$/;
const RUN_ID_PATTERN = /^[A-Za-z0-9][A-Za-z0-9._-]{0,119}$/;
const SESSION_NAME_PATTERN = /^[A-Za-z0-9][A-Za-z0-9._-]{0,127}$/;
const ROLE_NAME_PATTERN = /^[A-Za-z0-9][A-Za-z0-9._-]{0,63}$/;
const HASH_PATTERN = /^[0-9a-f]{16,64}$/;
const TARGET_RUN = /^run:([A-Za-z0-9][A-Za-z0-9._-]{0,119})$/;
const REPO_PATTERN = /^[\w.-]+\/[\w.-]+$/;

export function isRunId(value: unknown): value is string {
  return typeof value === 'string' && RUN_ID_PATTERN.test(value);
}

export function isRunSessionName(value: unknown): value is string {
  return typeof value === 'string' && SESSION_NAME_PATTERN.test(value);
}

function readIso(reader: Reader, value: unknown, path: string): string {
  const text = readString(reader, value, path, { max: 40 });
  if (!ISO_PATTERN.test(text) || Number.isNaN(Date.parse(text))) fail(reader, path, 'must be an ISO 8601 timestamp');
  return text;
}

function readEnum<T extends string>(reader: Reader, value: unknown, path: string, allowed: readonly T[]): T {
  if (typeof value !== 'string' || !(allowed as readonly string[]).includes(value)) {
    fail(reader, path, `must be one of ${allowed.join(', ')}`);
  }
  return value as T;
}

function readCount(reader: Reader, value: unknown, path: string, max = Number.MAX_SAFE_INTEGER): number {
  if (typeof value !== 'number' || !Number.isInteger(value) || value < 0 || value > max) fail(reader, path, 'must be a non-negative integer');
  return value;
}

function readMoney(reader: Reader, value: unknown, path: string): number {
  if (typeof value !== 'number' || !Number.isFinite(value) || value < 0 || value > 1_000_000) fail(reader, path, 'must be a non-negative amount');
  return value;
}

function readBool(reader: Reader, value: unknown, path: string): boolean {
  if (typeof value !== 'boolean') fail(reader, path, 'must be a boolean');
  return value;
}

function readWorkspace(reader: Reader, value: unknown, path: string): OrgRunWorkspace {
  const text = readString(reader, value, path, { max: 66 });
  if (text !== 'unassigned' && !isOrgWorkspaceId(text)) fail(reader, path, 'must look like ws:<lowercase-name>, or be unassigned');
  return text as OrgRunWorkspace;
}

function readLink(reader: Reader, value: unknown, path: string): OrgRunLink {
  const root = readObject(reader, value, path);
  return {
    kind: readEnum(reader, root.kind, `${path}.kind`, RUN_LINK_KINDS),
    key: readString(reader, root.key, `${path}.key`, { max: 256 }),
    role: readEnum(reader, root.role, `${path}.role`, RUN_LINK_ROLES),
  };
}

function readSessionBrief(reader: Reader, value: unknown, path: string): OrgRunSessionBrief {
  const root = readObject(reader, value, path);
  const brief: OrgRunSessionBrief = {
    role: readString(reader, root.role, `${path}.role`, { max: 64 }),
    status: readEnum(reader, root.status, `${path}.status`, RUN_SESSION_STATES),
  };
  if (root.turns !== undefined && root.turns !== null) brief.turns = readCount(reader, root.turns, `${path}.turns`);
  return brief;
}

const MAX_ROW_ANSWER = 2048;

function readRow(reader: Reader, value: unknown, path: string): OrgRunRow {
  const root = readObject(reader, value, path);
  if (root.type !== 'run') fail(reader, `${path}.type`, 'must be run');
  const id = readString(reader, root.id, `${path}.id`, { max: 120 });
  if (!RUN_ID_PATTERN.test(id)) fail(reader, `${path}.id`, 'must be a run id');
  const row: OrgRunRow = {
    id,
    type: 'run',
    workspace: readWorkspace(reader, root.workspace, `${path}.workspace`),
    workflow: readString(reader, root.workflow, `${path}.workflow`, { max: 128 }),
    source: readEnum(reader, root.source, `${path}.source`, RUN_SOURCES),
    title: readString(reader, root.title, `${path}.title`, { max: MAX_SHORT_TEXT, min: 0 }),
    status: readEnum(reader, root.status, `${path}.status`, RUN_STATUSES),
    startedAt: readIso(reader, root.startedAt, `${path}.startedAt`),
    costUsd: readMoney(reader, root.costUsd, `${path}.costUsd`),
    dryRun: readBool(reader, root.dryRun, `${path}.dryRun`),
    links: readArray(reader, root.links, `${path}.links`, MAX_RUN_LINKS, (entry, entryPath) => readLink(reader, entry, entryPath)),
    toolErrors: readCount(reader, root.toolErrors, `${path}.toolErrors`),
    flags: readArray(reader, root.flags, `${path}.flags`, MAX_RUN_FLAGS, (entry, entryPath) => readEnum(reader, entry, entryPath, RUN_FLAGS)),
    sessions: readArray(reader, root.sessions, `${path}.sessions`, MAX_RUN_SESSIONS, (entry, entryPath) => readSessionBrief(reader, entry, entryPath)),
    hasTranscript: readBool(reader, root.hasTranscript, `${path}.hasTranscript`),
    hasEnvelope: readBool(reader, root.hasEnvelope, `${path}.hasEnvelope`),
  };
  if (root.durationMs !== undefined && root.durationMs !== null) row.durationMs = readCount(reader, root.durationMs, `${path}.durationMs`);
  if (root.requester !== undefined && root.requester !== null) row.requester = readUserPrincipal(reader, root.requester, `${path}.requester`);
  const githubUrl = readOptionalString(reader, root.githubUrl, `${path}.githubUrl`, { max: 2048 });
  if (githubUrl !== undefined) row.githubUrl = githubUrl;
  const trigger = readOptionalString(reader, root.trigger, `${path}.trigger`, { max: 64 });
  if (trigger !== undefined) row.trigger = trigger;
  const answer = readOptionalString(reader, root.answer, `${path}.answer`, { max: MAX_ROW_ANSWER });
  if (answer !== undefined) row.answer = answer;
  return row;
}

function readCursor(reader: Reader, value: unknown, path: string): string | undefined {
  return readOptionalString(reader, value, path, { max: MAX_CURSOR });
}

function readSessionDetail(reader: Reader, value: unknown, path: string): OrgRunSessionDetail {
  const root = readObject(reader, value, path);
  const session = readString(reader, root.session, `${path}.session`, { max: 128 });
  if (!SESSION_NAME_PATTERN.test(session)) fail(reader, `${path}.session`, 'must be a session name');
  const detail: OrgRunSessionDetail = {
    session,
    role: readString(reader, root.role, `${path}.role`, { max: 64 }),
    status: readEnum(reader, root.status, `${path}.status`, RUN_SESSION_STATES),
    startedAt: readIso(reader, root.startedAt, `${path}.startedAt`),
    toolCalls: readCount(reader, root.toolCalls, `${path}.toolCalls`),
    toolErrors: readCount(reader, root.toolErrors, `${path}.toolErrors`),
    hasTranscript: readBool(reader, root.hasTranscript, `${path}.hasTranscript`),
    hasEnvelope: readBool(reader, root.hasEnvelope, `${path}.hasEnvelope`),
  };
  const model = readOptionalString(reader, root.model, `${path}.model`, { max: 128 });
  if (model !== undefined) detail.model = model;
  if (root.finishedAt !== undefined && root.finishedAt !== null) detail.finishedAt = readIso(reader, root.finishedAt, `${path}.finishedAt`);
  if (root.costUsd !== undefined && root.costUsd !== null) detail.costUsd = readMoney(reader, root.costUsd, `${path}.costUsd`);
  if (root.turns !== undefined && root.turns !== null) detail.turns = readCount(reader, root.turns, `${path}.turns`);
  const error = readOptionalString(reader, root.error, `${path}.error`, { max: MAX_LONG_TEXT });
  if (error !== undefined) detail.error = error;
  if (root.unavailableReason !== undefined && root.unavailableReason !== null) {
    detail.unavailableReason = readEnum(reader, root.unavailableReason, `${path}.unavailableReason`, RUN_UNAVAILABLE_REASONS);
  }
  return detail;
}

function readCounts(reader: Reader, value: unknown, path: string): OrgRunCounts {
  const root = readObject(reader, value, path);
  return {
    events: readCount(reader, root.events, `${path}.events`),
    toolCalls: readCount(reader, root.toolCalls, `${path}.toolCalls`),
    toolErrors: readCount(reader, root.toolErrors, `${path}.toolErrors`),
    evidenceCalls: readCount(reader, root.evidenceCalls, `${path}.evidenceCalls`),
    publications: readCount(reader, root.publications, `${path}.publications`),
    failedPublications: readCount(reader, root.failedPublications, `${path}.failedPublications`),
  };
}

function readEvent(reader: Reader, value: unknown, path: string): OrgRunEvent {
  const root = readObject(reader, value, path);
  const event: OrgRunEvent = {
    n: readCount(reader, root.n, `${path}.n`),
    at: readIso(reader, root.at, `${path}.at`),
    type: readString(reader, root.type, `${path}.type`, { max: 64 }),
  };
  const text = readOptionalString(reader, root.text, `${path}.text`, { max: MAX_RUN_EVENT_TEXT });
  if (text !== undefined) event.text = text;
  return event;
}

function readMessage(reader: Reader, value: unknown, path: string): OrgRunMessage {
  const root = readObject(reader, value, path);
  const message: OrgRunMessage = {
    n: readCount(reader, root.n, `${path}.n`),
    role: readEnum(reader, root.role, `${path}.role`, RUN_MESSAGE_ROLES),
  };
  if (root.at !== undefined && root.at !== null) message.at = readIso(reader, root.at, `${path}.at`);
  if (root.text !== undefined && root.text !== null) {
    const text = readString(reader, root.text, `${path}.text`, { min: 0, max: MAX_TRANSCRIPT_MESSAGE_BYTES });
    if (utf8Length(text) > MAX_TRANSCRIPT_MESSAGE_BYTES) fail(reader, `${path}.text`, `must be at most ${MAX_TRANSCRIPT_MESSAGE_BYTES} bytes`);
    message.text = text;
  }
  if (root.tool !== undefined && root.tool !== null) {
    const tool = readObject(reader, root.tool, `${path}.tool`);
    const call: OrgRunToolCall = {
      name: readString(reader, tool.name, `${path}.tool.name`, { max: 128 }),
      isError: readBool(reader, tool.isError, `${path}.tool.isError`),
    };
    const input = readOptionalString(reader, tool.input, `${path}.tool.input`, { max: MAX_RUN_TOOL_INPUT });
    if (input !== undefined) call.input = input;
    message.tool = call;
  }
  if (root.withheld !== undefined && root.withheld !== null) message.withheld = readBool(reader, root.withheld, `${path}.withheld`);
  return message;
}

function readAuditRow(reader: Reader, value: unknown, path: string): OrgAuditRow {
  const root = readObject(reader, value, path);
  const row: OrgAuditRow = {
    at: readIso(reader, root.at, `${path}.at`),
    actor: readUserPrincipal(reader, root.actor, `${path}.actor`),
    basis: readEnum(reader, root.basis, `${path}.basis`, AUDIT_BASES),
    action: readEnum(reader, root.action, `${path}.action`, AUDIT_ACTIONS),
    workspace: readWorkspace(reader, root.workspace, `${path}.workspace`),
  };
  if (root.runId !== undefined && root.runId !== null) {
    const runId = readString(reader, root.runId, `${path}.runId`, { max: 120 });
    if (!RUN_ID_PATTERN.test(runId)) fail(reader, `${path}.runId`, 'must be a run id');
    row.runId = runId;
  }
  if (root.filterHash !== undefined && root.filterHash !== null) {
    row.filterHash = readString(reader, root.filterHash, `${path}.filterHash`, { max: 64, pattern: HASH_PATTERN });
  }
  if (root.resultCount !== undefined && root.resultCount !== null) row.resultCount = readCount(reader, root.resultCount, `${path}.resultCount`);
  return row;
}

function withCursor<T extends object>(reader: Reader, root: Record<string, unknown>, path: string, page: T): T & { nextCursor?: string } {
  const nextCursor = readCursor(reader, root.nextCursor, `${path}.nextCursor`);
  return nextCursor === undefined ? page : { ...page, nextCursor };
}

/* Responses: parsed by clients, invalid-response on failure. */

export function parseOrgRunRow(value: unknown, path = 'run'): OrgRunRow {
  return readRow(RESPONSE, value, path);
}

export function parseOrgRunPage(value: unknown): OrgRunPage {
  const root = readObject(RESPONSE, value, 'runs');
  const page: OrgRunPage = {
    runs: readArray(RESPONSE, root.runs, 'runs.runs', MAX_RUN_PAGE, (entry, path) => readRow(RESPONSE, entry, path)),
  };
  if (root.indexedThrough !== undefined && root.indexedThrough !== null) page.indexedThrough = readIso(RESPONSE, root.indexedThrough, 'runs.indexedThrough');
  return withCursor(RESPONSE, root, 'runs', page);
}

export function parseOrgRunDetail(value: unknown): OrgRunDetail {
  const root = readObject(RESPONSE, value, 'runDetail');
  const detail: OrgRunDetail = {
    run: readRow(RESPONSE, root.run, 'runDetail.run'),
    counts: readCounts(RESPONSE, root.counts, 'runDetail.counts'),
    sessions: readArray(RESPONSE, root.sessions, 'runDetail.sessions', MAX_RUN_SESSIONS, (entry, path) => readSessionDetail(RESPONSE, entry, path)),
  };
  const error = readOptionalString(RESPONSE, root.error, 'runDetail.error', { max: MAX_LONG_TEXT });
  if (error !== undefined) detail.error = error;
  return detail;
}

export function parseOrgRunEventPage(value: unknown): OrgRunEventPage {
  const root = readObject(RESPONSE, value, 'runEvents');
  const page = {
    events: readArray(RESPONSE, root.events, 'runEvents.events', MAX_RUN_EVENTS_PAGE, (entry, path) => readEvent(RESPONSE, entry, path)),
    total: readCount(RESPONSE, root.total, 'runEvents.total'),
  };
  return withCursor(RESPONSE, root, 'runEvents', page);
}

export function parseOrgRunMessagesPage(value: unknown): OrgRunMessagesPage {
  const root = readObject(RESPONSE, value, 'runMessages');
  const messages = readArray(RESPONSE, root.messages, 'runMessages.messages', MAX_RUN_MESSAGES_PAGE, (entry, path) => readMessage(RESPONSE, entry, path));
  const bytes = messages.reduce((sum, message) => sum + utf8Length(message.text ?? '') + utf8Length(message.tool?.input ?? ''), 0);
  if (bytes > MAX_TRANSCRIPT_PAGE_BYTES) fail(RESPONSE, 'runMessages.messages', `must carry at most ${MAX_TRANSCRIPT_PAGE_BYTES} bytes of text`);
  const page: OrgRunMessagesPage = { messages, total: readCount(RESPONSE, root.total, 'runMessages.total') };
  if (root.nextFrom !== undefined && root.nextFrom !== null) page.nextFrom = readCount(RESPONSE, root.nextFrom, 'runMessages.nextFrom');
  return page;
}

export function parseOrgRunGrepResult(value: unknown): OrgRunGrepResult {
  const root = readObject(RESPONSE, value, 'runGrep');
  return {
    hits: readArray(RESPONSE, root.hits, 'runGrep.hits', MAX_GREP_HITS, (entry, path) => {
      const hit = readObject(RESPONSE, entry, path);
      const runId = readString(RESPONSE, hit.runId, `${path}.runId`, { max: 120 });
      if (!RUN_ID_PATTERN.test(runId)) fail(RESPONSE, `${path}.runId`, 'must be a run id');
      return {
        runId,
        session: readString(RESPONSE, hit.session, `${path}.session`, { max: 128 }),
        n: readCount(RESPONSE, hit.n, `${path}.n`),
        role: readEnum(RESPONSE, hit.role, `${path}.role`, RUN_MESSAGE_ROLES),
        excerpt: readString(RESPONSE, hit.excerpt, `${path}.excerpt`, { max: MAX_GREP_EXCERPT, min: 0 }),
      };
    }),
    searched: readCount(RESPONSE, root.searched, 'runGrep.searched', MAX_GREP_RUNS),
    truncated: readBool(RESPONSE, root.truncated, 'runGrep.truncated'),
  };
}

export function parseOrgAuditPage(value: unknown): OrgAuditPage {
  const root = readObject(RESPONSE, value, 'audit');
  const rows = readArray(RESPONSE, root.rows, 'audit.rows', MAX_AUDIT_PAGE, (entry, path) => readAuditRow(RESPONSE, entry, path));
  return withCursor(RESPONSE, root, 'audit', { rows });
}

/* Requests: parsed by servers (and by the client before sending), invalid-request on failure. */

export function parseOrgRunGrepRequest(value: unknown): OrgRunGrepRequest {
  const root = readObject(REQUEST, value, 'runGrep');
  const runIds = readArray(REQUEST, root.runIds, 'runGrep.runIds', MAX_GREP_RUNS, (entry, path) => {
    const id = readString(REQUEST, entry, path, { max: 120 });
    if (!RUN_ID_PATTERN.test(id)) fail(REQUEST, path, 'must be a run id');
    return id;
  });
  if (runIds.length === 0) fail(REQUEST, 'runGrep.runIds', 'must name at least one run');
  if (new Set(runIds).size !== runIds.length) fail(REQUEST, 'runGrep.runIds', 'must not repeat a run');
  return { runIds, pattern: readString(REQUEST, root.pattern, 'runGrep.pattern', { max: MAX_GREP_PATTERN, min: 2 }) };
}

/** Reads the query of `GET /v1/runs` from URL parameters; the server and the client both use it, so they cannot disagree. */
export function parseOrgRunQuery(params: URLSearchParams): OrgRunQuery {
  const query: OrgRunQuery = {};
  const text = (name: string, max = 256): string | undefined => {
    const value = params.get(name);
    return value === null ? undefined : readString(REQUEST, value, name, { max });
  };
  const number = (name: string): number | undefined => {
    const value = params.get(name);
    if (value === null) return undefined;
    const parsed = Number(value);
    if (!Number.isFinite(parsed) || parsed < 0) fail(REQUEST, name, 'must be a non-negative number');
    return parsed;
  };
  const workspace = text('workspace', 66);
  if (workspace !== undefined) {
    if (!isOrgWorkspaceId(workspace)) fail(REQUEST, 'workspace', 'must look like ws:<lowercase-name>');
    query.workspace = workspace;
  }
  const source = text('source');
  if (source !== undefined) query.source = readEnum(REQUEST, source, 'source', RUN_SOURCES);
  const workflow = text('workflow', 128);
  if (workflow !== undefined) query.workflow = readString(REQUEST, workflow, 'workflow', { max: 128, pattern: ROLE_NAME_PATTERN });
  const role = text('role', 64);
  if (role !== undefined) query.role = readString(REQUEST, role, 'role', { max: 64, pattern: ROLE_NAME_PATTERN });
  const channel = text('channel', 32);
  if (channel !== undefined) query.channel = channel;
  const thread = text('thread', 32);
  if (thread !== undefined) query.thread = thread;
  const repo = text('repo', 256);
  if (repo !== undefined) query.repo = readString(REQUEST, repo, 'repo', { max: 256, pattern: REPO_PATTERN });
  const pr = number('pr');
  if (pr !== undefined) {
    if (!Number.isInteger(pr)) fail(REQUEST, 'pr', 'must be an integer');
    query.pr = pr;
  }
  const issue = text('issue', 128);
  if (issue !== undefined) query.issue = issue;
  const trigger = text('trigger', 64);
  if (trigger !== undefined) query.trigger = trigger;
  const status = text('status');
  if (status !== undefined) query.status = readEnum(REQUEST, status, 'status', RUN_STATUSES);
  const outcome = text('outcome');
  if (outcome !== undefined) query.outcome = readEnum(REQUEST, outcome, 'outcome', RUN_OUTCOMES);
  const flag = text('flag');
  if (flag !== undefined) query.flag = readEnum(REQUEST, flag, 'flag', RUN_FLAGS);
  const requester = text('requester', 260);
  if (requester !== undefined) {
    query.requester = requester === 'me' ? 'me' : readUserPrincipal(REQUEST, requester, 'requester');
  }
  const since = text('since', 40);
  if (since !== undefined) query.since = readIso(REQUEST, since, 'since');
  const until = text('until', 40);
  if (until !== undefined) query.until = readIso(REQUEST, until, 'until');
  const costMin = number('costMin');
  if (costMin !== undefined) query.costMin = costMin;
  const costMax = number('costMax');
  if (costMax !== undefined) query.costMax = costMax;
  const q = text('q', 200);
  if (q !== undefined) query.q = q;
  const sort = text('sort');
  if (sort !== undefined) query.sort = readEnum(REQUEST, sort, 'sort', RUN_SORTS);
  const limit = number('limit');
  if (limit !== undefined) {
    if (limit < 1) fail(REQUEST, 'limit', 'must be a positive integer');
    query.limit = Math.min(Math.trunc(limit), MAX_RUN_PAGE);
  }
  const cursor = text('cursor', MAX_CURSOR);
  if (cursor !== undefined) query.cursor = cursor;
  return query;
}

/** The URL parameters of a run query, in a fixed order; `parseOrgRunQuery` reads them back. */
export function orgRunQueryParams(query: OrgRunQuery): URLSearchParams {
  const params = new URLSearchParams();
  const order = [
    'workspace', 'source', 'workflow', 'role', 'channel', 'thread', 'repo', 'pr', 'issue', 'trigger', 'status', 'outcome', 'flag',
    'requester', 'since', 'until', 'costMin', 'costMax', 'q', 'sort', 'limit', 'cursor',
  ] as const;
  for (const name of order) {
    const value = query[name];
    if (value !== undefined) params.set(name, String(value));
  }
  parseOrgRunQuery(params);
  return params;
}

export function parseOrgRunEventsQuery(params: URLSearchParams): OrgRunEventsQuery {
  const query: OrgRunEventsQuery = {};
  const type = params.get('type');
  if (type !== null) query.type = readString(REQUEST, type, 'type', { max: 64 });
  const after = params.get('after');
  if (after !== null) query.after = parseNonNegative(after, 'after');
  const limit = params.get('limit');
  if (limit !== null) query.limit = Math.min(Math.max(parseNonNegative(limit, 'limit'), 1), MAX_RUN_EVENTS_PAGE);
  return query;
}

export function parseOrgRunMessagesQuery(params: URLSearchParams): OrgRunMessagesQuery {
  const query: OrgRunMessagesQuery = {};
  const from = params.get('from');
  if (from !== null) query.from = parseNonNegative(from, 'from');
  const limit = params.get('limit');
  if (limit !== null) query.limit = Math.min(Math.max(parseNonNegative(limit, 'limit'), 1), MAX_RUN_MESSAGES_PAGE);
  return query;
}

export function parseOrgAuditQuery(params: URLSearchParams): OrgAuditQuery {
  const target = readString(REQUEST, params.get('target') ?? '', 'target', { max: 130 });
  if (target !== 'me' && !TARGET_RUN.test(target)) fail(REQUEST, 'target', 'must be me or run:<id>');
  const query: OrgAuditQuery = { target: target as OrgAuditQuery['target'] };
  const actor = params.get('actor');
  if (actor !== null) query.actor = actor === 'me' ? 'me' : readUserPrincipal(REQUEST, actor, 'actor');
  const since = params.get('since');
  if (since !== null) query.since = readIso(REQUEST, since, 'since');
  const limit = params.get('limit');
  if (limit !== null) query.limit = Math.min(Math.max(parseNonNegative(limit, 'limit'), 1), MAX_AUDIT_PAGE);
  const cursor = params.get('cursor');
  if (cursor !== null) query.cursor = readString(REQUEST, cursor, 'cursor', { max: MAX_CURSOR });
  return query;
}

/** The run id of an audit `target` of the form `run:<id>`, or undefined for `me`. */
export function auditTargetRunId(target: OrgAuditQuery['target']): string | undefined {
  return TARGET_RUN.exec(target)?.[1];
}

function parseNonNegative(value: string, name: string): number {
  const parsed = Number(value);
  if (!Number.isInteger(parsed) || parsed < 0) fail(REQUEST, name, 'must be a non-negative integer');
  return parsed;
}
