import { parseOrgReturnedMessages, type OrgSessionMessage } from './messages.js';
import { readUserPrincipal, type UserPrincipal } from './principals.js';
import {
  MAX_SHORT_TEXT,
  fail,
  readObject,
  readOptionalString,
  readString,
  type Reader,
} from './validate.js';

const RESPONSE: Reader = { code: 'invalid-response' };
const REQUEST: Reader = { code: 'invalid-request' };

export const DEFAULT_LEASE_TTL_SECONDS = 60;
export const MIN_LEASE_TTL_SECONDS = 1;
export const MAX_LEASE_TTL_SECONDS = 3600;
export const MAX_LEASE_STATE_REF = 512;

/** Error codes the lease routes add to the shared set. */
export const LEASE_ERROR_CODES = ['lease-held', 'lease-lost', 'lease-free'] as const;

/** One host drives a session at a time: a person's desktop or a cloud runner. */
export type OrgLeaseHolder = {
  /** An opaque host id the host picks, stable while the host runs (for example `desktop-3f2a` or `runner-17`). */
  host: string;
  principal: UserPrincipal;
};

export type OrgLease = {
  holder: OrgLeaseHolder;
  acquiredAt: string;
  expiresAt: string;
  /** How often the holder should heartbeat; every heartbeat renews `expiresAt` by the lease ttl. */
  heartbeatIntervalSeconds: number;
};

/** What a holder leaves behind when it releases at a safe point. `stateRef` is opaque to the organization. */
export type OrgLeaseCheckpoint = {
  /** Transcript messages the releasing host had written when it stopped. */
  messageCount: number;
  stateRef?: string;
  releasedBy: OrgLeaseHolder;
  at: string;
};

export type OrgHandoverRequest = {
  requestedBy: OrgLeaseHolder;
  at: string;
  note?: string;
};

/**
 * `GET /v1/sessions/:id/lease` and the answer to acquire, heartbeat and release.
 * `lease` is null when the session is free (never held, released or expired).
 */
export type OrgLeaseView = {
  lease: OrgLease | null;
  /** A pending handover request; present only while a lease is held. The holder should release at its next safe point. */
  handoverRequest?: OrgHandoverRequest;
  /** The checkpoint of the most recent release that left one; replaced by the next such release. */
  checkpoint?: OrgLeaseCheckpoint;
  /** Only on the answer to acquire by a desktop that takes the session from the cloud, and only with the `messages` feature: the messages still queued that the cloud executor had not run (Slack-origin ones are rejected instead). The inbox marks them `cancelled`; the desktop runs them itself. */
  returnedMessages?: OrgSessionMessage[];
};

/** Body of the 409 `lease-held` error: the usual `error` plus who holds the lease and until when. */
export type OrgLeaseHeld = {
  holder: OrgLeaseHolder;
  expiresAt: string;
};

/** Body of `POST /v1/sessions/:id/lease`. */
export type OrgLeaseAcquireRequest = {
  host: string;
  /** Lease lifetime without a heartbeat. Default 60, from 1 to 3600. */
  ttlSeconds?: number;
  /** Owner only: take a held lease. The previous holder sees 410 `lease-lost` on its next heartbeat. */
  force?: boolean;
};

/** Body of `POST /v1/sessions/:id/lease/heartbeat`. */
export type OrgLeaseHeartbeatRequest = { host: string };

/** Body of `POST /v1/sessions/:id/lease/release`. */
export type OrgLeaseReleaseRequest = {
  host: string;
  checkpoint?: { messageCount: number; stateRef?: string };
};

/** Body of `POST /v1/sessions/:id/lease/handover`. */
export type OrgLeaseHandoverRequest = { host: string; note?: string };

const HOST_PATTERN = /^[A-Za-z0-9][A-Za-z0-9._:-]{0,127}$/;
const ISO_PATTERN = /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(\.\d{1,9})?(Z|[+-]\d{2}:\d{2})$/;

export function isLeaseHostId(value: unknown): value is string {
  return typeof value === 'string' && HOST_PATTERN.test(value);
}

export function sameLeaseHolder(a: OrgLeaseHolder, b: OrgLeaseHolder): boolean {
  return a.host === b.host && a.principal === b.principal;
}

function readHost(reader: Reader, value: unknown, path: string): string {
  const host = readString(reader, value, path, { max: 128 });
  if (!HOST_PATTERN.test(host)) fail(reader, path, 'must be 1 to 128 letters, digits, dot, dash, colon or underscore');
  return host;
}

function readIso(reader: Reader, value: unknown, path: string): string {
  const text = readString(reader, value, path, { max: 40 });
  if (!ISO_PATTERN.test(text) || Number.isNaN(Date.parse(text))) fail(reader, path, 'must be an ISO 8601 timestamp');
  return text;
}

function readCount(reader: Reader, value: unknown, path: string, max: number): number {
  if (typeof value !== 'number' || !Number.isInteger(value) || value < 0 || value > max) {
    fail(reader, path, `must be an integer from 0 to ${max}`);
  }
  return value;
}

function readHolder(reader: Reader, value: unknown, path: string): OrgLeaseHolder {
  const root = readObject(reader, value, path);
  return { host: readHost(reader, root.host, `${path}.host`), principal: readUserPrincipal(reader, root.principal, `${path}.principal`) };
}

function readLease(reader: Reader, value: unknown, path: string): OrgLease {
  const root = readObject(reader, value, path);
  const lease: OrgLease = {
    holder: readHolder(reader, root.holder, `${path}.holder`),
    acquiredAt: readIso(reader, root.acquiredAt, `${path}.acquiredAt`),
    expiresAt: readIso(reader, root.expiresAt, `${path}.expiresAt`),
    heartbeatIntervalSeconds: readCount(reader, root.heartbeatIntervalSeconds, `${path}.heartbeatIntervalSeconds`, MAX_LEASE_TTL_SECONDS),
  };
  if (lease.heartbeatIntervalSeconds < 1) fail(reader, `${path}.heartbeatIntervalSeconds`, 'must be at least 1');
  return lease;
}

function readStateRef(reader: Reader, value: unknown, path: string): string | undefined {
  return readOptionalString(reader, value, path, { max: MAX_LEASE_STATE_REF });
}

function readCheckpointFields(reader: Reader, root: Record<string, unknown>, path: string): { messageCount: number; stateRef?: string } {
  const checkpoint: { messageCount: number; stateRef?: string } = {
    messageCount: readCount(reader, root.messageCount, `${path}.messageCount`, Number.MAX_SAFE_INTEGER),
  };
  const stateRef = readStateRef(reader, root.stateRef, `${path}.stateRef`);
  if (stateRef !== undefined) checkpoint.stateRef = stateRef;
  return checkpoint;
}

/* Responses: parsed by clients, invalid-response on failure. */

export function parseOrgLeaseView(value: unknown, path = 'leaseView'): OrgLeaseView {
  const root = readObject(RESPONSE, value, path);
  const view: OrgLeaseView = { lease: root.lease === null ? null : readLease(RESPONSE, root.lease, `${path}.lease`) };
  if (root.handoverRequest !== undefined && root.handoverRequest !== null) {
    const request = readObject(RESPONSE, root.handoverRequest, `${path}.handoverRequest`);
    const handover: OrgHandoverRequest = {
      requestedBy: readHolder(RESPONSE, request.requestedBy, `${path}.handoverRequest.requestedBy`),
      at: readIso(RESPONSE, request.at, `${path}.handoverRequest.at`),
    };
    const note = readOptionalString(RESPONSE, request.note, `${path}.handoverRequest.note`, { max: MAX_SHORT_TEXT });
    if (note !== undefined) handover.note = note;
    view.handoverRequest = handover;
  }
  if (root.checkpoint !== undefined && root.checkpoint !== null) {
    const checkpoint = readObject(RESPONSE, root.checkpoint, `${path}.checkpoint`);
    view.checkpoint = {
      ...readCheckpointFields(RESPONSE, checkpoint, `${path}.checkpoint`),
      releasedBy: readHolder(RESPONSE, checkpoint.releasedBy, `${path}.checkpoint.releasedBy`),
      at: readIso(RESPONSE, checkpoint.at, `${path}.checkpoint.at`),
    };
  }
  const returned = parseOrgReturnedMessages(root.returnedMessages, `${path}.returnedMessages`);
  if (returned !== undefined && returned.length > 0) view.returnedMessages = returned;
  return view;
}

/** Parses the body of a 409 `lease-held` answer. */
export function parseOrgLeaseHeld(value: unknown): OrgLeaseHeld {
  const root = readObject(RESPONSE, value, 'leaseHeld');
  return { holder: readHolder(RESPONSE, root.holder, 'leaseHeld.holder'), expiresAt: readIso(RESPONSE, root.expiresAt, 'leaseHeld.expiresAt') };
}

/* Requests: parsed by servers (and by the client before sending), invalid-request on failure. */

export function parseOrgLeaseAcquireRequest(value: unknown): OrgLeaseAcquireRequest {
  const root = readObject(REQUEST, value, 'lease');
  const request: OrgLeaseAcquireRequest = { host: readHost(REQUEST, root.host, 'lease.host') };
  if (root.ttlSeconds !== undefined && root.ttlSeconds !== null) {
    const ttl = readCount(REQUEST, root.ttlSeconds, 'lease.ttlSeconds', MAX_LEASE_TTL_SECONDS);
    if (ttl < MIN_LEASE_TTL_SECONDS) fail(REQUEST, 'lease.ttlSeconds', `must be at least ${MIN_LEASE_TTL_SECONDS}`);
    request.ttlSeconds = ttl;
  }
  if (root.force !== undefined && root.force !== null) {
    if (typeof root.force !== 'boolean') fail(REQUEST, 'lease.force', 'must be a boolean');
    request.force = root.force;
  }
  return request;
}

export function parseOrgLeaseHeartbeatRequest(value: unknown): OrgLeaseHeartbeatRequest {
  return { host: readHost(REQUEST, readObject(REQUEST, value, 'heartbeat').host, 'heartbeat.host') };
}

export function parseOrgLeaseReleaseRequest(value: unknown): OrgLeaseReleaseRequest {
  const root = readObject(REQUEST, value, 'release');
  const request: OrgLeaseReleaseRequest = { host: readHost(REQUEST, root.host, 'release.host') };
  if (root.checkpoint !== undefined && root.checkpoint !== null) {
    request.checkpoint = readCheckpointFields(REQUEST, readObject(REQUEST, root.checkpoint, 'release.checkpoint'), 'release.checkpoint');
  }
  return request;
}

export function parseOrgLeaseHandoverRequest(value: unknown): OrgLeaseHandoverRequest {
  const root = readObject(REQUEST, value, 'handover');
  const request: OrgLeaseHandoverRequest = { host: readHost(REQUEST, root.host, 'handover.host') };
  const note = readOptionalString(REQUEST, root.note, 'handover.note', { max: MAX_SHORT_TEXT });
  if (note !== undefined) request.note = note;
  return request;
}
