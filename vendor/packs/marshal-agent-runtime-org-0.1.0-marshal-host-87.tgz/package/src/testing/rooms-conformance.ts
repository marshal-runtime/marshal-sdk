import { randomBytes } from 'node:crypto';
import { isDeepStrictEqual } from 'node:util';
import type { UserPrincipal } from '../principals.js';
import {
  ROOM_ROUTES,
  ROOMS_PROTOCOL_VERSION,
  parseRoomChangePage,
  parseRoomEnvelope,
  parseRoomServerFrame,
  type RoomActor,
  type RoomChange,
  type RoomClientFrame,
  type RoomEnvelope,
  type RoomId,
  type RoomRecordKey,
  type RoomRole,
  type RoomServerFrame,
} from '../rooms/protocol.js';
import { replayRoomChanges } from '../rooms/reducer.js';
import { RoomTextReplica } from '../rooms/text.js';
import { MAX_ROOM_TEXT_UPDATE_BYTES, type RoomTextUpdate } from '../rooms/text-types.js';

/**
 * Transport-level conformance for a rooms service: a real socket and real HTTP against `apiBase` and `socketUrl`, so the
 * same cases check the in-memory provider and the deployed service. Hooks that only a test deployment can offer (losing
 * the bus, holding the drainer, expiring presence) are optional; cases that need a missing hook are skipped.
 */
export type RoomsConformanceContext = {
  apiBase: string;
  socketUrl: string;
  tokenFor(principal: UserPrincipal): string | Promise<string>;
  /** Three distinct members of the organization. `owner` creates the rooms of every case. */
  principals: { owner: UserPrincipal; peer: UserPrincipal; third: UserPrincipal };
  /** Workspace the cases create rooms in. Default `ws:conformance`. */
  workspaceId?: string;
  /** Makes the bus lose its state for every room (Redis failover, restart of the memory bus). Enables the epoch case. */
  loseBusState?(): Promise<void>;
  /** Stops (true) or restarts (false) the drainer, so changes stay above durable. */
  holdDurable?(hold: boolean): Promise<void> | void;
  /** Expires presence now; without it the presence case waits `presenceTtlMs` (skipped when that is over 20 s). */
  expirePresence?(): Promise<void>;
  presenceTtlMs?: number;
  /** Per wait. Default 5000 ms. */
  timeoutMs?: number;
  fetch?: typeof fetch;
  /** Default `globalThis.WebSocket` (Node 22+). */
  WebSocket?: new (url: string) => MinimalWebSocket;
};

export type MinimalWebSocket = {
  send(data: string): void;
  close(code?: number): void;
  addEventListener(type: 'message', listener: (event: { data: unknown }) => void): void;
  addEventListener(type: 'open' | 'close' | 'error', listener: (event: unknown) => void): void;
};

export type RoomsConformanceCase = {
  name: string;
  /** Hooks the case needs; a runner skips the case when the context lacks one. */
  needs?: ('loseBusState' | 'holdDurable' | 'presence')[];
  run(context: RoomsConformanceContext): Promise<void>;
};

export class RoomsConformanceFailure extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'RoomsConformanceFailure';
  }
}

function check(condition: unknown, message: string): asserts condition {
  if (!condition) throw new RoomsConformanceFailure(message);
}

const PERSON: RoomActor = { kind: 'person' };

/** A socket client for the conformance cases: every frame it gets is parsed and kept, and waits pick from them. */
export class RoomsTestClient {
  readonly frames: RoomServerFrame[] = [];
  closed = false;
  private readonly waiters = new Set<() => void>();
  private readonly taken = new Set<number>();

  private constructor(
    private readonly socket: MinimalWebSocket,
    private readonly timeoutMs: number,
  ) {
    socket.addEventListener('message', (event) => {
      this.frames.push(parseRoomServerFrame(JSON.parse(String(event.data))));
      for (const waiter of [...this.waiters]) waiter();
    });
    socket.addEventListener('close', () => {
      this.closed = true;
      for (const waiter of [...this.waiters]) waiter();
    });
  }

  static async connect(context: RoomsConformanceContext, principal: UserPrincipal, options: { client?: string; hello?: boolean } = {}): Promise<RoomsTestClient> {
    const Socket = context.WebSocket ?? (globalThis as unknown as { WebSocket: new (url: string) => MinimalWebSocket }).WebSocket;
    const socket = new Socket(context.socketUrl);
    await new Promise<void>((resolve, reject) => {
      socket.addEventListener('open', () => resolve());
      socket.addEventListener('error', () => reject(new RoomsConformanceFailure('socket did not open')));
    });
    const client = new RoomsTestClient(socket, context.timeoutMs ?? 5000);
    if (options.hello !== false) {
      client.send({ t: 'hello', v: ROOMS_PROTOCOL_VERSION, token: await context.tokenFor(principal), client: options.client ?? `cf-${randomBytes(4).toString('hex')}` });
      const welcome = await client.next((frame) => frame.t === 'welcome' || frame.t === 'error');
      check(welcome.t === 'welcome' && welcome.principal === principal, `hello as ${principal} must be welcomed as that principal`);
    }
    return client;
  }

  send(frame: RoomClientFrame | Record<string, unknown>): void {
    this.socket.send(JSON.stringify(frame));
  }

  close(): void {
    this.socket.close(1000);
  }

  /** The oldest matching frame not yet taken by another `next`, waiting for it. Concurrent waits each take their own frame. */
  async next<T extends RoomServerFrame = RoomServerFrame>(match: (frame: RoomServerFrame) => boolean, what = 'frame'): Promise<T> {
    const deadline = Date.now() + this.timeoutMs;
    for (;;) {
      for (let index = 0; index < this.frames.length; index += 1) {
        if (!this.taken.has(index) && match(this.frames[index]!)) {
          this.taken.add(index);
          return this.frames[index] as T;
        }
      }
      const left = deadline - Date.now();
      if (left <= 0) throw new RoomsConformanceFailure(`timed out waiting for ${what}; last frames ${this.frames.slice(-5).map((frame) => frame.t).join(', ')}`);
      if (this.closed) throw new RoomsConformanceFailure(`socket closed while waiting for ${what}`);
      let done: () => void = () => undefined;
      await new Promise<void>((resolve) => {
        const timer = setTimeout(() => done(), left);
        done = () => {
          clearTimeout(timer);
          resolve();
        };
        this.waiters.add(done);
      });
      this.waiters.delete(done);
    }
  }

  /** Waits until `predicate` holds over every frame received so far. */
  async until(predicate: (frames: RoomServerFrame[]) => boolean, what: string): Promise<void> {
    const deadline = Date.now() + this.timeoutMs;
    while (!predicate(this.frames)) {
      if (Date.now() > deadline) throw new RoomsConformanceFailure(`timed out waiting until ${what}`);
      await new Promise((resolve) => setTimeout(resolve, 10));
    }
  }

  /** Changes received for a room, from `changes` and `change` frames, in arrival order. */
  changes(room: RoomId): RoomChange[] {
    const result: RoomChange[] = [];
    for (const frame of this.frames) {
      if (frame.t === 'changes' && frame.room === room) result.push(...frame.changes);
      if (frame.t === 'change' && frame.room === room) result.push(frame.change);
    }
    return result;
  }

  async join(room: RoomId, have?: { epoch: string; seq: number }): Promise<{ t: 'joined'; room: RoomId; role: RoomRole; epoch: string; head: number; durable: number }> {
    this.send(have ? { t: 'join', room, have } : { t: 'join', room });
    const joined = await this.next((frame) => (frame.t === 'joined' || frame.t === 'error') && frame.room === room, `joined ${room}`);
    check(joined.t === 'joined', `join ${room} must succeed`);
    await this.next((frame) => frame.t === 'changes' && frame.room === room && !frame.more, `catch-up of ${room}`);
    return joined as never;
  }

  /** Sends a `set` and waits for its `ack` or `nack`. */
  async op(room: RoomId, record: RoomRecordKey, set: Record<string, unknown>, extra: { id?: string; ifSeq?: number; actor?: RoomActor; type?: string } = {}): Promise<RoomServerFrame & { t: 'ack' | 'nack' }> {
    const id = extra.id ?? newId();
    this.send({ t: 'op', room, id, record, type: extra.type ?? record.slice(0, record.indexOf(':')), op: 'set', set, actor: extra.actor ?? PERSON, ...(extra.ifSeq !== undefined ? { ifSeq: extra.ifSeq } : {}) });
    return this.next((frame) => (frame.t === 'ack' || frame.t === 'nack') && frame.room === room && frame.id === id, `ack of ${id}`);
  }
}

/** Sends a text edit (`op: set` with `text`) without waiting; returns its id. */
function sendText(client: RoomsTestClient, room: RoomId, record: RoomRecordKey, field: string, update: RoomTextUpdate, id = newId()): string {
  client.send({ t: 'op', room, id, record, type: record.slice(0, record.indexOf(':')), op: 'set', text: { [field]: update }, actor: PERSON });
  return id;
}

async function acked(client: RoomsTestClient, room: RoomId, id: string): Promise<RoomServerFrame & { t: 'ack' | 'nack' }> {
  return client.next((frame) => (frame.t === 'ack' || frame.t === 'nack') && frame.room === room && frame.id === id, `ack of ${id}`);
}

/** The text a fresh member gets for a record field, by replaying its catch-up with the shared reducer. */
async function textOfFreshReader(context: RoomsConformanceContext, room: RoomId, record: RoomRecordKey, field: string): Promise<string | undefined> {
  const reader = await RoomsTestClient.connect(context, context.principals.owner);
  try {
    await reader.join(room);
    return replayRoomChanges(reader.changes(room)).get(record)?.fields[field] as string | undefined;
  } finally {
    reader.close();
  }
}

/** Waits until the server's stored records (`GET …/records`, merged by the shared reducer) show `expected`. */
async function serverTextBecomes(context: RoomsConformanceContext, room: RoomId, record: RoomRecordKey, field: string, expected: string): Promise<void> {
  const deadline = Date.now() + (context.timeoutMs ?? 5000);
  let last: unknown;
  while (Date.now() < deadline) {
    const page = await http<{ records: { key: string; fields: Record<string, unknown> }[] }>(context, context.principals.owner, 'GET', ROOM_ROUTES.records(room));
    last = page.json?.records?.find((entry) => entry.key === record)?.fields[field];
    if (page.status === 200 && last === expected) return;
    await new Promise((resolve) => setTimeout(resolve, 20));
  }
  throw new RoomsConformanceFailure(`GET records must show the merged text ${JSON.stringify(expected)}, got ${JSON.stringify(last)}`);
}

function newId(): string {
  return `c-${randomBytes(8).toString('hex')}`;
}

async function http<T>(context: RoomsConformanceContext, principal: UserPrincipal, method: string, path: string, body?: unknown): Promise<{ status: number; json: T }> {
  const doFetch = context.fetch ?? fetch;
  const response = await doFetch(new URL(path, context.apiBase).toString(), {
    method,
    headers: { authorization: `Bearer ${await context.tokenFor(principal)}`, ...(body === undefined ? {} : { 'content-type': 'application/json' }) },
    ...(body === undefined ? {} : { body: JSON.stringify(body) }),
  });
  const text = await response.text();
  return { status: response.status, json: (text ? JSON.parse(text) : undefined) as T };
}

async function createRoom(context: RoomsConformanceContext, grants: Partial<Record<'peer' | 'third', Exclude<RoomRole, 'owner'>>> = {}): Promise<RoomEnvelope> {
  const id = `cf-${randomBytes(6).toString('hex')}`;
  const created = await http<unknown>(context, context.principals.owner, 'POST', ROOM_ROUTES.rooms, {
    id,
    workspaceId: context.workspaceId ?? 'ws:conformance',
    kind: '@marshal/conformance/board',
    schemaVersion: 1,
    title: 'Conformance',
  });
  check(created.status === 201, `create room must answer 201, got ${created.status}`);
  const room = parseRoomEnvelope(created.json);
  check(room.role === 'owner' && room.owner === context.principals.owner, 'the creator owns the room');
  const retry = await http<unknown>(context, context.principals.owner, 'POST', ROOM_ROUTES.rooms, { id, workspaceId: context.workspaceId ?? 'ws:conformance', kind: '@marshal/conformance/board', schemaVersion: 1, title: 'Conformance' });
  check(retry.status === 200 && parseRoomEnvelope(retry.json).id === id, 'a retried create answers 200 with the same room');
  for (const [who, role] of Object.entries(grants)) {
    const granted = await http(context, context.principals.owner, 'POST', ROOM_ROUTES.grants(id), { principal: context.principals[who as 'peer' | 'third'], role });
    check(granted.status === 200, `grant ${role} must answer 200, got ${granted.status}`);
  }
  return room;
}

function seqs(changes: RoomChange[]): number[] {
  return changes.map((change) => change.seq);
}

function strictlyIncreasing(values: number[]): boolean {
  return values.every((value, index) => index === 0 || value > values[index - 1]!);
}

export function roomsConformanceCases(): RoomsConformanceCase[] {
  return [
    {
      name: 'hello with an unknown token is refused with unauthorized and the socket closes',
      async run(context) {
        const client = await RoomsTestClient.connect(context, context.principals.owner, { hello: false });
        client.send({ t: 'hello', v: ROOMS_PROTOCOL_VERSION, token: 'not-a-token', client: 'cf-bad' });
        const error = await client.next((frame) => frame.t === 'error');
        check(error.t === 'error' && error.code === 'unauthorized', 'unknown token answers error unauthorized');
        await client.until(() => client.closed, 'the socket closed');
      },
    },
    {
      name: 'a frame before hello is refused with hello-required',
      async run(context) {
        const client = await RoomsTestClient.connect(context, context.principals.owner, { hello: false });
        client.send({ t: 'ping' });
        const error = await client.next((frame) => frame.t === 'error');
        check(error.t === 'error' && error.code === 'hello-required', 'ping before hello answers hello-required');
      },
    },
    {
      name: 'ping answers pong with the server clock',
      async run(context) {
        const client = await RoomsTestClient.connect(context, context.principals.owner);
        client.send({ t: 'ping' });
        const pong = await client.next((frame) => frame.t === 'pong', 'pong');
        check(pong.t === 'pong' && typeof pong.serverTime === 'string', 'pong must carry serverTime so clients can estimate their clock offset');
        client.close();
      },
    },
    {
      name: 'concurrent writers: every member sees every change once, in order, with no gaps',
      async run(context) {
        const room = await createRoom(context, { peer: 'collaborator', third: 'collaborator' });
        const clients = await Promise.all([context.principals.owner, context.principals.peer, context.principals.third].map((principal) => RoomsTestClient.connect(context, principal)));
        const joined = await Promise.all(clients.map((client) => client.join(room.id)));
        const start = joined[0]!.head;
        const perClient = 20;
        const acks = await Promise.all(
          clients.map((client, index) =>
            Promise.all(Array.from({ length: perClient }, (_, n) => client.op(room.id, `item:${index}-${n}`, { n, by: index }))),
          ),
        );
        const total = clients.length * perClient;
        for (const [index, client] of clients.entries()) {
          const own = acks[index]!;
          check(own.every((frame) => frame.t === 'ack'), 'every change is acknowledged');
          await client.until(() => client.changes(room.id).length >= total - perClient, `client ${index} got the others' changes`);
          const received = seqs(client.changes(room.id));
          check(strictlyIncreasing(received), `client ${index} receives changes in strictly increasing order`);
          const all = [...received, ...own.map((frame) => (frame as { seq: number }).seq)].sort((a, b) => a - b);
          check(isDeepStrictEqual(all, Array.from({ length: total }, (_, n) => start + n + 1)), `client ${index}: acks and changes cover every position once with no gap`);
        }
        for (const client of clients) client.close();
      },
    },
    {
      name: 'a retried change id is answered with its first position and delivered once',
      async run(context) {
        const room = await createRoom(context, { peer: 'collaborator' });
        const writer = await RoomsTestClient.connect(context, context.principals.owner);
        const reader = await RoomsTestClient.connect(context, context.principals.peer);
        await writer.join(room.id);
        await reader.join(room.id);
        const id = newId();
        writer.send({ t: 'op', room: room.id, id, record: 'item:a', type: 'item', op: 'set', set: { v: 1 }, actor: PERSON });
        writer.send({ t: 'op', room: room.id, id, record: 'item:a', type: 'item', op: 'set', set: { v: 1 }, actor: PERSON });
        const first = await writer.next((frame) => frame.t === 'ack' && frame.id === id);
        const second = await writer.next((frame) => frame.t === 'ack' && frame.id === id);
        const third = await writer.op(room.id, 'item:a', { v: 1 }, { id });
        check(first.t === 'ack' && second.t === 'ack' && third.t === 'ack', 'every send of the id is acknowledged');
        check(first.seq === second.seq && second.seq === third.seq, 'every retry gets the first position');
        await writer.op(room.id, 'item:b', { v: 2 });
        await reader.until(() => reader.changes(room.id).some((change) => change.record === 'item:b'), 'a later change arrived');
        check(reader.changes(room.id).filter((change) => change.id === id).length === 1, 'the retried change is delivered once');
        writer.close();
        reader.close();
      },
    },
    {
      name: 'ifSeq: a change is refused with conflict when the record moved after what the sender saw',
      async run(context) {
        const room = await createRoom(context, { peer: 'collaborator' });
        const a = await RoomsTestClient.connect(context, context.principals.owner);
        const b = await RoomsTestClient.connect(context, context.principals.peer);
        await a.join(room.id);
        await b.join(room.id);
        const created = await a.op(room.id, 'item:x', { v: 1 }, { ifSeq: 0 });
        check(created.t === 'ack', 'ifSeq 0 creates a new record');
        const seen = (created as { seq: number }).seq;
        const fromB = await b.op(room.id, 'item:x', { v: 2 }, { ifSeq: seen });
        check(fromB.t === 'ack', 'ifSeq equal to the last position is accepted');
        const stale = await a.op(room.id, 'item:x', { v: 3 }, { ifSeq: seen });
        check(stale.t === 'nack' && stale.code === 'conflict', 'ifSeq behind the last position answers conflict');
        const again = await a.op(room.id, 'item:x', { v: 4 }, { ifSeq: 0 });
        check(again.t === 'nack' && again.code === 'conflict', 'ifSeq 0 on an existing record answers conflict');
        await a.op(room.id, 'item:y', { v: 1 });
        await b.until(() => b.changes(room.id).some((change) => change.record === 'item:y'), 'a later change arrived');
        check(!b.changes(room.id).some((change) => change.set?.v === 3 || change.set?.v === 4), 'refused changes reach nobody');
        a.close();
        b.close();
      },
    },
    {
      name: 'roles: viewers cannot write, requests need driver, outsiders cannot join, only the owner grants',
      async run(context) {
        const room = await createRoom(context, { peer: 'viewer' });
        const missing = await RoomsTestClient.connect(context, context.principals.third);
        missing.send({ t: 'join', room: room.id });
        const forbidden = await missing.next((frame) => frame.t === 'error' && frame.room === room.id);
        check(forbidden.t === 'error' && forbidden.code === 'forbidden', 'a principal without a grant gets error forbidden');
        missing.send({ t: 'join', room: `${room.id}-missing` });
        const notFound = await missing.next((frame) => frame.t === 'error' && frame.room === `${room.id}-missing`);
        check(notFound.t === 'error' && notFound.code === 'not-found', 'an unknown room gets error not-found');
        const notJoined = await missing.op(room.id, 'item:a', { v: 1 });
        check(notJoined.t === 'nack' && notJoined.code === 'not-joined', 'an op on a room not joined answers not-joined');
        missing.close();

        const viewer = await RoomsTestClient.connect(context, context.principals.peer);
        const joined = await viewer.join(room.id);
        check(joined.role === 'viewer', 'joined carries the role');
        const write = await viewer.op(room.id, 'item:a', { v: 1 });
        check(write.t === 'nack' && write.code === 'forbidden', 'a viewer write answers forbidden');
        const grant = await http(context, context.principals.peer, 'POST', ROOM_ROUTES.grants(room.id), { principal: context.principals.third, role: 'viewer' });
        check(grant.status === 403, `a non-owner grant answers 403, got ${grant.status}`);

        await http(context, context.principals.owner, 'POST', ROOM_ROUTES.grants(room.id), { principal: context.principals.peer, role: 'collaborator' });
        const role = await viewer.next((frame) => frame.t === 'role' && frame.room === room.id);
        check(role.t === 'role' && role.role === 'collaborator', 'a role change is pushed');
        check((await viewer.op(room.id, 'item:a', { v: 1 })).t === 'ack', 'a collaborator writes records');
        const request = await viewer.op(room.id, 'request:r1', { to: 'agent:team', text: 'go', status: 'open' });
        check(request.t === 'nack' && request.code === 'forbidden', 'a collaborator cannot write a request');
        await http(context, context.principals.owner, 'POST', ROOM_ROUTES.grants(room.id), { principal: context.principals.peer, role: 'driver' });
        await viewer.next((frame) => frame.t === 'role' && frame.room === room.id && frame.role === 'driver');
        check((await viewer.op(room.id, 'request:r1', { to: 'agent:team', text: 'go', status: 'open' })).t === 'ack', 'a driver writes a request');
        viewer.close();
      },
    },
    {
      name: 'a change larger than the limit is refused with too-large',
      async run(context) {
        const room = await createRoom(context);
        const client = await RoomsTestClient.connect(context, context.principals.owner);
        await client.join(room.id);
        const big = await client.op(room.id, 'item:big', { v: 'x'.repeat(70 * 1024) });
        check(big.t === 'nack' && big.code === 'too-large', 'a 70 KiB change answers too-large');
        client.close();
      },
    },
    {
      name: 'join with have: a returning member gets exactly the changes after its position',
      async run(context) {
        const room = await createRoom(context, { peer: 'collaborator' });
        const writer = await RoomsTestClient.connect(context, context.principals.owner);
        await writer.join(room.id);
        for (let n = 0; n < 3; n += 1) await writer.op(room.id, `item:early-${n}`, { n });
        const away = await RoomsTestClient.connect(context, context.principals.peer);
        const first = await away.join(room.id);
        check(away.changes(room.id).length === 3, 'a join without have gets the whole history');
        const position = { epoch: first.epoch, seq: first.head };
        away.close();
        const later: number[] = [];
        for (let n = 0; n < 5; n += 1) later.push(((await writer.op(room.id, `item:late-${n}`, { n })) as { seq: number }).seq);
        const back = await RoomsTestClient.connect(context, context.principals.peer);
        const rejoined = await back.join(room.id, position);
        check(rejoined.epoch === position.epoch, 'same epoch');
        check(!back.frames.some((frame) => frame.t === 'reset'), 'no reset in the same epoch');
        check(isDeepStrictEqual(seqs(back.changes(room.id)), later), 'exactly the changes after have, in order');
        check(rejoined.head === later.at(-1), 'joined.head is the last position');
        writer.close();
        back.close();
      },
    },
    {
      name: 'durable is never ahead of what a fresh reader gets',
      async run(context) {
        const room = await createRoom(context, { peer: 'viewer' });
        const writer = await RoomsTestClient.connect(context, context.principals.owner);
        await writer.join(room.id);
        let checked = 0;
        for (let round = 0; round < 4; round += 1) {
          await Promise.all(Array.from({ length: 10 }, (_, n) => writer.op(room.id, `item:${round}-${n}`, { n })));
          const durable = await writer.next((frame) => frame.t === 'durable' && frame.room === room.id && frame.through >= (round + 1) * 10, 'durable for the round');
          const through = (durable as { through: number }).through;
          const fresh = await RoomsTestClient.connect(context, context.principals.peer);
          await fresh.join(room.id);
          const got = new Set(seqs(fresh.changes(room.id)));
          for (let seq = 1; seq <= through; seq += 1) check(got.has(seq), `a fresh joiner has position ${seq} at or below durable ${through}`);
          fresh.close();
          const page = parseRoomChangePage((await http(context, context.principals.peer, 'GET', `${ROOM_ROUTES.changes(room.id)}?after=0&limit=500`)).json);
          check(page.changes.length >= through && page.changes.every((change) => change.seq <= page.durable), 'history over HTTP covers durable and never exceeds it');
          checked += 1;
        }
        check(checked === 4, 'every round checked');
        writer.close();
      },
    },
    {
      name: 'presence reaches the others and expires with left',
      needs: ['presence'],
      async run(context) {
        const room = await createRoom(context, { peer: 'viewer' });
        const a = await RoomsTestClient.connect(context, context.principals.owner, { client: 'cf-presence-a' });
        const b = await RoomsTestClient.connect(context, context.principals.peer);
        await a.join(room.id);
        await b.join(room.id);
        const actor: RoomActor = { kind: 'agent', host: 'desktop', session: 's-1', runtime: 'claude' };
        b.send({ t: 'presence', room: room.id, actor: PERSON, state: { viewing: 'item:a' } });
        a.send({ t: 'presence', room: room.id, actor, state: { step: 'drafting' } });
        const seen = await b.next((frame) => frame.t === 'presence' && frame.room === room.id);
        check(seen.t === 'presence' && seen.principal === context.principals.owner && seen.client === 'cf-presence-a', 'presence names principal and client');
        check(isDeepStrictEqual(seen.actor, actor) && isDeepStrictEqual(seen.state, { step: 'drafting' }), 'presence carries actor and state');
        check(!b.frames.some((frame) => frame.t === 'presence' && frame.principal === context.principals.peer), 'nobody gets their own presence back');
        if (context.expirePresence) await context.expirePresence();
        else await new Promise((resolve) => setTimeout(resolve, (context.presenceTtlMs ?? 15_000) + 1000));
        const left = await b.next((frame) => frame.t === 'left' && frame.room === room.id && frame.principal === context.principals.owner, 'left');
        check(left.t === 'left' && left.client === 'cf-presence-a', 'left names the client');
        a.close();
        b.close();
      },
    },
    {
      name: 'revoke: a removed member is told, stops receiving, and cannot write or rejoin',
      async run(context) {
        const room = await createRoom(context, { peer: 'collaborator' });
        const owner = await RoomsTestClient.connect(context, context.principals.owner);
        const peer = await RoomsTestClient.connect(context, context.principals.peer);
        await owner.join(room.id);
        await peer.join(room.id);
        const revoked = await http(context, context.principals.owner, 'DELETE', ROOM_ROUTES.grant(room.id, context.principals.peer));
        check(revoked.status === 200, `revoke answers 200, got ${revoked.status}`);
        await peer.next((frame) => frame.t === 'revoked' && frame.room === room.id, 'revoked');
        const write = await peer.op(room.id, 'item:after', { v: 1 });
        check(write.t === 'nack' && (write.code === 'not-joined' || write.code === 'forbidden'), 'a write after revoke is refused');
        await owner.op(room.id, 'item:secret', { v: 2 });
        await owner.op(room.id, 'item:secret-2', { v: 3 });
        await new Promise((resolve) => setTimeout(resolve, 200));
        check(!peer.changes(room.id).some((change) => change.record.startsWith('item:secret')), 'nothing after revoke reaches the removed member');
        peer.send({ t: 'join', room: room.id });
        const again = await peer.next((frame) => frame.t === 'error' && frame.room === room.id);
        check(again.t === 'error' && again.code === 'forbidden', 'a rejoin after revoke is forbidden');
        owner.close();
        peer.close();
      },
    },
    {
      name: 'text: two writers interleaving in one field converge on every member and on the server, keeping both',
      async run(context) {
        const room = await createRoom(context, { peer: 'collaborator' });
        const record = 'note:t1' as RoomRecordKey;
        const owner = await RoomsTestClient.connect(context, context.principals.owner);
        const peer = await RoomsTestClient.connect(context, context.principals.peer);
        await owner.join(room.id);
        await peer.join(room.id);
        const ownerText = new RoomTextReplica({ record, field: 'body' });
        const peerText = new RoomTextReplica({ record, field: 'body' });
        const [base] = ownerText.splice(0, 0, '[]');
        check((await acked(owner, room.id, sendText(owner, room.id, record, 'body', base!))).t === 'ack', 'the first text edit is acked');
        await peer.next((frame) => frame.t === 'change' && frame.room === room.id, 'the first text edit');
        peerText.receive(base!);
        const sent: [RoomsTestClient, string][] = [];
        for (let round = 0; round < 10; round += 1) {
          for (const update of ownerText.splice(1, 0, 'a')) sent.push([owner, sendText(owner, room.id, record, 'body', update)]);
          for (const update of peerText.splice(peerText.value().length - 1, 0, 'b')) sent.push([peer, sendText(peer, room.id, record, 'body', update)]);
        }
        for (const [client, id] of sent) check((await acked(client, room.id, id)).t === 'ack', 'every interleaved text edit is acked');
        await owner.until((frames) => frames.filter((frame) => frame.t === 'change').length >= 10, 'the peer edits reached the owner');
        await peer.until((frames) => frames.filter((frame) => frame.t === 'change').length >= 11, 'the owner edits reached the peer');
        for (const change of owner.changes(room.id)) if (change.text?.body) ownerText.receive(change.text.body);
        for (const change of peer.changes(room.id)) if (change.text?.body) peerText.receive(change.text.body);
        const expected = ownerText.value();
        check(peerText.value() === expected, 'both writers hold the same text');
        check([...expected].filter((char) => char === 'a').length === 10 && [...expected].filter((char) => char === 'b').length === 10, 'every character of both writers is kept');
        check((await textOfFreshReader(context, room.id, record, 'body')) === expected, 'a fresh member replays to the same text');
        await serverTextBecomes(context, room.id, record, 'body', expected);
        owner.close();
        peer.close();
      },
    },
    {
      name: 'text: a writer who was offline rejoins with have, sends its outbox, and both edits are kept',
      async run(context) {
        const room = await createRoom(context, { peer: 'collaborator' });
        const record = 'note:t2' as RoomRecordKey;
        const owner = await RoomsTestClient.connect(context, context.principals.owner);
        await owner.join(room.id);
        const ownerText = new RoomTextReplica({ record, field: 'body' });
        const [base] = ownerText.splice(0, 0, 'draft');
        const baseAck = await acked(owner, room.id, sendText(owner, room.id, record, 'body', base!));
        check(baseAck.t === 'ack', 'the base text is acked');
        const peerText = new RoomTextReplica({ record, field: 'body' });
        peerText.receive(base!);
        const outbox = peerText.splice(5, 0, ' (peer offline)');
        for (const update of ownerText.splice(0, 0, 'Owner: ')) check((await acked(owner, room.id, sendText(owner, room.id, record, 'body', update))).t === 'ack', 'the owner edit is acked');
        const peer = await RoomsTestClient.connect(context, context.principals.peer);
        await peer.join(room.id, { epoch: baseAck.t === 'ack' ? baseAck.epoch : '', seq: baseAck.t === 'ack' ? baseAck.seq : 0 });
        for (const change of peer.changes(room.id)) if (change.text?.body) peerText.receive(change.text.body);
        for (const update of outbox) check((await acked(peer, room.id, sendText(peer, room.id, record, 'body', update))).t === 'ack', 'the outbox edit is acked');
        await owner.until((frames) => frames.some((frame) => frame.t === 'change' && frame.change.author === context.principals.peer), 'the outbox reached the owner');
        for (const change of owner.changes(room.id)) if (change.text?.body) ownerText.receive(change.text.body);
        check(ownerText.value() === 'Owner: draft (peer offline)' && peerText.value() === ownerText.value(), `both edits are kept, got ${JSON.stringify(ownerText.value())}`);
        await serverTextBecomes(context, room.id, record, 'body', ownerText.value());
        owner.close();
        peer.close();
      },
    },
    {
      name: 'text: the same text update retried with its id is ordered once',
      async run(context) {
        const room = await createRoom(context);
        const record = 'note:t3' as RoomRecordKey;
        const owner = await RoomsTestClient.connect(context, context.principals.owner);
        await owner.join(room.id);
        const [update] = new RoomTextReplica({ record, field: 'body' }).splice(0, 0, 'once');
        const id = newId();
        const first = await acked(owner, room.id, sendText(owner, room.id, record, 'body', update!, id));
        const again = await acked(owner, room.id, sendText(owner, room.id, record, 'body', update!, id));
        check(first.t === 'ack' && again.t === 'ack' && first.seq === again.seq, 'the retry is answered with the first position');
        const reader = await RoomsTestClient.connect(context, context.principals.owner);
        await reader.join(room.id);
        check(reader.changes(room.id).filter((change) => change.id === id).length === 1, 'the retried text change is stored once');
        check(replayRoomChanges(reader.changes(room.id)).get(record)?.fields.body === 'once', 'the text reads once');
        reader.close();
        owner.close();
      },
    },
    {
      name: 'text: a viewer cannot write text',
      async run(context) {
        const room = await createRoom(context, { peer: 'viewer' });
        const peer = await RoomsTestClient.connect(context, context.principals.peer);
        await peer.join(room.id);
        const record = 'note:t4' as RoomRecordKey;
        const [update] = new RoomTextReplica({ record, field: 'body' }).splice(0, 0, 'nope');
        const answer = await acked(peer, room.id, sendText(peer, room.id, record, 'body', update!));
        check(answer.t === 'nack' && answer.code === 'forbidden', 'a viewer text edit answers forbidden');
        peer.close();
      },
    },
    {
      name: 'text: an update over the text update limit is refused with too-large',
      async run(context) {
        const room = await createRoom(context);
        const owner = await RoomsTestClient.connect(context, context.principals.owner);
        await owner.join(room.id);
        const answer = await acked(owner, room.id, sendText(owner, room.id, 'note:t5' as RoomRecordKey, 'body', { gen: 0, update: 'A'.repeat(MAX_ROOM_TEXT_UPDATE_BYTES + 4) }));
        check(answer.t === 'nack' && answer.code === 'too-large', 'an oversized text update answers too-large');
        owner.close();
      },
    },
    {
      name: 'epoch change: members are reset, authors resend, and nothing a desktop held is lost',
      needs: ['loseBusState'],
      async run(context) {
        const room = await createRoom(context, { peer: 'collaborator' });
        const author = await RoomsTestClient.connect(context, context.principals.owner);
        const other = await RoomsTestClient.connect(context, context.principals.peer);
        const first = await author.join(room.id);
        await other.join(room.id);
        const stored = await author.op(room.id, 'item:stored', { v: 1 });
        await author.next((frame) => frame.t === 'durable' && frame.room === room.id && frame.through >= (stored as { seq: number }).seq, 'durable');
        await context.holdDurable?.(true);
        const outbox: { id: string; record: RoomRecordKey; set: Record<string, unknown> }[] = [
          { id: newId(), record: 'item:held-1', set: { v: 2 } },
          { id: newId(), record: 'item:held-2', set: { v: 3 } },
        ];
        for (const entry of outbox) check((await author.op(room.id, entry.record, entry.set, { id: entry.id })).t === 'ack', 'held change acknowledged');
        await other.until(() => other.changes(room.id).length >= 3, 'the other member saw the held changes');
        await context.loseBusState!();
        await context.holdDurable?.(false);
        const reset = await author.next((frame) => frame.t === 'reset' && frame.room === room.id, 'reset to the author');
        const otherReset = await other.next((frame) => frame.t === 'reset' && frame.room === room.id, 'reset to the other member');
        check(reset.t === 'reset' && reset.epoch !== first.epoch, 'reset names a new epoch');
        check(otherReset.t === 'reset' && otherReset.epoch === reset.epoch, 'every member gets the same new epoch');
        await author.next((frame) => frame.t === 'joined' && frame.room === room.id && frame.epoch === reset.epoch, 'joined in the new epoch');
        const durable = reset.durable;
        for (const entry of outbox) {
          const ack = await author.op(room.id, entry.record, entry.set, { id: entry.id });
          check(ack.t === 'ack' && ack.epoch === reset.epoch, 'a resent change is acknowledged in the new epoch');
          check(ack.seq > durable || context.holdDurable === undefined, 'a resent change that was not stored gets a new position above durable');
        }
        await other.until(
          () => outbox.every((entry) => other.frames.some((frame) => frame.t === 'change' && frame.change.id === entry.id && frame.change.epoch === reset.epoch) || context.holdDurable === undefined),
          'the other member got the resent changes in the new epoch',
        );
        const stale = await RoomsTestClient.connect(context, context.principals.peer);
        stale.send({ t: 'join', room: room.id, have: { epoch: first.epoch, seq: first.head + 3 } });
        const staleReset = await stale.next((frame) => frame.t === 'reset' && frame.room === room.id, 'reset on a join with an old epoch');
        check(staleReset.t === 'reset' && staleReset.epoch === reset.epoch, 'a join with an old epoch is reset first');
        await stale.next((frame) => frame.t === 'joined' && frame.room === room.id, 'joined after reset');
        stale.close();
        const last = await author.op(room.id, 'item:after', { v: 4 });
        await author.next((frame) => frame.t === 'durable' && frame.room === room.id && frame.epoch === reset.epoch && frame.through >= (last as { seq: number }).seq, 'durable in the new epoch');
        const fresh = await RoomsTestClient.connect(context, context.principals.peer);
        await fresh.join(room.id);
        const changes = fresh.changes(room.id);
        for (const entry of outbox) check(changes.filter((change) => change.id === entry.id).length === 1, `${entry.record} is stored exactly once`);
        const records = replayRoomChanges(changes);
        check(records.get('item:held-1')?.fields.v === 2 && records.get('item:held-2')?.fields.v === 3 && records.get('item:stored')?.fields.v === 1, 'every change is in the replayed records');
        author.close();
        other.close();
        fresh.close();
      },
    },
  ];
}

/** Runs every case the context supports; returns the names it skipped. Throws on the first failure. */
export async function runRoomsConformance(context: RoomsConformanceContext, cases = roomsConformanceCases()): Promise<{ passed: string[]; skipped: string[] }> {
  const passed: string[] = [];
  const skipped: string[] = [];
  for (const entry of cases) {
    const missing = (entry.needs ?? []).some((need) =>
      need === 'loseBusState' ? !context.loseBusState : need === 'holdDurable' ? !context.holdDurable : need === 'presence' ? !context.expirePresence && (context.presenceTtlMs ?? 15_000) > 20_000 : false,
    );
    if (missing) {
      skipped.push(entry.name);
      continue;
    }
    try {
      await entry.run(context);
    } catch (error) {
      if (error instanceof Error) error.message = `${entry.name}: ${error.message}`;
      throw error;
    }
    passed.push(entry.name);
  }
  return { passed, skipped };
}
