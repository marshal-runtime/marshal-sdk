import { createHash } from 'node:crypto';
import { ENVELOPE_CONTENT_TYPE, ENVELOPE_HEADERS, sha256Hex } from '../cloud.js';
import type { OrgFeature } from '../discovery.js';
import type { OrgWorkspaceId } from '../model.js';
import type { UserPrincipal } from '../principals.js';
import {
  DEFAULT_RUN_PAGE,
  MAX_GREP_EXCERPT,
  MAX_GREP_HITS,
  MAX_RUN_MESSAGES_PAGE,
  auditTargetRunId,
  isRunId,
  isRunSessionName,
  parseOrgAuditQuery,
  parseOrgRunEventsQuery,
  parseOrgRunGrepRequest,
  parseOrgRunMessagesQuery,
  parseOrgRunQuery,
  type OrgAuditAction,
  type OrgAuditBasis,
  type OrgAuditRow,
  type OrgRunCounts,
  type OrgRunDetail,
  type OrgRunEvent,
  type OrgRunGrepHit,
  type OrgRunMessage,
  type OrgRunQuery,
  type OrgRunRow,
  type OrgRunSessionDetail,
  type OrgRunWorkspace,
} from '../runs.js';
import { MAX_TRANSCRIPT_PAGE_BYTES, utf8Length } from '../sessions.js';
import { OrgContractError } from '../validate.js';

const MAX_BODY_BYTES = 64 * 1024;
const MAX_ENVELOPE_RESPONSE = 24 * 1024 * 1024;

/** One run of the fake index. `dm` marks a run from a direct conversation with the bot: only its requester can read it. */
export type InMemoryRun = {
  row: OrgRunRow;
  dm?: boolean;
  error?: string;
  counts?: Partial<OrgRunCounts>;
  events?: OrgRunEvent[];
  sessions: Array<{ detail: OrgRunSessionDetail; messages?: OrgRunMessage[]; envelope?: Uint8Array; subagents?: Record<string, Uint8Array> }>;
};

export type RunsHandlerDeps = {
  features: ReadonlySet<OrgFeature>;
  now(): number;
  runs: InMemoryRun[];
  /** The workspace-level read right: who may read the runs of each workspace. */
  auditors: Partial<Record<OrgWorkspaceId, UserPrincipal[]>>;
  json(status: number, body: unknown): Response;
  error(status: number, code: string): Response;
};

const RUN_PATH = /^\/v1\/runs\/([^/]+)$/;
const EVENTS_PATH = /^\/v1\/runs\/([^/]+)\/events$/;
const MESSAGES_PATH = /^\/v1\/runs\/([^/]+)\/sessions\/([^/]+)\/messages$/;
const ENVELOPE_PATH = /^\/v1\/runs\/([^/]+)\/sessions\/([^/]+)\/envelope$/;
const SUBAGENTS_PATH = /^\/v1\/runs\/([^/]+)\/sessions\/([^/]+)\/subagents$/;
const SUBAGENT_PATH = /^\/v1\/runs\/([^/]+)\/sessions\/([^/]+)\/subagents\/([^/]+)$/;

/** The run index and audit routes of the in-memory provider, with the same authorization the organization's server applies. */
export function createRunsHandler(deps: RunsHandlerDeps) {
  const { json, error } = deps;
  const audit: OrgAuditRow[] = [];
  const iso = () => new Date(deps.now()).toISOString();

  const basisOf = (run: InMemoryRun, caller: UserPrincipal): OrgAuditBasis | undefined => {
    if (run.row.requester === caller) return 'requester';
    const workspace = run.row.workspace;
    if (workspace === 'unassigned' || run.dm) return undefined;
    return deps.auditors[workspace]?.includes(caller) ? 'auditor' : undefined;
  };

  const record = (caller: UserPrincipal, run: InMemoryRun, action: OrgAuditAction, extra: Partial<OrgAuditRow> = {}) => {
    if (basisOf(run, caller) !== 'auditor') return;
    audit.push({ at: iso(), actor: caller, basis: 'auditor', action, workspace: run.row.workspace, runId: run.row.id, ...extra });
  };

  const find = (id: string, caller: UserPrincipal): { run: InMemoryRun; basis: OrgAuditBasis } | undefined => {
    if (!isRunId(id)) return undefined;
    const run = deps.runs.find((candidate) => candidate.row.id === id);
    const basis = run ? basisOf(run, caller) : undefined;
    return run && basis ? { run, basis } : undefined;
  };

  const readOffset = (cursor: string | undefined): number => {
    if (cursor === undefined) return 0;
    if (!/^\d{1,9}$/.test(cursor)) throw new OrgContractError('invalid-request', 'cursor', 'is not a cursor this provider issued');
    return Number(cursor);
  };

  function matches(row: OrgRunRow, query: OrgRunQuery, caller: UserPrincipal): boolean {
    if (query.workspace !== undefined && row.workspace !== query.workspace) return false;
    if (query.source !== undefined && row.source !== query.source) return false;
    if (query.workflow !== undefined && row.workflow !== query.workflow) return false;
    if (query.role !== undefined && !row.sessions.some((session) => session.role === query.role)) return false;
    if (query.status !== undefined && row.status !== query.status) return false;
    if (query.flag !== undefined && !row.flags.includes(query.flag)) return false;
    if (query.outcome === 'dry-run' && !row.dryRun) return false;
    if (query.outcome === 'live' && row.dryRun) return false;
    if (query.outcome === 'refused' && !row.flags.includes('refused')) return false;
    if (query.requester !== undefined && row.requester !== (query.requester === 'me' ? caller : query.requester)) return false;
    if (query.since !== undefined && Date.parse(row.startedAt) < Date.parse(query.since)) return false;
    if (query.until !== undefined && Date.parse(row.startedAt) > Date.parse(query.until)) return false;
    if (query.costMin !== undefined && row.costUsd < query.costMin) return false;
    if (query.costMax !== undefined && row.costUsd > query.costMax) return false;
    if (query.channel !== undefined && !row.links.some((link) => link.kind === 'slack' && link.key.startsWith(`${query.channel}:`))) return false;
    if (query.thread !== undefined && !row.links.some((link) => link.kind === 'slack' && link.key.endsWith(`:${query.thread}`))) return false;
    if (query.repo !== undefined && !row.links.some((link) => link.kind === 'pr' && link.key.startsWith(`${query.repo}#`))) return false;
    if (query.pr !== undefined && !row.links.some((link) => link.kind === 'pr' && link.key.endsWith(`#${query.pr}`))) return false;
    if (query.issue !== undefined && !row.links.some((link) => (link.kind === 'datadog' || link.kind === 'linear') && link.key === query.issue)) return false;
    if (query.q !== undefined && !`${row.title} ${row.workflow}`.toLowerCase().includes(query.q.toLowerCase())) return false;
    return true;
  }

  function list(caller: UserPrincipal, url: URL): Response {
    const query = parseOrgRunQuery(url.searchParams);
    const visible = deps.runs.flatMap((run) => {
      const basis = basisOf(run, caller);
      return basis && matches(run.row, query, caller) ? [{ run, basis }] : [];
    });
    const sort = query.sort ?? 'started';
    visible.sort((a, b) =>
      sort === 'cost'
        ? b.run.row.costUsd - a.run.row.costUsd
        : sort === 'toolErrors'
          ? b.run.row.toolErrors - a.run.row.toolErrors
          : Date.parse(b.run.row.startedAt) - Date.parse(a.run.row.startedAt),
    );
    const offset = readOffset(query.cursor);
    const limit = query.limit ?? DEFAULT_RUN_PAGE;
    const page = visible.slice(offset, offset + limit);
    const byWorkspace = new Map<OrgRunWorkspace, number>();
    for (const entry of page) {
      if (entry.basis === 'auditor') byWorkspace.set(entry.run.row.workspace, (byWorkspace.get(entry.run.row.workspace) ?? 0) + 1);
    }
    const filterHash = createHash('sha256').update(url.searchParams.toString()).digest('hex').slice(0, 32);
    for (const [workspace, resultCount] of byWorkspace) {
      audit.push({ at: iso(), actor: caller, basis: 'auditor', action: 'list', workspace, filterHash, resultCount });
    }
    const body: Record<string, unknown> = { runs: page.map((entry) => entry.run.row), indexedThrough: iso() };
    if (offset + limit < visible.length) body.nextCursor = String(offset + limit);
    return json(200, body);
  }

  function detail(run: InMemoryRun): OrgRunDetail {
    const counts: OrgRunCounts = {
      events: run.events?.length ?? 0,
      toolCalls: run.sessions.reduce((sum, session) => sum + session.detail.toolCalls, 0),
      toolErrors: run.row.toolErrors,
      evidenceCalls: 0,
      publications: 0,
      failedPublications: 0,
      ...run.counts,
    };
    return { run: run.row, counts, ...(run.error === undefined ? {} : { error: run.error }), sessions: run.sessions.map((session) => session.detail) };
  }

  function events(run: InMemoryRun, url: URL): Response {
    const query = parseOrgRunEventsQuery(url.searchParams);
    const all = (run.events ?? []).filter((event) => query.type === undefined || event.type === query.type);
    const after = query.after ?? 0;
    const limit = query.limit ?? 100;
    const page = all.filter((event) => event.n > after).slice(0, limit);
    const last = page[page.length - 1];
    const body: Record<string, unknown> = { events: page, total: all.length };
    if (last && all.some((event) => event.n > last.n)) body.nextCursor = String(last.n);
    return json(200, body);
  }

  function messages(run: InMemoryRun, sessionName: string, url: URL): Response {
    const session = isRunSessionName(sessionName) ? run.sessions.find((candidate) => candidate.detail.session === sessionName) : undefined;
    if (!session) return error(404, 'not-found');
    if (!session.detail.hasTranscript || !session.messages) return error(409, 'transcript-unavailable');
    const query = parseOrgRunMessagesQuery(url.searchParams);
    const from = query.from ?? 0;
    const limit = query.limit ?? 100;
    const page: OrgRunMessage[] = [];
    let bytes = 0;
    for (const message of session.messages.slice(from, from + Math.min(limit, MAX_RUN_MESSAGES_PAGE))) {
      const size = utf8Length(message.text ?? '') + utf8Length(message.tool?.input ?? '');
      if (page.length > 0 && bytes + size > MAX_TRANSCRIPT_PAGE_BYTES) break;
      bytes += size;
      page.push(message);
    }
    const body: Record<string, unknown> = { messages: page, total: session.messages.length };
    if (from + page.length < session.messages.length) body.nextFrom = from + page.length;
    return json(200, body);
  }

  function envelopeResponse(bytes: Uint8Array, messageCount: number): Response {
    if (bytes.length > MAX_ENVELOPE_RESPONSE) return error(413, 'envelope-too-large');
    return new Response(bytes as never, {
      status: 200,
      headers: {
        'content-type': ENVELOPE_CONTENT_TYPE,
        'content-length': String(bytes.length),
        [ENVELOPE_HEADERS.format]: 'claude-jsonl',
        [ENVELOPE_HEADERS.sha256]: sha256Hex(bytes),
        [ENVELOPE_HEADERS.messages]: String(messageCount),
      },
    });
  }

  function envelope(run: InMemoryRun, sessionName: string, agent?: string): Response {
    const session = isRunSessionName(sessionName) ? run.sessions.find((candidate) => candidate.detail.session === sessionName) : undefined;
    if (!session) return error(404, 'not-found');
    if (!session.envelope) return error(409, 'no-envelope');
    if (agent === undefined) return envelopeResponse(session.envelope, session.messages?.length ?? 0);
    const bytes = Object.hasOwn(session.subagents ?? {}, agent) ? session.subagents![agent] : undefined;
    return bytes ? envelopeResponse(bytes, 0) : error(404, 'not-found');
  }

  function subagents(run: InMemoryRun, sessionName: string): Response {
    const session = isRunSessionName(sessionName) ? run.sessions.find((candidate) => candidate.detail.session === sessionName) : undefined;
    if (!session) return error(404, 'not-found');
    if (!session.envelope) return error(409, 'no-envelope');
    return json(200, { agents: Object.keys(session.subagents ?? {}) });
  }

  async function grep(caller: UserPrincipal, init: RequestInit | undefined): Promise<Response> {
    const text = typeof init?.body === 'string' ? init.body : '';
    if (utf8Length(text) > MAX_BODY_BYTES) return error(413, 'too-large');
    let parsed: unknown;
    try {
      parsed = JSON.parse(text);
    } catch {
      throw new OrgContractError('invalid-request', 'body', 'must be JSON');
    }
    const request = parseOrgRunGrepRequest(parsed);
    const needle = request.pattern.toLowerCase();
    const filterHash = createHash('sha256').update(request.pattern).digest('hex').slice(0, 32);
    const hits: OrgRunGrepHit[] = [];
    let searched = 0;
    let truncated = false;
    for (const id of request.runIds) {
      const found = find(id, caller);
      if (!found) continue;
      searched += 1;
      let inRun = 0;
      for (const session of found.run.sessions) {
        for (const message of session.messages ?? []) {
          if (message.withheld || message.text === undefined || !message.text.toLowerCase().includes(needle)) continue;
          if (hits.length >= MAX_GREP_HITS) {
            truncated = true;
            continue;
          }
          const at = message.text.toLowerCase().indexOf(needle);
          const start = Math.max(0, at - 60);
          hits.push({ runId: id, session: session.detail.session, n: message.n, role: message.role, excerpt: message.text.slice(start, start + MAX_GREP_EXCERPT) });
          inRun += 1;
        }
      }
      record(caller, found.run, 'grep', { filterHash, resultCount: inRun });
    }
    return json(200, { hits, searched, truncated });
  }

  function readAudit(caller: UserPrincipal, url: URL): Response {
    const query = parseOrgAuditQuery(url.searchParams);
    const runId = auditTargetRunId(query.target);
    const aboutOwnRuns = (row: OrgAuditRow) => row.runId !== undefined && deps.runs.find((run) => run.row.id === row.runId)?.row.requester === caller;
    let rows: OrgAuditRow[];
    if (runId !== undefined) {
      const found = find(runId, caller);
      if (!found) return error(404, 'not-found');
      rows = audit.filter((row) => row.runId === runId && (found.basis === 'requester' || row.actor === caller));
    } else {
      rows = audit.filter((row) => aboutOwnRuns(row) || row.actor === caller);
    }
    if (query.actor !== undefined) {
      const actor = query.actor === 'me' ? caller : query.actor;
      rows = rows.filter((row) => row.actor === actor);
    }
    if (query.since !== undefined) rows = rows.filter((row) => Date.parse(row.at) >= Date.parse(query.since!));
    rows = [...rows].reverse();
    const offset = readOffset(query.cursor);
    const limit = query.limit ?? 50;
    const body: Record<string, unknown> = { rows: rows.slice(offset, offset + limit) };
    if (offset + limit < rows.length) body.nextCursor = String(offset + limit);
    return json(200, body);
  }

  const handler = async (method: string, path: string, url: URL, init: RequestInit | undefined, caller: UserPrincipal): Promise<Response | undefined> => {
    const served = path === '/v1/runs' || path.startsWith('/v1/runs/') || path === '/v1/audit';
    if (!served) return undefined;
    if (!deps.features.has('runIndex')) return error(404, 'not-found');
    try {
      if (path === '/v1/runs/grep') return method === 'POST' ? await grep(caller, init) : error(405, 'method-not-allowed');
      if (method !== 'GET') return error(405, 'method-not-allowed');
      if (path === '/v1/audit') return readAudit(caller, url);
      if (path === '/v1/runs') return list(caller, url);
      const runMatch = RUN_PATH.exec(path);
      const eventsMatch = EVENTS_PATH.exec(path);
      const messagesMatch = MESSAGES_PATH.exec(path);
      const envelopeMatch = ENVELOPE_PATH.exec(path);
      const subagentsMatch = SUBAGENTS_PATH.exec(path);
      const subagentMatch = SUBAGENT_PATH.exec(path);
      const nativeMatch = envelopeMatch ?? subagentsMatch ?? subagentMatch;
      if (nativeMatch && !deps.features.has('runEnvelopes')) return error(404, 'not-found');
      const id = decodeURIComponent((runMatch ?? eventsMatch ?? messagesMatch ?? nativeMatch)?.[1] ?? '');
      if (!runMatch && !eventsMatch && !messagesMatch && !nativeMatch) return error(404, 'not-found');
      const found = find(id, caller);
      if (!found) return error(404, 'not-found');
      if (runMatch) {
        record(caller, found.run, 'get');
        return json(200, detail(found.run));
      }
      if (eventsMatch) {
        record(caller, found.run, 'events');
        return events(found.run, url);
      }
      const session = decodeURIComponent((messagesMatch ?? nativeMatch)![2]!);
      if (messagesMatch) {
        record(caller, found.run, 'messages');
        return messages(found.run, session, url);
      }
      record(caller, found.run, 'envelope');
      if (subagentsMatch) return subagents(found.run, session);
      return envelope(found.run, session, subagentMatch ? decodeURIComponent(subagentMatch[3]!) : undefined);
    } catch (failure) {
      if (failure instanceof OrgContractError) return error(400, 'invalid-request');
      throw failure;
    }
  };

  handler.auditRows = (): readonly OrgAuditRow[] => audit;
  return handler;
}
