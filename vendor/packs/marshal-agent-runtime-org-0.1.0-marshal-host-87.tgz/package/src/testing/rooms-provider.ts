import { randomBytes } from 'node:crypto';
import { MAX_ROOM_TEXT_RESET_FRAME_BYTES } from '../rooms/text-types.js';
import { createServer, type IncomingMessage, type Server, type ServerResponse } from 'node:http';
import type { AddressInfo } from 'node:net';
import { isPrincipal, type UserPrincipal } from '../principals.js';
import { OrgContractError } from '../validate.js';
import { InMemoryRoomBus, type RoomBusEvent, type RoomStoreReader } from '../rooms/bus.js';
import {
  DURABLE_BATCH_CHANGES,
  DURABLE_BATCH_MS,
  MAX_CHANGES_PER_FRAME,
  MAX_JOINED_ROOMS,
  MAX_PRESENCE_BYTES,
  MAX_PRESENCE_UPDATES_PER_SECOND,
  MAX_ROOM_MEMBERS,
  PRESENCE_TTL_MS,
  ROOMS_PROTOCOL_VERSION,
  jsonBytes,
  parseRoomClientFrame,
  parseRoomCreateRequest,
  parseRoomGrantRequest,
  roomOpFrameIdentity,
  roomOpTooLarge,
  type RoomChange,
  type RoomClientFrame,
  type RoomEnvelope,
  type RoomGrant,
  type RoomId,
  type RoomRecordKey,
  type RoomRecordState,
  type RoomRole,
  type RoomServerFrame,
} from '../rooms/protocol.js';
import { applyRoomChange, roomRecordLastSeq, type RoomRecords } from '../rooms/reducer.js';
import { roomRoleAllows } from '../rooms/schema.js';
import { acceptTestWebSocket, type TestWebSocket } from './websocket-server.js';

/** The system of record of the in-memory provider: what Postgres holds for the rooms service. */
export class InMemoryRoomStore implements RoomStoreReader {
  readonly changes = new Map<RoomId, RoomChange[]>();
  readonly records = new Map<RoomId, RoomRecords>();
  private readonly ids = new Map<RoomId, Map<string, number>>();

  async head(room: RoomId): Promise<number> {
    return this.changes.get(room)?.at(-1)?.seq ?? 0;
  }
  async recordSeq(room: RoomId, record: RoomRecordKey): Promise<number | undefined> {
    const state = this.records.get(room)?.get(record);
    return state ? roomRecordLastSeq(state) : undefined;
  }
  async changeSeq(room: RoomId, author: UserPrincipal, id: string): Promise<number | undefined> {
    return this.ids.get(room)?.get(`${author}\u0000${id}`);
  }
  /** Appends a batch in one step (one transaction for the service). Changes already stored by author and id are skipped. */
  write(room: RoomId, batch: RoomChange[]): void {
    let log = this.changes.get(room);
    if (!log) this.changes.set(room, (log = []));
    let records = this.records.get(room);
    if (!records) this.records.set(room, (records = new Map()));
    let ids = this.ids.get(room);
    if (!ids) this.ids.set(room, (ids = new Map()));
    for (const change of batch) {
      const key = `${change.author}\u0000${change.id}`;
      if (ids.has(key) || change.seq <= (log.at(-1)?.seq ?? 0)) continue;
      ids.set(key, change.seq);
      log.push(change);
      applyRoomChange(records, change);
    }
  }
  after(room: RoomId, afterSeq: number, limit = Number.MAX_SAFE_INTEGER): RoomChange[] {
    const log = this.changes.get(room) ?? [];
    const result: RoomChange[] = [];
    for (const change of log) {
      if (change.seq <= afterSeq) continue;
      result.push(change);
      if (result.length >= limit) break;
    }
    return result;
  }
}

export type InMemoryRoomsProviderOptions = {
  /** Members of the organization. A token is issued only for them. Default: anyone. */
  members?: UserPrincipal[];
  presenceTtlMs?: number;
  heartbeatMs?: number;
  /** Drainer interval. Default `DURABLE_BATCH_MS`. */
  drainMs?: number;
  maxChangesPerSecond?: number;
  now?: () => number;
};

export type InMemoryRoomsProvider = {
  apiBase: string;
  socketUrl: string;
  issueToken(principal: UserPrincipal): string;
  bus: InMemoryRoomBus;
  store: InMemoryRoomStore;
  /** The bus forgets every room, as a Redis failover or restart would; joined sockets get `reset`. */
  loseBusState(): Promise<void>;
  /** While held, the drainer stores nothing, so changes stay above durable. */
  holdDurable(hold: boolean): void;
  /** Expires every presence entry now. */
  expirePresence(): Promise<void>;
  /** Sends `bye` to every socket and closes it. */
  sayBye(reason: 'deploy' | 'max-age' | 'overload' | 'shutdown'): void;
  close(): Promise<void>;
};

type RoomRow = {
  id: RoomId;
  workspaceId: string;
  kind: string;
  schemaVersion: number;
  title: string;
  owner: UserPrincipal;
  createdAt: string;
  updatedAt: string;
  archivedAt?: string;
  grants: Map<UserPrincipal, RoomGrant>;
};

type Joined = { role: RoomRole; epoch: string; sent: number; catchingUp: boolean; buffered: RoomChange[] };

type Connection = {
  socket: TestWebSocket;
  principal?: UserPrincipal;
  client?: string;
  joined: Map<RoomId, Joined>;
  presenceSent: number[];
};

/**
 * A complete rooms service in one process: HTTP routes and the socket on 127.0.0.1, the in-memory bus, a drainer into an
 * in-memory store. The conformance suite runs against it, and against the real service with the same context shape.
 */
export async function createInMemoryRoomsProvider(options: InMemoryRoomsProviderOptions = {}): Promise<InMemoryRoomsProvider> {
  const now = options.now ?? Date.now;
  const store = new InMemoryRoomStore();
  const bus = new InMemoryRoomBus({ store, now, presenceTtlMs: options.presenceTtlMs ?? PRESENCE_TTL_MS, maxChangesPerSecond: options.maxChangesPerSecond });
  const tokens = new Map<string, UserPrincipal>();
  const members = options.members ? new Set(options.members) : undefined;
  const rooms = new Map<RoomId, RoomRow>();
  const connections = new Set<Connection>();
  const origins = new Map<string, Connection>();
  let durableHeld = false;
  let draining = false;

  const iso = () => new Date(now()).toISOString();
  const send = (connection: Connection, frame: RoomServerFrame) => connection.socket.send(JSON.stringify(frame));
  const roleOf = (room: RoomRow, principal: UserPrincipal): RoomRole | undefined =>
    principal === room.owner ? 'owner' : room.grants.get(principal)?.role;

  const envelope = async (room: RoomRow, role: RoomRole): Promise<RoomEnvelope> => {
    const state = await bus.state(room.id);
    const result: RoomEnvelope = {
      id: room.id,
      workspaceId: room.workspaceId,
      kind: room.kind,
      schemaVersion: room.schemaVersion,
      title: room.title,
      owner: room.owner,
      role,
      head: state.head,
      durable: state.durable,
      epoch: state.epoch,
      createdAt: room.createdAt,
      updatedAt: room.updatedAt,
    };
    if (room.archivedAt) result.archivedAt = room.archivedAt;
    return result;
  };
  const grantList = (room: RoomRow) => ({
    grants: [{ principal: room.owner, role: 'owner' as const, grantedBy: room.owner, grantedAt: room.createdAt }, ...room.grants.values()],
  });

  // ---- catch-up and fan-out ----

  const changesAfter = async (room: RoomId, afterSeq: number): Promise<RoomChange[]> => {
    const recent = await bus.recent(room, afterSeq);
    if (recent) return recent;
    const stored = store.after(room, afterSeq);
    const last = stored.at(-1)?.seq ?? afterSeq;
    return [...stored, ...((await bus.recent(room, last)) ?? [])];
  };

  const catchUp = async (connection: Connection, room: RoomId, joined: Joined, afterSeq: number) => {
    joined.catchingUp = true;
    joined.buffered = [];
    joined.sent = afterSeq;
    const changes = await changesAfter(room, afterSeq);
    for (let index = 0; index < changes.length || index === 0; index += MAX_CHANGES_PER_FRAME) {
      const page = changes.slice(index, index + MAX_CHANGES_PER_FRAME);
      send(connection, { t: 'changes', room, changes: page, more: index + MAX_CHANGES_PER_FRAME < changes.length });
      if (changes.length === 0) break;
    }
    joined.sent = Math.max(afterSeq, changes.at(-1)?.seq ?? afterSeq);
    joined.catchingUp = false;
    for (const change of joined.buffered) deliver(connection, room, joined, change);
    joined.buffered = [];
  };

  const deliver = (connection: Connection, room: RoomId, joined: Joined, change: RoomChange) => {
    if (change.epoch !== joined.epoch) return;
    if (joined.catchingUp) {
      joined.buffered.push(change);
      return;
    }
    if (change.seq <= joined.sent) return;
    joined.sent = change.seq;
    send(connection, { t: 'change', room, change });
  };

  const onBusEvent = (event: RoomBusEvent) => {
    for (const connection of connections) {
      const joined = connection.joined.get(event.room);
      if (!joined) continue;
      switch (event.kind) {
        case 'change': {
          const origin = origins.get(`${event.room}\u0000${event.change.author}\u0000${event.change.id}`);
          if (origin === connection) {
            if (event.change.seq > joined.sent && !joined.catchingUp) joined.sent = event.change.seq;
            continue;
          }
          deliver(connection, event.room, joined, event.change);
          break;
        }
        case 'durable':
          if (event.epoch === joined.epoch) send(connection, { t: 'durable', room: event.room, epoch: event.epoch, through: event.through });
          break;
        case 'presence':
          if (event.entry.principal === connection.principal && event.entry.client === connection.client) continue;
          send(connection, { t: 'presence', room: event.room, ...event.entry });
          break;
        case 'left':
          send(connection, { t: 'left', room: event.room, principal: event.principal, client: event.client });
          break;
        case 'epoch':
          if (event.epoch === joined.epoch) continue;
          void (async () => {
            joined.epoch = event.epoch;
            send(connection, { t: 'reset', room: event.room, epoch: event.epoch, durable: event.durable });
            send(connection, { t: 'joined', room: event.room, role: joined.role, epoch: event.epoch, head: event.head, durable: event.durable });
            await catchUp(connection, event.room, joined, Math.min(joined.sent, event.durable));
          })();
          break;
      }
    }
  };
  bus.subscribe(onBusEvent);

  // ---- drainer ----

  const drain = async () => {
    if (durableHeld || draining) return;
    draining = true;
    try {
      for (const room of await bus.pendingRooms()) {
        const state = await bus.state(room);
        const batch = await bus.undrained(room, DURABLE_BATCH_CHANGES);
        if (batch.length === 0) continue;
        store.write(room, batch);
        await bus.markDurable(room, state.epoch, batch.at(-1)!.seq);
      }
    } finally {
      draining = false;
    }
  };
  const drainTimer = setInterval(() => void drain(), options.drainMs ?? DURABLE_BATCH_MS);
  const presenceTimer = setInterval(() => void bus.sweepPresence(), 250);

  // ---- socket ----

  const handleFrame = async (connection: Connection, raw: string) => {
    let value: unknown;
    try {
      value = JSON.parse(raw);
    } catch {
      return send(connection, { t: 'error', code: 'invalid' });
    }
    let frame: RoomClientFrame;
    const oversized = roomOpFrameIdentity(value);
    if (oversized && Buffer.byteLength(raw, 'utf8') > MAX_ROOM_TEXT_RESET_FRAME_BYTES) {
      return send(connection, { t: 'nack', room: oversized.room, id: oversized.id, code: 'too-large' });
    }
    try {
      frame = parseRoomClientFrame(value);
    } catch (error) {
      if (!(error instanceof OrgContractError)) throw error;
      const op = roomOpFrameIdentity(value);
      if (op) return send(connection, { t: 'nack', room: op.room, id: op.id, code: 'invalid' });
      const record = value as Record<string, unknown> | null;
      if (record && record.t === 'hello') {
        send(connection, { t: 'error', code: record.v !== ROOMS_PROTOCOL_VERSION ? 'unsupported-version' : 'unauthorized' });
        return connection.socket.close(1008);
      }
      return send(connection, { t: 'error', code: 'invalid' });
    }
    if (frame.t === 'hello') {
      const principal = tokens.get(frame.token);
      if (!principal || connection.principal) {
        send(connection, { t: 'error', code: 'unauthorized' });
        return connection.socket.close(1008);
      }
      connection.principal = principal;
      connection.client = frame.client;
      return send(connection, { t: 'welcome', principal, heartbeatMs: options.heartbeatMs ?? 25_000, serverTime: iso() });
    }
    const principal = connection.principal;
    if (!principal) {
      send(connection, { t: 'error', code: 'hello-required' });
      return connection.socket.close(1008);
    }
    switch (frame.t) {
      case 'ping':
        return send(connection, { t: 'pong', serverTime: iso() });
      case 'leave':
        connection.joined.delete(frame.room);
        await bus.dropPresence(frame.room, principal, connection.client!);
        return;
      case 'join': {
        const room = rooms.get(frame.room);
        if (!room) return send(connection, { t: 'error', code: 'not-found', room: frame.room });
        const role = roleOf(room, principal);
        if (!role) return send(connection, { t: 'error', code: 'forbidden', room: frame.room });
        if (!connection.joined.has(frame.room) && connection.joined.size >= MAX_JOINED_ROOMS) return send(connection, { t: 'error', code: 'too-many-rooms', room: frame.room });
        const state = await bus.state(frame.room);
        const joined: Joined = { role, epoch: state.epoch, sent: 0, catchingUp: true, buffered: [] };
        connection.joined.set(frame.room, joined);
        let from = 0;
        if (frame.have) {
          if (frame.have.epoch !== state.epoch) {
            send(connection, { t: 'reset', room: frame.room, epoch: state.epoch, durable: state.durable });
            from = Math.min(frame.have.seq, state.durable);
          } else from = Math.min(frame.have.seq, state.head);
        }
        send(connection, { t: 'joined', room: frame.room, role, epoch: state.epoch, head: state.head, durable: state.durable });
        await catchUp(connection, frame.room, joined, from);
        for (const entry of await bus.presence(frame.room)) {
          if (entry.principal === principal && entry.client === connection.client) continue;
          send(connection, { t: 'presence', room: frame.room, ...entry });
        }
        return;
      }
      case 'presence': {
        const joined = connection.joined.get(frame.room);
        if (!joined) return;
        const at = now();
        connection.presenceSent = connection.presenceSent.filter((sent) => at - sent < 1000);
        if (connection.presenceSent.length >= MAX_PRESENCE_UPDATES_PER_SECOND) return;
        if (jsonBytes(frame.state) > MAX_PRESENCE_BYTES) return;
        connection.presenceSent.push(at);
        await bus.setPresence(frame.room, { principal, client: connection.client!, actor: frame.actor, state: frame.state, at: iso() });
        return;
      }
      case 'op': {
        const nack = (code: 'forbidden' | 'conflict' | 'too-large' | 'busy' | 'invalid' | 'not-joined') => send(connection, { t: 'nack', room: frame.room, id: frame.id, code });
        const joined = connection.joined.get(frame.room);
        if (!joined) return nack('not-joined');
        if (roomOpTooLarge(frame, Buffer.byteLength(raw, 'utf8'))) return nack('too-large');
        if (!roomRoleAllows(joined.role, { kind: 'write', type: frame.type })) return nack('forbidden');
        const originKey = `${frame.room}\u0000${principal}\u0000${frame.id}`;
        origins.set(originKey, connection);
        const result = await bus.order({
          room: frame.room,
          id: frame.id,
          author: principal,
          actor: frame.actor,
          at: iso(),
          record: frame.record,
          type: frame.type,
          op: frame.op,
          ...(frame.set !== undefined ? { set: frame.set } : {}),
          ...(frame.text !== undefined ? { text: frame.text } : {}),
          ...(frame.base !== undefined ? { base: frame.base } : {}),
          ...(frame.ifSeq !== undefined ? { ifSeq: frame.ifSeq } : {}),
        });
        origins.delete(originKey);
        if (result.kind === 'ordered') return send(connection, { t: 'ack', room: frame.room, id: frame.id, seq: result.change.seq, epoch: result.change.epoch });
        if (result.kind === 'duplicate') return send(connection, { t: 'ack', room: frame.room, id: frame.id, seq: result.seq, epoch: result.epoch });
        return nack(result.kind);
      }
    }
  };

  // ---- HTTP ----

  const readBody = async (request: IncomingMessage): Promise<unknown> => {
    const chunks: Buffer[] = [];
    for await (const chunk of request) chunks.push(chunk as Buffer);
    const text = Buffer.concat(chunks).toString('utf8');
    return text ? JSON.parse(text) : undefined;
  };
  const reply = (response: ServerResponse, status: number, body?: unknown) => {
    response.writeHead(status, { 'content-type': 'application/json' });
    response.end(body === undefined ? '' : JSON.stringify(body));
  };

  const handleHttp = async (request: IncomingMessage, response: ServerResponse) => {
    const url = new URL(request.url ?? '/', 'http://127.0.0.1');
    const auth = request.headers.authorization;
    const principal = auth?.startsWith('Bearer ') ? tokens.get(auth.slice(7)) : undefined;
    if (!principal) return reply(response, 401, { error: 'unauthorized' });
    const parts = url.pathname.split('/').filter(Boolean).map(decodeURIComponent);
    if (parts[0] !== 'v1' || parts[1] !== 'rooms') return reply(response, 404, { error: 'not-found' });
    try {
      if (parts.length === 2 && request.method === 'POST') {
        const input = parseRoomCreateRequest(await readBody(request));
        const existing = rooms.get(input.id);
        if (existing) return existing.owner === principal ? reply(response, 200, await envelope(existing, 'owner')) : reply(response, 409, { error: 'exists' });
        const room: RoomRow = { ...input, owner: principal, createdAt: iso(), updatedAt: iso(), grants: new Map() };
        rooms.set(room.id, room);
        return reply(response, 201, await envelope(room, 'owner'));
      }
      if (parts.length === 2 && request.method === 'GET') {
        const kind = url.searchParams.get('kind');
        const workspaceId = url.searchParams.get('workspaceId');
        const listed = [];
        for (const room of rooms.values()) {
          const role = roleOf(room, principal);
          if (!role || (kind && room.kind !== kind) || (workspaceId && room.workspaceId !== workspaceId)) continue;
          listed.push(await envelope(room, role));
        }
        return reply(response, 200, { rooms: listed });
      }
      const room = rooms.get(parts[2] ?? '');
      const role = room ? roleOf(room, principal) : undefined;
      if (!room || !role) return reply(response, 404, { error: 'not-found' });
      if (parts.length === 3 && request.method === 'GET') return reply(response, 200, await envelope(room, role));
      if (parts.length === 3 && request.method === 'PUT') {
        if (!roomRoleAllows(role, { kind: 'update-room' })) return reply(response, 403, { error: 'forbidden' });
        const body = (await readBody(request)) as { title?: unknown; archived?: unknown } | undefined;
        if (typeof body?.title === 'string' && body.title.length > 0 && body.title.length <= 256) room.title = body.title;
        if (body?.archived === true) room.archivedAt = iso();
        if (body?.archived === false) delete room.archivedAt;
        room.updatedAt = iso();
        return reply(response, 200, await envelope(room, role));
      }
      if (parts[3] === 'grants') {
        if (parts.length === 4 && request.method === 'GET') return reply(response, 200, grantList(room));
        if (!roomRoleAllows(role, { kind: 'grant' })) return reply(response, 403, { error: 'forbidden' });
        if (parts.length === 4 && request.method === 'POST') {
          const grant = parseRoomGrantRequest(await readBody(request));
          if (grant.principal === room.owner) return reply(response, 409, { error: 'owner' });
          if (!room.grants.has(grant.principal) && room.grants.size + 1 >= MAX_ROOM_MEMBERS) return reply(response, 409, { error: 'room-full' });
          room.grants.set(grant.principal, { principal: grant.principal, role: grant.role, grantedBy: principal, grantedAt: iso() });
          for (const connection of connections) {
            const joined = connection.principal === grant.principal ? connection.joined.get(room.id) : undefined;
            if (joined && joined.role !== grant.role) {
              joined.role = grant.role;
              send(connection, { t: 'role', room: room.id, role: grant.role });
            }
          }
          return reply(response, 200, grantList(room));
        }
        if (parts.length === 5 && request.method === 'DELETE') {
          const target = parts[4] as UserPrincipal;
          if (!isPrincipal(target) || target === room.owner) return reply(response, 409, { error: 'owner' });
          room.grants.delete(target);
          for (const connection of connections) {
            if (connection.principal !== target || !connection.joined.has(room.id)) continue;
            connection.joined.delete(room.id);
            send(connection, { t: 'revoked', room: room.id });
            await bus.dropPresence(room.id, target, connection.client!);
          }
          return reply(response, 200, grantList(room));
        }
      }
      if (parts[3] === 'changes' && request.method === 'GET') {
        const after = Number(url.searchParams.get('after') ?? '0');
        const requested = Number(url.searchParams.get('limit') ?? MAX_CHANGES_PER_FRAME);
        if (!Number.isInteger(after) || after < 0 || !Number.isInteger(requested) || requested < 1) return reply(response, 400, { error: 'invalid' });
        const limit = Math.min(requested, MAX_CHANGES_PER_FRAME);
        const state = await bus.state(room.id);
        const page = store.after(room.id, after, limit + 1).filter((change) => change.seq <= state.durable);
        return reply(response, 200, { changes: page.slice(0, limit), more: page.length > limit, epoch: state.epoch, durable: state.durable });
      }
      if (parts[3] === 'records' && request.method === 'GET') {
        const after = Number(url.searchParams.get('after') ?? '0');
        const state = await bus.state(room.id);
        const records: RoomRecordState[] = [...(store.records.get(room.id)?.values() ?? [])].filter((record) => roomRecordLastSeq(record) > after);
        return reply(response, 200, { records, through: await store.head(room.id), epoch: state.epoch });
      }
      return reply(response, 404, { error: 'not-found' });
    } catch (error) {
      if (error instanceof OrgContractError || error instanceof SyntaxError) return reply(response, 400, { error: 'invalid' });
      throw error;
    }
  };

  const server: Server = createServer((request, response) => {
    handleHttp(request, response).catch(() => reply(response, 500, { error: 'internal' }));
  });
  server.on('upgrade', (request, rawSocket, head) => {
    const url = new URL(request.url ?? '/', 'http://127.0.0.1');
    if (url.pathname !== '/v1/rooms/socket') {
      rawSocket.end('HTTP/1.1 404 Not Found\r\n\r\n');
      return;
    }
    const socket = acceptTestWebSocket(request, rawSocket, head);
    if (!socket) return;
    const connection: Connection = { socket, joined: new Map(), presenceSent: [] };
    connections.add(connection);
    let queue = Promise.resolve();
    socket.onMessage((text) => {
      queue = queue.then(() => handleFrame(connection, text)).catch(() => socket.close(1011));
    });
    socket.onClose(() => {
      connections.delete(connection);
      if (connection.principal && connection.client) {
        for (const room of connection.joined.keys()) void bus.dropPresence(room, connection.principal, connection.client);
      }
    });
  });
  await new Promise<void>((resolve) => server.listen(0, '127.0.0.1', resolve));
  const port = (server.address() as AddressInfo).port;

  return {
    apiBase: `http://127.0.0.1:${port}`,
    socketUrl: `ws://127.0.0.1:${port}/v1/rooms/socket`,
    issueToken(principal) {
      if (members && !members.has(principal)) throw new Error(`${principal} is not a member`);
      const token = `rt_${randomBytes(18).toString('hex')}`;
      tokens.set(token, principal);
      return token;
    },
    bus,
    store,
    async loseBusState() {
      const known = bus.loseState();
      for (const room of known) await bus.state(room);
    },
    holdDurable(hold) {
      durableHeld = hold;
    },
    async expirePresence() {
      for (const [room] of rooms) {
        for (const entry of await bus.presence(room)) await bus.dropPresence(room, entry.principal, entry.client);
      }
    },
    sayBye(reason) {
      for (const connection of connections) {
        send(connection, { t: 'bye', reason });
        connection.socket.close(1001);
      }
    },
    async close() {
      clearInterval(drainTimer);
      clearInterval(presenceTimer);
      for (const connection of connections) connection.socket.close(1001);
      await new Promise<void>((resolve) => server.close(() => resolve()));
    },
  };
}
