import { isDeepStrictEqual } from 'node:util';
import { ORG_ROUTES } from '../client.js';
import { orgDiscoveryUrl, orgSupports, parseOrgDiscoveryDocument, type OrgDiscoveryDocument, type OrgFeature } from '../discovery.js';
import {
  MAX_DIRECTORY_RESULTS,
  parseDirectoryResults,
  parseOrgIdentity,
  parseOrgWorkspace,
  parseOrgWorkspaceList,
  type OrgWorkspaceId,
} from '../model.js';
import {
  MAX_MESSAGE_TEXT_BYTES,
  MAX_HELD_PER_AUTHOR,
  MAX_QUEUED_MESSAGES,
  parseOrgPostedMessage,
  parseOrgSessionMessage,
  parseOrgSessionMessagePage,
  type OrgPostedMessage,
  type OrgSessionMessage,
  type OrgSessionMessagePage,
} from '../messages.js';
import {
  BUNDLE_CONTENT_TYPE,
  BUNDLE_HEADERS,
  normalizeOrgRepository,
  parseOrgMountBundleInfo,
  parseOrgPlacementView,
  type OrgMountBundleInfo,
} from '../placement.js';
import { parseOrgForkResult, type OrgForkResult } from '../forks.js';
import {
  DEFAULT_PARTICIPANT_TURNS_PER_DAY,
  MAX_CLAIM_MESSAGES,
  MAX_LIVE_QUEUED_PER_AUTHOR,
  MAX_PARTICIPANT_TURNS_PER_DAY,
  parseOrgClaimedMessages,
  parseOrgCompletedMessages,
  parseOrgLivePending,
  parseOrgSessionLive,
  type OrgClaimedMessages,
  type OrgSessionLive,
} from '../live.js';
import type { FetchLike } from '../oidc.js';
import type { UserPrincipal } from '../principals.js';
import { gzipSync } from 'node:zlib';
import { WATCH_CONTENT_TYPE, WATCH_KINDS, WATCH_VERSION_PATTERN, readWatchEvents, type OrgWatchEvent } from '../watch.js';
import { parseOrgLeaseView, type OrgLeaseView } from '../leases.js';
import {
  ENVELOPE_CONTENT_TYPE,
  ENVELOPE_HEADERS,
  checkEnvelopeAgainstCheckpoint,
  envelopeStateRef,
  isCloudHostId,
  parseOrgCloudCapabilities,
  parseOrgCloudRunStarted,
  parseOrgCloudRunView,
  parseOrgEnvelopeInfo,
  sha256Hex,
  type OrgCloudCapabilities,
  type OrgCloudRunStarted,
  type OrgEnvelopeInfo,
} from '../cloud.js';
import {
  MAX_GREP_RUNS,
  parseOrgAuditPage,
  parseOrgRunDetail,
  parseOrgRunEventPage,
  parseOrgRunGrepResult,
  parseOrgRunMessagesPage,
  parseOrgRunPage,
} from '../runs.js';
import {
  MAX_TRANSCRIPT_PAGE_BYTES,
  MAX_TRANSCRIPT_PAGE_MESSAGES,
  parseOrgGrantResult,
  parseOrgNotification,
  parseOrgNotificationPage,
  parseOrgSessionEnvelope,
  parseOrgSessionPage,
  type OrgSessionPage,
  parseOrgSessionView,
  parseOrgTranscriptPage,
  parseOrgTranscriptRefResponse,
  type OrgSessionUpload,
  type OrgTranscriptMessage,
} from '../sessions.js';

export type OrgProviderConformanceContext = {
  fetch: FetchLike;
  orgUrl: string;
  /** An access token the provider accepts for this principal. */
  accessTokenFor(principal: UserPrincipal): string | Promise<string>;
  /** A member of the organization. Required: whoami and the directory checks run as this user. */
  memberPrincipal: UserPrincipal;
  /** A principal with a valid token who is not a member; enables the 403 `not-a-member` check. */
  nonMemberPrincipal?: UserPrincipal;
  /**
   * Three distinct members for the sessions cases: `owner` uploads sessions, `peer` and `third` are other members.
   * Without it the sessions, mentions and notifications cases are skipped.
   */
  sessionPrincipals?: { owner: UserPrincipal; peer: UserPrincipal; third: UserPrincipal };
  /**
   * Drives the provider's cloud host one turn for a session it holds, releasing at a pending handover. `uploadEnvelope: false`
   * makes it append to the transcript but die before uploading its state. Only providers with a controllable fake cloud host
   * supply the three cloud hooks; the cases that need one are skipped without it.
   */
  advanceCloudRun?(sessionId: string, options?: { finish?: boolean; uploadEnvelope?: boolean }): Promise<void>;
  /**
   * What the run index serves, for the `runIndex` cases (skipped without it or without the feature). `requester` requested every
   * run named here; `auditor` may read the runs of `workspace`; `other` is a member with no right over any of them.
   */
  runFixtures?: OrgRunFixtures;
  /** Makes the cloud host stop heartbeating without releasing, so its lease lapses. */
  crashCloudRun?(sessionId: string): Promise<void>;
  /** Switches the cloud host's availability, as reported by the capabilities and enforced on a move. */
  setCloudAvailable?(available: boolean): Promise<void>;
};

export type OrgProviderConformanceCase = {
  name: string;
  run(context: OrgProviderConformanceContext): Promise<void>;
};

/** The seeded data the `runIndex` conformance cases read. */
export type OrgRunFixtures = {
  requester: UserPrincipal;
  auditor: UserPrincipal;
  other: UserPrincipal;
  workspace: OrgWorkspaceId;
  /** A run of `requester` in `workspace` whose session `session` has at least 3 messages. */
  runId: string;
  session: string;
  /** A run of `requester` that came from a direct conversation with the bot: its auditors must not see it. */
  dmRunId?: string;
  /** A run of `requester` that no workspace owns. */
  unassignedRunId?: string;
  /** A session of a run in `workspace` whose transcript is withheld. */
  withheld?: { runId: string; session: string };
  /** A text that occurs in a message of `runId`'s session, at least 2 characters. */
  grepText?: string;
};

type Answer = { status: number; body: unknown };

const SERVED_FEATURES: readonly OrgFeature[] = ['signIn', 'workspaces', 'directory', 'sessions', 'notifications', 'leases', 'cloudRuns', 'messages', 'placement', 'forks'];
const ERROR_CODE = /^[A-Za-z0-9_-]{1,64}$/;
const ABSENT_WORKSPACE: OrgWorkspaceId = 'ws:conformance-no-such-workspace';

function check(condition: unknown, message: string): asserts condition {
  if (!condition) throw new Error(`conformance: ${message}`);
}

async function request(
  context: OrgProviderConformanceContext,
  url: string,
  authorization?: string,
  options: { method?: string; body?: unknown } = {},
): Promise<Answer> {
  const response = await context.fetch(url, {
    method: options.method ?? 'GET',
    headers: {
      accept: 'application/json',
      ...(options.body === undefined ? {} : { 'content-type': 'application/json' }),
      ...(authorization ? { authorization } : {}),
    },
    ...(options.body === undefined ? {} : { body: JSON.stringify(options.body) }),
  });
  const text = await response.text();
  let body: unknown;
  try {
    body = text.length ? JSON.parse(text) : undefined;
  } catch {
    body = undefined;
  }
  return { status: response.status, body };
}

async function discover(context: OrgProviderConformanceContext): Promise<OrgDiscoveryDocument> {
  const answer = await request(context, orgDiscoveryUrl(context.orgUrl));
  check(answer.status === 200, `discovery answered ${answer.status}, expected 200`);
  return parseOrgDiscoveryDocument(answer.body);
}

function apiUrl(document: OrgDiscoveryDocument, route: string): string {
  return `${document.apiBase.replace(/\/+$/, '')}${route}`;
}

async function bearer(context: OrgProviderConformanceContext, principal: UserPrincipal): Promise<string> {
  return `Bearer ${await context.accessTokenFor(principal)}`;
}

function featureRoutes(document: OrgDiscoveryDocument): { feature: OrgFeature; route: string }[] {
  const routes: Record<string, string> = {
    signIn: ORG_ROUTES.whoami,
    workspaces: ORG_ROUTES.workspaces,
    directory: `${ORG_ROUTES.directory}?q=a&limit=1`,
    sessions: ORG_ROUTES.sessions,
    notifications: ORG_ROUTES.notifications,
    leases: ORG_ROUTES.sessionLease('conformance-no-such-session'),
    cloudRuns: ORG_ROUTES.cloudCapabilities,
    messages: ORG_ROUTES.sessionMessages('conformance-no-such-session'),
    placement: ORG_ROUTES.sessionPlacement('conformance-no-such-session'),
    forks: ORG_ROUTES.sessionFork('conformance-no-such-session'),
  };
  return SERVED_FEATURES.filter((feature) => orgSupports(document, feature)).map((feature) => ({ feature, route: routes[feature]! }));
}

function expectErrorBody(answer: Answer, label: string): string {
  const body = answer.body;
  check(typeof body === 'object' && body !== null && !Array.isArray(body), `${label}: error body must be a JSON object`);
  const keys = Object.keys(body);
  check(keys.length === 1 && keys[0] === 'error', `${label}: error body must carry only "error", got ${JSON.stringify(keys)}`);
  const code = (body as { error: unknown }).error;
  check(typeof code === 'string' && ERROR_CODE.test(code), `${label}: error must be a short code`);
  return code;
}

export function orgProviderConformanceCases(): OrgProviderConformanceCase[] {
  return [
    {
      name: 'discovery is valid and served without auth',
      async run(context) {
        const document = await discover(context);
        check(document.features.length > 0, 'discovery declares no known features');
      },
    },
    {
      name: "whoami matches the token's principal",
      async run(context) {
        const document = await discover(context);
        if (!orgSupports(document, 'signIn')) return;
        const answer = await request(context, apiUrl(document, ORG_ROUTES.whoami), await bearer(context, context.memberPrincipal));
        check(answer.status === 200, `whoami answered ${answer.status}, expected 200`);
        const identity = parseOrgIdentity(answer.body);
        check(identity.principal === context.memberPrincipal, 'whoami principal differs from the token principal');
        check(identity.orgId === document.orgId, 'whoami orgId differs from the discovery orgId');
      },
    },
    {
      name: 'routes reject missing or invalid tokens with 401 unauthorized',
      async run(context) {
        const document = await discover(context);
        for (const { feature, route } of featureRoutes(document)) {
          for (const [label, authorization] of [
            ['no token', undefined],
            ['garbage token', 'Bearer conformance-invalid-token'],
            ['wrong scheme', 'Basic Zm9vOmJhcg=='],
          ] as const) {
            const answer = await request(context, apiUrl(document, route), authorization);
            check(answer.status === 401, `${feature} with ${label} answered ${answer.status}, expected 401`);
            check(expectErrorBody(answer, `${feature} with ${label}`) === 'unauthorized', `${feature} with ${label}: expected error "unauthorized"`);
          }
        }
      },
    },
    {
      name: 'a non-member gets 403 not-a-member',
      async run(context) {
        if (!context.nonMemberPrincipal) return;
        const document = await discover(context);
        const authorization = await bearer(context, context.nonMemberPrincipal);
        for (const { feature, route } of featureRoutes(document)) {
          const answer = await request(context, apiUrl(document, route), authorization);
          check(answer.status === 403, `${feature} for a non-member answered ${answer.status}, expected 403`);
          check(expectErrorBody(answer, `${feature} for a non-member`) === 'not-a-member', `${feature} for a non-member: expected error "not-a-member"`);
        }
      },
    },
    {
      name: 'directory honors limit (50 at most) and q',
      async run(context) {
        const document = await discover(context);
        if (!orgSupports(document, 'directory')) return;
        const authorization = await bearer(context, context.memberPrincipal);
        const identityAnswer = orgSupports(document, 'signIn')
          ? await request(context, apiUrl(document, ORG_ROUTES.whoami), authorization)
          : undefined;
        const seedName = identityAnswer ? parseOrgIdentity(identityAnswer.body).displayName : 'a';
        const query = seedName.trim().split(/\s+/)[0]!.slice(0, 3).toLowerCase() || 'a';
        const search = async (params: Record<string, string>) => {
          const answer = await request(context, apiUrl(document, `${ORG_ROUTES.directory}?${new URLSearchParams(params).toString()}`), authorization);
          check(answer.status === 200, `directory ${JSON.stringify(params)} answered ${answer.status}, expected 200`);
          return parseDirectoryResults(answer.body);
        };

        const matched = await search({ q: query, limit: '50' });
        check(matched.length <= MAX_DIRECTORY_RESULTS, `directory returned ${matched.length} entries, more than ${MAX_DIRECTORY_RESULTS}`);
        for (const entry of matched) {
          const haystack = `${entry.displayName} ${entry.email ?? ''}`.toLowerCase();
          check(haystack.includes(query), `directory entry ${entry.principal} does not match q=${query}`);
        }
        const one = await search({ q: query, limit: '1' });
        check(one.length <= 1, `directory returned ${one.length} entries for limit=1`);
        const huge = await search({ q: query, limit: '500' });
        check(huge.length <= MAX_DIRECTORY_RESULTS, `directory returned ${huge.length} entries for limit=500`);
        const none = await search({ q: 'zzzz-conformance-no-such-person-qqqq', limit: '10' });
        check(none.length === 0, 'directory returned entries for a query that matches nobody');
      },
    },
    {
      name: 'the workspace by id equals the list entry',
      async run(context) {
        const document = await discover(context);
        if (!orgSupports(document, 'workspaces')) return;
        const authorization = await bearer(context, context.memberPrincipal);
        const list = await request(context, apiUrl(document, ORG_ROUTES.workspaces), authorization);
        check(list.status === 200, `workspace list answered ${list.status}, expected 200`);
        for (const listed of parseOrgWorkspaceList(list.body).slice(0, 10)) {
          const single = await request(context, apiUrl(document, ORG_ROUTES.workspace(listed.id)), authorization);
          check(single.status === 200, `workspace ${listed.id} answered ${single.status}, expected 200`);
          check(isDeepStrictEqual(parseOrgWorkspace(single.body), listed), `workspace ${listed.id} differs from its list entry`);
        }
      },
    },
    {
      name: 'an unknown workspace gets 404',
      async run(context) {
        const document = await discover(context);
        if (!orgSupports(document, 'workspaces')) return;
        const answer = await request(context, apiUrl(document, ORG_ROUTES.workspace(ABSENT_WORKSPACE)), await bearer(context, context.memberPrincipal));
        check(answer.status === 404, `unknown workspace answered ${answer.status}, expected 404`);
        expectErrorBody(answer, 'unknown workspace');
      },
    },
    {
      name: 'features not declared are not served',
      async run(context) {
        const document = await discover(context);
        const authorization = await bearer(context, context.memberPrincipal);
        const routes: Record<string, string> = {
          signIn: ORG_ROUTES.whoami,
          workspaces: ORG_ROUTES.workspaces,
          directory: `${ORG_ROUTES.directory}?q=a&limit=1`,
          sessions: ORG_ROUTES.sessions,
          notifications: ORG_ROUTES.notifications,
          leases: ORG_ROUTES.sessionLease('conformance-no-such-session'),
          cloudRuns: ORG_ROUTES.cloudCapabilities,
          messages: ORG_ROUTES.sessionMessages('conformance-no-such-session'),
          placement: ORG_ROUTES.sessionPlacement('conformance-no-such-session'),
        };
        for (const feature of SERVED_FEATURES) {
          if (orgSupports(document, feature)) continue;
          const answer = await request(context, apiUrl(document, routes[feature]!), authorization);
          check(
            answer.status >= 400 && answer.status !== 401,
            `${feature} is not declared but its route answered ${answer.status}`,
          );
        }
      },
    },
    {
      name: 'error bodies carry only {error} codes',
      async run(context) {
        const document = await discover(context);
        const authorization = await bearer(context, context.memberPrincipal);
        const probes: { label: string; url: string; authorization?: string }[] = [
          { label: 'missing token', url: apiUrl(document, ORG_ROUTES.whoami) },
          { label: 'unknown route', url: apiUrl(document, '/v1/conformance-no-such-route'), authorization },
        ];
        if (orgSupports(document, 'workspaces')) {
          probes.push({ label: 'unknown workspace', url: apiUrl(document, ORG_ROUTES.workspace(ABSENT_WORKSPACE)), authorization });
        }
        if (orgSupports(document, 'directory')) {
          probes.push({ label: 'directory without q', url: apiUrl(document, ORG_ROUTES.directory), authorization });
        }
        for (const probe of probes) {
          const answer = await request(context, probe.url, probe.authorization);
          if (answer.status < 400) continue;
          expectErrorBody(answer, probe.label);
        }
      },
    },
    ...sessionConformanceCases(),
    ...leaseConformanceCases(),
    ...cloudConformanceCases(),
    ...placementConformanceCases(),
    ...messageConformanceCases(),
    ...liveConformanceCases(),
    ...sharedTranscriptConformanceCases(),
    ...cloudListConformanceCases(),
    ...multiUserConformanceCases(),
    ...forkConformanceCases(),
    ...sessionWatchConformanceCases(),
    ...runIndexConformanceCases(),
  ];
}

type SessionsRun = {
  context: OrgProviderConformanceContext;
  document: OrgDiscoveryDocument;
  owner: UserPrincipal;
  peer: UserPrincipal;
  third: UserPrincipal;
  auth(principal: UserPrincipal): Promise<string>;
  call(principal: UserPrincipal | undefined, route: string, method?: string, body?: unknown): Promise<Answer>;
  expectError(answer: Answer, status: number, code: string, label: string): void;
  upload(id?: string): Promise<{ id: string; envelope: OrgSessionUpload }>;
};

let sessionCounter = 0;

async function withSessions(
  context: OrgProviderConformanceContext,
  features: OrgFeature[],
  body: (run: SessionsRun) => Promise<void>,
): Promise<void> {
  const principals = context.sessionPrincipals;
  if (!principals) return;
  const document = await discover(context);
  if (!features.every((feature) => orgSupports(document, feature))) return;
  const workspaceId = await firstWorkspaceId(context, document);
  const call: SessionsRun['call'] = async (principal, route, method = 'GET', payload) =>
    request(context, apiUrl(document, route), principal ? await bearer(context, principal) : undefined, { method, body: payload });
  await body({
    context,
    document,
    ...principals,
    auth: (principal) => bearer(context, principal),
    call,
    expectError(answer, status, code, label) {
      check(answer.status === status, `${label} answered ${answer.status}, expected ${status}`);
      check(expectErrorBody(answer, label) === code, `${label}: expected error "${code}"`);
    },
    async upload(id) {
      sessionCounter += 1;
      const sessionId = id ?? `conformance-${Date.now().toString(36)}-${sessionCounter}`;
      const at = new Date().toISOString();
      const envelope: OrgSessionUpload = {
        id: sessionId,
        workspaceId,
        title: 'Conformance session',
        owner: principals.owner,
        createdAt: at,
        updatedAt: at,
        labels: 'team',
        runtime: 'claude',
      };
      const answer = await call(principals.owner, ORG_ROUTES.session(sessionId), 'PUT', envelope);
      check(answer.status === 200, `session upload answered ${answer.status}, expected 200`);
      const stored = parseOrgSessionEnvelope(answer.body);
      check(stored.id === sessionId && stored.owner === principals.owner, 'stored session differs from the upload');
      check(stored.transcript.messageCount === 0 && stored.transcript.bytes === 0, 'a new session must start with an empty transcript');
      return { id: sessionId, envelope };
    },
  });
}

async function firstWorkspaceId(context: OrgProviderConformanceContext, document: OrgDiscoveryDocument): Promise<OrgWorkspaceId> {
  if (!orgSupports(document, 'workspaces')) return 'ws:conformance';
  const answer = await request(context, apiUrl(document, ORG_ROUTES.workspaces), await bearer(context, context.memberPrincipal));
  check(answer.status === 200, `workspace list answered ${answer.status}, expected 200`);
  const first = parseOrgWorkspaceList(answer.body)[0];
  check(first, 'the sessions cases need at least one workspace');
  return first.id;
}

function message(index: number, text = `message ${index}`): OrgTranscriptMessage {
  return { role: index % 2 === 0 ? 'user' : 'assistant', text, at: new Date(1_700_000_000_000 + index * 1000).toISOString() };
}

function sessionConformanceCases(): OrgProviderConformanceCase[] {
  return [
    {
      name: 'sessions: the owner uploads a session and reads it back',
      run: (context) =>
        withSessions(context, ['sessions'], async (run) => {
          const { id } = await run.upload();
          const write = await run.call(run.owner, ORG_ROUTES.sessionTranscript(id), 'PUT', { mode: 'replace', messages: [message(0), message(1, 'héllo')] });
          check(write.status === 200, `transcript write answered ${write.status}, expected 200`);
          const ref = parseOrgTranscriptRefResponse(write.body);
          check(ref.messageCount === 2 && ref.bytes === new TextEncoder().encode('message 0héllo').length, 'transcript reference does not match what was written');
          const answer = await run.call(run.owner, ORG_ROUTES.session(id));
          check(answer.status === 200, `session read answered ${answer.status}, expected 200`);
          const view = parseOrgSessionView(answer.body);
          check(view.role === 'owner' && view.session.transcript.messageCount === 2, 'owner view is wrong');
          const page = parseOrgTranscriptPage((await run.call(run.owner, ORG_ROUTES.sessionTranscript(id))).body);
          check(page.total === 2 && page.messages[1]?.text === 'héllo', 'transcript page differs from what was written');
          run.expectError(await run.call(run.peer, ORG_ROUTES.session(id), 'PUT', { ...view.session }), 403, 'forbidden', 'upload by a non-owner');
          const forged = await run.call(run.owner, ORG_ROUTES.session(id), 'PUT', { ...view.session, owner: run.peer });
          run.expectError(forged, 403, 'forbidden', 'upload naming another owner');
          const mismatch = await run.call(run.owner, ORG_ROUTES.session(`${id}-other`), 'PUT', { ...view.session });
          check(mismatch.status === 400, `upload with a mismatched id answered ${mismatch.status}, expected 400`);
          run.expectError(mismatch, 400, 'invalid-request', 'upload with a mismatched id');
        }),
    },
    {
      name: 'sessions: a non-grantee cannot read a session',
      run: (context) =>
        withSessions(context, ['sessions'], async (run) => {
          const { id } = await run.upload();
          for (const route of [ORG_ROUTES.session(id), ORG_ROUTES.sessionTranscript(id)]) {
            run.expectError(await run.call(run.peer, route), 404, 'not-found', `read of ${route} by a non-grantee`);
          }
          const listed = parseOrgSessionPage((await run.call(run.peer, ORG_ROUTES.sessions)).body);
          check(!listed.sessions.some((view) => view.session.id === id), 'a non-grantee sees the session in the list');
          run.expectError(await run.call(run.peer, ORG_ROUTES.sessionTranscript(id), 'PUT', { mode: 'append', messages: [] }), 404, 'not-found', 'transcript write by a non-grantee');
          run.expectError(await run.call(run.peer, ORG_ROUTES.sessionGrants(id), 'POST', { principal: run.third, role: 'viewer' }), 404, 'not-found', 'grant by a non-grantee');
        }),
    },
    {
      name: 'sessions: a viewer cannot grant or write the transcript',
      run: (context) =>
        withSessions(context, ['sessions'], async (run) => {
          const { id } = await run.upload();
          const granted = await run.call(run.owner, ORG_ROUTES.sessionGrants(id), 'POST', { principal: run.peer, role: 'viewer' });
          check(granted.status === 200, `owner grant answered ${granted.status}, expected 200`);
          const result = parseOrgGrantResult(granted.body);
          check(result.grant.principal === run.peer && result.grant.role === 'viewer' && result.grant.grantedBy === run.owner, 'grant record is wrong');
          run.expectError(await run.call(run.peer, ORG_ROUTES.sessionGrants(id), 'POST', { principal: run.third, role: 'viewer' }), 403, 'forbidden', 'grant by a viewer');
          run.expectError(await run.call(run.peer, ORG_ROUTES.sessionTranscript(id), 'PUT', { mode: 'append', messages: [] }), 403, 'forbidden', 'transcript write by a viewer');
          const view = parseOrgSessionView((await run.call(run.peer, ORG_ROUTES.session(id))).body);
          check(view.role === 'viewer' && view.grants === undefined, 'a viewer must see their role and no grant list');
          const ownerView = parseOrgSessionView((await run.call(run.owner, ORG_ROUTES.session(id))).body);
          check(ownerView.grants?.some((entry) => entry.principal === run.peer) === true, 'the owner view must list grants');
        }),
    },
    {
      name: "sessions: a grant cannot exceed the granter's role",
      run: (context) =>
        withSessions(context, ['sessions'], async (run) => {
          const { id } = await run.upload();
          const grantRoute = ORG_ROUTES.sessionGrants(id);
          await run.call(run.owner, grantRoute, 'POST', { principal: run.peer, role: 'collaborator' });
          run.expectError(await run.call(run.peer, grantRoute, 'POST', { principal: run.third, role: 'driver' }), 403, 'forbidden', 'collaborator granting driver');
          const ok = await run.call(run.peer, grantRoute, 'POST', { principal: run.third, role: 'collaborator' });
          check(ok.status === 200, `collaborator granting collaborator answered ${ok.status}, expected 200`);
          run.expectError(await run.call(run.owner, grantRoute, 'POST', { principal: run.third, role: 'owner' }), 400, 'invalid-request', 'granting owner');
          run.expectError(await run.call(run.owner, grantRoute, 'POST', { principal: run.owner, role: 'viewer' }), 409, 'conflict', 'granting the owner a role');
          await run.call(run.owner, grantRoute, 'POST', { principal: run.third, role: 'driver' });
          run.expectError(await run.call(run.peer, grantRoute, 'POST', { principal: run.third, role: 'viewer' }), 403, 'forbidden', 'collaborator downgrading a driver');
          run.expectError(await run.call(run.peer, ORG_ROUTES.sessionGrant(id, run.third), 'DELETE'), 403, 'forbidden', 'collaborator revoking a driver they did not grant');
        }),
    },
    {
      name: 'sessions: a grantee outside the org gets 403 not-a-member',
      run: (context) =>
        withSessions(context, ['sessions'], async (run) => {
          const outsider = context.nonMemberPrincipal;
          if (!outsider) return;
          const { id } = await run.upload();
          const answer = await run.call(run.owner, ORG_ROUTES.sessionGrants(id), 'POST', { principal: outsider, role: 'viewer' });
          run.expectError(answer, 403, 'not-a-member', 'grant to a non-member');
          run.expectError(await run.call(outsider, ORG_ROUTES.session(id)), 403, 'not-a-member', 'session read by a non-member');
          const view = parseOrgSessionView((await run.call(run.owner, ORG_ROUTES.session(id))).body);
          check(!view.grants?.some((entry) => entry.principal === outsider), 'a refused grant must not be stored');
        }),
    },
    {
      name: 'sessions: the list is filtered by principal and workspace, and revoking ends access',
      run: (context) =>
        withSessions(context, ['sessions'], async (run) => {
          const { id } = await run.upload();
          const listFor = async (principal: UserPrincipal, query = '') =>
            parseOrgSessionPage((await run.call(principal, `${ORG_ROUTES.sessions}?limit=100${query}`)).body).sessions;
          check((await listFor(run.owner)).some((view) => view.session.id === id && view.role === 'owner'), 'the owner must see their session');
          check(!(await listFor(run.peer)).some((view) => view.session.id === id), 'a non-grantee must not see the session');
          await run.call(run.owner, ORG_ROUTES.sessionGrants(id), 'POST', { principal: run.peer, role: 'driver' });
          const seen = (await listFor(run.peer)).find((view) => view.session.id === id);
          check(seen?.role === 'driver' && seen.grants === undefined, 'a grantee must see the session with their role and no grant list');
          check(!(await listFor(run.third)).some((view) => view.session.id === id), 'an ungranted third member must not see the session');
          const owned = await listFor(run.owner);
          const workspace = owned.find((view) => view.session.id === id)!.session.workspaceId;
          check((await listFor(run.owner, `&workspace=${encodeURIComponent(workspace)}`)).some((view) => view.session.id === id), 'workspace filter dropped a matching session');
          check(!(await listFor(run.owner, '&workspace=ws:conformance-no-such-workspace')).some((view) => view.session.id === id), 'workspace filter kept a non-matching session');
          const revoked = await run.call(run.owner, ORG_ROUTES.sessionGrant(id, run.peer), 'DELETE');
          check(revoked.status === 204, `revoke answered ${revoked.status}, expected 204`);
          run.expectError(await run.call(run.peer, ORG_ROUTES.session(id)), 404, 'not-found', 'read after revoke');
          run.expectError(await run.call(run.owner, ORG_ROUTES.sessionGrant(id, run.peer), 'DELETE'), 404, 'not-found', 'second revoke');
        }),
    },
    {
      name: 'sessions: transcript pages are capped and paged by cursor',
      run: (context) =>
        withSessions(context, ['sessions'], async (run) => {
          const { id } = await run.upload();
          const route = ORG_ROUTES.sessionTranscript(id);
          const total = MAX_TRANSCRIPT_PAGE_MESSAGES + 50;
          const first = Array.from({ length: MAX_TRANSCRIPT_PAGE_MESSAGES }, (_, index) => message(index));
          const second = Array.from({ length: 50 }, (_, index) => message(MAX_TRANSCRIPT_PAGE_MESSAGES + index));
          check((await run.call(run.owner, route, 'PUT', { mode: 'replace', messages: first })).status === 200, 'a full page of messages was refused');
          check((await run.call(run.owner, route, 'PUT', { mode: 'append', messages: second, expectedCount: first.length })).status === 200, 'append was refused');
          run.expectError(await run.call(run.owner, route, 'PUT', { mode: 'append', messages: [message(999)], expectedCount: 1 }), 409, 'conflict', 'append with a stale count');
          run.expectError(
            await run.call(run.owner, route, 'PUT', { mode: 'append', messages: Array.from({ length: MAX_TRANSCRIPT_PAGE_MESSAGES + 1 }, (_, index) => message(index)) }),
            413,
            'too-large',
            'too many messages in one write',
          );
          run.expectError(
            await run.call(run.owner, route, 'PUT', { mode: 'append', messages: [message(0, 'x'.repeat(64 * 1024 + 1))] }),
            413,
            'too-large',
            'an oversized message',
          );
          const heavy = Array.from({ length: Math.ceil(MAX_TRANSCRIPT_PAGE_BYTES / (60 * 1024)) + 1 }, (_, index) => message(index, 'y'.repeat(60 * 1024)));
          run.expectError(await run.call(run.owner, route, 'PUT', { mode: 'append', messages: heavy }), 413, 'too-large', 'too many bytes in one write');
          const collected: OrgTranscriptMessage[] = [];
          let cursor: string | undefined;
          for (let guard = 0; guard < 20; guard += 1) {
            const query = cursor ? `?cursor=${encodeURIComponent(cursor)}` : '';
            const answer = await run.call(run.owner,`${route}${query}`);
            check(answer.status === 200, `transcript read answered ${answer.status}, expected 200`);
            const page = parseOrgTranscriptPage(answer.body);
            check(page.messages.length <= MAX_TRANSCRIPT_PAGE_MESSAGES, 'a transcript page exceeded the message cap');
            check(page.total === total, 'transcript total is wrong');
            collected.push(...page.messages);
            cursor = page.nextCursor;
            if (!cursor) break;
          }
          check(!cursor, 'paging by cursor never finished');
          check(collected.length === total && collected.every((entry, index) => entry.text === message(index).text), 'paging lost or reordered messages');
          const limited = parseOrgTranscriptPage((await run.call(run.owner, `${route}?limit=5`)).body);
          check(limited.messages.length === 5 && limited.nextCursor !== undefined, 'limit=5 must return 5 messages and a cursor');
        }),
    },
    {
      name: 'notifications: a mention notifies the mentioned user only',
      run: (context) =>
        withSessions(context, ['sessions', 'mentions', 'notifications'], async (run) => {
          const { id } = await run.upload();
          const unreadFor = async (principal: UserPrincipal) =>
            parseOrgNotificationPage((await run.call(principal, `${ORG_ROUTES.notifications}?unread=true&limit=100`)).body).notifications.filter((entry) => entry.sessionId === id);
          const answer = await run.call(run.owner, ORG_ROUTES.sessionGrants(id), 'POST', {
            principal: run.peer,
            role: 'collaborator',
            mention: { note: 'please look' },
          });
          check(answer.status === 200, `grant with mention answered ${answer.status}, expected 200`);
          const result = parseOrgGrantResult(answer.body);
          check(result.mention?.to === run.peer && result.mention.from === run.owner && result.mention.note === 'please look', 'mention record is wrong');
          const mine = await unreadFor(run.peer);
          check(mine.length === 1 && mine[0]!.kind === 'mention' && mine[0]!.from === run.owner && !mine[0]!.read, 'the mentioned user must get one unread mention');
          check(mine[0]!.id === result.notificationId, 'notificationId in the grant result must match the notification');
          check((await unreadFor(run.owner)).length === 0, 'the mentioner must not be notified');
          check((await unreadFor(run.third)).length === 0, 'another member must not be notified');
          run.expectError(await run.call(run.third, ORG_ROUTES.notificationRead(mine[0]!.id), 'POST'), 404, 'not-found', "marking someone else's notification read");
          const read = await run.call(run.peer, ORG_ROUTES.notificationRead(mine[0]!.id), 'POST');
          check(read.status === 200 && parseOrgNotification(read.body).read, 'marking a notification read must return it as read');
          check((await unreadFor(run.peer)).length === 0, 'a read notification must leave the unread list');
          const all = parseOrgNotificationPage((await run.call(run.peer, `${ORG_ROUTES.notifications}?unread=false&limit=100`)).body);
          check(all.notifications.some((entry) => entry.id === mine[0]!.id), 'unread=false must list read notifications');
          await run.call(run.owner, ORG_ROUTES.sessionGrants(id), 'POST', { principal: run.third, role: 'viewer', notify: true });
          const shared = await unreadFor(run.third);
          check(shared.length === 1 && shared[0]!.kind === 'share', 'notify must create a share notification');
          const silent = await run.call(run.owner, ORG_ROUTES.sessionGrants(id), 'POST', { principal: run.third, role: 'collaborator' });
          check(silent.status === 200 && parseOrgGrantResult(silent.body).notificationId === undefined, 'a grant without mention or notify must not notify');
          check((await unreadFor(run.third)).length === 1, 'a silent grant must not add a notification');
        }),
    },
  ];
}

const sleep = (ms: number) => new Promise<void>((resolve) => setTimeout(resolve, ms));

function leaseConformanceCases(): OrgProviderConformanceCase[] {
  const view = (answer: Answer, label: string): OrgLeaseView => {
    check(answer.status === 200, `${label} answered ${answer.status}, expected 200`);
    return parseOrgLeaseView(answer.body);
  };
  return [
    {
      name: 'leases: acquire, a held lease answers 409 lease-held with holder and expiry, and a free session reads as null',
      run: (context) =>
        withSessions(context, ['sessions', 'leases'], async (run) => {
          const { id } = await run.upload();
          check(view(await run.call(run.owner, ORG_ROUTES.sessionLease(id)), 'read of a free lease').lease === null, 'a never-held session must have no lease');
          const first = view(await run.call(run.owner, ORG_ROUTES.sessionLease(id), 'POST', { host: 'host-a', ttlSeconds: 30 }), 'acquire');
          check(first.lease?.holder.host === 'host-a' && first.lease.holder.principal === run.owner, 'the lease must name the acquiring host and principal');
          check(Date.parse(first.lease.expiresAt) > Date.parse(first.lease.acquiredAt), 'expiresAt must be after acquiredAt');
          check(first.lease.heartbeatIntervalSeconds >= 1, 'heartbeatIntervalSeconds must be at least 1');
          await run.call(run.owner, ORG_ROUTES.sessionGrants(id), 'POST', { principal: run.peer, role: 'driver' });
          const held = await run.call(run.peer, ORG_ROUTES.sessionLease(id), 'POST', { host: 'host-b' });
          check(held.status === 409, `acquire of a held lease answered ${held.status}, expected 409`);
          const body = held.body as { error?: unknown; holder?: { host?: unknown; principal?: unknown }; expiresAt?: unknown };
          check(body.error === 'lease-held', 'a held lease must answer "lease-held"');
          check(body.holder?.host === 'host-a' && body.holder.principal === run.owner, 'lease-held must carry the holder');
          check(body.expiresAt === first.lease.expiresAt, 'lease-held must carry the expiry');
          check(Object.keys(body).sort().join() === 'error,expiresAt,holder', 'lease-held must carry only error, holder and expiresAt');
          check(view(await run.call(run.peer, ORG_ROUTES.sessionLease(id)), 'read by a driver').lease?.holder.host === 'host-a', 'a reader must see the holder');
          const again = view(await run.call(run.owner, ORG_ROUTES.sessionLease(id), 'POST', { host: 'host-a' }), 'acquire again by the holder');
          check(again.lease?.holder.host === 'host-a', 'the holder acquiring again must keep the lease');
        }),
    },
    {
      name: 'leases: a heartbeat renews the lease and only the holder may send it',
      run: (context) =>
        withSessions(context, ['sessions', 'leases'], async (run) => {
          const { id } = await run.upload();
          const first = view(await run.call(run.owner, ORG_ROUTES.sessionLease(id), 'POST', { host: 'host-a', ttlSeconds: 30 }), 'acquire');
          await sleep(30);
          const renewed = view(await run.call(run.owner, ORG_ROUTES.sessionLeaseHeartbeat(id), 'POST', { host: 'host-a' }), 'heartbeat');
          check(renewed.lease !== null && Date.parse(renewed.lease.expiresAt) > Date.parse(first.lease!.expiresAt), 'a heartbeat must push expiresAt out');
          run.expectError(await run.call(run.owner, ORG_ROUTES.sessionLeaseHeartbeat(id), 'POST', { host: 'host-other' }), 410, 'lease-lost', 'heartbeat from another host');
          await run.call(run.owner, ORG_ROUTES.sessionGrants(id), 'POST', { principal: run.peer, role: 'driver' });
          run.expectError(await run.call(run.peer, ORG_ROUTES.sessionLeaseHeartbeat(id), 'POST', { host: 'host-a' }), 410, 'lease-lost', 'heartbeat from another principal');
        }),
    },
    {
      name: 'leases: a lease without heartbeat expires and frees the session',
      run: (context) =>
        withSessions(context, ['sessions', 'leases'], async (run) => {
          const { id } = await run.upload();
          await run.call(run.owner, ORG_ROUTES.sessionGrants(id), 'POST', { principal: run.peer, role: 'driver' });
          view(await run.call(run.owner, ORG_ROUTES.sessionLease(id), 'POST', { host: 'host-a', ttlSeconds: 1 }), 'acquire with a 1 second ttl');
          await sleep(1200);
          check(view(await run.call(run.owner, ORG_ROUTES.sessionLease(id)), 'read after expiry').lease === null, 'an expired lease must read as free');
          run.expectError(await run.call(run.owner, ORG_ROUTES.sessionLeaseHeartbeat(id), 'POST', { host: 'host-a' }), 410, 'lease-lost', 'heartbeat after expiry');
          const taken = view(await run.call(run.peer, ORG_ROUTES.sessionLease(id), 'POST', { host: 'host-b' }), 'acquire after expiry');
          check(taken.lease?.holder.principal === run.peer, 'an expired lease must be free to acquire');
        }),
    },
    {
      name: 'leases: handover request, release with a checkpoint, then acquire',
      run: (context) =>
        withSessions(context, ['sessions', 'leases'], async (run) => {
          const { id } = await run.upload();
          await run.call(run.owner, ORG_ROUTES.sessionGrants(id), 'POST', { principal: run.peer, role: 'driver' });
          run.expectError(await run.call(run.peer, ORG_ROUTES.sessionLeaseHandover(id), 'POST', { host: 'host-b' }), 409, 'lease-free', 'handover of a free lease');
          view(await run.call(run.owner, ORG_ROUTES.sessionLease(id), 'POST', { host: 'host-a', ttlSeconds: 30 }), 'acquire');
          const asked = view(await run.call(run.peer, ORG_ROUTES.sessionLeaseHandover(id), 'POST', { host: 'host-b', note: 'taking over' }), 'handover request');
          check(asked.handoverRequest?.requestedBy.principal === run.peer && asked.handoverRequest.requestedBy.host === 'host-b', 'the handover request must name the requester');
          const seen = view(await run.call(run.owner, ORG_ROUTES.sessionLeaseHeartbeat(id), 'POST', { host: 'host-a' }), 'heartbeat with a pending handover');
          check(seen.handoverRequest?.requestedBy.host === 'host-b', 'the holder must see the handover request on its heartbeat');
          if (orgSupports(run.document, 'notifications')) {
            const page = parseOrgNotificationPage((await run.call(run.owner, `${ORG_ROUTES.notifications}?unread=true&limit=100`)).body);
            check(
              page.notifications.some((entry) => entry.kind === 'handover-request' && entry.sessionId === id && entry.from === run.peer),
              'the holder must get a handover-request notification',
            );
          }
          const early = await run.call(run.peer, ORG_ROUTES.sessionLease(id), 'POST', { host: 'host-b' });
          check(early.status === 409 && (early.body as { error?: unknown }).error === 'lease-held', 'the requester cannot acquire before the holder releases');
          const released = view(
            await run.call(run.owner, ORG_ROUTES.sessionLeaseRelease(id), 'POST', { host: 'host-a', checkpoint: { messageCount: 7, stateRef: 'state-1' } }),
            'release',
          );
          check(released.lease === null, 'a released lease must read as free');
          check(released.checkpoint?.messageCount === 7 && released.checkpoint.stateRef === 'state-1', 'release must keep the checkpoint');
          const taken = view(await run.call(run.peer, ORG_ROUTES.sessionLease(id), 'POST', { host: 'host-b' }), 'acquire after release');
          check(taken.lease?.holder.host === 'host-b', 'the requester must acquire the released lease');
          check(taken.checkpoint?.messageCount === 7 && taken.checkpoint.releasedBy.host === 'host-a', 'the new holder must see the previous checkpoint');
          check(taken.handoverRequest === undefined, 'a new lease must start without a handover request');
          run.expectError(await run.call(run.owner, ORG_ROUTES.sessionLeaseRelease(id), 'POST', { host: 'host-a' }), 410, 'lease-lost', 'release by the previous holder');
        }),
    },
    {
      name: 'leases: only the owner may force-take, and the previous holder sees lease-lost',
      run: (context) =>
        withSessions(context, ['sessions', 'leases'], async (run) => {
          const { id } = await run.upload();
          await run.call(run.owner, ORG_ROUTES.sessionGrants(id), 'POST', { principal: run.peer, role: 'driver' });
          view(await run.call(run.peer, ORG_ROUTES.sessionLease(id), 'POST', { host: 'host-b', ttlSeconds: 30 }), 'driver acquire');
          run.expectError(await run.call(run.peer, ORG_ROUTES.sessionLease(id), 'POST', { host: 'host-c', force: true }), 403, 'forbidden', 'force by a driver');
          const forced = view(await run.call(run.owner, ORG_ROUTES.sessionLease(id), 'POST', { host: 'host-a', force: true }), 'owner force');
          check(forced.lease?.holder.principal === run.owner && forced.lease.holder.host === 'host-a', 'the owner must hold the lease after force');
          run.expectError(await run.call(run.peer, ORG_ROUTES.sessionLeaseHeartbeat(id), 'POST', { host: 'host-b' }), 410, 'lease-lost', 'heartbeat after being forced out');
          view(await run.call(run.owner, ORG_ROUTES.sessionLeaseHeartbeat(id), 'POST', { host: 'host-a' }), 'heartbeat by the new holder');
        }),
    },
    {
      name: 'leases: a viewer or collaborator cannot acquire, and a lease grants no access',
      run: (context) =>
        withSessions(context, ['sessions', 'leases'], async (run) => {
          const { id } = await run.upload();
          await run.call(run.owner, ORG_ROUTES.sessionGrants(id), 'POST', { principal: run.peer, role: 'viewer' });
          run.expectError(await run.call(run.peer, ORG_ROUTES.sessionLease(id), 'POST', { host: 'host-b' }), 403, 'forbidden', 'acquire by a viewer');
          await run.call(run.owner, ORG_ROUTES.sessionGrants(id), 'POST', { principal: run.peer, role: 'collaborator' });
          run.expectError(await run.call(run.peer, ORG_ROUTES.sessionLease(id), 'POST', { host: 'host-b' }), 403, 'forbidden', 'acquire by a collaborator');
          run.expectError(await run.call(run.peer, ORG_ROUTES.sessionLeaseHandover(id), 'POST', { host: 'host-b' }), 403, 'forbidden', 'handover by a collaborator');
          view(await run.call(run.owner, ORG_ROUTES.sessionLease(id), 'POST', { host: 'host-a', ttlSeconds: 30 }), 'owner acquire');
          run.expectError(await run.call(run.third, ORG_ROUTES.sessionLease(id)), 404, 'not-found', 'lease read without a grant');
          run.expectError(await run.call(run.third, ORG_ROUTES.sessionLease(id), 'POST', { host: 'host-c' }), 404, 'not-found', 'acquire without a grant');
          view(await run.call(run.peer, ORG_ROUTES.sessionLease(id)), 'read by a collaborator');
        }),
    },
    {
      name: 'leases: revoking the holder grant frees the lease',
      run: (context) =>
        withSessions(context, ['sessions', 'leases'], async (run) => {
          const { id } = await run.upload();
          await run.call(run.owner, ORG_ROUTES.sessionGrants(id), 'POST', { principal: run.peer, role: 'driver' });
          view(await run.call(run.peer, ORG_ROUTES.sessionLease(id), 'POST', { host: 'host-b', ttlSeconds: 30 }), 'driver acquire');
          check((await run.call(run.owner, ORG_ROUTES.sessionGrant(id, run.peer), 'DELETE')).status === 204, 'revoke must answer 204');
          check(view(await run.call(run.owner, ORG_ROUTES.sessionLease(id)), 'read after revoke').lease === null, 'revoking the holder must free the lease');
          run.expectError(await run.call(run.peer, ORG_ROUTES.sessionLeaseHeartbeat(id), 'POST', { host: 'host-b' }), 404, 'not-found', 'heartbeat after revoke');
        }),
    },
    {
      name: 'leases: an undeclared leases feature is not served',
      run: (context) =>
        withSessions(context, ['sessions'], async (run) => {
          if (orgSupports(run.document, 'leases')) return;
          const { id } = await run.upload();
          run.expectError(await run.call(run.owner, ORG_ROUTES.sessionLease(id)), 404, 'not-found', 'lease read');
          run.expectError(await run.call(run.owner, ORG_ROUTES.sessionLease(id), 'POST', { host: 'host-a' }), 404, 'not-found', 'lease acquire');
        }),
    },
  ];
}

type RawAnswer = { status: number; headers: Headers; bytes: Uint8Array; json: unknown };

async function rawCall(
  run: SessionsRun,
  principal: UserPrincipal,
  route: string,
  method: string,
  headers: Record<string, string>,
  body?: Uint8Array,
): Promise<RawAnswer> {
  const response = await run.context.fetch(apiUrl(run.document, route), {
    method,
    headers: { authorization: await run.auth(principal), ...headers },
    ...(body ? { body: body as never } : {}),
  });
  const bytes = new Uint8Array(await response.arrayBuffer());
  let json: unknown;
  if ((response.headers.get('content-type') ?? '').includes('json')) {
    try {
      json = JSON.parse(new TextDecoder().decode(bytes));
    } catch {
      json = undefined;
    }
  }
  return { status: response.status, headers: response.headers, bytes, json };
}

function rawError(answer: RawAnswer, status: number, code: string, label: string): void {
  check(answer.status === status, `${label} answered ${answer.status}, expected ${status}`);
  const body = answer.json as { error?: unknown } | undefined;
  check(typeof body === 'object' && body !== null && body.error === code, `${label}: expected error "${code}"`);
}

function envelopeHeaders(host: string, format: string, payload: Uint8Array, messages: number): Record<string, string> {
  return {
    'content-type': ENVELOPE_CONTENT_TYPE,
    'content-length': String(payload.length),
    [ENVELOPE_HEADERS.host]: host,
    [ENVELOPE_HEADERS.format]: format,
    [ENVELOPE_HEADERS.sha256]: sha256Hex(payload),
    [ENVELOPE_HEADERS.messages]: String(messages),
  };
}

const gz = (text: string): Uint8Array => new Uint8Array(gzipSync(Buffer.from(text)));
const OVERSIZE_TEST_LIMIT = 8 * 1024 * 1024;

function cloudConformanceCases(): OrgProviderConformanceCase[] {
  const features: OrgFeature[] = ['sessions', 'leases', 'cloudRuns'];
  const lease = (answer: Answer, label: string): OrgLeaseView => {
    check(answer.status === 200, `${label} answered ${answer.status}, expected 200`);
    return parseOrgLeaseView(answer.body);
  };
  const capabilities = async (run: SessionsRun): Promise<OrgCloudCapabilities> => {
    const answer = await run.call(run.owner, ORG_ROUTES.cloudCapabilities);
    check(answer.status === 200, `capabilities answered ${answer.status}, expected 200`);
    return parseOrgCloudCapabilities(answer.body);
  };
  const upload = async (run: SessionsRun, id: string, host: string, payload: Uint8Array, messages = 0): Promise<OrgEnvelopeInfo> => {
    const caps = await capabilities(run);
    const answer = await rawCall(run, run.owner, ORG_ROUTES.sessionEnvelope(id), 'PUT', envelopeHeaders(host, caps.formats[0]!, payload, messages), payload);
    check(answer.status === 200, `envelope upload answered ${answer.status}, expected 200`);
    return parseOrgEnvelopeInfo(answer.json);
  };
  const hold = async (run: SessionsRun, id: string, host = 'host-a') =>
    lease(await run.call(run.owner, ORG_ROUTES.sessionLease(id), 'POST', { host, ttlSeconds: 120 }), 'owner acquire');

  return [
    {
      name: 'cloudRuns: capabilities name the cloud host, formats and the size cap',
      run: (context) =>
        withSessions(context, features, async (run) => {
          const caps = await capabilities(run);
          check(caps.formats.length > 0 && caps.maxEnvelopeBytes >= 1, 'capabilities must list a format and a size cap');
          check((await run.call(run.third, ORG_ROUTES.cloudCapabilities)).status === 200, 'any member may read the capabilities');
          check((await run.call(undefined, ORG_ROUTES.cloudCapabilities)).status === 401, 'capabilities need a token');
        }),
    },
    {
      name: 'cloudRuns: only the lease holder uploads and downloads the envelope, and the bytes round-trip',
      run: (context) =>
        withSessions(context, features, async (run) => {
          const { id } = await run.upload();
          const payload = gz('native state one');
          run.expectError(await run.call(run.owner, ORG_ROUTES.sessionEnvelopeInfo(id)), 409, 'no-envelope', 'info before an upload');
          rawError(await rawCall(run, run.owner, ORG_ROUTES.sessionEnvelope(id), 'PUT', envelopeHeaders('host-a', (await capabilities(run)).formats[0]!, payload, 0), payload), 410, 'lease-lost', 'upload without the lease');
          await hold(run, id);
          const info = await upload(run, id, 'host-a', payload, 3);
          check(info.sha256 === sha256Hex(payload) && info.bytes === payload.length && info.messageCount === 3, 'info must describe the stored bytes');
          check(info.uploadedBy.host === 'host-a' && info.uploadedBy.principal === run.owner, 'info must name the uploader');
          const down = await rawCall(run, run.owner, ORG_ROUTES.sessionEnvelope(id), 'GET', { [ENVELOPE_HEADERS.host]: 'host-a' });
          check(down.status === 200 && down.headers.get(ENVELOPE_HEADERS.sha256) === info.sha256 && down.headers.get(ENVELOPE_HEADERS.messages) === '3', 'download headers must match the info');
          check(sha256Hex(down.bytes) === info.sha256 && down.bytes.length === payload.length, 'downloaded bytes differ from the uploaded ones');
          rawError(await rawCall(run, run.owner, ORG_ROUTES.sessionEnvelope(id), 'GET', { [ENVELOPE_HEADERS.host]: 'host-other' }), 409, 'lease-held', 'download from a host that is not the holder');
          await run.call(run.owner, ORG_ROUTES.sessionGrants(id), 'POST', { principal: run.peer, role: 'collaborator' });
          rawError(await rawCall(run, run.peer, ORG_ROUTES.sessionEnvelope(id), 'GET', { [ENVELOPE_HEADERS.host]: 'host-b' }), 403, 'forbidden', 'download by a collaborator');
          check((await run.call(run.peer, ORG_ROUTES.sessionEnvelopeInfo(id))).status === 200, 'a reader may see the envelope info');
          run.expectError(await run.call(run.third, ORG_ROUTES.sessionEnvelopeInfo(id)), 404, 'not-found', 'info without a grant');
          await run.call(run.owner, ORG_ROUTES.sessionLeaseRelease(id), 'POST', { host: 'host-a' });
          rawError(await rawCall(run, run.owner, ORG_ROUTES.sessionEnvelope(id), 'GET', { [ENVELOPE_HEADERS.host]: 'host-a' }), 409, 'lease-free', 'download without a lease');
        }),
    },
    {
      name: 'cloudRuns: the organization checks size, format, gzip and sha256, and stores nothing on failure',
      run: (context) =>
        withSessions(context, features, async (run) => {
          const { id } = await run.upload();
          await hold(run, id);
          const caps = await capabilities(run);
          const format = caps.formats[0]!;
          const payload = gz('integrity');
          const route = ORG_ROUTES.sessionEnvelope(id);
          const wrongSha = { ...envelopeHeaders('host-a', format, payload, 0), [ENVELOPE_HEADERS.sha256]: '0'.repeat(64) };
          rawError(await rawCall(run, run.owner, route, 'PUT', wrongSha, payload), 422, 'envelope-mismatch', 'upload with a wrong sha256');
          const plain = new TextEncoder().encode('not gzip at all');
          rawError(await rawCall(run, run.owner, route, 'PUT', envelopeHeaders('host-a', format, plain, 0), plain), 400, 'invalid-request', 'upload that is not gzip');
          rawError(await rawCall(run, run.owner, route, 'PUT', envelopeHeaders('host-a', 'no-such-format', payload, 0), payload), 415, 'unsupported-format', 'upload in an unsupported format');
          const noHeaders = envelopeHeaders('host-a', format, payload, 0);
          delete noHeaders[ENVELOPE_HEADERS.sha256];
          rawError(await rawCall(run, run.owner, route, 'PUT', noHeaders, payload), 400, 'invalid-request', 'upload without a sha256');
          if (caps.maxEnvelopeBytes < OVERSIZE_TEST_LIMIT) {
            const big = new Uint8Array(caps.maxEnvelopeBytes + 1);
            big[0] = 0x1f;
            big[1] = 0x8b;
            rawError(await rawCall(run, run.owner, route, 'PUT', envelopeHeaders('host-a', format, big, 0), big), 413, 'envelope-too-large', 'upload above the advertised cap');
          }
          run.expectError(await run.call(run.owner, ORG_ROUTES.sessionEnvelopeInfo(id)), 409, 'no-envelope', 'info after refused uploads');
        }),
    },
    {
      name: 'cloudRuns: moving to the cloud hands over the lease and the transcript stays with the cloud host',
      run: (context) =>
        withSessions(context, features, async (run) => {
          const { id } = await run.upload();
          const caps = await capabilities(run);
          const path = ORG_ROUTES.sessionCloudRuns(id);
          run.expectError(await run.call(run.owner, path, 'POST', { host: 'host-a', envelopeSha256: 'a'.repeat(64) }), 410, 'lease-lost', 'move without the lease');
          await hold(run, id);
          run.expectError(await run.call(run.owner, path, 'POST', { host: 'host-a', envelopeSha256: 'a'.repeat(64) }), 409, 'no-envelope', 'move without an uploaded envelope');
          const info = await upload(run, id, 'host-a', gz('before the move'), 0);
          run.expectError(await run.call(run.owner, path, 'POST', { host: 'host-a', envelopeSha256: 'b'.repeat(64) }), 422, 'envelope-mismatch', 'move naming another envelope');
          run.expectError(await run.call(run.owner, ORG_ROUTES.sessionLease(id), 'POST', { host: caps.cloudHost, force: true }), 403, 'forbidden', 'taking the cloud host id');
          const started = answerStarted(await run.call(run.owner, path, 'POST', { host: 'host-a', envelopeSha256: info.sha256, instruction: 'run the tests' }));
          check(started.run.sessionId === id && (started.run.status === 'starting' || started.run.status === 'running'), 'the run must be starting or running');
          check(started.lease.lease !== null && isCloudHostId(started.lease.lease.holder.host, caps.cloudHost) && started.lease.lease.holder.principal === run.owner, 'the cloud host must hold the lease for the mover');
          const seen = lease(await run.call(run.owner, ORG_ROUTES.sessionLease(id)), 'lease read after the move');
          check(seen.lease !== null && isCloudHostId(seen.lease.holder.host, caps.cloudHost), 'a reader must see the cloud host as holder');
          run.expectError(await run.call(run.owner, ORG_ROUTES.sessionLeaseHeartbeat(id), 'POST', { host: 'host-a' }), 410, 'lease-lost', 'desktop heartbeat after the move');
          const held = await run.call(run.owner, ORG_ROUTES.sessionTranscript(id), 'PUT', { mode: 'append', messages: [message(0)] });
          check(held.status === 409 && (held.body as { error?: unknown }).error === 'lease-held', 'the owner must not write the transcript while the cloud holds the lease');
          const runView = parseOrgCloudRunView((await run.call(run.owner, ORG_ROUTES.sessionCloudRun(id))).body);
          check(runView.run?.id === started.run.id, 'a reader sees the latest run');
          run.expectError(await run.call(run.third, ORG_ROUTES.sessionCloudRun(id)), 404, 'not-found', 'run read without a grant');
        }),
    },
    {
      name: 'cloudRuns: continue here: handover, cloud release with a checkpoint that names the envelope, acquire, download',
      run: (context) =>
        withSessions(context, features, async (run) => {
          const advance = context.advanceCloudRun;
          if (!advance) return;
          const { id } = await run.upload();
          const caps = await capabilities(run);
          await hold(run, id);
          const first = await upload(run, id, 'host-a', gz('state at move'), 0);
          answerStarted(await run.call(run.owner, ORG_ROUTES.sessionCloudRuns(id), 'POST', { host: 'host-a', envelopeSha256: first.sha256, instruction: 'continue' }));
          await advance(id);
          check(lease(await run.call(run.owner, ORG_ROUTES.sessionLease(id)), 'lease while the cloud runs').lease?.holder.host.startsWith(caps.cloudHost) === true, 'the cloud must keep the lease until a safe point');
          const asked = lease(await run.call(run.owner, ORG_ROUTES.sessionLeaseHandover(id), 'POST', { host: 'host-a', note: 'continue here' }), 'handover request');
          check(asked.handoverRequest?.requestedBy.host === 'host-a', 'the cloud holder must see the handover request');
          await advance(id);
          const freed = lease(await run.call(run.owner, ORG_ROUTES.sessionLease(id)), 'lease after the cloud released');
          check(freed.lease === null && freed.checkpoint !== undefined && isCloudHostId(freed.checkpoint.releasedBy.host, caps.cloudHost), 'the cloud must release with a checkpoint');
          check(parseOrgCloudRunView((await run.call(run.owner, ORG_ROUTES.sessionCloudRun(id))).body).run?.status === 'released', 'a run the cloud released must read as released');
          lease(await run.call(run.owner, ORG_ROUTES.sessionLease(id), 'POST', { host: 'host-a', ttlSeconds: 120 }), 'desktop acquire');
          const info = parseOrgEnvelopeInfo((await run.call(run.owner, ORG_ROUTES.sessionEnvelopeInfo(id))).body);
          const transcript = parseOrgTranscriptPage((await run.call(run.owner, ORG_ROUTES.sessionTranscript(id))).body);
          const verdict = checkEnvelopeAgainstCheckpoint({ envelope: info, checkpoint: freed.checkpoint, cloudHost: caps.cloudHost, transcriptMessageCount: transcript.total });
          check(verdict.status === 'fresh' && info.sha256 !== first.sha256, `the envelope must match the cloud checkpoint (${JSON.stringify(verdict)})`);
          const down = await rawCall(run, run.owner, ORG_ROUTES.sessionEnvelope(id), 'GET', { [ENVELOPE_HEADERS.host]: 'host-a' });
          check(down.status === 200 && sha256Hex(down.bytes) === freed.checkpoint?.stateRef?.slice('sha256:'.length), 'the downloaded envelope must hash to the checkpoint stateRef');
        }),
    },
    {
      name: 'cloudRuns: a user token can never act as the cloud host on a lease, envelope or cloud-run route',
      run: (context) =>
        withSessions(context, features, async (run) => {
          const { id } = await run.upload();
          const caps = await capabilities(run);
          const forged = [caps.cloudHost, `${caps.cloudHost}:run-1`];
          const payload = gz('forged by a desktop');
          await hold(run, id);
          const real = await upload(run, id, 'host-a', gz('real state'), 0);
          for (const host of forged) {
            rawError(await rawCall(run, run.owner, ORG_ROUTES.sessionEnvelope(id), 'PUT', envelopeHeaders(host, caps.formats[0]!, payload, 0), payload), 403, 'forbidden', `upload as ${host}`);
            run.expectError(await run.call(run.owner, ORG_ROUTES.sessionLeaseHeartbeat(id), 'POST', { host }), 403, 'forbidden', `heartbeat as ${host}`);
            run.expectError(await run.call(run.owner, ORG_ROUTES.sessionLeaseRelease(id), 'POST', { host }), 403, 'forbidden', `release as ${host}`);
            run.expectError(await run.call(run.owner, ORG_ROUTES.sessionLeaseHandover(id), 'POST', { host }), 403, 'forbidden', `handover request as ${host}`);
            run.expectError(await run.call(run.owner, ORG_ROUTES.sessionLease(id), 'POST', { host }), 403, 'forbidden', `acquire as ${host}`);
            run.expectError(await run.call(run.owner, ORG_ROUTES.sessionCloudRuns(id), 'POST', { host, envelopeSha256: real.sha256 }), 403, 'forbidden', `move as ${host}`);
            rawError(await rawCall(run, run.owner, ORG_ROUTES.sessionEnvelope(id), 'GET', { [ENVELOPE_HEADERS.host]: host }), 403, 'forbidden', `download as ${host}`);
          }
          answerStarted(await run.call(run.owner, ORG_ROUTES.sessionCloudRuns(id), 'POST', { host: 'host-a', envelopeSha256: real.sha256 }));
          const holder = lease(await run.call(run.owner, ORG_ROUTES.sessionLease(id)), 'lease after the move').lease!.holder;
          check(isCloudHostId(holder.host, caps.cloudHost), 'the cloud host must hold the lease after the move');
          for (const host of [...forged, holder.host]) {
            const forgedState = envelopeHeaders(host, caps.formats[0]!, payload, 0);
            rawError(await rawCall(run, run.owner, ORG_ROUTES.sessionEnvelope(id), 'PUT', forgedState, payload), 403, 'forbidden', `upload as ${host} while the cloud runs`);
            run.expectError(await run.call(run.owner, ORG_ROUTES.sessionLeaseHeartbeat(id), 'POST', { host }), 403, 'forbidden', `heartbeat as ${host} while the cloud runs`);
            run.expectError(
              await run.call(run.owner, ORG_ROUTES.sessionLeaseRelease(id), 'POST', { host, checkpoint: { messageCount: 99, stateRef: envelopeStateRef(sha256Hex(payload)) } }),
              403,
              'forbidden',
              `release as ${host} while the cloud runs`,
            );
            rawError(await rawCall(run, run.owner, ORG_ROUTES.sessionEnvelope(id), 'GET', { [ENVELOPE_HEADERS.host]: host }), 403, 'forbidden', `download as ${host} while the cloud runs`);
          }
          const after = lease(await run.call(run.owner, ORG_ROUTES.sessionLease(id)), 'lease after the forgery attempts');
          check(after.lease?.holder.host === holder.host && after.checkpoint === undefined, 'forgery attempts must change neither the holder nor the checkpoint');
          const info = parseOrgEnvelopeInfo((await run.call(run.owner, ORG_ROUTES.sessionEnvelopeInfo(id))).body);
          check(info.sha256 === real.sha256, 'forgery attempts must not replace the stored envelope');
        }),
    },
    {
      name: 'cloudRuns: a move needs an envelope the current holder uploaded during the current lease',
      run: (context) =>
        withSessions(context, features, async (run) => {
          const { id } = await run.upload();
          await hold(run, id, 'host-a');
          const old = await upload(run, id, 'host-a', gz('uploaded in an earlier lease'), 0);
          await run.call(run.owner, ORG_ROUTES.sessionLeaseRelease(id), 'POST', { host: 'host-a' });
          await hold(run, id, 'host-b');
          run.expectError(await run.call(run.owner, ORG_ROUTES.sessionCloudRuns(id), 'POST', { host: 'host-b', envelopeSha256: old.sha256 }), 422, 'envelope-mismatch', 'move with another lease\'s envelope');
          check(lease(await run.call(run.owner, ORG_ROUTES.sessionLease(id)), 'lease after the refused move').lease?.holder.host === 'host-b', 'a refused move must leave the lease alone');
          const fresh = await upload(run, id, 'host-b', gz('uploaded in this lease'), 0);
          answerStarted(await run.call(run.owner, ORG_ROUTES.sessionCloudRuns(id), 'POST', { host: 'host-b', envelopeSha256: fresh.sha256 }));
        }),
    },
    {
      name: 'cloudRuns: a handover request pending on the desktop lease is dropped when the move replaces it',
      run: (context) =>
        withSessions(context, features, async (run) => {
          const { id } = await run.upload();
          await run.call(run.owner, ORG_ROUTES.sessionGrants(id), 'POST', { principal: run.peer, role: 'driver' });
          await hold(run, id);
          const asked = lease(await run.call(run.peer, ORG_ROUTES.sessionLeaseHandover(id), 'POST', { host: 'host-b' }), 'handover request');
          check(asked.handoverRequest?.requestedBy.host === 'host-b', 'the holder must see the pending request');
          const info = await upload(run, id, 'host-a', gz('state'), 0);
          const started = answerStarted(await run.call(run.owner, ORG_ROUTES.sessionCloudRuns(id), 'POST', { host: 'host-a', envelopeSha256: info.sha256 }));
          check(started.lease.handoverRequest === undefined, 'the move must drop the pending handover request');
          check(lease(await run.call(run.owner, ORG_ROUTES.sessionLease(id)), 'lease read').handoverRequest === undefined, 'a later read must not show the dropped request either');
        }),
    },
    {
      name: 'cloudRuns: cloud-unavailable refuses the move and leaves the desktop lease and run alone',
      run: (context) =>
        withSessions(context, features, async (run) => {
          const toggle = context.setCloudAvailable;
          if (!toggle) return;
          const { id } = await run.upload();
          await hold(run, id);
          const info = await upload(run, id, 'host-a', gz('state'), 0);
          await toggle(false);
          try {
            check((await capabilities(run)).available === false, 'capabilities must report the cloud as unavailable');
            run.expectError(await run.call(run.owner, ORG_ROUTES.sessionCloudRuns(id), 'POST', { host: 'host-a', envelopeSha256: info.sha256 }), 503, 'cloud-unavailable', 'move while unavailable');
            check(lease(await run.call(run.owner, ORG_ROUTES.sessionLease(id)), 'lease after 503').lease?.holder.host === 'host-a', 'the desktop must keep its lease');
            check(parseOrgCloudRunView((await run.call(run.owner, ORG_ROUTES.sessionCloudRun(id))).body).run === null, 'a refused move must not create a run');
            check((await run.call(run.owner, ORG_ROUTES.sessionLeaseHeartbeat(id), 'POST', { host: 'host-a' })).status === 200, 'the desktop must still heartbeat');
          } finally {
            await toggle(true);
          }
          answerStarted(await run.call(run.owner, ORG_ROUTES.sessionCloudRuns(id), 'POST', { host: 'host-a', envelopeSha256: info.sha256 }));
        }),
    },
    {
      name: 'cloudRuns: an owner force against the cloud fails the run with lease-forced',
      run: (context) =>
        withSessions(context, features, async (run) => {
          const { id } = await run.upload();
          await hold(run, id);
          const info = await upload(run, id, 'host-a', gz('state'), 0);
          const started = answerStarted(await run.call(run.owner, ORG_ROUTES.sessionCloudRuns(id), 'POST', { host: 'host-a', envelopeSha256: info.sha256 }));
          const forced = lease(await run.call(run.owner, ORG_ROUTES.sessionLease(id), 'POST', { host: 'host-a2', force: true }), 'owner force');
          check(forced.lease?.holder.host === 'host-a2', 'the owner must hold the lease after the force');
          const view = parseOrgCloudRunView((await run.call(run.owner, ORG_ROUTES.sessionCloudRun(id))).body).run;
          check(view?.id === started.run.id && view.status === 'failed' && view.error === 'lease-forced' && view.finishedAt !== undefined, `the run must be failed with lease-forced (got ${JSON.stringify(view)})`);
        }),
    },
    {
      name: 'cloudRuns: revoking the grant of the person the cloud runs for fails the run with lease-revoked',
      run: (context) =>
        withSessions(context, features, async (run) => {
          const { id } = await run.upload();
          await run.call(run.owner, ORG_ROUTES.sessionGrants(id), 'POST', { principal: run.peer, role: 'driver' });
          check(lease(await run.call(run.peer, ORG_ROUTES.sessionLease(id), 'POST', { host: 'host-b', ttlSeconds: 120 }), 'driver acquire').lease !== null, 'the driver must hold the lease');
          const caps = await capabilities(run);
          const payload = gz('driver state');
          const put = await rawCall(run, run.peer, ORG_ROUTES.sessionEnvelope(id), 'PUT', envelopeHeaders('host-b', caps.formats[0]!, payload, 0), payload);
          check(put.status === 200, `driver upload answered ${put.status}, expected 200`);
          answerStarted(await run.call(run.peer, ORG_ROUTES.sessionCloudRuns(id), 'POST', { host: 'host-b', envelopeSha256: sha256Hex(payload) }));
          check((await run.call(run.owner, ORG_ROUTES.sessionGrant(id, run.peer), 'DELETE')).status === 204, 'revoke must answer 204');
          const view = parseOrgCloudRunView((await run.call(run.owner, ORG_ROUTES.sessionCloudRun(id))).body).run;
          check(view?.status === 'failed' && view.error === 'lease-revoked', `the run must be failed with lease-revoked (got ${JSON.stringify(view)})`);
          check(lease(await run.call(run.owner, ORG_ROUTES.sessionLease(id)), 'lease after revoke').lease === null, 'the lease must be free');
        }),
    },
    {
      name: 'cloudRuns: a cloud that dies mid-turn fails the run with lease-expired and the envelope is older than the transcript',
      run: (context) =>
        withSessions(context, features, async (run) => {
          const { advanceCloudRun: advance, crashCloudRun: crash } = context;
          if (!advance || !crash) return;
          const { id } = await run.upload();
          const caps = await capabilities(run);
          await hold(run, id);
          const info = await upload(run, id, 'host-a', gz('state at move'), 0);
          const started = answerStarted(await run.call(run.owner, ORG_ROUTES.sessionCloudRuns(id), 'POST', { host: 'host-a', envelopeSha256: info.sha256 }));
          await advance(id, { uploadEnvelope: false });
          await crash(id);
          const view = parseOrgCloudRunView((await run.call(run.owner, ORG_ROUTES.sessionCloudRun(id))).body).run;
          check(view?.id === started.run.id && view.status === 'failed' && view.error === 'lease-expired' && view.finishedAt !== undefined, `the run must be failed with lease-expired (got ${JSON.stringify(view)})`);
          const freed = lease(await run.call(run.owner, ORG_ROUTES.sessionLease(id)), 'lease after the crash');
          check(freed.lease === null && freed.checkpoint === undefined, 'a crashed cloud leaves a free lease and no checkpoint');
          lease(await run.call(run.owner, ORG_ROUTES.sessionLease(id), 'POST', { host: 'host-a', ttlSeconds: 120 }), 'desktop acquire after the crash');
          const stored = parseOrgEnvelopeInfo((await run.call(run.owner, ORG_ROUTES.sessionEnvelopeInfo(id))).body);
          const transcript = parseOrgTranscriptPage((await run.call(run.owner, ORG_ROUTES.sessionTranscript(id))).body);
          check(transcript.total > stored.messageCount, 'the transcript must have grown past the envelope');
          const verdict = checkEnvelopeAgainstCheckpoint({ envelope: stored, checkpoint: freed.checkpoint, cloudHost: caps.cloudHost, transcriptMessageCount: transcript.total });
          check(verdict.status === 'stale', `the desktop must see a stale envelope (got ${JSON.stringify(verdict)})`);
        }),
    },
    {
      name: 'cloudRuns: a release whose checkpoint stateRef names another envelope is refused',
      run: (context) =>
        withSessions(context, features, async (run) => {
          const { id } = await run.upload();
          await hold(run, id);
          const info = await upload(run, id, 'host-a', gz('release guard'), 0);
          run.expectError(
            await run.call(run.owner, ORG_ROUTES.sessionLeaseRelease(id), 'POST', { host: 'host-a', checkpoint: { messageCount: 0, stateRef: envelopeStateRef('c'.repeat(64)) } }),
            422,
            'envelope-mismatch',
            'release naming another envelope',
          );
          const ok = lease(await run.call(run.owner, ORG_ROUTES.sessionLeaseRelease(id), 'POST', { host: 'host-a', checkpoint: { messageCount: 0, stateRef: envelopeStateRef(info.sha256) } }), 'release naming the envelope');
          check(ok.lease === null, 'a matching release must free the lease');
        }),
    },
    {
      name: 'cloudRuns: an undeclared cloudRuns feature is not served',
      run: (context) =>
        withSessions(context, ['sessions', 'leases'], async (run) => {
          if (orgSupports(run.document, 'cloudRuns')) return;
          const { id } = await run.upload();
          run.expectError(await run.call(run.owner, ORG_ROUTES.cloudCapabilities), 404, 'not-found', 'capabilities');
          run.expectError(await run.call(run.owner, ORG_ROUTES.sessionEnvelopeInfo(id)), 404, 'not-found', 'envelope info');
          run.expectError(await run.call(run.owner, ORG_ROUTES.sessionCloudRuns(id), 'POST', { host: 'h', envelopeSha256: 'a'.repeat(64) }), 404, 'not-found', 'move to cloud');
        }),
    },
  ];

  function answerStarted(answer: Answer): OrgCloudRunStarted {
    check(answer.status === 200, `move to cloud answered ${answer.status}, expected 200`);
    return parseOrgCloudRunStarted(answer.body);
  }
}

const BUNDLE_MAGIC = '# v2 git bundle\n';
const fakeBundle = (text: string): Uint8Array => new TextEncoder().encode(`${BUNDLE_MAGIC}${text}`);
const BASE_COMMIT = 'a'.repeat(40);

function bundleHeaders(host: string, payload: Uint8Array): Record<string, string> {
  return {
    'content-type': BUNDLE_CONTENT_TYPE,
    'content-length': String(payload.length),
    [BUNDLE_HEADERS.host]: host,
    [BUNDLE_HEADERS.sha256]: sha256Hex(payload),
  };
}

function placementConformanceCases(): OrgProviderConformanceCase[] {
  const features: OrgFeature[] = ['sessions', 'leases', 'cloudRuns', 'placement'];
  /** The repository a manifest names, per workspace: one of the workspace's own, so a server that checks it accepts the move. */
  const repoOf = new Map<string, { repo: string; enforced: boolean }>();
  /** Throws when the workspace lists no repository the manifest could name: a case that skipped itself would be green without testing anything. A server without the workspaces feature has no list to check, so any repository passes there. */
  const useRepo = async (run: SessionsRun, workspaceId: string): Promise<void> => {
    if (!orgSupports(run.document, 'workspaces')) {
      repoOf.set(workspaceId, { repo: 'zyg-edge/zyg', enforced: false });
      return;
    }
    const answer = await run.call(run.owner, ORG_ROUTES.workspace(workspaceId as OrgWorkspaceId));
    check(answer.status === 200, `workspace read answered ${answer.status}, expected 200`);
    const repo = parseOrgWorkspace(answer.body)
      .repositories.map((entry) => normalizeOrgRepository(entry.repository))
      .find((entry) => entry !== undefined);
    check(repo !== undefined, `workspace ${workspaceId} lists no repository, so the placement cases cannot name one; give the workspace of the conformance sessions a repository`);
    repoOf.set(workspaceId, { repo, enforced: true });
  };
  const lease = (answer: Answer, label: string): OrgLeaseView => {
    check(answer.status === 200, `${label} answered ${answer.status}, expected 200`);
    return parseOrgLeaseView(answer.body);
  };
  const hold = async (run: SessionsRun, id: string, host = 'host-a') =>
    lease(await run.call(run.owner, ORG_ROUTES.sessionLease(id), 'POST', { host, ttlSeconds: 120 }), 'owner acquire');
  const capabilities = async (run: SessionsRun): Promise<OrgCloudCapabilities> => {
    const answer = await run.call(run.owner, ORG_ROUTES.cloudCapabilities);
    check(answer.status === 200, `capabilities answered ${answer.status}, expected 200`);
    return parseOrgCloudCapabilities(answer.body);
  };
  const uploadEnvelope = async (run: SessionsRun, id: string, host: string): Promise<OrgEnvelopeInfo> => {
    const payload = gz(`native state of ${id}`);
    const answer = await rawCall(run, run.owner, ORG_ROUTES.sessionEnvelope(id), 'PUT', envelopeHeaders(host, (await capabilities(run)).formats[0]!, payload, 0), payload);
    check(answer.status === 200, `envelope upload answered ${answer.status}, expected 200`);
    return parseOrgEnvelopeInfo(answer.json);
  };
  const uploadBundle = async (run: SessionsRun, id: string, mountId: string, host: string, payload: Uint8Array): Promise<OrgMountBundleInfo> => {
    const answer = await rawCall(run, run.owner, ORG_ROUTES.sessionMountBundle(id, mountId), 'PUT', bundleHeaders(host, payload), payload);
    check(answer.status === 200, `bundle upload answered ${answer.status}, expected 200`);
    return parseOrgMountBundleInfo(answer.json);
  };
  const manifest = (id: string, workspaceId: string, host: string, bundle: { sha256: string; bytes: number }, patch: Record<string, unknown> = {}) => ({
    version: 1,
    sessionId: id,
    createdBy: host,
    createdAt: new Date().toISOString(),
    boundary: workspaceId,
    cwdMount: 'm1',
    mounts: [
      {
        id: 'm1',
        kind: 'git',
        localLabel: 'zyg (worktree conformance)',
        cloudPath: '/work/m1',
        repo: repoOf.get(workspaceId)?.repo ?? 'zyg-edge/zyg',
        baseCommit: BASE_COMMIT,
        baseBranch: 'main',
        wip: { transport: 'bundle', sha256: bundle.sha256, bytes: bundle.bytes, tracked: 2, untracked: 1, localCommits: 1, skipped: [{ path: '.env.local', why: 'secret' }] },
      },
      { id: 'm2', kind: 'local-only', localLabel: '~/Downloads/brief', why: 'no-remote' },
    ],
    tools: { available: ['Read', 'Edit'], unavailable: [{ name: 'subagents', why: 'not-in-the-cloud-host' }] },
    midTurn: { interrupted: true, tool: 'Bash', note: 'interrupted by a move' },
    ...patch,
  });
  const move = (run: SessionsRun, id: string, host: string, envelopeSha256: string, placement: unknown) =>
    run.call(run.owner, ORG_ROUTES.sessionCloudRuns(id), 'POST', { host, envelopeSha256, placement });
  const stillOnDesktop = async (run: SessionsRun, id: string, host: string, label: string): Promise<void> => {
    const held = lease(await run.call(run.owner, ORG_ROUTES.sessionLease(id)), `lease after ${label}`);
    check(held.lease?.holder.host === host, `${label}: the desktop must keep its lease`);
    check(parseOrgCloudRunView((await run.call(run.owner, ORG_ROUTES.sessionCloudRun(id))).body).run === null, `${label}: a refused move must not create a run`);
    check(parseOrgPlacementView((await run.call(run.owner, ORG_ROUTES.sessionPlacement(id))).body).placement === null, `${label}: a refused move must not store a placement`);
  };

  return [
    {
      name: 'placement: capabilities advertise the manifest version and the bundle cap',
      run: (context) =>
        withSessions(context, features, async (run) => {
          const placement = (await capabilities(run)).placement;
          check(placement !== undefined && placement.manifestVersions.includes(1) && placement.maxBundleBytes >= 1, 'capabilities must advertise manifest version 1 and a bundle cap');
        }),
    },
    {
      name: 'placement: only the lease holder uploads a bundle, and the organization checks sha256, size and git format',
      run: (context) =>
        withSessions(context, features, async (run) => {
          const { id } = await run.upload();
          const payload = fakeBundle('one');
          const route = ORG_ROUTES.sessionMountBundle(id, 'm1');
          rawError(await rawCall(run, run.owner, route, 'PUT', bundleHeaders('host-a', payload), payload), 410, 'lease-lost', 'bundle upload without the lease');
          await hold(run, id);
          const info = await uploadBundle(run, id, 'm1', 'host-a', payload);
          check(info.mountId === 'm1' && info.sha256 === sha256Hex(payload) && info.bytes === payload.length, 'info must describe the stored bytes');
          check(info.uploadedBy.host === 'host-a' && info.uploadedBy.principal === run.owner, 'info must name the uploader');
          const again = await uploadBundle(run, id, 'm1', 'host-a', fakeBundle('replaced'));
          check(again.sha256 !== info.sha256, 'a second upload to the same mount replaces the first');
          const wrongSha = { ...bundleHeaders('host-a', payload), [BUNDLE_HEADERS.sha256]: '0'.repeat(64) };
          rawError(await rawCall(run, run.owner, route, 'PUT', wrongSha, payload), 422, 'bundle-mismatch', 'bundle with a wrong sha256');
          const plain = new TextEncoder().encode('not a bundle');
          rawError(await rawCall(run, run.owner, route, 'PUT', bundleHeaders('host-a', plain), plain), 400, 'invalid-request', 'upload that is not a git bundle');
          const noSha = bundleHeaders('host-a', payload);
          delete noSha[BUNDLE_HEADERS.sha256];
          rawError(await rawCall(run, run.owner, route, 'PUT', noSha, payload), 400, 'invalid-request', 'upload without a sha256');
          rawError(await rawCall(run, run.owner, ORG_ROUTES.sessionMountBundle(id, 'x1'), 'PUT', bundleHeaders('host-a', payload), payload), 400, 'invalid-request', 'upload to a malformed mount id');
          const caps = (await capabilities(run)).placement!;
          if (caps.maxBundleBytes < OVERSIZE_TEST_LIMIT) {
            const big = new Uint8Array(caps.maxBundleBytes + 1);
            big.set(new TextEncoder().encode(BUNDLE_MAGIC));
            rawError(await rawCall(run, run.owner, route, 'PUT', bundleHeaders('host-a', big), big), 413, 'bundle-too-large', 'upload above the advertised cap');
          }
          await run.call(run.owner, ORG_ROUTES.sessionGrants(id), 'POST', { principal: run.peer, role: 'collaborator' });
          rawError(await rawCall(run, run.peer, route, 'PUT', bundleHeaders('host-b', payload), payload), 403, 'forbidden', 'upload by a collaborator');
          rawError(await rawCall(run, run.third, route, 'PUT', bundleHeaders('host-c', payload), payload), 404, 'not-found', 'upload without a grant');
        }),
    },
    {
      name: 'placement: a user token can never upload a bundle as the cloud host',
      run: (context) =>
        withSessions(context, features, async (run) => {
          const { id } = await run.upload();
          const caps = await capabilities(run);
          const payload = fakeBundle('forged');
          await hold(run, id);
          for (const host of [caps.cloudHost, `${caps.cloudHost}:run-1`]) {
            rawError(await rawCall(run, run.owner, ORG_ROUTES.sessionMountBundle(id, 'm1'), 'PUT', bundleHeaders(host, payload), payload), 403, 'forbidden', `bundle upload as ${host}`);
          }
        }),
    },
    {
      name: 'placement: a move with a manifest stores it, names the bundle object, and hands over the lease',
      run: (context) =>
        withSessions(context, features, async (run) => {
          const { id, envelope } = await run.upload();
          await useRepo(run, envelope.workspaceId);
          const caps = await capabilities(run);
          check(parseOrgPlacementView((await run.call(run.owner, ORG_ROUTES.sessionPlacement(id))).body).placement === null, 'a session that never moved has no placement');
          await hold(run, id);
          const info = await uploadEnvelope(run, id, 'host-a');
          const bundle = await uploadBundle(run, id, 'm1', 'host-a', fakeBundle('wip'));
          const sent = manifest(id, envelope.workspaceId, 'host-a', bundle);
          const started = parseOrgCloudRunStarted((await move(run, id, 'host-a', info.sha256, sent)).body);
          check(started.lease.lease !== null && isCloudHostId(started.lease.lease.holder.host, caps.cloudHost), 'the cloud host must hold the lease after the move');
          const stored = parseOrgPlacementView((await run.call(run.owner, ORG_ROUTES.sessionPlacement(id))).body).placement;
          check(stored !== null && stored.sessionId === id && stored.cwdMount === 'm1' && stored.mounts.length === 2, 'the stored manifest must match the one sent');
          const git = stored.mounts.find((mount) => mount.kind === 'git');
          check(git?.kind === 'git' && git.wip?.sha256 === bundle.sha256 && git.wip.bytes === bundle.bytes, 'the stored git mount must keep the bundle sha256 and size');
          check(typeof git.wip.object === 'string' && git.wip.object.includes(id) && git.wip.object.includes('m1'), 'the organization must name the bundle object');
          check(git.wip.skipped.length === 1 && git.wip.skipped[0]!.path === '.env.local' && stored.midTurn?.tool === 'Bash', 'skipped paths and midTurn must survive');
          await run.call(run.owner, ORG_ROUTES.sessionGrants(id), 'POST', { principal: run.peer, role: 'collaborator' });
          run.expectError(await run.call(run.peer, ORG_ROUTES.sessionPlacement(id)), 403, 'forbidden', 'placement read by a collaborator');
          run.expectError(await run.call(run.third, ORG_ROUTES.sessionPlacement(id)), 404, 'not-found', 'placement read without a grant');
        }),
    },
    {
      name: 'placement: a refused manifest leaves the desktop lease, the run and the placement alone',
      run: (context) =>
        withSessions(context, features, async (run) => {
          const { id, envelope } = await run.upload();
          await useRepo(run, envelope.workspaceId);
          await hold(run, id);
          const info = await uploadEnvelope(run, id, 'host-a');
          const workspaceId = envelope.workspaceId;
          const none = { sha256: sha256Hex(fakeBundle('absent')), bytes: fakeBundle('absent').length };
          run.expectError(await move(run, id, 'host-a', info.sha256, manifest(id, workspaceId, 'host-a', none)), 409, 'no-bundle', 'move before the bundle was uploaded');
          await stillOnDesktop(run, id, 'host-a', 'a missing bundle');
          const bundle = await uploadBundle(run, id, 'm1', 'host-a', fakeBundle('wip'));
          run.expectError(await move(run, id, 'host-a', info.sha256, manifest(id, workspaceId, 'host-a', { sha256: '1'.repeat(64), bytes: bundle.bytes })), 422, 'bundle-mismatch', 'manifest naming another bundle');
          run.expectError(await move(run, id, 'host-a', info.sha256, manifest(id, workspaceId, 'host-a', { sha256: bundle.sha256, bytes: bundle.bytes + 1 })), 422, 'bundle-mismatch', 'manifest with another size');
          run.expectError(await move(run, id, 'host-a', info.sha256, manifest(`${id}-other`, workspaceId, 'host-a', bundle)), 422, 'invalid-placement', 'manifest of another session');
          run.expectError(await move(run, id, 'host-a', info.sha256, manifest(id, workspaceId, 'host-other', bundle)), 422, 'invalid-placement', 'manifest built by another host');
          run.expectError(await move(run, id, 'host-a', info.sha256, manifest(id, 'ws:conformance-another', 'host-a', bundle)), 422, 'invalid-placement', 'manifest of another boundary');
          if (repoOf.get(workspaceId)?.enforced) {
            const outside = manifest(id, workspaceId, 'host-a', bundle);
            (outside.mounts[0] as { repo: string }).repo = 'conformance-other/not-in-the-workspace';
            run.expectError(await move(run, id, 'host-a', info.sha256, outside), 422, 'invalid-placement', 'manifest naming a repository outside the workspace');
          }
          const withObject = manifest(id, workspaceId, 'host-a', bundle);
          (withObject.mounts[0] as { wip: Record<string, unknown> }).wip.object = `org-sessions/${id}/mounts/m1-x.bundle`;
          run.expectError(await move(run, id, 'host-a', info.sha256, withObject), 400, 'invalid-request', 'manifest that names its own bundle object');
          const twoGit = manifest(id, workspaceId, 'host-a', bundle);
          twoGit.mounts.push({ id: 'm3', kind: 'git', localLabel: 'second', cloudPath: '/work/m3', repo: 'zyg-edge/other', baseCommit: BASE_COMMIT } as never);
          run.expectError(await move(run, id, 'host-a', info.sha256, twoGit), 400, 'invalid-request', 'manifest with two git mounts');
          run.expectError(await move(run, id, 'host-a', info.sha256, manifest(id, workspaceId, 'host-a', bundle, { cwdMount: 'm2' })), 400, 'invalid-request', 'manifest whose working directory is a local-only mount');
          const absolute = manifest(id, workspaceId, 'host-a', bundle);
          (absolute.mounts[0] as { localLabel: string }).localLabel = '/Users/someone/zyg';
          run.expectError(await move(run, id, 'host-a', info.sha256, absolute), 400, 'invalid-request', 'manifest that leaks a local absolute path');
          const escaping = manifest(id, workspaceId, 'host-a', bundle);
          (escaping.mounts[0] as { wip: { skipped: unknown[] } }).wip.skipped = [{ path: '../outside', why: 'secret' }];
          run.expectError(await move(run, id, 'host-a', info.sha256, escaping), 400, 'invalid-request', 'manifest with a path outside the repository');
          await stillOnDesktop(run, id, 'host-a', 'refused manifests');
          answerOk(await move(run, id, 'host-a', info.sha256, manifest(id, workspaceId, 'host-a', bundle)), 'the move after the refusals');
        }),
    },
    {
      name: 'placement: a bundle uploaded in an earlier lease does not move with a later one',
      run: (context) =>
        withSessions(context, features, async (run) => {
          const { id, envelope } = await run.upload();
          await useRepo(run, envelope.workspaceId);
          await hold(run, id, 'host-a');
          const bundle = await uploadBundle(run, id, 'm1', 'host-a', fakeBundle('earlier lease'));
          await run.call(run.owner, ORG_ROUTES.sessionLeaseRelease(id), 'POST', { host: 'host-a' });
          await hold(run, id, 'host-b');
          const info = await uploadEnvelope(run, id, 'host-b');
          run.expectError(await move(run, id, 'host-b', info.sha256, manifest(id, envelope.workspaceId, 'host-b', bundle)), 422, 'bundle-mismatch', 'move with a bundle of a released lease');
          await stillOnDesktop(run, id, 'host-b', 'a stale bundle');
        }),
    },
    {
      name: 'placement: a move without a manifest still works and clears an earlier placement',
      run: (context) =>
        withSessions(context, features, async (run) => {
          const advance = context.advanceCloudRun;
          const { id, envelope } = await run.upload();
          await useRepo(run, envelope.workspaceId);
          await hold(run, id);
          const info = await uploadEnvelope(run, id, 'host-a');
          answerOk(await run.call(run.owner, ORG_ROUTES.sessionCloudRuns(id), 'POST', { host: 'host-a', envelopeSha256: info.sha256 }), 'a move without placement');
          const placementOf = async () => parseOrgPlacementView((await run.call(run.owner, ORG_ROUTES.sessionPlacement(id))).body).placement;
          check((await placementOf()) === null, 'a move without a manifest stores no placement');
          if (!advance) return;
          const backToDesktop = async () => {
            await advance(id);
            await run.call(run.owner, ORG_ROUTES.sessionLeaseHandover(id), 'POST', { host: 'host-a' });
            await advance(id);
            await hold(run, id);
          };
          await backToDesktop();
          const second = await uploadEnvelope(run, id, 'host-a');
          const bundle = await uploadBundle(run, id, 'm1', 'host-a', fakeBundle('second move'));
          answerOk(await move(run, id, 'host-a', second.sha256, manifest(id, envelope.workspaceId, 'host-a', bundle)), 'a second move with placement');
          check((await placementOf()) !== null, 'the second move stores its placement');
          await backToDesktop();
          const third = await uploadEnvelope(run, id, 'host-a');
          answerOk(await run.call(run.owner, ORG_ROUTES.sessionCloudRuns(id), 'POST', { host: 'host-a', envelopeSha256: third.sha256 }), 'a third move without placement');
          check((await placementOf()) === null, 'a move without a manifest clears the placement of the run before it');
        }),
    },
    {
      name: 'placement: an undeclared placement feature is not served and a manifest is refused',
      run: (context) =>
        withSessions(context, ['sessions', 'leases', 'cloudRuns'], async (run) => {
          if (orgSupports(run.document, 'placement')) return;
          const { id, envelope } = await run.upload();
          await useRepo(run, envelope.workspaceId);
          const payload = fakeBundle('unserved');
          await hold(run, id);
          const info = await uploadEnvelope(run, id, 'host-a');
          rawError(await rawCall(run, run.owner, ORG_ROUTES.sessionMountBundle(id, 'm1'), 'PUT', bundleHeaders('host-a', payload), payload), 404, 'not-found', 'bundle upload');
          run.expectError(await run.call(run.owner, ORG_ROUTES.sessionPlacement(id)), 404, 'not-found', 'placement read');
          const bundle = { sha256: sha256Hex(payload), bytes: payload.length };
          run.expectError(await move(run, id, 'host-a', info.sha256, manifest(id, envelope.workspaceId, 'host-a', bundle)), 400, 'invalid-request', 'move with a manifest');
          check((await capabilities(run)).placement === undefined, 'capabilities must not advertise placement');
        }),
    },
  ];

  function answerOk(answer: Answer, label: string): void {
    check(answer.status === 200, `${label} answered ${answer.status}, expected 200`);
    parseOrgCloudRunStarted(answer.body);
  }
}

function messageConformanceCases(): OrgProviderConformanceCase[] {
  const features: OrgFeature[] = ['sessions', 'leases', 'cloudRuns', 'messages'];
  const post = async (run: SessionsRun, as: UserPrincipal | undefined, id: string, clientMsgId: string, text: string): Promise<Answer> =>
    run.call(as, ORG_ROUTES.sessionMessages(id), 'POST', { clientMsgId, text });
  const posted = (answer: Answer, label: string): OrgPostedMessage => {
    check(answer.status === 202, `${label} answered ${answer.status}, expected 202`);
    return parseOrgPostedMessage(answer.body);
  };
  const list = async (run: SessionsRun, as: UserPrincipal, id: string, query = ''): Promise<OrgSessionMessagePage> => {
    const answer = await run.call(as, `${ORG_ROUTES.sessionMessages(id)}${query}`);
    check(answer.status === 200, `message list answered ${answer.status}, expected 200`);
    return parseOrgSessionMessagePage(answer.body);
  };
  const grant = (run: SessionsRun, id: string, principal: UserPrincipal, role: 'viewer' | 'collaborator' | 'driver') =>
    run.call(run.owner, ORG_ROUTES.sessionGrants(id), 'POST', { principal, role });
  const inCloud = async (run: SessionsRun): Promise<{ id: string }> => {
    const { id } = await run.upload();
    const answer = await run.call(run.owner, ORG_ROUTES.cloudCapabilities);
    check(answer.status === 200, `capabilities answered ${answer.status}, expected 200`);
    const caps = parseOrgCloudCapabilities(answer.body);
    check((await run.call(run.owner, ORG_ROUTES.sessionLease(id), 'POST', { host: 'host-a', ttlSeconds: 120 })).status === 200, 'owner acquire');
    const payload = gz('state at move');
    check((await rawCall(run, run.owner, ORG_ROUTES.sessionEnvelope(id), 'PUT', envelopeHeaders('host-a', caps.formats[0]!, payload, 0), payload)).status === 200, 'envelope upload');
    check((await run.call(run.owner, ORG_ROUTES.sessionCloudRuns(id), 'POST', { host: 'host-a', envelopeSha256: sha256Hex(payload) })).status === 200, 'move to cloud');
    return { id };
  };

  return [
    {
      name: 'messages: the owner posts, the same clientMsgId returns the stored message, and the list pages by seq',
      run: (context) =>
        withSessions(context, features, async (run) => {
          const { id } = await inCloud(run);
          run.expectError(await post(run, undefined, id, 'm1', 'hi'), 401, 'unauthorized', 'post without a token');
          const first = posted(await post(run, run.owner, id, 'm1', 'first'), 'owner post');
          check(first.status === 'queued' && first.seq >= 1 && first.position === 0, 'the owner\'s message must be queued and next');
          const again = posted(await post(run, run.owner, id, 'm1', 'first'), 'repeated post');
          check(again.id === first.id && again.seq === first.seq, 'the same clientMsgId must return the stored message');
          const second = posted(await post(run, run.owner, id, 'm2', 'second'), 'second post');
          check(second.seq > first.seq && second.position === 1, 'the second message must wait behind the first');
          const page = await list(run, run.owner, id);
          check(page.messages.length === 2 && page.messages[0]!.text === 'first' && page.messages[1]!.text === 'second', 'the list must hold both messages in order');
          const head = page.messages[0]!;
          check(head.author === run.owner && head.roleAtSend === 'owner' && head.clientMsgId === 'm1', 'the author and the role at send time come from the caller');
          const after = await list(run, run.owner, id, `?after=${first.seq}&limit=1`);
          check(after.messages.length === 1 && after.messages[0]!.id === second.id, 'after must skip the messages up to that seq');
          run.expectError(await run.call(run.owner, `${ORG_ROUTES.sessionMessages(id)}?after=-1`), 400, 'invalid-request', 'list with a bad after');
          run.expectError(await post(run, run.owner, id, 'bad id!', 'x'), 400, 'invalid-request', 'post with a bad clientMsgId');
          run.expectError(await post(run, run.owner, id, 'm3', '   '), 400, 'invalid-request', 'post of an empty text');
        }),
    },
    {
      name: 'messages: only the owner\'s messages queue, others are held, a viewer cannot post, and only the owner sees everything',
      run: (context) =>
        withSessions(context, features, async (run) => {
          const { id } = await inCloud(run);
          run.expectError(await post(run, run.third, id, 'x1', 'hi'), 404, 'not-found', 'post without a grant');
          await grant(run, id, run.peer, 'collaborator');
          await grant(run, id, run.third, 'viewer');
          run.expectError(await post(run, run.third, id, 'v1', 'let me in'), 403, 'forbidden', 'post by a viewer');
          const held = posted(await post(run, run.peer, id, 'c1', 'please run this'), 'collaborator post');
          check(held.status === 'held' && held.position === 0, 'a collaborator\'s message must be held');
          posted(await post(run, run.owner, id, 'o1', 'mine'), 'owner post');
          const ownersView = await list(run, run.owner, id);
          check(ownersView.messages.length === 2, 'the owner sees every message');
          const peersView = await list(run, run.peer, id);
          check(peersView.messages.length === 1 && peersView.messages[0]!.author === run.peer && peersView.messages[0]!.status === 'held', 'a collaborator sees only their own message');
          check((await list(run, run.third, id)).messages.length === 0, 'a viewer sees no one else\'s messages');
          run.expectError(await run.call(undefined, ORG_ROUTES.sessionMessages(id)), 401, 'unauthorized', 'list without a token');
        }),
    },
    {
      name: 'messages: a post to a session that is not in the cloud answers 409 not-in-cloud',
      run: (context) =>
        withSessions(context, features, async (run) => {
          const { id } = await run.upload();
          run.expectError(await post(run, run.owner, id, 'n1', 'nobody runs this'), 409, 'not-in-cloud', 'post to a session that never moved');
          check((await list(run, run.owner, id)).messages.length === 0, 'a refused post stores nothing');
        }),
    },
    {
      name: 'messages: one author holds at most ten messages',
      run: (context) =>
        withSessions(context, features, async (run) => {
          const { id } = await inCloud(run);
          await grant(run, id, run.peer, 'collaborator');
          for (let index = 0; index < MAX_HELD_PER_AUTHOR; index += 1) posted(await post(run, run.peer, id, `h${index}`, `idea ${index}`), 'held post below the cap');
          run.expectError(await post(run, run.peer, id, 'h-over', 'one idea too many'), 429, 'queue-full', 'held post above the cap');
        }),
    },
    {
      name: 'messages: cancel is for queued or held messages, by their author or the owner',
      run: (context) =>
        withSessions(context, features, async (run) => {
          const { id } = await inCloud(run);
          await grant(run, id, run.peer, 'driver');
          await grant(run, id, run.third, 'collaborator');
          const mine = posted(await post(run, run.peer, id, 'p1', 'peer message'), 'driver post');
          const theirs = posted(await post(run, run.third, id, 't1', 'third message'), 'collaborator post');
          run.expectError(await run.call(run.third, ORG_ROUTES.sessionMessage(id, mine.id), 'DELETE'), 403, 'forbidden', 'cancel of another person\'s message');
          const cancelled = parseOrgSessionMessage((await run.call(run.peer, ORG_ROUTES.sessionMessage(id, mine.id), 'DELETE')).body);
          check(cancelled.status === 'cancelled' && cancelled.id === mine.id, 'an author cancels their own queued message');
          run.expectError(await run.call(run.peer, ORG_ROUTES.sessionMessage(id, mine.id), 'DELETE'), 409, 'conflict', 'second cancel');
          const byOwner = parseOrgSessionMessage((await run.call(run.owner, ORG_ROUTES.sessionMessage(id, theirs.id), 'DELETE')).body);
          check(byOwner.status === 'cancelled', 'the owner cancels a held message');
          run.expectError(await run.call(run.owner, ORG_ROUTES.sessionMessage(id, '00000000-0000-4000-8000-000000000000'), 'DELETE'), 404, 'not-found', 'cancel of an unknown message');
          run.expectError(await run.call(run.owner, ORG_ROUTES.sessionMessage(id, 'not-an-id'), 'DELETE'), 404, 'not-found', 'cancel of a malformed id');
        }),
    },
    {
      name: 'messages: the owner runs a held message, which becomes a new queued message that quotes it',
      run: (context) =>
        withSessions(context, features, async (run) => {
          const { id } = await inCloud(run);
          await grant(run, id, run.peer, 'collaborator');
          const held = posted(await post(run, run.peer, id, 'c1', 'please run the linter'), 'collaborator post');
          run.expectError(await run.call(run.peer, ORG_ROUTES.sessionMessageRun(id, held.id), 'POST', { clientMsgId: 'r1' }), 403, 'forbidden', 'run by a collaborator');
          run.expectError(await run.call(run.owner, ORG_ROUTES.sessionMessageRun(id, held.id), 'POST', {}), 400, 'invalid-request', 'run without a clientMsgId');
          const started = posted(await run.call(run.owner, ORG_ROUTES.sessionMessageRun(id, held.id), 'POST', { clientMsgId: 'r1' }), 'run of a held message');
          check(started.status === 'queued' && started.id !== held.id, 'running a held message queues a new owner message');
          const all = (await list(run, run.owner, id)).messages;
          const made = all.find((entry: OrgSessionMessage) => entry.id === started.id);
          check(made !== undefined && made.author === run.owner && made.roleAtSend === 'owner' && made.quotes === held.id, 'the new message is the owner\'s and quotes the held message by its id');
          check(all.find((entry: OrgSessionMessage) => entry.id === held.id)?.status === 'done', 'the held message is done once it ran');
          run.expectError(await run.call(run.owner, ORG_ROUTES.sessionMessageRun(id, held.id), 'POST', { clientMsgId: 'r2' }), 409, 'conflict', 'second run of the same message');
        }),
    },
    {
      name: 'messages: a full queue answers 429 queue-full and an oversize text 413 too-large',
      run: (context) =>
        withSessions(context, features, async (run) => {
          const { id } = await inCloud(run);
          for (let index = 0; index < MAX_QUEUED_MESSAGES; index += 1) posted(await post(run, run.owner, id, `q${index}`, `message ${index}`), 'post below the cap');
          run.expectError(await post(run, run.owner, id, 'one-too-many', 'no room'), 429, 'queue-full', 'post above the cap');
          check(posted(await post(run, run.owner, id, 'q0', 'message 0'), 'repeat of a stored message').seq >= 1, 'a repeated post is answered from the store even when the queue is full');
          run.expectError(await post(run, run.owner, id, 'big', 'x'.repeat(MAX_MESSAGE_TEXT_BYTES + 1)), 413, 'too-large', 'post of an oversize text');
          check((await list(run, run.owner, id)).messages.length === MAX_QUEUED_MESSAGES, 'a refused post stores nothing');
        }),
    },
    {
      name: 'messages: the cloud host runs queued messages and marks them done with their turn',
      run: (context) =>
        withSessions(context, features, async (run) => {
          const advance = context.advanceCloudRun;
          if (!advance) return;
          const { id } = await run.upload();
          const caps = await (async () => {
            const answer = await run.call(run.owner, ORG_ROUTES.cloudCapabilities);
            check(answer.status === 200, `capabilities answered ${answer.status}, expected 200`);
            return parseOrgCloudCapabilities(answer.body);
          })();
          const held = await run.call(run.owner, ORG_ROUTES.sessionLease(id), 'POST', { host: 'host-a', ttlSeconds: 120 });
          check(held.status === 200, 'owner acquire');
          const payload = gz('state at move');
          const stored = await rawCall(run, run.owner, ORG_ROUTES.sessionEnvelope(id), 'PUT', envelopeHeaders('host-a', caps.formats[0]!, payload, 0), payload);
          check(stored.status === 200, 'envelope upload');
          check((await run.call(run.owner, ORG_ROUTES.sessionCloudRuns(id), 'POST', { host: 'host-a', envelopeSha256: sha256Hex(payload) })).status === 200, 'move to cloud');
          const queued = posted(await post(run, run.owner, id, 'w1', 'while the cloud works'), 'post to a cloud session');
          check((await list(run, run.owner, id)).executor.state !== 'none', 'a cloud session with a live executor must not report none');
          await advance(id);
          const done = (await list(run, run.owner, id)).messages.find((entry) => entry.id === queued.id);
          check(done?.status === 'done' && typeof done.turnId === 'string', 'a message the cloud ran is done and names its turn');
        }),
    },
    {
      name: 'messages: a desktop that takes the session gets the still-queued messages back in the lease answer',
      run: (context) =>
        withSessions(context, features, async (run) => {
          const advance = context.advanceCloudRun;
          if (!advance) return;
          const { id } = await run.upload();
          const answer = await run.call(run.owner, ORG_ROUTES.cloudCapabilities);
          check(answer.status === 200, 'capabilities');
          const caps = parseOrgCloudCapabilities(answer.body);
          check((await run.call(run.owner, ORG_ROUTES.sessionLease(id), 'POST', { host: 'host-a', ttlSeconds: 120 })).status === 200, 'owner acquire');
          const payload = gz('state at move');
          check((await rawCall(run, run.owner, ORG_ROUTES.sessionEnvelope(id), 'PUT', envelopeHeaders('host-a', caps.formats[0]!, payload, 0), payload)).status === 200, 'envelope upload');
          check((await run.call(run.owner, ORG_ROUTES.sessionCloudRuns(id), 'POST', { host: 'host-a', envelopeSha256: sha256Hex(payload) })).status === 200, 'move to cloud');
          const queued = posted(await post(run, run.owner, id, 'w1', 'not run yet'), 'post to a cloud session');
          const taken = await run.call(run.owner, ORG_ROUTES.sessionLease(id), 'POST', { host: 'host-b', ttlSeconds: 120, force: true });
          check(taken.status === 200, `force acquire answered ${taken.status}, expected 200`);
          const returned = (taken.body as { returnedMessages?: unknown }).returnedMessages;
          check(Array.isArray(returned) && returned.length === 1, 'the lease answer must give the queued message back');
          check(parseOrgSessionMessage((returned as unknown[])[0]).id === queued.id, 'the returned message is the queued one');
          check((await list(run, run.owner, id)).messages.find((entry) => entry.id === queued.id)?.status === 'cancelled', 'a returned message is cancelled in the inbox');
        }),
    },
    {
      name: 'messages: an undeclared messages feature is not served',
      run: (context) =>
        withSessions(context, ['sessions'], async (run) => {
          if (orgSupports(run.document, 'messages')) return;
          const { id } = await run.upload();
          run.expectError(await run.call(run.owner, ORG_ROUTES.sessionMessages(id)), 404, 'not-found', 'message list');
          run.expectError(await post(run, run.owner, id, 'm1', 'hi'), 404, 'not-found', 'message post');
        }),
    },
  ];
}

function liveConformanceCases(): OrgProviderConformanceCase[] {
  const features: OrgFeature[] = ['sessions', 'leases', 'cloudRuns', 'messages', 'liveSessions'];
  const host = 'desk-a';
  const post = async (run: SessionsRun, as: UserPrincipal, id: string, clientMsgId: string, text: string): Promise<Answer> =>
    run.call(as, ORG_ROUTES.sessionMessages(id), 'POST', { clientMsgId, text });
  const posted = (answer: Answer, label: string): OrgPostedMessage => {
    check(answer.status === 202, `${label} answered ${answer.status}, expected 202`);
    return parseOrgPostedMessage(answer.body);
  };
  const list = async (run: SessionsRun, as: UserPrincipal, id: string): Promise<OrgSessionMessagePage> => {
    const answer = await run.call(as, ORG_ROUTES.sessionMessages(id));
    check(answer.status === 200, `message list answered ${answer.status}, expected 200`);
    return parseOrgSessionMessagePage(answer.body);
  };
  const grant = async (run: SessionsRun, id: string, principal: UserPrincipal, role: 'viewer' | 'collaborator' | 'driver') => {
    const answer = await run.call(run.owner, ORG_ROUTES.sessionGrants(id), 'POST', { principal, role });
    check(answer.status === 200, `grant answered ${answer.status}, expected 200`);
  };
  const setLive = (run: SessionsRun, as: UserPrincipal, id: string, body: unknown) => run.call(as, ORG_ROUTES.sessionLive(id), 'PUT', body);
  const claim = (run: SessionsRun, as: UserPrincipal, id: string, claimHost = host, max?: number) =>
    run.call(as, ORG_ROUTES.sessionMessagesClaim(id), 'POST', max === undefined ? { host: claimHost } : { host: claimHost, max });
  const claimed = (answer: Answer, label: string): OrgClaimedMessages => {
    check(answer.status === 200, `${label} answered ${answer.status}, expected 200`);
    return parseOrgClaimedMessages(answer.body);
  };
  const statusOf = async (run: SessionsRun, id: string, messageId: string) => (await list(run, run.owner, id)).messages.find((entry) => entry.id === messageId)?.status;
  /** A session on the owner's desktop (`host` holds the lease), live with `host` as its executor. */
  const liveSession = async (run: SessionsRun, body: Record<string, unknown> = {}): Promise<{ id: string; live: OrgSessionLive }> => {
    const { id } = await run.upload();
    check((await run.call(run.owner, ORG_ROUTES.sessionLease(id), 'POST', { host, ttlSeconds: 120 })).status === 200, 'owner acquire');
    const answer = await setLive(run, run.owner, id, { enabled: true, host, ...body });
    check(answer.status === 200, `live on answered ${answer.status}, expected 200`);
    return { id, live: parseOrgSessionLive(answer.body) };
  };

  return [
    {
      name: 'live: only the owner turns a session live, turning it on names the executor host, and the host is shown to the owner only',
      run: (context) =>
        withSessions(context, features, async (run) => {
          const { id } = await run.upload();
          await grant(run, id, run.peer, 'driver');
          const before = parseOrgSessionLive((await run.call(run.owner, ORG_ROUTES.sessionLive(id))).body);
          check(before.enabled === false && before.participantTurnsPerDay === DEFAULT_PARTICIPANT_TURNS_PER_DAY, 'a session is not live until its owner says so');
          run.expectError(await setLive(run, run.peer, id, { enabled: true, host: 'desk-b' }), 403, 'forbidden', 'live on by a driver');
          run.expectError(await setLive(run, run.owner, id, { enabled: true }), 400, 'invalid-request', 'live on without a host');
          run.expectError(await setLive(run, run.owner, id, { enabled: true, host, participantTurnsPerDay: 0 }), 400, 'invalid-request', 'live on with a zero budget');
          run.expectError(await setLive(run, run.owner, id, { enabled: true, host, participantTurnsPerDay: MAX_PARTICIPANT_TURNS_PER_DAY + 1 }), 400, 'invalid-request', 'live on with a budget over the cap');
          const on = parseOrgSessionLive((await setLive(run, run.owner, id, { enabled: true, host, participantTurnsPerDay: 7 })).body);
          check(on.enabled && on.host === host && on.participantTurnsPerDay === 7, 'the owner\'s answer carries the switch, the host and the budget');
          const seen = parseOrgSessionLive((await run.call(run.peer, ORG_ROUTES.sessionLive(id))).body);
          check(seen.enabled && seen.host === undefined && seen.participantTurnsPerDay === 7, 'a participant sees the switch and the budget but not the host');
          check(parseOrgSessionView((await run.call(run.peer, ORG_ROUTES.session(id))).body).live?.enabled === true, 'the session view says it is live');
          run.expectError(await run.call(run.third, ORG_ROUTES.sessionLive(id)), 404, 'not-found', 'live read without a grant');
          const off = parseOrgSessionLive((await setLive(run, run.owner, id, { enabled: false })).body);
          check(!off.enabled, 'the owner turns it off without naming a host');
        }),
    },
    {
      name: 'live: collaborators and drivers queue instructions on a live desktop session, a viewer cannot, and everyone sees every instruction',
      run: (context) =>
        withSessions(context, features, async (run) => {
          const { id } = await liveSession(run);
          await grant(run, id, run.peer, 'collaborator');
          await grant(run, id, run.third, 'viewer');
          run.expectError(await post(run, run.third, id, 'v1', 'let me in'), 403, 'forbidden', 'instruction by a viewer');
          const fromPeer = posted(await post(run, run.peer, id, 'c1', 'please run the tests'), 'collaborator post');
          check(fromPeer.status === 'queued' && fromPeer.position === 0, 'a collaborator\'s instruction is queued, not held');
          const fromOwner = posted(await post(run, run.owner, id, 'o1', 'and then the linter'), 'owner post');
          check(fromOwner.status === 'queued' && fromOwner.position === 1 && fromOwner.seq > fromPeer.seq, 'the server orders the instructions by seq');
          for (const viewer of [run.peer, run.third]) {
            const seen = await list(run, viewer, id);
            check(seen.messages.length === 2, 'every participant sees every instruction of a live session');
            check(seen.executor.hostKind === 'desktop', 'the executor of a live desktop session is a desktop');
          }
          const { id: plain } = await run.upload();
          await grant(run, plain, run.peer, 'collaborator');
          run.expectError(await post(run, run.peer, plain, 'c1', 'nobody runs this'), 409, 'not-in-cloud', 'post to a desktop session that is not live');
        }),
    },
    {
      name: 'live: one participant queues at most five instructions and starts at most the owner\'s budget per day',
      run: (context) =>
        withSessions(context, features, async (run) => {
          const { id } = await liveSession(run, { participantTurnsPerDay: 7 });
          await grant(run, id, run.peer, 'collaborator');
          const first = [];
          for (let index = 0; index < MAX_LIVE_QUEUED_PER_AUTHOR; index += 1) first.push(posted(await post(run, run.peer, id, `q${index}`, `idea ${index}`), 'post below the queue cap'));
          run.expectError(await post(run, run.peer, id, 'q-over', 'one too many'), 429, 'queue-full', 'post above the per-author queue cap');
          check(posted(await post(run, run.owner, id, 'o1', 'the owner is not capped'), 'owner post').status === 'queued', 'the owner is not held to the participant caps');
          const taken = claimed(await claim(run, run.owner, id, host, MAX_CLAIM_MESSAGES), 'claim');
          check(taken.messages.length === MAX_CLAIM_MESSAGES, 'the owner\'s desktop claims every author');
          check((await run.call(run.owner, ORG_ROUTES.sessionMessagesDone(id), 'POST', { host, turnId: 'turn-1' })).status === 200, 'done');
          posted(await post(run, run.peer, id, 'q5', 'idea 5'), 'post below the budget');
          posted(await post(run, run.peer, id, 'q6', 'idea 6'), 'post at the budget');
          run.expectError(await post(run, run.peer, id, 'q7', 'idea 7'), 429, 'turn-budget-spent', 'post above the daily budget');
        }),
    },
    {
      name: 'live: the owner\'s executor claims every author in seq order, done names the turn, and other claims run the owner\'s messages only',
      run: (context) =>
        withSessions(context, features, async (run) => {
          const { id } = await liveSession(run);
          await grant(run, id, run.peer, 'driver');
          await grant(run, id, run.third, 'collaborator');
          const a = posted(await post(run, run.third, id, 't1', 'first'), 'collaborator post');
          const b = posted(await post(run, run.owner, id, 'o1', 'second'), 'owner post');
          const c = posted(await post(run, run.peer, id, 'p1', 'third'), 'driver post');
          run.expectError(await claim(run, run.owner, id, 'desk-z'), 410, 'lease-lost', 'claim from a host without the lease');
          run.expectError(await claim(run, run.owner, id, host, MAX_CLAIM_MESSAGES + 1), 400, 'invalid-request', 'claim of too many');
          run.expectError(await claim(run, run.third, id), 403, 'forbidden', 'claim by a collaborator');
          const two = claimed(await claim(run, run.owner, id, host, 2), 'first claim');
          check(two.messages.map((entry) => entry.id).join() === [a.id, b.id].join(), 'a claim takes the oldest instructions first, whoever wrote them');
          check(two.messages.every((entry) => entry.status === 'claimed'), 'claimed messages say so');
          check((await list(run, run.peer, id)).executor.state === 'running', 'a claimed message means the executor is running');
          run.expectError(await run.call(run.owner, ORG_ROUTES.sessionMessagesDone(id), 'POST', { host, turnId: 'bad turn!' }), 400, 'invalid-request', 'done with a bad turn id');
          const done = parseOrgCompletedMessages((await run.call(run.owner, ORG_ROUTES.sessionMessagesDone(id), 'POST', { host, turnId: 'turn-1', final: 'all green' })).body);
          check(done.done === 2 && done.more === 1, 'done counts the turn\'s messages and what still waits');
          const ran = (await list(run, run.owner, id)).messages.find((entry) => entry.id === a.id);
          check(ran?.status === 'done' && ran.turnId === 'turn-1', 'a message that ran is done and names its turn');
          check((await statusOf(run, id, c.id)) === 'queued', 'the third message still waits');
          // The driver takes the session on its own desktop: it may claim, but only the owner's messages.
          check((await run.call(run.owner, ORG_ROUTES.sessionLeaseRelease(id), 'POST', { host })).status === 200, 'owner release');
          check((await run.call(run.peer, ORG_ROUTES.sessionLease(id), 'POST', { host: 'desk-p', ttlSeconds: 120 })).status === 200, 'driver acquire');
          const byDriver = claimed(await claim(run, run.peer, id, 'desk-p'), 'driver claim');
          check(byDriver.messages.length === 0, 'only the owner\'s executor claims other authors\' messages');
          check((await statusOf(run, id, c.id)) === 'queued', 'a driver\'s claim leaves other authors\' messages queued');
        }),
    },
    {
      name: 'live: a claim of an earlier tenure goes back to the queue, and a taken session never returns others\' messages',
      run: (context) =>
        withSessions(context, features, async (run) => {
          const { id } = await liveSession(run);
          await grant(run, id, run.peer, 'collaborator');
          const theirs = posted(await post(run, run.peer, id, 'c1', 'from the collaborator'), 'collaborator post');
          const mine = posted(await post(run, run.owner, id, 'o1', 'from the owner'), 'owner post');
          check(claimed(await claim(run, run.owner, id), 'first claim').messages.length === 2, 'the executor claims both');
          // The owner's Marshal restarts and takes the session again under a new host: it gets nothing back twice.
          check((await setLive(run, run.owner, id, { enabled: true, host: 'desk-b' })).status === 200, 'live host moves');
          const taken = await run.call(run.owner, ORG_ROUTES.sessionLease(id), 'POST', { host: 'desk-b', ttlSeconds: 120, force: true });
          check(taken.status === 200, `force acquire answered ${taken.status}, expected 200`);
          const returned = (taken.body as { returnedMessages?: unknown }).returnedMessages;
          const returnedIds = Array.isArray(returned) ? returned.map((entry) => parseOrgSessionMessage(entry)) : [];
          check(returnedIds.every((entry) => entry.author === run.owner), 'only the owner\'s own messages come back in the lease answer');
          check(!returnedIds.some((entry) => entry.id === theirs.id), 'another author\'s message never comes back in the lease answer');
          const again = claimed(await claim(run, run.owner, id, 'desk-b'), 'claim of the new tenure');
          const ids = again.messages.map((entry) => entry.id);
          check(ids.includes(theirs.id), 'the new tenure claims another author\'s message the earlier one never finished');
          check(ids.includes(mine.id) || returnedIds.some((entry) => entry.id === mine.id), 'the owner\'s unfinished message is either returned to the desktop or claimed again');
          run.expectError(await claim(run, run.owner, id, host), 410, 'lease-lost', 'claim by the earlier host');
        }),
    },
    {
      name: 'live: an author whose grant is revoked or lowered to viewer has their queued instructions rejected',
      run: (context) =>
        withSessions(context, features, async (run) => {
          const { id } = await liveSession(run);
          await grant(run, id, run.peer, 'collaborator');
          await grant(run, id, run.third, 'collaborator');
          const peers = posted(await post(run, run.peer, id, 'c1', 'from bob'), 'peer post');
          const thirds = posted(await post(run, run.third, id, 't1', 'from carol'), 'third post');
          await grant(run, id, run.peer, 'viewer');
          check((await run.call(run.owner, ORG_ROUTES.sessionGrant(id, run.third), 'DELETE')).status === 204, 'revoke');
          check((await statusOf(run, id, peers.id)) === 'rejected', 'a lowered author\'s queued instruction is rejected');
          check((await statusOf(run, id, thirds.id)) === 'rejected', 'a revoked author\'s queued instruction is rejected');
          check(claimed(await claim(run, run.owner, id), 'claim').messages.length === 0, 'rejected instructions are never claimed');
        }),
    },
    {
      name: 'live: the owner\'s pending feed is keyed by host, and asking for it makes the executor hot',
      run: (context) =>
        withSessions(context, features, async (run) => {
          const { id } = await liveSession(run);
          await grant(run, id, run.peer, 'collaborator');
          check((await run.call(run.owner, ORG_ROUTES.sessionLeaseRelease(id), 'POST', { host })).status === 200, 'owner release');
          check((await list(run, run.peer, id)).executor.state === 'none', 'a live session with nothing queued and an absent desktop has no executor');
          posted(await post(run, run.peer, id, 'c1', 'are you there?'), 'collaborator post');
          check((await list(run, run.peer, id)).executor.state === 'queued', 'a queued instruction for an absent desktop waits');
          run.expectError(await run.call(run.owner, ORG_ROUTES.livePending), 400, 'invalid-request', 'pending without a host');
          const elsewhere = parseOrgLivePending((await run.call(run.owner, `${ORG_ROUTES.livePending}?host=desk-other`)).body);
          check(!elsewhere.sessions.some((entry) => entry.id === id), 'another host of the owner is not told about this session');
          const pendingAnswer = await run.call(run.owner, `${ORG_ROUTES.livePending}?host=${host}`);
          check(pendingAnswer.status === 200, `pending answered ${pendingAnswer.status}, expected 200`);
          const pending = parseOrgLivePending(pendingAnswer.body);
          check(pending.sessions.some((entry) => entry.id === id && entry.queued === 1), 'the executor host is told this session has one instruction');
          check(pending.pollSeconds >= 1, 'the feed says how often to ask');
          const executor = (await list(run, run.peer, id)).executor;
          check(executor.state === 'hot' && executor.hostKind === 'desktop', 'a desktop that asked for its work is online');
          const peersFeed = parseOrgLivePending((await run.call(run.peer, `${ORG_ROUTES.livePending}?host=${host}`)).body);
          check(!peersFeed.sessions.some((entry) => entry.id === id), 'only the owner is told about the owner\'s sessions');
        }),
    },
    {
      name: 'live: the server names the author of each transcript user message from the inbox row it ran',
      run: (context) =>
        withSessions(context, features, async (run) => {
          const { id } = await liveSession(run);
          await grant(run, id, run.peer, 'collaborator');
          const theirs = posted(await post(run, run.peer, id, 'c1', 'from bob'), 'collaborator post');
          const at = new Date(1_700_000_000_000).toISOString();
          const write = await run.call(run.owner, ORG_ROUTES.sessionTranscript(id), 'PUT', {
            mode: 'append',
            messages: [
              { role: 'user', text: 'from bob', at, messageId: theirs.id, author: run.owner },
              { role: 'assistant', text: 'done', at },
              { role: 'user', text: 'typed locally', at, author: run.peer },
            ],
          });
          check(write.status === 200, `transcript append answered ${write.status}, expected 200`);
          run.expectError(
            await run.call(run.owner, ORG_ROUTES.sessionTranscript(id), 'PUT', { mode: 'append', messages: [{ role: 'assistant', text: 'x', at, messageId: theirs.id }] }),
            400,
            'invalid-request',
            'a messageId on an assistant message',
          );
          const page = parseOrgTranscriptPage((await run.call(run.peer, ORG_ROUTES.sessionTranscript(id))).body);
          const [first, second, third] = page.messages;
          check(first?.author === run.peer && first.messageId === theirs.id, 'a user message that ran an inbox row is that row\'s author\'s, whatever the client said');
          check(second?.author === undefined || orgSupports(run.document, 'sharedTranscript'), 'an assistant message has no author');
          check(third?.author === run.owner, 'a user message without a messageId is the owner\'s, whatever the client said');
          const { id: plain } = await run.upload();
          check((await run.call(run.owner, ORG_ROUTES.sessionTranscript(plain), 'PUT', { mode: 'append', messages: [{ role: 'user', text: 'not live', at }] })).status === 200, 'transcript append to a session that is not live');
          const plainPage = parseOrgTranscriptPage((await run.call(run.owner, ORG_ROUTES.sessionTranscript(plain))).body);
          check(plainPage.messages[0]?.author === undefined || orgSupports(run.document, 'sharedTranscript'), 'a session that is not live names no author by default');
        }),
    },
    {
      name: 'live: turning live off or moving to the cloud holds what others queued',
      run: (context) =>
        withSessions(context, features, async (run) => {
          const { id } = await liveSession(run);
          await grant(run, id, run.peer, 'collaborator');
          const before = posted(await post(run, run.peer, id, 'c1', 'queued while live'), 'collaborator post');
          const mine = posted(await post(run, run.owner, id, 'o1', 'the owner\'s own'), 'owner post');
          check((await setLive(run, run.owner, id, { enabled: false })).status === 200, 'live off');
          check((await statusOf(run, id, before.id)) === 'held', 'another author\'s queued instruction is held once live is off');
          check((await statusOf(run, id, mine.id)) === 'queued', 'the owner\'s own message stays queued');
          run.expectError(await post(run, run.peer, id, 'c2', 'after off'), 409, 'not-in-cloud', 'post to a session that is no longer live');

          const second = await liveSession(run);
          await grant(run, second.id, run.peer, 'collaborator');
          const queued = posted(await post(run, run.peer, second.id, 'c1', 'queued before the move'), 'collaborator post');
          const caps = parseOrgCloudCapabilities((await run.call(run.owner, ORG_ROUTES.cloudCapabilities)).body);
          const payload = gz('state at move');
          check((await rawCall(run, run.owner, ORG_ROUTES.sessionEnvelope(second.id), 'PUT', envelopeHeaders(host, caps.formats[0]!, payload, 0), payload)).status === 200, 'envelope upload');
          check((await run.call(run.owner, ORG_ROUTES.sessionCloudRuns(second.id), 'POST', { host, envelopeSha256: sha256Hex(payload) })).status === 200, 'move to cloud');
          check((await statusOf(run, second.id, queued.id)) === 'held', 'a collaborator\'s queued instruction is held once the session moves to the cloud');
          const later = posted(await post(run, run.peer, second.id, 'c2', 'after the move'), 'collaborator post after the move');
          check(later.status === 'held', 'a cloud session holds a collaborator\'s message for the owner, live or not');
        }),
    },
    {
      name: 'live: an undeclared liveSessions feature is not served',
      run: (context) =>
        withSessions(context, ['sessions'], async (run) => {
          if (orgSupports(run.document, 'liveSessions')) return;
          const { id } = await run.upload();
          run.expectError(await run.call(run.owner, ORG_ROUTES.sessionLive(id)), 404, 'not-found', 'live read');
          run.expectError(await setLive(run, run.owner, id, { enabled: true, host }), 404, 'not-found', 'live write');
          run.expectError(await claim(run, run.owner, id), 404, 'not-found', 'claim');
          run.expectError(await run.call(run.owner, ORG_ROUTES.sessionMessagesDone(id), 'POST', { host, turnId: 'turn-1' }), 404, 'not-found', 'done');
          run.expectError(await run.call(run.owner, `${ORG_ROUTES.livePending}?host=${host}`), 404, 'not-found', 'pending');
          check(parseOrgSessionView((await run.call(run.owner, ORG_ROUTES.session(id))).body).live === undefined, 'the session view carries no live switch');
        }),
    },
  ];
}

function sharedTranscriptConformanceCases(): OrgProviderConformanceCase[] {
  const features: OrgFeature[] = ['sessions', 'sharedTranscript'];
  const at = new Date(1_700_000_000_000).toISOString();
  const grant = async (run: SessionsRun, id: string, principal: UserPrincipal, role: 'viewer' | 'collaborator' | 'driver') => {
    const answer = await run.call(run.owner, ORG_ROUTES.sessionGrants(id), 'POST', { principal, role });
    check(answer.status === 200, `grant answered ${answer.status}, expected 200`);
  };
  const append = (run: SessionsRun, as: UserPrincipal, id: string, messages: unknown[], extra: Record<string, unknown> = {}) =>
    run.call(as, ORG_ROUTES.sessionTranscript(id), 'PUT', { mode: 'append', messages, ...extra });
  const read = async (run: SessionsRun, as: UserPrincipal, id: string) => {
    const answer = await run.call(as, ORG_ROUTES.sessionTranscript(id));
    check(answer.status === 200, `transcript read answered ${answer.status}, expected 200`);
    return parseOrgTranscriptPage(answer.body);
  };
  const ok = (answer: Answer, label: string) => check(answer.status === 200, `${label} answered ${answer.status}, expected 200`);

  return [
    {
      name: 'sharedTranscript: a collaborator or driver appends user and assistant messages, a viewer and a stranger cannot',
      run: (context) =>
        withSessions(context, features, async (run) => {
          const { id } = await run.upload();
          await grant(run, id, run.peer, 'collaborator');
          ok(await append(run, run.peer, id, [{ role: 'user', text: 'from the collaborator', at, id: 'bob-1' }, { role: 'assistant', text: 'their Marshal', at, id: 'bob-2' }]), 'collaborator append');
          await grant(run, id, run.peer, 'driver');
          ok(await append(run, run.peer, id, [{ role: 'user', text: 'from the driver', at }]), 'driver append');
          await grant(run, id, run.peer, 'viewer');
          run.expectError(await append(run, run.peer, id, [{ role: 'user', text: 'x', at }]), 403, 'forbidden', 'viewer append');
          run.expectError(await append(run, run.third, id, [{ role: 'user', text: 'x', at }]), 404, 'not-found', 'stranger append');
          run.expectError(await append(run, undefined as unknown as UserPrincipal, id, [{ role: 'user', text: 'x', at }]), 401, 'unauthorized', 'unauthenticated append');
          check((await read(run, run.owner, id)).total === 3, 'only the collaborator\'s and the driver\'s writes were stored');
        }),
    },
    {
      name: 'sharedTranscript: a non-owner only appends user and assistant messages, never replaces',
      run: (context) =>
        withSessions(context, features, async (run) => {
          const { id } = await run.upload();
          await grant(run, id, run.peer, 'collaborator');
          run.expectError(await run.call(run.peer, ORG_ROUTES.sessionTranscript(id), 'PUT', { mode: 'replace', messages: [] }), 403, 'forbidden', 'collaborator replace');
          for (const role of ['system', 'tool']) {
            const answer = await append(run, run.peer, id, [{ role, text: 'x', at }]);
            check(answer.status === 400 || answer.status === 403, `a ${role} message from a collaborator answered ${answer.status}, expected a refusal`);
          }
          run.expectError(await append(run, run.peer, id, [{ role: 'user', text: 'x', at, messageId: '3f0e9d3e-5b1c-4f5d-9c7a-0a1b2c3d4e5f' }]), 400, 'invalid-request', 'collaborator messageId');
          ok(await append(run, run.owner, id, [{ role: 'user', text: 'one', at }]), 'owner append');
          run.expectError(await append(run, run.peer, id, [{ role: 'user', text: 'two', at }], { expectedCount: 0 }), 409, 'conflict', 'append against a stale count');
          ok(await append(run, run.peer, id, [{ role: 'user', text: 'two', at }], { expectedCount: 1 }), 'append against the current count');
          check((await read(run, run.owner, id)).total === 2, 'refused writes stored nothing');
        }),
    },
    {
      name: 'sharedTranscript: the server names the caller as the author of every message and returns the client id',
      run: (context) =>
        withSessions(context, features, async (run) => {
          const { id } = await run.upload();
          await grant(run, id, run.peer, 'collaborator');
          ok(await append(run, run.owner, id, [{ role: 'user', text: 'owner says', at, id: 'o-1', author: run.peer }, { role: 'assistant', text: 'owner reply', at, id: 'o-2' }]), 'owner append');
          ok(await append(run, run.peer, id, [{ role: 'user', text: 'peer says', at, id: 'p-1', author: run.owner }, { role: 'assistant', text: 'peer reply', at, id: 'p-2' }]), 'peer append');
          for (const reader of [run.owner, run.peer]) {
            const page = await read(run, reader, id);
            check(
              page.messages.map((entry) => `${entry.id}:${entry.author}`).join('|') === `o-1:${run.owner}|o-2:${run.owner}|p-1:${run.peer}|p-2:${run.peer}`,
              'every message carries its writer as author and its id, whatever the client said and whoever reads',
            );
          }
        }),
    },
    {
      name: 'sharedTranscript: the owner replaces only while the transcript holds nobody else\'s message',
      run: (context) =>
        withSessions(context, features, async (run) => {
          const { id } = await run.upload();
          await grant(run, id, run.peer, 'collaborator');
          ok(await append(run, run.owner, id, [{ role: 'user', text: 'mine', at }]), 'owner append');
          ok(await run.call(run.owner, ORG_ROUTES.sessionTranscript(id), 'PUT', { mode: 'replace', messages: [{ role: 'user', text: 'mine again', at }] }), 'owner replace before others wrote');
          ok(await append(run, run.peer, id, [{ role: 'user', text: 'theirs', at }]), 'peer append');
          run.expectError(await run.call(run.owner, ORG_ROUTES.sessionTranscript(id), 'PUT', { mode: 'replace', messages: [{ role: 'user', text: 'overwrite', at }] }), 409, 'conflict', 'owner replace after another wrote');
          ok(await append(run, run.owner, id, [{ role: 'assistant', text: 'still appends', at }]), 'owner append after another wrote');
          const page = await read(run, run.owner, id);
          check(page.messages.map((entry) => entry.text).join('|') === 'mine again|theirs|still appends', 'the refused replace changed nothing');
        }),
    },
    {
      name: 'sharedTranscript: two people appending at the same time both keep their messages, in arrival order',
      run: (context) =>
        withSessions(context, features, async (run) => {
          const { id } = await run.upload();
          await grant(run, id, run.peer, 'collaborator');
          const writes = [run.owner, run.peer, run.owner, run.peer].map((who, turn) =>
            append(run, who, id, [{ role: 'user', text: `${who} ${turn} a`, at, id: `w${turn}-a` }, { role: 'assistant', text: `${who} ${turn} b`, at, id: `w${turn}-b` }]),
          );
          for (const answer of await Promise.all(writes)) ok(answer, 'concurrent append');
          const page = await read(run, run.peer, id);
          check(page.total === 8, `expected 8 messages after four concurrent two-message appends, found ${page.total}`);
          for (let turn = 0; turn < 4; turn += 1) {
            const first = page.messages.findIndex((entry) => entry.id === `w${turn}-a`);
            check(first >= 0 && page.messages[first + 1]?.id === `w${turn}-b`, 'one append\'s messages stay together and in order');
          }
          check((await read(run, run.owner, id)).messages.map((entry) => entry.id).join() === page.messages.map((entry) => entry.id).join(), 'both people read the same order');
        }),
    },
    {
      name: 'sharedTranscript: a transcript cursor is the decimal index of the next message',
      run: (context) =>
        withSessions(context, ['sessions'], async (run) => {
          const { id } = await run.upload();
          const messages = Array.from({ length: 5 }, (_, index) => ({ role: 'user', text: `m${index}`, at }));
          ok(await append(run, run.owner, id, messages), 'owner append');
          const route = ORG_ROUTES.sessionTranscript(id);
          const first = parseOrgTranscriptPage((await run.call(run.owner, `${route}?limit=2`)).body);
          check(first.nextCursor === '2', 'the cursor after two messages is "2"');
          const rest = parseOrgTranscriptPage((await run.call(run.owner, `${route}?cursor=${first.nextCursor}`)).body);
          check(rest.messages.map((entry) => entry.text).join() === 'm2,m3,m4' && rest.nextCursor === undefined, 'a cursor reads from that message index on');
          const from = parseOrgTranscriptPage((await run.call(run.owner, `${route}?cursor=4`)).body);
          check(from.messages.map((entry) => entry.text).join() === 'm4', 'a client-built String(n) cursor reads from message n');
          const end = parseOrgTranscriptPage((await run.call(run.owner, `${route}?cursor=5`)).body);
          check(end.messages.length === 0 && end.total === 5, 'the cursor at the end reads nothing');
        }),
    },
    {
      name: 'sharedTranscript: an undeclared feature leaves the transcript as it was',
      run: (context) =>
        withSessions(context, ['sessions'], async (run) => {
          if (orgSupports(run.document, 'sharedTranscript')) return;
          const { id } = await run.upload();
          await grant(run, id, run.peer, 'collaborator');
          run.expectError(await append(run, run.peer, id, [{ role: 'user', text: 'x', at }]), 403, 'forbidden', 'collaborator append');
          ok(await append(run, run.owner, id, [{ role: 'assistant', text: 'y', at, id: 'ignored' }]), 'owner append');
          const page = await read(run, run.peer, id);
          check(page.messages[0]?.author === undefined && page.messages[0]?.id === undefined, 'no author on an assistant message and no client id is kept');
        }),
    },
  ];
}

function cloudListConformanceCases(): OrgProviderConformanceCase[] {
  const features: OrgFeature[] = ['sessions', 'leases', 'cloudRuns', 'cloudList'];
  const list = async (run: SessionsRun, as: UserPrincipal, query: string): Promise<OrgSessionPage> => {
    const answer = await run.call(as, `${ORG_ROUTES.sessions}${query}`);
    check(answer.status === 200, `session list answered ${answer.status}, expected 200`);
    return parseOrgSessionPage(answer.body);
  };
  const moveToCloud = async (run: SessionsRun, id: string): Promise<void> => {
    const answer = await run.call(run.owner, ORG_ROUTES.cloudCapabilities);
    check(answer.status === 200, `capabilities answered ${answer.status}, expected 200`);
    const caps = parseOrgCloudCapabilities(answer.body);
    check((await run.call(run.owner, ORG_ROUTES.sessionLease(id), 'POST', { host: 'host-a', ttlSeconds: 120 })).status === 200, 'owner acquire');
    const payload = gz('state at move');
    check((await rawCall(run, run.owner, ORG_ROUTES.sessionEnvelope(id), 'PUT', envelopeHeaders('host-a', caps.formats[0]!, payload, 0), payload)).status === 200, 'envelope upload');
    check((await run.call(run.owner, ORG_ROUTES.sessionCloudRuns(id), 'POST', { host: 'host-a', envelopeSha256: sha256Hex(payload) })).status === 200, 'move to cloud');
  };

  return [
    {
      name: 'cloudList: placement and owner=me filter the list, and every row carries its summary',
      run: (context) =>
        withSessions(context, features, async (run) => {
          const local = await run.upload();
          const cloud = await run.upload();
          const shared = await run.upload();
          await moveToCloud(run, cloud.id);
          check((await run.call(run.owner, ORG_ROUTES.sessionGrants(shared.id), 'POST', { principal: run.peer, role: 'viewer' })).status === 200, 'grant to the peer');
          const ids = (page: OrgSessionPage) => page.sessions.map((view) => view.session.id);
          const onlyCloud = await list(run, run.owner, '?placement=cloud&owner=me&limit=100');
          check(ids(onlyCloud).includes(cloud.id) && !ids(onlyCloud).includes(local.id) && !ids(onlyCloud).includes(shared.id), 'placement=cloud&owner=me must list the session moved to the cloud and neither of the others');
          check(onlyCloud.sessions.every((view) => view.placement === 'cloud' && view.role === 'owner'), 'every row of placement=cloud&owner=me must be a cloud session the caller owns');
          const row = onlyCloud.sessions.find((view) => view.session.id === cloud.id)!;
          check(typeof row.queued === 'number' && row.turnState !== undefined && row.lastActivityAt !== undefined, 'a row must carry placement, turnState, queued and lastActivityAt');
          const onlyLocal = await list(run, run.owner, '?placement=local&owner=me&limit=100');
          check(ids(onlyLocal).includes(local.id) && ids(onlyLocal).includes(shared.id) && !ids(onlyLocal).includes(cloud.id), 'placement=local&owner=me must exclude the cloud session');
          check(onlyLocal.sessions.every((view) => view.placement === 'local'), 'every row of placement=local must be local');
          const all = await list(run, run.owner, '?limit=100');
          check(ids(all).includes(local.id) && ids(all).includes(cloud.id) && all.sessions.every((view) => view.placement !== undefined && view.lastActivityAt !== undefined), 'an unfiltered list carries the summary too');
          const peerRows = await list(run, run.peer, '?owner=me&limit=100');
          check(!ids(peerRows).includes(shared.id) && peerRows.sessions.every((view) => view.role === 'owner'), 'owner=me must hide sessions that are only shared with the caller');
          check(ids(await list(run, run.peer, '?limit=100')).includes(shared.id), 'the peer still sees the shared session without owner=me');
          check(!ids(await list(run, run.peer, '?placement=cloud&owner=me&limit=100')).includes(cloud.id), 'a filter must not widen who sees a session');
        }),
    },
    {
      name: 'cloudList: a queued message shows in the summary, and bad filters (placement without owner=me included) are refused',
      run: (context) =>
        withSessions(context, [...features, 'messages'], async (run) => {
          const { id } = await run.upload();
          await moveToCloud(run, id);
          const sent = await run.call(run.owner, ORG_ROUTES.sessionMessages(id), 'POST', { clientMsgId: 'q1', text: 'queued while the cloud works' });
          check(sent.status === 202, `post answered ${sent.status}, expected 202`);
          const row = (await list(run, run.owner, '?placement=cloud&owner=me')).sessions.find((view) => view.session.id === id);
          check(row?.queued === 1, 'the queued message must be counted');
          check(row.turnState === 'running' || row.turnState === 'queued', 'a cloud session with work must be running or queued');
          run.expectError(await run.call(run.owner, `${ORG_ROUTES.sessions}?placement=moon&owner=me`), 400, 'invalid-request', 'list with a bad placement');
          run.expectError(await run.call(run.owner, `${ORG_ROUTES.sessions}?placement=cloud`), 400, 'invalid-request', 'placement without owner=me');
          run.expectError(await run.call(run.owner, `${ORG_ROUTES.sessions}?placement=local&owner=you`), 400, 'invalid-request', 'placement with a bad owner');
          run.expectError(await run.call(run.owner, `${ORG_ROUTES.sessions}?owner=you`), 400, 'invalid-request', 'list with a bad owner');
          run.expectError(await run.call(undefined, `${ORG_ROUTES.sessions}?placement=cloud&owner=me`), 401, 'unauthorized', 'list without a token');
        }),
    },
  ];
}

function forkConformanceCases(): OrgProviderConformanceCase[] {
  const features: OrgFeature[] = ['sessions', 'leases', 'cloudRuns', 'forks'];
  const body = (id: string) => ({ clientForkId: id });
  const forkOf = (answer: Answer, label: string): OrgForkResult => {
    check(answer.status === 200, `${label} answered ${answer.status}, expected 200`);
    return parseOrgForkResult(answer.body);
  };
  const formatOf = async (run: SessionsRun): Promise<string> => {
    const answer = await run.call(run.owner, ORG_ROUTES.cloudCapabilities);
    check(answer.status === 200, `capabilities answered ${answer.status}, expected 200`);
    return parseOrgCloudCapabilities(answer.body).formats[0]!;
  };
  const turn = (index: number) => ({ role: index % 2 ? 'assistant' : 'user', text: `turn ${index}`, at: new Date().toISOString() });
  /** The owner drives the session, writes `count` messages and an envelope, and releases with a checkpoint that names it. */
  const checkpointed = async (run: SessionsRun, id: string, count: number, state: string): Promise<Uint8Array> => {
    const format = await formatOf(run);
    check((await run.call(run.owner, ORG_ROUTES.sessionLease(id), 'POST', { host: 'host-a', ttlSeconds: 120 })).status === 200, 'owner acquire');
    check((await run.call(run.owner, ORG_ROUTES.sessionTranscript(id), 'PUT', { mode: 'replace', messages: Array.from({ length: count }, (_, index) => turn(index)) })).status === 200, 'transcript write');
    const payload = gz(state);
    check((await rawCall(run, run.owner, ORG_ROUTES.sessionEnvelope(id), 'PUT', envelopeHeaders('host-a', format, payload, count), payload)).status === 200, 'envelope upload');
    const released = await run.call(run.owner, ORG_ROUTES.sessionLeaseRelease(id), 'POST', { host: 'host-a', checkpoint: { messageCount: count, stateRef: envelopeStateRef(sha256Hex(payload)) } });
    check(released.status === 200, `release answered ${released.status}, expected 200`);
    return payload;
  };
  const grant = (run: SessionsRun, id: string, principal: UserPrincipal, role: 'viewer' | 'collaborator' | 'driver') =>
    run.call(run.owner, ORG_ROUTES.sessionGrants(id), 'POST', { principal, role });

  return [
    {
      name: 'forks: the owner forks the checkpoint into a new session of their own, with the transcript and the envelope, and the source is untouched',
      run: (context) =>
        withSessions(context, features, async (run) => {
          const { id } = await run.upload();
          const payload = await checkpointed(run, id, 3, 'state at the checkpoint');
          const leaseBefore = await run.call(run.owner, ORG_ROUTES.sessionLease(id));
          const made = forkOf(await run.call(run.owner, ORG_ROUTES.sessionFork(id), 'POST', body('f1')), 'owner fork');
          check(made.session.id !== id && made.session.owner === run.owner && made.role === 'owner', 'the fork must be a new session owned by the caller');
          check(made.session.transcript.messageCount === 3, 'the fork keeps the transcript the envelope covers');
          check(made.forkedFrom.sessionId === id && made.forkedFrom.messageCount === 3 && made.forkedFrom.envelopeSha256 === sha256Hex(payload), 'forkedFrom must name the source, the envelope and the messages kept');
          check(made.session.forkedFrom?.sessionId === id, 'the fork\'s own envelope must carry forkedFrom');
          check(made.envelope?.sha256 === sha256Hex(payload) && made.envelope.messageCount === 3, 'the result must describe the copied envelope');
          const view = await run.call(run.owner, ORG_ROUTES.session(made.session.id));
          check(view.status === 200 && parseOrgSessionView(view.body).session.forkedFrom?.sessionId === id, 'GET of the fork must show where it came from');
          check(isDeepStrictEqual((await run.call(run.owner, ORG_ROUTES.sessionLease(id))).body, leaseBefore.body), 'a fork must not change the source\'s lease');
          check(parseOrgSessionView((await run.call(run.owner, ORG_ROUTES.session(id))).body).session.forkedFrom === undefined, 'the source is not a fork');
          const page = await run.call(run.owner, ORG_ROUTES.sessionTranscript(made.session.id));
          check(page.status === 200 && parseOrgTranscriptPage(page.body).messages.map((entry) => entry.text).join('|') === 'turn 0|turn 1|turn 2', 'the fork\'s transcript must be the source\'s first messages');
          const download = await rawCall(run, run.owner, ORG_ROUTES.sessionFork(made.session.id), 'GET', {});
          check(download.status === 200 && Buffer.compare(Buffer.from(download.bytes), Buffer.from(payload)) === 0, 'the fork\'s owner downloads the copied envelope');
          check(download.headers.get(ENVELOPE_HEADERS.sha256) === sha256Hex(payload) && download.headers.get(ENVELOPE_HEADERS.messages) === '3', 'the download carries the envelope headers');
          const again = forkOf(await run.call(run.owner, ORG_ROUTES.sessionFork(id), 'POST', body('f1')), 'repeated fork');
          check(again.session.id === made.session.id, 'the same clientForkId must return the fork already made');
          const other = forkOf(await run.call(run.owner, ORG_ROUTES.sessionFork(id), 'POST', body('f2')), 'second fork');
          check(other.session.id !== made.session.id, 'another clientForkId makes another fork');
          const elsewhere = await run.upload();
          await checkpointed(run, elsewhere.id, 1, 'state of another session');
          run.expectError(await run.call(run.owner, ORG_ROUTES.sessionFork(elsewhere.id), 'POST', body('f1')), 409, 'conflict', 'a retry key already used on another source');
          const named = forkOf(await run.call(run.owner, ORG_ROUTES.sessionFork(id), 'POST', { clientForkId: 'f3', newId: id }), 'fork that asks for an id');
          check(named.session.id !== id && named.session.id !== made.session.id, 'the server names the fork, whatever id the request asks for');
        }),
    },
    {
      name: 'forks: a driver may fork and owns the fork, others may not, and the fork is private',
      run: (context) =>
        withSessions(context, features, async (run) => {
          const { id } = await run.upload();
          await checkpointed(run, id, 2, 'shared state');
          await grant(run, id, run.peer, 'driver');
          check((await run.call(run.owner, ORG_ROUTES.sessionGrants(id), 'POST', { principal: run.third, role: 'collaborator' })).status === 200, 'grant to the third member');
          run.expectError(await run.call(undefined, ORG_ROUTES.sessionFork(id), 'POST', body('x')), 401, 'unauthorized', 'fork without a token');
          run.expectError(await run.call(run.third, ORG_ROUTES.sessionFork(id), 'POST', body('x')), 403, 'forbidden', 'fork by a collaborator');
          const made = forkOf(await run.call(run.peer, ORG_ROUTES.sessionFork(id), 'POST', body('p1')), 'driver fork');
          check(made.session.owner === run.peer, 'the driver owns the fork');
          const mine = await run.call(run.peer, ORG_ROUTES.session(made.session.id));
          check(mine.status === 200 && (parseOrgSessionView(mine.body).grants ?? []).length === 0, 'a fork carries no grants');
          run.expectError(await run.call(run.owner, ORG_ROUTES.session(made.session.id)), 404, 'not-found', 'the source owner reading the driver\'s private fork');
          run.expectError(await run.call(run.owner, ORG_ROUTES.sessionFork(made.session.id), 'GET'), 404, 'not-found', 'the source owner downloading the driver\'s fork');
          const lease = await run.call(run.peer, ORG_ROUTES.sessionLease(id));
          check(lease.status === 200 && parseOrgLeaseView(lease.body).lease === null, 'the source stays free');
          if (orgSupports(run.document, 'notifications')) {
            const notices = await run.call(run.owner, ORG_ROUTES.notifications);
            check(notices.status === 200 && parseOrgNotificationPage(notices.body).notifications.some((entry) => entry.kind === 'fork' && entry.sessionId === id && entry.from === run.peer), 'the source owner is told about the fork');
          }
        }),
    },
    {
      name: 'forks: no checkpoint, no fork; and bad requests and a session that is no fork are refused',
      run: (context) =>
        withSessions(context, features, async (run) => {
          const { id } = await run.upload();
          run.expectError(await run.call(run.owner, ORG_ROUTES.sessionFork(id), 'POST', body('a')), 409, 'no-checkpoint', 'fork of a session that never released');
          const format = await formatOf(run);
          await checkpointed(run, id, 2, 'first');
          check((await run.call(run.owner, ORG_ROUTES.sessionLease(id), 'POST', { host: 'host-a', ttlSeconds: 120 })).status === 200, 'owner acquire again');
          const newer = gz('second, uploaded mid-turn');
          check((await rawCall(run, run.owner, ORG_ROUTES.sessionEnvelope(id), 'PUT', envelopeHeaders('host-a', format, newer, 2), newer)).status === 200, 'newer envelope upload');
          run.expectError(await run.call(run.owner, ORG_ROUTES.sessionFork(id), 'POST', body('b')), 409, 'no-checkpoint', 'fork while the stored envelope is newer than the checkpoint');
          run.expectError(await run.call(run.owner, ORG_ROUTES.sessionFork(id), 'POST', {}), 400, 'invalid-request', 'fork without a retry key');
          run.expectError(await run.call(run.owner, ORG_ROUTES.sessionFork(id), 'POST', { clientForkId: 'has space' }), 400, 'invalid-request', 'fork with a bad retry key');
          run.expectError(await run.call(run.third, ORG_ROUTES.sessionFork(id), 'POST', body('d')), 404, 'not-found', 'fork by a stranger');
          const download = await rawCall(run, run.owner, ORG_ROUTES.sessionFork(id), 'GET', {});
          rawError(download, 409, 'no-envelope', 'download of a session that is no fork');
        }),
    },
  ];
}

function multiUserConformanceCases(): OrgProviderConformanceCase[] {
  const features: OrgFeature[] = ['sessions', 'leases', 'cloudRuns', 'messages', 'multiUser'];
  const send = (run: SessionsRun, as: UserPrincipal | undefined, id: string, clientMsgId: string, kind?: string): Promise<Answer> =>
    run.call(as, ORG_ROUTES.sessionMessages(id), 'POST', { clientMsgId, text: `text of ${clientMsgId}`, ...(kind === undefined ? {} : { kind }) });
  const list = async (run: SessionsRun, as: UserPrincipal, id: string): Promise<OrgSessionMessagePage> => {
    const answer = await run.call(as, ORG_ROUTES.sessionMessages(id));
    check(answer.status === 200, `message list answered ${answer.status}, expected 200`);
    return parseOrgSessionMessagePage(answer.body);
  };
  const inCloud = async (run: SessionsRun): Promise<{ id: string }> => {
    const { id } = await run.upload();
    const caps = await run.call(run.owner, ORG_ROUTES.cloudCapabilities);
    check(caps.status === 200, `capabilities answered ${caps.status}, expected 200`);
    const formats = parseOrgCloudCapabilities(caps.body).formats;
    check((await run.call(run.owner, ORG_ROUTES.sessionLease(id), 'POST', { host: 'host-a', ttlSeconds: 120 })).status === 200, 'owner acquire');
    const payload = gz('state at move');
    check((await rawCall(run, run.owner, ORG_ROUTES.sessionEnvelope(id), 'PUT', envelopeHeaders('host-a', formats[0]!, payload, 0), payload)).status === 200, 'envelope upload');
    check((await run.call(run.owner, ORG_ROUTES.sessionCloudRuns(id), 'POST', { host: 'host-a', envelopeSha256: sha256Hex(payload) })).status === 200, 'move to cloud');
    return { id };
  };

  return [
    {
      name: 'multiUser: a viewer comments, the comment is held, marked and visible to the owner, and an instruction from a viewer is still refused',
      run: (context) =>
        withSessions(context, features, async (run) => {
          const { id } = await inCloud(run);
          check((await run.call(run.owner, ORG_ROUTES.sessionGrants(id), 'POST', { principal: run.third, role: 'viewer' })).status === 200, 'grant a viewer');
          const answer = await send(run, run.third, id, 'n1', 'comment');
          check(answer.status === 202, `a viewer's comment answered ${answer.status}, expected 202`);
          check(parseOrgPostedMessage(answer.body).status === 'held', 'a comment must be held');
          const seen = (await list(run, run.owner, id)).messages;
          check(seen.length === 1 && seen[0]!.kind === 'comment' && seen[0]!.author === run.third && seen[0]!.roleAtSend === 'viewer', 'the owner must see the comment, marked as one, with its author and role');
          check((await list(run, run.third, id)).messages.length === 1, 'the author sees their own comment');
          run.expectError(await send(run, run.third, id, 'i1'), 403, 'forbidden', 'instruction by a viewer');
          run.expectError(await send(run, run.peer, id, 'n2', 'comment'), 404, 'not-found', 'comment without a grant');
        }),
    },
    {
      name: 'multiUser: the owner cannot run a comment, the author can cancel it, and a repeated clientMsgId returns the first comment',
      run: (context) =>
        withSessions(context, features, async (run) => {
          const { id } = await inCloud(run);
          check((await run.call(run.owner, ORG_ROUTES.sessionGrants(id), 'POST', { principal: run.third, role: 'viewer' })).status === 200, 'grant a viewer');
          const first = parseOrgPostedMessage((await send(run, run.third, id, 'n1', 'comment')).body);
          const again = await send(run, run.third, id, 'n1', 'comment');
          check(again.status === 202 && parseOrgPostedMessage(again.body).id === first.id, 'a repeated comment must return the first');
          run.expectError(await run.call(run.owner, ORG_ROUTES.sessionMessageRun(id, first.id), 'POST', { clientMsgId: 'r1' }), 409, 'conflict', 'run of a comment');
          const cancelled = await run.call(run.third, ORG_ROUTES.sessionMessage(id, first.id), 'DELETE');
          check(cancelled.status === 200 && parseOrgSessionMessage(cancelled.body).status === 'cancelled', 'the author must be able to cancel a comment');
          run.expectError(await send(run, run.owner, id, 'n9', 'shout'), 400, 'invalid-request', 'unknown kind');
        }),
    },
    {
      name: 'multiUser: the owner is told once about held messages and comments, a muted session records none, and the mute is the caller\'s own',
      run: (context) =>
        withSessions(context, [...features, 'notifications'], async (run) => {
          const { id } = await inCloud(run);
          check((await run.call(run.owner, ORG_ROUTES.sessionGrants(id), 'POST', { principal: run.peer, role: 'collaborator' })).status === 200, 'grant a collaborator');
          check((await run.call(run.owner, ORG_ROUTES.sessionGrants(id), 'POST', { principal: run.third, role: 'viewer' })).status === 200, 'grant a viewer');
          const heldFor = async (): Promise<number> => {
            const answer = await run.call(run.owner, ORG_ROUTES.notifications);
            check(answer.status === 200, `notifications answered ${answer.status}, expected 200`);
            return parseOrgNotificationPage(answer.body).notifications.filter((entry) => entry.kind === 'held-message' && entry.sessionId === id).length;
          };
          const state = async (as: UserPrincipal): Promise<boolean> => {
            const answer = await run.call(as, ORG_ROUTES.sessionMute(id));
            check(answer.status === 200 && typeof (answer.body as { muted?: unknown }).muted === 'boolean', 'the mute state must be { muted: boolean }');
            return (answer.body as { muted: boolean }).muted;
          };
          check((await send(run, run.peer, id, 'p1')).status === 202, 'collaborator instruction');
          check((await send(run, run.third, id, 'n1', 'comment')).status === 202, 'viewer comment');
          check((await heldFor()) === 1, 'the owner must get one held-message notification, not one per message, within the throttle window');
          check(!(await state(run.owner)), 'a session starts unmuted');
          const muted = await run.call(run.owner, ORG_ROUTES.sessionMute(id), 'PUT', { muted: true });
          check(muted.status === 200 && (muted.body as { muted: boolean }).muted === true, 'the owner must be able to mute');
          check((await state(run.owner)) && !(await state(run.peer)), 'a mute belongs to the person who set it');
          run.expectError(await run.call(run.owner, ORG_ROUTES.sessionMute(id), 'PUT', { muted: 'yes' }), 400, 'invalid-request', 'mute with a bad body');
          run.expectError(await run.call(undefined, ORG_ROUTES.sessionMute(id)), 401, 'unauthorized', 'mute without a token');
        }),
    },
    {
      name: 'multiUser: an undeclared multiUser feature refuses comments',
      run: (context) =>
        withSessions(context, ['sessions', 'leases', 'cloudRuns', 'messages'], async (run) => {
          if (orgSupports(run.document, 'multiUser')) return;
          const { id } = await inCloud(run);
          run.expectError(await send(run, run.owner, id, 'n1', 'comment'), 400, 'invalid-request', 'comment without the feature');
          run.expectError(await run.call(run.owner, ORG_ROUTES.sessionMute(id)), 404, 'not-found', 'mute without the feature');
        }),
    },
  ];
}

function sessionWatchConformanceCases(): OrgProviderConformanceCase[] {
  const features: OrgFeature[] = ['sessions', 'sessionWatch'];
  const open = async (run: SessionsRun, as: UserPrincipal, id: string, after?: string, signal?: AbortSignal): Promise<Response> =>
    run.context.fetch(apiUrl(run.document, `${ORG_ROUTES.sessionWatch(id)}${after === undefined ? '' : `?after=${after}`}`), {
      method: 'GET',
      headers: { accept: WATCH_CONTENT_TYPE, authorization: await run.auth(as) },
      ...(signal ? { signal } : {}),
    });
  const nextPing = async (events: AsyncGenerator<OrgWatchEvent>, label: string): Promise<Extract<OrgWatchEvent, { type: 'ping' }>> => {
    const timeout = new Promise<never>((_, reject) => setTimeout(() => reject(new Error(`conformance: no ${label} within 5 s`)), 5000));
    const next = await Promise.race([events.next(), timeout]);
    check(!next.done && next.value.type === 'ping', `${label}: expected a ping event`);
    return next.value;
  };

  return [
    {
      name: 'sessionWatch: the feed streams a first ping naming every kind, then a ping for a change, and resumes after a version',
      run: (context) =>
        withSessions(context, features, async (run) => {
          const { id } = await run.upload();
          const controller = new AbortController();
          const response = await open(run, run.owner, id, undefined, controller.signal);
          check(response.status === 200, `watch answered ${response.status}, expected 200`);
          check((response.headers.get('content-type') ?? '').startsWith(WATCH_CONTENT_TYPE), 'watch must answer text/event-stream');
          check(response.body !== null, 'watch must stream a body');
          const events = readWatchEvents(response.body);
          const first = await nextPing(events, 'first ping');
          check(WATCH_KINDS.every((kind) => first.kinds.includes(kind)), 'the first ping must name every kind');
          check(WATCH_VERSION_PATTERN.test(first.version), 'a version must be 16 lowercase hex characters');
          const write = await run.call(run.owner, ORG_ROUTES.sessionTranscript(id), 'PUT', { mode: 'replace', messages: [message(0)] });
          check(write.status === 200, `transcript upload answered ${write.status}, expected 200`);
          const changed = await nextPing(events, 'change ping');
          check(changed.version !== first.version && changed.kinds.includes('transcript'), 'a transcript change must produce a new version naming transcript');
          controller.abort();
          const resumed = new AbortController();
          const again = await open(run, run.owner, id, changed.version, resumed.signal);
          check(again.status === 200 && again.body !== null, 'a watch resumed with the current version must open');
          const quiet = readWatchEvents(again.body);
          const raced = await Promise.race([quiet.next(), new Promise<string>((resolve) => setTimeout(() => resolve('quiet'), 200))]);
          check(raced === 'quiet', 'a watch resumed with the current version must send nothing until something changes');
          resumed.abort();
        }),
    },
    {
      name: 'sessionWatch: no role is 404, a malformed after is 400, no token is 401, and other methods are refused',
      run: (context) =>
        withSessions(context, features, async (run) => {
          const { id } = await run.upload();
          const stranger = await open(run, run.peer, id);
          check(stranger.status === 404, `a caller without a role got ${stranger.status}, expected 404`);
          await stranger.body?.cancel();
          const malformed = await open(run, run.owner, id, 'not-a-version');
          check(malformed.status === 400, `a malformed after got ${malformed.status}, expected 400`);
          await malformed.body?.cancel();
          run.expectError(await run.call(undefined, ORG_ROUTES.sessionWatch(id)), 401, 'unauthorized', 'watch without a token');
          run.expectError(await run.call(run.owner, ORG_ROUTES.sessionWatch(id), 'POST', {}), 405, 'method-not-allowed', 'watch with POST');
        }),
    },
    {
      name: 'sessionWatch: an undeclared sessionWatch feature is not served',
      run: (context) =>
        withSessions(context, ['sessions'], async (run) => {
          if (orgSupports(run.document, 'sessionWatch')) return;
          const { id } = await run.upload();
          run.expectError(await run.call(run.owner, ORG_ROUTES.sessionWatch(id)), 404, 'not-found', 'watch');
        }),
    },
  ];
}

type RunsRun = {
  context: OrgProviderConformanceContext;
  document: OrgDiscoveryDocument;
  fixtures: OrgRunFixtures;
  call(principal: UserPrincipal | undefined, route: string, method?: string, body?: unknown): Promise<Answer>;
  expectError(answer: Answer, status: number, code: string, label: string): void;
};

async function withRuns(context: OrgProviderConformanceContext, body: (run: RunsRun) => Promise<void>): Promise<void> {
  const fixtures = context.runFixtures;
  if (!fixtures) return;
  const document = await discover(context);
  if (!orgSupports(document, 'runIndex')) return;
  await body({
    context,
    document,
    fixtures,
    call: async (principal, route, method = 'GET', payload) =>
      request(context, apiUrl(document, route), principal ? await bearer(context, principal) : undefined, { method, body: payload }),
    expectError(answer, status, code, label) {
      check(answer.status === status, `${label} answered ${answer.status}, expected ${status}`);
      check(expectErrorBody(answer, label) === code, `${label}: expected error "${code}"`);
    },
  });
}

function runIndexConformanceCases(): OrgProviderConformanceCase[] {
  const runs = (answer: Answer, label: string) => {
    check(answer.status === 200, `${label} answered ${answer.status}, expected 200`);
    return parseOrgRunPage(answer.body);
  };
  const listUrl = (query: Record<string, string>) => `${ORG_ROUTES.runs}?${new URLSearchParams(query).toString()}`;
  return [
    {
      name: 'runIndex: a requester lists only their own runs, including a direct-message run and an unassigned run',
      run: (context) =>
        withRuns(context, async (run) => {
          const { requester, runId, dmRunId, unassignedRunId } = run.fixtures;
          const page = runs(await run.call(requester, ORG_ROUTES.runs), 'requester list');
          check(page.runs.length > 0 && page.runs.every((row) => row.requester === requester), 'a requester must see only runs they requested');
          const ids = new Set(page.runs.map((row) => row.id));
          check(ids.has(runId), 'the requester must see their run');
          if (dmRunId) check(ids.has(dmRunId), 'the requester must see their direct-message run');
          if (unassignedRunId) check(ids.has(unassignedRunId), 'the requester must see their unassigned run');
          check(page.runs.every((row) => row.type === 'run'), 'every row must say type run');
        }),
    },
    {
      name: 'runIndex: a member with no right over a run learns nothing about it',
      run: (context) =>
        withRuns(context, async (run) => {
          const { other, runId, session } = run.fixtures;
          const page = runs(await run.call(other, ORG_ROUTES.runs), 'other list');
          check(!page.runs.some((row) => row.id === runId), 'a member with no right must not see the run in a list');
          for (const [label, route] of [
            ['get', ORG_ROUTES.run(runId)],
            ['events', ORG_ROUTES.runEvents(runId)],
            ['messages', ORG_ROUTES.runMessages(runId, session)],
            ['envelope', ORG_ROUTES.runEnvelope(runId, session)],
            ['absent run', ORG_ROUTES.run('conformance-no-such-run')],
          ] as const) {
            run.expectError(await run.call(other, route), 404, 'not-found', label);
          }
          run.expectError(await run.call(undefined, ORG_ROUTES.runs), 401, 'unauthorized', 'a list without a token');
        }),
    },
    {
      name: 'runIndex: an auditor reads the workspace runs but never a direct-message or unassigned run',
      run: (context) =>
        withRuns(context, async (run) => {
          const { auditor, workspace, runId, dmRunId, unassignedRunId } = run.fixtures;
          const page = runs(await run.call(auditor, listUrl({ workspace })), 'auditor list');
          check(page.runs.some((row) => row.id === runId), 'the auditor must see a run of the workspace');
          check(page.runs.every((row) => row.workspace === workspace), 'a workspace filter must return only that workspace');
          const all = runs(await run.call(auditor, ORG_ROUTES.runs), 'auditor unfiltered list');
          for (const hidden of [dmRunId, unassignedRunId]) {
            if (!hidden) continue;
            check(!all.runs.some((row) => row.id === hidden), 'an auditor must not see a direct-message or unassigned run');
            run.expectError(await run.call(auditor, ORG_ROUTES.run(hidden)), 404, 'not-found', 'auditor get of a hidden run');
          }
          const detail = parseOrgRunDetail((await run.call(auditor, ORG_ROUTES.run(runId))).body);
          check(detail.run.id === runId, 'the run detail must carry the requested run');
        }),
    },
    {
      name: 'runIndex: filters, paging and invalid input',
      run: (context) =>
        withRuns(context, async (run) => {
          const { requester, workspace, runId } = run.fixtures;
          const first = runs(await run.call(requester, listUrl({ limit: '1' })), 'first page');
          check(first.runs.length === 1, 'limit 1 must return one row');
          if (first.nextCursor !== undefined) {
            const second = runs(await run.call(requester, listUrl({ limit: '1', cursor: first.nextCursor })), 'second page');
            check(second.runs[0]?.id !== first.runs[0]?.id, 'the next page must not repeat the first row');
          }
          const byWorkspace = runs(await run.call(requester, listUrl({ workspace })), 'workspace filter');
          check(byWorkspace.runs.some((row) => row.id === runId), 'the workspace filter must keep the run');
          const none = runs(await run.call(requester, listUrl({ workflow: 'conformance-no-such-workflow' })), 'workflow filter');
          check(none.runs.length === 0, 'a workflow nobody ran must return no rows');
          for (const query of [{ status: 'exploded' }, { source: 'carrier-pigeon' }, { limit: '0' }, { since: 'yesterday' }, { requester: 'someone' }] as Record<string, string>[]) {
            run.expectError(await run.call(requester, listUrl(query)), 400, 'invalid-request', `list with ${JSON.stringify(query)}`);
          }
        }),
    },
    {
      name: 'runIndex: messages page by index, and a withheld session is reported, not hidden',
      run: (context) =>
        withRuns(context, async (run) => {
          const { requester, runId, session, withheld } = run.fixtures;
          const page = parseOrgRunMessagesPage((await run.call(requester, `${ORG_ROUTES.runMessages(runId, session)}?limit=2`)).body);
          check(page.messages.length > 0 && page.messages.length <= 2, 'limit 2 must return at most two messages');
          check(page.total >= 3, 'the fixture session must have at least three messages');
          check(page.nextFrom !== undefined, 'a partial page must carry nextFrom');
          const bytes = page.messages.reduce((sum, message) => sum + new TextEncoder().encode(message.text ?? '').length, 0);
          check(bytes <= MAX_TRANSCRIPT_PAGE_BYTES, 'a page must stay within the byte cap');
          const next = parseOrgRunMessagesPage((await run.call(requester, `${ORG_ROUTES.runMessages(runId, session)}?from=${page.nextFrom}&limit=2`)).body);
          check(next.messages[0]?.n === page.nextFrom, 'the next page must start at nextFrom');
          run.expectError(await run.call(requester, ORG_ROUTES.runMessages(runId, 'conformance-no-such-session')), 404, 'not-found', 'unknown session');
          run.expectError(await run.call(requester, `${ORG_ROUTES.runMessages(runId, session)}?from=-1`), 400, 'invalid-request', 'negative from');
          if (withheld) {
            run.expectError(await run.call(requester, ORG_ROUTES.runMessages(withheld.runId, withheld.session)), 409, 'transcript-unavailable', 'withheld session');
          }
          const events = parseOrgRunEventPage((await run.call(requester, ORG_ROUTES.runEvents(runId))).body);
          check(events.total >= events.events.length, 'event total must cover the page');
        }),
    },
    {
      name: 'runIndex: grep reads only runs the caller may read and is bounded',
      run: (context) =>
        withRuns(context, async (run) => {
          const { auditor, other, runId, grepText } = run.fixtures;
          if (grepText) {
            const found = parseOrgRunGrepResult((await run.call(auditor, ORG_ROUTES.runsGrep, 'POST', { runIds: [runId], pattern: grepText })).body);
            check(found.searched === 1 && found.hits.some((hit) => hit.runId === runId), 'an auditor grep must find the text in the run');
            check(found.hits.every((hit) => hit.excerpt.length <= 240), 'an excerpt must stay short');
            const blind = parseOrgRunGrepResult((await run.call(other, ORG_ROUTES.runsGrep, 'POST', { runIds: [runId], pattern: grepText })).body);
            check(blind.searched === 0 && blind.hits.length === 0, 'a grep by a member with no right must search nothing and say nothing');
          }
          const tooMany = Array.from({ length: MAX_GREP_RUNS + 1 }, (_, index) => `conformance-run-${index}`);
          run.expectError(await run.call(auditor, ORG_ROUTES.runsGrep, 'POST', { runIds: tooMany, pattern: 'abc' }), 400, 'invalid-request', 'grep over too many runs');
          run.expectError(await run.call(auditor, ORG_ROUTES.runsGrep, 'POST', { runIds: [runId], pattern: 'a' }), 400, 'invalid-request', 'grep with a one-character pattern');
        }),
    },
    {
      name: 'runIndex: a read by an auditor is logged, content-free, and visible to the requester; the requester reading their own run is not logged',
      run: (context) =>
        withRuns(context, async (run) => {
          const { requester, auditor, other, runId, session } = run.fixtures;
          await run.call(requester, ORG_ROUTES.run(runId));
          await run.call(auditor, ORG_ROUTES.run(runId));
          await run.call(auditor, ORG_ROUTES.runMessages(runId, session));
          const aboutRun = parseOrgAuditPage((await run.call(requester, `${ORG_ROUTES.audit}?target=${encodeURIComponent(`run:${runId}`)}`)).body);
          check(aboutRun.rows.some((row) => row.actor === auditor && row.basis === 'auditor' && row.action === 'get' && row.runId === runId), 'the requester must see the auditor read of their run');
          check(aboutRun.rows.some((row) => row.actor === auditor && row.action === 'messages'), 'a messages read must be logged');
          check(!aboutRun.rows.some((row) => row.actor === requester), 'a requester reading their own run must not be logged');
          const own = parseOrgAuditPage((await run.call(auditor, `${ORG_ROUTES.audit}?target=me`)).body);
          check(own.rows.length > 0 && own.rows.every((row) => row.actor === auditor || row.runId !== undefined), 'an auditor must see rows of their own reads');
          const byActor = parseOrgAuditPage((await run.call(requester, `${ORG_ROUTES.audit}?target=me&actor=${encodeURIComponent(auditor)}`)).body);
          check(byActor.rows.length > 0 && byActor.rows.every((row) => row.actor === auditor), 'the actor filter must keep only that actor');
          const aboutAuditor = parseOrgAuditPage((await run.call(auditor, `${ORG_ROUTES.audit}?target=${encodeURIComponent(`run:${runId}`)}`)).body);
          check(aboutAuditor.rows.every((row) => row.actor === auditor), 'an auditor must see only their own reads of a run');
          run.expectError(await run.call(other, `${ORG_ROUTES.audit}?target=${encodeURIComponent(`run:${runId}`)}`), 404, 'not-found', 'audit of a run the caller cannot read');
          run.expectError(await run.call(auditor, `${ORG_ROUTES.audit}?target=everyone`), 400, 'invalid-request', 'audit with a bad target');
          const text = JSON.stringify(aboutRun.rows);
          check(!text.includes('messages":'), 'an audit row must carry no content');
        }),
    },
    {
      name: 'runIndex: an undeclared runIndex feature is not served',
      run: async (context) => {
        const document = await discover(context);
        if (orgSupports(document, 'runIndex')) return;
        const call = async (route: string) => request(context, apiUrl(document, route), await bearer(context, context.memberPrincipal));
        for (const route of [ORG_ROUTES.runs, ORG_ROUTES.run('conformance-no-such-run'), `${ORG_ROUTES.audit}?target=me`]) {
          const answer = await call(route);
          check(answer.status === 404 && expectErrorBody(answer, 'undeclared runIndex') === 'not-found', `${route} must answer 404 not-found without the runIndex feature`);
        }
      },
    },
  ];
}
