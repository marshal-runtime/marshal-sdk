import { ORG_CONTRACT_VERSION, ORG_DISCOVERY_PATH, type OrgDiscoveryDocument, type OrgFeature } from '../discovery.js';
import {
  MAX_DIRECTORY_RESULTS,
  isOrgWorkspaceId,
  type DirectoryEntry,
  type OrgIdentity,
  type OrgWorkspace,
} from '../model.js';
import { pkceChallenge, randomUrlSafe, type FetchLike } from '../oidc.js';
import type { Principal, UserPrincipal } from '../principals.js';
import { isLoopbackHost } from '../validate.js';
import { createRunsHandler, type InMemoryRun } from './runs-handler.js';
import { createSessionsHandler } from './sessions-handler.js';
import type { OrgWorkspaceId } from '../model.js';

export type InMemoryOrgUser = {
  principal: UserPrincipal;
  email: string;
  displayName: string;
  groups?: Principal[];
  roles?: string[];
};

export type InMemoryOrgSeed = {
  /** Origin the fake serves. Default `https://org.fake.test`. */
  orgUrl?: string;
  orgId?: string;
  displayName?: string;
  clientId?: string;
  scopes?: string[];
  /** Features declared in the discovery document and served. Default `signIn`, `workspaces`, `directory`. */
  features?: OrgFeature[];
  /** The organization's members. A valid token for anyone else gets 403 `not-a-member`. */
  users: InMemoryOrgUser[];
  workspaces?: OrgWorkspace[];
  /** Directory entries. Default: one entry per user. */
  directory?: DirectoryEntry[];
  /** The user the authorize endpoint signs in. Default: the first user. */
  signInUser?: UserPrincipal;
  accessTokenTtlSeconds?: number;
  /** The fake cloud host behind the `cloudRuns` feature. */
  cloud?: { host?: string; formats?: string[]; maxEnvelopeBytes?: number; maxBundleBytes?: number; available?: boolean };
  /** The run index behind the `runIndex` feature: engine runs the fake serves, and who may read each workspace's runs. */
  runs?: InMemoryRun[];
  runAuditors?: Partial<Record<OrgWorkspaceId, UserPrincipal[]>>;
  /** Clock in epoch milliseconds, so tests can expire tokens. */
  now?: () => number;
};

export type InMemoryOrgProvider = {
  fetch: FetchLike;
  orgUrl: string;
  issuer: string;
  clientId: string;
  /** Issues an access token for any principal. Members are the seeded users. */
  issueToken(userPrincipal: UserPrincipal): string;
  /** Every request the fake served, in order. Authorization values are never recorded. */
  requests: { method: string; url: string }[];
  /** The audit rows the run routes wrote, oldest first. */
  runAuditRows(): readonly import('../runs.js').OrgAuditRow[];
  /** Drives the fake cloud host: `advance` runs one turn of a session it holds and releases at handover or when `finish` is set (`uploadEnvelope: false` appends the message but dies before uploading); `crash` lets its lease lapse. */
  cloud: {
    advance(sessionId: string, options?: { finish?: boolean; uploadEnvelope?: boolean }): { released: boolean };
    /** The cloud host dies without releasing; its lease lapses and the run turns `failed` (`lease-expired`). */
    crash(sessionId: string): void;
    setAvailable(available: boolean): void;
  };
};

type TokenRecord = { principal: UserPrincipal; expiresAt: number };
type CodeRecord = { principal: UserPrincipal; clientId: string; redirectUri: string; challenge: string };
type RefreshRecord = { principal: UserPrincipal; clientId: string };

const DEFAULT_FEATURES: OrgFeature[] = ['signIn', 'workspaces', 'directory'];

export function createInMemoryOrgProvider(seed: InMemoryOrgSeed): InMemoryOrgProvider {
  const origin = new URL(seed.orgUrl ?? 'https://org.fake.test').origin;
  const secure = origin.startsWith('https:') || isLoopbackHost(new URL(origin).hostname);
  if (!secure) throw new Error('orgUrl must be https, or http on a loopback host');
  const issuer = `${origin}/idp`;
  const apiBase = `${origin}/api`;
  const clientId = seed.clientId ?? 'marshal-desktop';
  const features = new Set<OrgFeature>(seed.features ?? DEFAULT_FEATURES);
  const now = seed.now ?? Date.now;
  const ttlMs = (seed.accessTokenTtlSeconds ?? 3600) * 1000;
  const users = new Map(seed.users.map((user) => [user.principal, user]));
  const workspaces = seed.workspaces ?? [];
  const directory: DirectoryEntry[] =
    seed.directory ??
    seed.users.map((user) => ({ principal: user.principal, kind: 'user' as const, displayName: user.displayName, email: user.email }));
  const signInUser = seed.signInUser ?? seed.users[0]?.principal;

  const accessTokens = new Map<string, TokenRecord>();
  const codes = new Map<string, CodeRecord>();
  const refreshTokens = new Map<string, RefreshRecord>();
  const requests: { method: string; url: string }[] = [];

  const discovery: OrgDiscoveryDocument = {
    version: ORG_CONTRACT_VERSION,
    orgId: seed.orgId ?? 'fake',
    displayName: seed.displayName ?? 'Fake Org',
    oidc: { issuer, clientId, scopes: seed.scopes ?? ['openid', 'email', 'profile'] },
    apiBase,
    features: [...features],
  };

  const json = (status: number, body: unknown, headers: Record<string, string> = {}) =>
    new Response(JSON.stringify(body), { status, headers: { 'content-type': 'application/json', ...headers } });
  const error = (status: number, code: string, headers: Record<string, string> = {}) => json(status, { error: code }, headers);

  function issueToken(principal: UserPrincipal): string {
    const token = `at_${randomUrlSafe(24)}`;
    accessTokens.set(token, { principal, expiresAt: now() + ttlMs });
    return token;
  }

  function tokenResponse(principal: UserPrincipal): Response {
    const refresh = `rt_${randomUrlSafe(24)}`;
    refreshTokens.set(refresh, { principal, clientId });
    return json(
      200,
      { access_token: issueToken(principal), token_type: 'Bearer', expires_in: Math.floor(ttlMs / 1000), refresh_token: refresh, scope: discovery.oidc.scopes.join(' ') },
      { 'cache-control': 'no-store' },
    );
  }

  function handleAuthorize(url: URL): Response {
    const params = url.searchParams;
    const redirectUri = params.get('redirect_uri') ?? '';
    let redirect: URL;
    try {
      redirect = new URL(redirectUri);
    } catch {
      return error(400, 'invalid-request');
    }
    if (redirect.protocol !== 'http:' || !isLoopbackHost(redirect.hostname)) return error(400, 'invalid-request');
    const fail = (code: string) => {
      redirect.searchParams.set('error', code);
      const state = params.get('state');
      if (state) redirect.searchParams.set('state', state);
      return new Response(null, { status: 302, headers: { location: redirect.toString() } });
    };
    if (params.get('client_id') !== clientId) return error(400, 'invalid-request');
    if (params.get('response_type') !== 'code') return fail('unsupported_response_type');
    const challenge = params.get('code_challenge');
    if (!challenge || params.get('code_challenge_method') !== 'S256') return fail('invalid_request');
    if (!signInUser || !users.has(signInUser)) return fail('access_denied');
    const code = `code_${randomUrlSafe(18)}`;
    codes.set(code, { principal: signInUser, clientId, redirectUri, challenge });
    redirect.searchParams.set('code', code);
    const state = params.get('state');
    if (state) redirect.searchParams.set('state', state);
    return new Response(null, { status: 302, headers: { location: redirect.toString() } });
  }

  async function handleToken(init: RequestInit | undefined): Promise<Response> {
    const form = new URLSearchParams(typeof init?.body === 'string' ? init.body : '');
    if (form.get('client_id') !== clientId) return error(401, 'invalid_client');
    const grant = form.get('grant_type');
    if (grant === 'authorization_code') {
      const code = form.get('code') ?? '';
      const record = codes.get(code);
      codes.delete(code);
      if (!record || record.redirectUri !== form.get('redirect_uri') || record.clientId !== clientId) return error(400, 'invalid_grant');
      const verifier = form.get('code_verifier') ?? '';
      if (verifier.length < 43 || (await pkceChallenge(verifier)) !== record.challenge) return error(400, 'invalid_grant');
      return tokenResponse(record.principal);
    }
    if (grant === 'refresh_token') {
      const refresh = form.get('refresh_token') ?? '';
      const record = refreshTokens.get(refresh);
      if (!record || record.clientId !== clientId) return error(400, 'invalid_grant');
      refreshTokens.delete(refresh);
      return tokenResponse(record.principal);
    }
    return error(400, 'unsupported_grant_type');
  }

  function authenticate(headers: Headers): { user: InMemoryOrgUser } | Response {
    const match = /^Bearer (\S+)$/.exec(headers.get('authorization') ?? '');
    const record = match ? accessTokens.get(match[1]!) : undefined;
    if (!record || record.expiresAt <= now()) return error(401, 'unauthorized', { 'www-authenticate': 'Bearer' });
    const user = users.get(record.principal);
    if (!user) return error(403, 'not-a-member');
    return { user };
  }

  let cloudAvailable = seed.cloud?.available ?? true;
  const sessionsHandler = createSessionsHandler({
    cloud: {
      host: seed.cloud?.host ?? 'cloud',
      formats: seed.cloud?.formats ?? ['claude-jsonl'],
      maxEnvelopeBytes: seed.cloud?.maxEnvelopeBytes ?? 40 * 1024 * 1024,
      maxBundleBytes: seed.cloud?.maxBundleBytes ?? 24 * 1024 * 1024,
      available: () => cloudAvailable,
    },
    features,
    isMember: (principal) => users.has(principal),
    workspaces,
    now,
    json,
    error,
  });

  const runsHandler = createRunsHandler({ features, now, runs: seed.runs ?? [], auditors: seed.runAuditors ?? {}, json, error });

  async function handleApi(method: string, path: string, url: URL, init: RequestInit | undefined, headers: Headers): Promise<Response> {
    const auth = authenticate(headers);
    if (auth instanceof Response) return auth;
    const handled = (await sessionsHandler(method, path, url, init, auth.user.principal)) ?? (await runsHandler(method, path, url, init, auth.user.principal));
    if (handled) return handled;
    if (method !== 'GET') return error(405, 'method-not-allowed');
    const feature: OrgFeature | undefined =
      path === '/v1/whoami' ? 'signIn' : path === '/v1/workspaces' || path.startsWith('/v1/workspaces/') ? 'workspaces' : path === '/v1/directory' ? 'directory' : undefined;
    if (!feature || !features.has(feature)) return error(404, 'not-found');
    if (feature === 'signIn') {
      const { user } = auth;
      const identity: OrgIdentity = {
        orgId: discovery.orgId,
        principal: user.principal,
        email: user.email,
        displayName: user.displayName,
        groups: user.groups ?? [],
        roles: user.roles ?? [],
      };
      return json(200, identity);
    }
    if (feature === 'workspaces') {
      if (path === '/v1/workspaces') return json(200, { workspaces });
      let id: string;
      try {
        id = decodeURIComponent(path.slice('/v1/workspaces/'.length));
      } catch {
        return error(404, 'not-found');
      }
      const found = isOrgWorkspaceId(id) ? workspaces.find((workspace) => workspace.id === id) : undefined;
      return found ? json(200, found) : error(404, 'not-found');
    }
    const query = (url.searchParams.get('q') ?? '').trim().toLowerCase();
    if (query.length === 0 || query.length > 128) return error(400, 'invalid-request');
    const requested = Number(url.searchParams.get('limit') ?? 10);
    if (!Number.isFinite(requested) || requested < 1) return error(400, 'invalid-request');
    const limit = Math.min(Math.trunc(requested), MAX_DIRECTORY_RESULTS);
    const entries = directory
      .filter((entry) => entry.displayName.toLowerCase().includes(query) || (entry.email ?? '').toLowerCase().includes(query))
      .slice(0, limit);
    return json(200, { entries });
  }

  const fakeFetch: FetchLike = async (input, init) => {
    const url = new URL(input);
    const method = (init?.method ?? 'GET').toUpperCase();
    requests.push({ method, url: url.toString() });
    if (url.origin !== origin) throw new TypeError(`fetch failed: ${url.origin} is not served by this fake`);
    const headers = new Headers(init?.headers);
    const path = url.pathname;
    if (path === ORG_DISCOVERY_PATH) return method === 'GET' ? json(200, discovery) : error(405, 'method-not-allowed');
    if (path === '/idp/.well-known/openid-configuration') {
      return json(200, {
        issuer,
        authorization_endpoint: `${issuer}/authorize`,
        token_endpoint: `${issuer}/token`,
        code_challenge_methods_supported: ['S256'],
        response_types_supported: ['code'],
      });
    }
    if (path === '/idp/authorize') return method === 'GET' ? handleAuthorize(url) : error(405, 'method-not-allowed');
    if (path === '/idp/token') return method === 'POST' ? handleToken(init) : error(405, 'method-not-allowed');
    if (path === '/api' || path.startsWith('/api/')) {
      return handleApi(method, path.slice('/api'.length), url, init, headers);
    }
    return error(404, 'not-found');
  };

  return {
    fetch: fakeFetch,
    orgUrl: origin,
    issuer,
    clientId,
    issueToken,
    requests,
    runAuditRows: () => runsHandler.auditRows(),
    cloud: {
      advance: (sessionId, options) => sessionsHandler.advanceCloud(sessionId, options),
      crash: (sessionId) => sessionsHandler.crashCloud(sessionId),
      setAvailable: (available) => {
        cloudAvailable = available;
      },
    },
  };
}

