import { createHash, randomUUID } from 'node:crypto';
import { gzipSync } from 'node:zlib';
import {
  ENVELOPE_HEADERS,
  ENVELOPE_CONTENT_TYPE,
  envelopeStateRef,
  isEnvelopeFormat,
  isSha256Hex,
  looksLikeGzip,
  parseOrgCloudRunRequest,
  sha256Hex,
  type OrgCloudRunRequest,
  isCloudHostId,
  type OrgCloudCapabilities,
  type OrgCloudRun,
  type OrgEnvelopeInfo,
} from '../cloud.js';
import { WATCH_KINDS, WATCH_VERSION_PATTERN, type OrgWatchKind } from '../watch.js';
import { roleAllows, type OrgWorkspace, type SessionRole } from '../model.js';
import {
  BUNDLE_CONTENT_TYPE,
  BUNDLE_HEADERS,
  MAX_PLACEMENT_MOUNTS,
  PLACEMENT_MANIFEST_VERSION,
  isMountId,
  isOrgWorkspaceRepository,
  looksLikeGitBundle,
  type OrgMountBundleInfo,
  type OrgPlacementManifest,
} from '../placement.js';
import type { UserPrincipal } from '../principals.js';
import {
  DEFAULT_SESSION_PAGE,
  MAX_NOTIFICATIONS_PAGE,
  MAX_SESSION_PAGE,
  SESSION_PLACEMENTS,
  MAX_TRANSCRIPT_BYTES,
  MAX_TRANSCRIPT_MESSAGE_BYTES,
  MAX_TRANSCRIPT_PAGE_BYTES,
  MAX_TRANSCRIPT_PAGE_MESSAGES,
  isNotificationId,
  isSessionId,
  parseOrgGrantRequest,
  parseOrgSessionUpload,
  parseOrgTranscriptWrite,
  readCursorParam,
  readPageLimit,
  utf8Length,
  type OrgGrantResult,
  type OrgMention,
  type OrgNotification,
  type OrgSessionEnvelope,
  type OrgSessionGrant,
  type OrgSessionPlacement,
  type OrgSessionSummary,
  type OrgSessionTurnState,
  type OrgSessionView,
  type OrgTranscriptMessage,
  NOTIFICATION_THROTTLE_SECONDS,
} from '../sessions.js';
import {
  DEFAULT_LEASE_TTL_SECONDS,
  parseOrgLeaseAcquireRequest,
  parseOrgLeaseHandoverRequest,
  parseOrgLeaseHeartbeatRequest,
  parseOrgLeaseReleaseRequest,
  sameLeaseHolder,
  type OrgHandoverRequest,
  type OrgLease,
  type OrgLeaseCheckpoint,
  type OrgLeaseHolder,
  type OrgLeaseView,
} from '../leases.js';
import type { OrgFeature } from '../discovery.js';
import {
  CLIENT_MESSAGE_SOURCES,
  DEFAULT_MESSAGE_LIST,
  MAX_MESSAGE_LIST,
  MAX_COMMENTS_PER_AUTHOR,
  MAX_HELD_PER_AUTHOR,
  MAX_QUEUED_MESSAGES,
  MESSAGE_SOURCE_HEADER,
  isMessageId,
  parseOrgPostMessageRequest,
  parseOrgRunHeldMessageRequest,
  type OrgExecutorInfo,
  type OrgMessageSource,
  type OrgPostedMessage,
  type OrgSessionMessage,
} from '../messages.js';
import { parseOrgForkRequest, type OrgForkResult } from '../forks.js';
import {
  DEFAULT_LIVE_POLL_SECONDS,
  DEFAULT_PARTICIPANT_TURNS_PER_DAY,
  LIVE_PRESENCE_POLLS,
  MAX_CLAIM_BYTES,
  MAX_LIVE_PENDING,
  MAX_LIVE_QUEUED_PER_AUTHOR,
  parseOrgClaimMessagesRequest,
  parseOrgCompleteMessagesRequest,
  parseOrgSessionLiveRequest,
} from '../live.js';
import { isLeaseHostId } from '../leases.js';
import { OrgContractError } from '../validate.js';

const MAX_BODY_BYTES = 2 * 1024 * 1024;

const heartbeatSeconds = (ttlMs: number) => Math.max(1, Math.floor(ttlMs / 3000));

type LeaseState = { lease: OrgLease; ttlMs: number; handover?: OrgHandoverRequest };

type SessionRecord = {
  envelope: Omit<OrgSessionEnvelope, 'transcript'>;
  messages: OrgTranscriptMessage[];
  bytes: number;
  grants: Map<UserPrincipal, OrgSessionGrant>;
  lease?: LeaseState;
  checkpoint?: OrgLeaseCheckpoint;
  native?: { info: OrgEnvelopeInfo; bytes: Uint8Array };
  bundles?: Map<string, { info: OrgMountBundleInfo; bytes: Uint8Array }>;
  placement?: OrgPlacementManifest;
  run?: OrgCloudRun;
  runInstruction?: string;
  inbox: OrgSessionMessage[];
  /** `cloud` after a move to the cloud, `desktop` after the owner's desktop took the session back; absent for a session that never moved. */
  home?: 'cloud' | 'desktop';
  /** The owner's live switch (`liveSessions`); absent until the owner first sets it. */
  live?: boolean;
  /** The executor host the owner named when turning live on. */
  liveHost?: string;
  liveBudget?: number;
};

/** The lease tenure that claimed a message: a claim of an earlier tenure goes back to the queue at the next claim. */
type ClaimTenure = { holder: OrgLeaseHolder; acquiredAt: string };

/** Claims of one message before it is rejected, as on the server. */
const MAX_CLAIM_ATTEMPTS = 3;

export type SessionsHandlerDeps = {
  features: ReadonlySet<OrgFeature>;
  isMember(principal: UserPrincipal): boolean;
  workspaces: OrgWorkspace[];
  now(): number;
  /** The fake cloud host. Without it, or without the `cloudRuns` feature, the cloud routes are not served. */
  cloud?: { host: string; formats: string[]; maxEnvelopeBytes: number; maxBundleBytes: number; available(): boolean };
  json(status: number, body: unknown): Response;
  error(status: number, code: string): Response;
};

/** The sessions, grants and notifications routes of the in-memory provider. */
/** How often the in-memory watch looks for a change, in milliseconds. */
const WATCH_POLL_MS = 20;

export type CloudAdvance = { released: boolean };

export function createSessionsHandler(deps: SessionsHandlerDeps) {
  const sessions = new Map<string, SessionRecord>();
  const notifications = new Map<UserPrincipal, OrgNotification[]>();
  let notificationCounter = 0;
  const { json, error } = deps;
  const iso = () => new Date(deps.now()).toISOString();

  const roleOf = (record: SessionRecord, principal: UserPrincipal): SessionRole | undefined =>
    record.envelope.owner === principal ? 'owner' : record.grants.get(principal)?.role;

  const envelopeOf = (record: SessionRecord): OrgSessionEnvelope => ({
    ...record.envelope,
    transcript: { messageCount: record.messages.length, bytes: record.bytes },
  });

  const viewOf = (record: SessionRecord, role: SessionRole, withGrants: boolean, withSummary = false): OrgSessionView => {
    const view: OrgSessionView = { session: envelopeOf(record), role };
    if (withSummary) Object.assign(view, summaryOf(record, role));
    if (liveOn()) view.live = { enabled: record.live === true };
    if (withGrants && role === 'owner') view.grants = [...record.grants.values()];
    return view;
  };

  function readOffset(cursor: string | undefined): number {
    if (cursor === undefined) return 0;
    if (!/^\d{1,9}$/.test(cursor)) throw new OrgContractError('invalid-request', 'cursor', 'is not a cursor this provider issued');
    return Number(cursor);
  }

  async function readBody(init: RequestInit | undefined): Promise<unknown> {
    const text = typeof init?.body === 'string' ? init.body : '';
    if (utf8Length(text) > MAX_BODY_BYTES) throw new TooLarge();
    try {
      return JSON.parse(text);
    } catch {
      throw new OrgContractError('invalid-request', 'body', 'must be JSON');
    }
  }

  class TooLarge extends Error {}

  const cloudOn = () => deps.features.has('cloudRuns') && deps.features.has('leases') && deps.cloud !== undefined;
  const reserved = (host: string) => cloudOn() && isCloudHostId(host, deps.cloud!.host);
  const placementOn = () => deps.features.has('placement') && cloudOn();
  const isCloudHolder = (holder: OrgLeaseHolder) => cloudOn() && isCloudHostId(holder.host, deps.cloud!.host);

  function settleCloudRun(record: SessionRecord, error: 'lease-forced' | 'lease-expired' | 'lease-revoked'): void {
    if (record.lease && isCloudHolder(record.lease.lease.holder) && record.run?.status === 'running') {
      record.run = { ...record.run, status: 'failed', error, finishedAt: new Date(deps.now()).toISOString() };
    }
  }
  let runCounter = 0;

  async function readBinary(init: RequestInit | undefined, limit: number): Promise<Uint8Array> {
    const body = init?.body as unknown;
    const chunks: Uint8Array[] = [];
    let total = 0;
    const take = (chunk: Uint8Array) => {
      total += chunk.length;
      if (total > limit) throw new TooLarge();
      chunks.push(chunk);
    };
    if (body instanceof Uint8Array) take(body);
    else if (body && typeof (body as ReadableStream<Uint8Array>).getReader === 'function') {
      const reader = (body as ReadableStream<Uint8Array>).getReader();
      for (;;) {
        const next = await reader.read();
        if (next.done) break;
        try {
          take(next.value);
        } catch (failure) {
          await reader.cancel().catch(() => undefined);
          throw failure;
        }
      }
    } else if (typeof body === 'string') take(new TextEncoder().encode(body));
    const out = new Uint8Array(total);
    let offset = 0;
    for (const chunk of chunks) {
      out.set(chunk, offset);
      offset += chunk.length;
    }
    return out;
  }

  function getSession(id: string, principal: UserPrincipal): { record: SessionRecord; role: SessionRole } | Response {
    const record = isSessionId(id) ? sessions.get(id) : undefined;
    const role = record ? roleOf(record, principal) : undefined;
    // A caller with no role learns nothing about whether the session exists.
    if (!record || !role) return error(404, 'not-found');
    return { record, role };
  }

  function watchParts(record: SessionRecord): Record<OrgWatchKind, string> {
    return {
      transcript: `${record.messages.length}|${record.envelope.updatedAt}`,
      message: record.inbox.map((entry) => `${entry.id}:${entry.status}`).join(','),
      lease: JSON.stringify(liveLease(record)?.lease ?? null),
      run: `${record.run?.status ?? ''}|${record.run?.finishedAt ?? ''}`,
      turn: `${record.home ?? ''}${record.live === undefined ? '' : `|live:${record.live}`}`,
    };
  }

  function watch(id: string, caller: UserPrincipal, url: URL, signal: AbortSignal | undefined): Response {
    const found = getSession(id, caller);
    if (found instanceof Response) return found;
    const after = url.searchParams.get('after');
    if (after !== null && !WATCH_VERSION_PATTERN.test(after)) return error(400, 'invalid-request');
    const encoder = new TextEncoder();
    let timer: ReturnType<typeof setInterval> | undefined;
    let previous: Record<OrgWatchKind, string> | undefined;
    let version = after;
    const stream = new ReadableStream<Uint8Array>({
      start(controller) {
        const send = (text: string) => controller.enqueue(encoder.encode(text));
        const stop = () => {
          if (timer) clearInterval(timer);
          timer = undefined;
        };
        const tick = () => {
          const record = sessions.get(id);
          if (!record || roleOf(record, caller) === undefined) {
            send(`event: end\ndata: ${JSON.stringify({ reason: 'gone' })}\n\n`);
            stop();
            controller.close();
            return;
          }
          const parts = watchParts(record);
          const next = createHash('sha256').update(JSON.stringify(parts)).digest('hex').slice(0, 16);
          const before = previous;
          previous = parts;
          if (next === version) return;
          const kinds = WATCH_KINDS.filter((kind) => before === undefined || before[kind] !== parts[kind]);
          version = next;
          send(`event: ping\ndata: ${JSON.stringify({ version: next, kinds })}\n\n`);
        };
        send('retry: 3000\n\n');
        tick();
        timer = setInterval(tick, WATCH_POLL_MS);
        signal?.addEventListener('abort', () => {
          stop();
          try {
            controller.close();
          } catch {
            return;
          }
        }, { once: true });
      },
      cancel() {
        if (timer) clearInterval(timer);
      },
    });
    return new Response(stream, { status: 200, headers: { 'content-type': 'text/event-stream', 'cache-control': 'no-store' } });
  }

  /** The notification a person waits on: the throttle never hides it, like the server. */
  const UNTHROTTLED_NOTIFICATION_KIND = 'turn-finished';
  const mutes = new Set<string>();
  const lastNotified = new Map<string, number>();

  function pushMultiUserNotification(to: UserPrincipal, kind: OrgNotification['kind'], sessionId: string, from: UserPrincipal): void {
    if (!deps.features.has('multiUser') || !deps.features.has('notifications')) return;
    const key = `${to}|${sessionId}|${kind}`;
    if (mutes.has(`${to}|${sessionId}`)) return;
    if (kind !== UNTHROTTLED_NOTIFICATION_KIND && deps.now() - (lastNotified.get(key) ?? -Infinity) < NOTIFICATION_THROTTLE_SECONDS * 1000) return;
    lastNotified.set(key, deps.now());
    pushNotification(to, kind, sessionId, from);
  }

  function muteRoute(id: string, caller: UserPrincipal, method: string, body: unknown): Response {
    if (!deps.features.has('multiUser')) return error(404, 'not-found');
    const found = getSession(id, caller);
    if (found instanceof Response) return found;
    const key = `${caller}|${id}`;
    if (method === 'GET') return json(200, { muted: mutes.has(key) });
    if (method !== 'PUT') return error(405, 'method-not-allowed');
    const muted = typeof body === 'object' && body !== null ? (body as { muted?: unknown }).muted : undefined;
    if (typeof muted !== 'boolean') return error(400, 'invalid-request');
    if (muted) mutes.add(key);
    else mutes.delete(key);
    return json(200, { muted });
  }

  function pushNotification(to: UserPrincipal, kind: OrgNotification['kind'], sessionId: string, from: UserPrincipal): string {
    notificationCounter += 1;
    const id = `n-${notificationCounter}`;
    const list = notifications.get(to) ?? [];
    list.push({ id, kind, sessionId, from, at: iso(), read: false });
    notifications.set(to, list);
    return id;
  }

  function putSession(id: string, caller: UserPrincipal, body: unknown): Response {
    if (!deps.features.has('sessions')) return error(404, 'not-found');
    const upload = parseOrgSessionUpload(body);
    if (upload.id !== id || !isSessionId(id)) return error(400, 'invalid-request');
    if (upload.owner !== caller) return error(403, 'forbidden');
    if (deps.features.has('workspaces') && !deps.workspaces.some((workspace) => workspace.id === upload.workspaceId)) {
      return error(400, 'invalid-request');
    }
    const existing = sessions.get(id);
    if (existing && existing.envelope.owner !== caller) return error(403, 'forbidden');
    const record: SessionRecord = existing ?? { envelope: upload, messages: [], bytes: 0, grants: new Map(), inbox: [] };
    record.envelope = existing?.envelope.forkedFrom ? { ...upload, forkedFrom: existing.envelope.forkedFrom } : upload;
    sessions.set(id, record);
    return json(200, envelopeOf(record));
  }

  function putTranscript(id: string, caller: UserPrincipal, body: unknown): Response {
    const found = getSession(id, caller);
    if (found instanceof Response) return found;
    const shared = deps.features.has('sharedTranscript');
    const writes = found.role === 'owner' || (shared && (found.role === 'collaborator' || found.role === 'driver'));
    if (!writes) return error(403, 'forbidden');
    const cloudLease = cloudOn() ? liveLease(found.record) : undefined;
    if (cloudLease && isCloudHolder(cloudLease.lease.holder)) {
      return json(409, { error: 'lease-held', holder: cloudLease.lease.holder, expiresAt: cloudLease.lease.expiresAt });
    }
    const raw = typeof body === 'object' && body !== null ? (body as { messages?: unknown }).messages : undefined;
    if (Array.isArray(raw)) {
      let bytes = 0;
      for (const message of raw) {
        const text = typeof message === 'object' && message !== null ? (message as { text?: unknown }).text : undefined;
        const size = typeof text === 'string' ? utf8Length(text) : 0;
        if (size > MAX_TRANSCRIPT_MESSAGE_BYTES) return error(413, 'too-large');
        bytes += size;
      }
      if (raw.length > MAX_TRANSCRIPT_PAGE_MESSAGES || bytes > MAX_TRANSCRIPT_PAGE_BYTES) return error(413, 'too-large');
    }
    const write = parseOrgTranscriptWrite(body);
    const { record } = found;
    if (found.role !== 'owner') {
      // Another person's write only appends what they said and what their own Marshal answered.
      if (write.mode !== 'append') return error(403, 'forbidden');
      if (write.messages.some((message) => (message.role !== 'user' && message.role !== 'assistant') || message.messageId !== undefined)) {
        return error(400, 'invalid-request');
      }
    } else if (shared && write.mode === 'replace' && record.messages.some((message) => message.author !== undefined && message.author !== record.envelope.owner)) {
      return error(409, 'conflict');
    }
    if (write.mode === 'append' && write.expectedCount !== undefined && write.expectedCount !== record.messages.length) {
      return error(409, 'conflict');
    }
    const added = write.messages.reduce((sum, message) => sum + utf8Length(message.text), 0);
    const base = write.mode === 'replace' ? 0 : record.bytes;
    if (base + added > MAX_TRANSCRIPT_BYTES) return error(413, 'too-large');
    // With liveSessions the server names the author of each user message: the inbox row it ran, else the owner while the session is
    // live on a desktop; anywhere else no author (a cloud turn is never attributed to the owner by default).
    // With sharedTranscript every message names the person who wrote it: the caller, except a user message that ran an inbox row.
    const incoming = shared ? write.messages : write.messages.map(({ id: _id, ...message }) => message);
    const written = shared
      ? incoming.map((message) => {
          const row = message.role === 'user' && message.messageId !== undefined ? record.inbox.find((entry) => entry.id === message.messageId) : undefined;
          return { ...message, author: row?.author ?? caller };
        })
      : liveOn()
        ? incoming.map((message) => {
            if (message.role !== 'user') return message;
            const row = message.messageId === undefined ? undefined : record.inbox.find((entry) => entry.id === message.messageId);
            const author = row?.author ?? (liveDesktop(record) ? record.envelope.owner : undefined);
            return author === undefined ? message : { ...message, author };
          })
        : incoming;
    record.messages = write.mode === 'replace' ? [...written] : [...record.messages, ...written];
    record.bytes = base + added;
    return json(200, { transcript: { messageCount: record.messages.length, bytes: record.bytes } });
  }

  function getTranscript(id: string, caller: UserPrincipal, url: URL): Response {
    const found = getSession(id, caller);
    if (found instanceof Response) return found;
    const { messages } = found.record;
    const start = readOffset(readCursorParam(url.searchParams.get('cursor')));
    const limit = readPageLimit(url.searchParams.get('limit'), MAX_TRANSCRIPT_PAGE_MESSAGES, MAX_TRANSCRIPT_PAGE_MESSAGES);
    const page: OrgTranscriptMessage[] = [];
    let bytes = 0;
    for (let index = start; index < messages.length && page.length < limit; index += 1) {
      const size = utf8Length(messages[index]!.text);
      if (page.length > 0 && bytes + size > MAX_TRANSCRIPT_PAGE_BYTES) break;
      page.push(messages[index]!);
      bytes += size;
    }
    const end = start + page.length;
    return json(200, { messages: page, total: messages.length, ...(end < messages.length ? { nextCursor: String(end) } : {}) });
  }

  const cloudListOn = () => deps.features.has('cloudList');

  function placementOf(record: SessionRecord): OrgSessionPlacement {
    const holder = liveLease(record)?.lease.holder;
    return record.home === 'cloud' || (holder !== undefined && isCloudHolder(holder)) ? 'cloud' : 'local';
  }

  function summaryOf(record: SessionRecord, role: SessionRole): OrgSessionSummary {
    const holder = liveLease(record)?.lease.holder;
    const cloudHeld = holder !== undefined && isCloudHolder(holder);
    const queued = queuedCount(record);
    const held = role === 'owner' && record.inbox.some((entry) => entry.status === 'held' && entry.kind !== 'comment');
    let turnState: OrgSessionTurnState = 'idle';
    if (placementOf(record) === 'local') turnState = 'idle';
    else if (cloudHeld) turnState = 'running';
    else if (queued > 0) turnState = 'queued';
    else if (record.run?.status === 'failed') turnState = 'failed';
    else if (held) turnState = 'needs-you';
    const stamps = [record.envelope.updatedAt, ...record.messages.map((entry) => entry.at), ...record.inbox.map((entry) => entry.at)];
    if (record.run) stamps.push(record.run.finishedAt ?? record.run.startedAt);
    const summary: OrgSessionSummary = {
      placement: placementOf(record),
      turnState,
      queued,
      lastActivityAt: stamps.reduce((latest, stamp) => (Date.parse(stamp) > Date.parse(latest) ? stamp : latest)),
    };
    if (record.run?.link !== undefined) summary.runLink = record.run.link;
    return summary;
  }

  function listSessions(caller: UserPrincipal, url: URL): Response {
    const workspace = url.searchParams.get('workspace');
    const placement = url.searchParams.get('placement');
    const owner = url.searchParams.get('owner');
    if (cloudListOn()) {
      if (placement !== null && !(SESSION_PLACEMENTS as readonly string[]).includes(placement)) return error(400, 'invalid-request');
      if (owner !== null && owner !== 'me') return error(400, 'invalid-request');
      if (placement !== null && owner !== 'me') return error(400, 'invalid-request');
    }
    const limit = readPageLimit(url.searchParams.get('limit'), DEFAULT_SESSION_PAGE, MAX_SESSION_PAGE);
    const start = readOffset(readCursorParam(url.searchParams.get('cursor')));
    const visible = [...sessions.values()]
      .filter((record) => (workspace === null || record.envelope.workspaceId === workspace) && roleOf(record, caller) !== undefined)
      .filter((record) => !cloudListOn() || ((placement === null || placementOf(record) === placement) && (owner === null || roleOf(record, caller) === 'owner')))
      .sort((a, b) => b.envelope.updatedAt.localeCompare(a.envelope.updatedAt) || a.envelope.id.localeCompare(b.envelope.id));
    const slice = visible.slice(start, start + limit);
    const end = start + slice.length;
    return json(200, {
      sessions: slice.map((record) => viewOf(record, roleOf(record, caller)!, false, cloudListOn())),
      ...(end < visible.length ? { nextCursor: String(end) } : {}),
    });
  }

  function grant(id: string, caller: UserPrincipal, body: unknown): Response {
    const found = getSession(id, caller);
    if (found instanceof Response) return found;
    if (!roleAllows(found.role, 'collaborator')) return error(403, 'forbidden');
    const request = parseOrgGrantRequest(body);
    if (request.mention && (!deps.features.has('mentions') || !deps.features.has('notifications'))) return error(400, 'invalid-request');
    if (request.notify && !deps.features.has('notifications')) return error(400, 'invalid-request');
    if (!deps.isMember(request.principal)) return error(403, 'not-a-member');
    const { record } = found;
    if (request.principal === record.envelope.owner || request.principal === caller) return error(409, 'conflict');
    if (!roleAllows(found.role, request.role)) return error(403, 'forbidden');
    const current = record.grants.get(request.principal);
    if (current && !roleAllows(found.role, current.role)) return error(403, 'forbidden');
    const stored: OrgSessionGrant = { principal: request.principal, role: request.role, grantedBy: caller, grantedAt: iso() };
    record.grants.set(request.principal, stored);
    if (request.role === 'viewer') rejectAuthorRows(record, request.principal, 'viewer');
    const result: OrgGrantResult = { grant: stored };
    if (request.mention) {
      const mention: OrgMention = { from: caller, to: request.principal, sessionId: id, role: request.role };
      if (request.mention.note !== undefined) mention.note = request.mention.note;
      result.mention = mention;
      result.notificationId = pushNotification(request.principal, 'mention', id, caller);
    } else if (request.notify) {
      result.notificationId = pushNotification(request.principal, 'share', id, caller);
    }
    return json(200, result);
  }

  /** Lazily frees an expired lease: a missed heartbeat past expiry frees it. */
  function liveLease(record: SessionRecord): LeaseState | undefined {
    if (record.lease && Date.parse(record.lease.lease.expiresAt) <= deps.now()) {
      settleCloudRun(record, 'lease-expired');
      delete record.lease;
    }
    return record.lease;
  }

  const messagesOn = () => deps.features.has('messages') && cloudOn();
  const liveOn = () => deps.features.has('liveSessions') && messagesOn();
  /** A live session whose home is not the cloud: its owner's desktop runs every author's instructions. */
  const liveDesktop = (record: SessionRecord) => liveOn() && record.live === true && record.home !== 'cloud';
  const claims = new Map<string, ClaimTenure>();
  const claimAttempts = new Map<string, number>();
  /** When each owner's desktop host last asked for pending work, keyed `principal|host`. */
  const presence = new Map<string, number>();
  const ownerOnline = (record: SessionRecord) =>
    record.liveHost !== undefined &&
    deps.now() - (presence.get(`${record.envelope.owner}|${record.liveHost}`) ?? -Infinity) <= LIVE_PRESENCE_POLLS * DEFAULT_LIVE_POLL_SECONDS * 1000;
  const isInstruction = (entry: OrgSessionMessage) => entry.kind !== 'comment';
  const waiting = (entry: OrgSessionMessage) => entry.status === 'queued' || entry.status === 'claimed';
  const queuedCount = (record: SessionRecord) => record.inbox.filter(waiting).length;

  function executorOf(record: SessionRecord): OrgExecutorInfo {
    if (liveDesktop(record)) return desktopExecutorOf(record);
    const holder = liveLease(record)?.lease.holder;
    if (holder && isCloudHolder(holder)) return { state: 'running', hostLabel: holder.host };
    if (queuedCount(record) > 0 && deps.cloud?.available()) return { state: 'queued', estimatedStartSeconds: 30 };
    return { state: 'none' };
  }

  function desktopExecutorOf(record: SessionRecord): OrgExecutorInfo {
    const owner = record.envelope.owner;
    const base = { hostKind: 'desktop' as const, hostLabel: owner.slice('user:'.length).split('@')[0]!.slice(0, 128) };
    const holder = liveLease(record)?.lease.holder;
    if ((holder && holder.principal === owner && !isCloudHolder(holder)) || record.inbox.some((entry) => entry.status === 'claimed')) return { state: 'running', ...base };
    if (ownerOnline(record)) return { state: 'hot', ...base };
    if (queuedCount(record) > 0) return { state: 'queued', ...base };
    return { state: 'none', ...base };
  }

  function postedOf(record: SessionRecord, message: OrgSessionMessage): OrgPostedMessage {
    const position = message.status === 'queued' ? record.inbox.filter((entry) => waiting(entry) && entry.seq < message.seq).length : 0;
    return { id: message.id, seq: message.seq, status: message.status, position, executor: executorOf(record) };
  }

  function addMessage(record: SessionRecord, input: { author: UserPrincipal; source: OrgMessageSource; role: SessionRole; clientMsgId: string; text: string; status: OrgSessionMessage['status']; quotes?: string; kind?: 'comment' }): OrgSessionMessage {
    const message: OrgSessionMessage = {
      id: randomUUID(),
      seq: record.inbox.length + 1,
      clientMsgId: input.clientMsgId,
      author: input.author,
      source: input.source,
      roleAtSend: input.role,
      text: input.text,
      status: input.status,
      at: iso(),
      ...(input.kind === 'comment' ? { kind: 'comment' as const } : {}),
      ...(input.quotes === undefined ? {} : { quotes: input.quotes }),
    };
    record.inbox.push(message);
    return message;
  }

  function postMessage(id: string, caller: UserPrincipal, body: unknown, init: RequestInit | undefined): Response {
    const found = getSession(id, caller);
    if (found instanceof Response) return found;
    const raw = typeof body === 'object' && body !== null ? (body as { text?: unknown }).text : undefined;
    if (typeof raw === 'string' && utf8Length(raw) > MAX_TRANSCRIPT_MESSAGE_BYTES) return error(413, 'too-large');
    const request = parseOrgPostMessageRequest(body);
    const comment = request.kind === 'comment';
    if (comment && !deps.features.has('multiUser')) return error(400, 'invalid-request');
    if (!roleAllows(found.role, comment ? 'viewer' : 'collaborator')) return error(403, 'forbidden');
    const { record } = found;
    const earlier = record.inbox.find((entry) => entry.clientMsgId === request.clientMsgId && entry.author === caller);
    if (earlier) return json(202, postedOf(record, earlier));
    if (record.home !== 'cloud' && !liveDesktop(record)) return error(409, 'not-in-cloud');
    if (comment) {
      if (record.inbox.filter((entry) => entry.author === caller && entry.kind === 'comment' && entry.status === 'held').length >= MAX_COMMENTS_PER_AUTHOR) return error(429, 'queue-full');
      const note = addMessage(record, { author: caller, source: 'api', role: found.role, clientMsgId: request.clientMsgId, text: request.text, status: 'held', kind: 'comment' });
      if (caller !== record.envelope.owner) pushMultiUserNotification(record.envelope.owner, 'held-message', id, caller);
      return json(202, postedOf(record, note));
    }
    if (liveDesktop(record)) return postLive(record, caller, found.role, request, init);
    const held = found.role !== 'owner';
    if (!held && queuedCount(record) >= MAX_QUEUED_MESSAGES) return error(429, 'queue-full');
    if (held && record.inbox.filter((entry) => entry.author === caller && entry.status === 'held' && entry.kind !== 'comment').length >= MAX_HELD_PER_AUTHOR) return error(429, 'queue-full');
    const header = new Headers(init?.headers).get(MESSAGE_SOURCE_HEADER) as (typeof CLIENT_MESSAGE_SOURCES)[number] | null;
    const source: OrgMessageSource = header && CLIENT_MESSAGE_SOURCES.includes(header) ? header : 'api';
    const message = addMessage(record, { author: caller, source, role: found.role, clientMsgId: request.clientMsgId, text: request.text, status: held ? 'held' : 'queued' });
    if (held) pushMultiUserNotification(record.envelope.owner, 'held-message', id, caller);
    return json(202, postedOf(record, message));
  }

  function sourceOf(init: RequestInit | undefined): OrgMessageSource {
    const header = new Headers(init?.headers).get(MESSAGE_SOURCE_HEADER) as (typeof CLIENT_MESSAGE_SOURCES)[number] | null;
    return header && CLIENT_MESSAGE_SOURCES.includes(header) ? header : 'api';
  }

  /** An instruction to a live desktop session: queued for the owner's desktop, whoever (collaborator or above) wrote it. */
  function postLive(record: SessionRecord, caller: UserPrincipal, role: SessionRole, request: { clientMsgId: string; text: string }, init: RequestInit | undefined): Response {
    if (queuedCount(record) >= MAX_QUEUED_MESSAGES) return error(429, 'queue-full');
    if (role !== 'owner') {
      if (record.inbox.filter((entry) => entry.author === caller && entry.status === 'queued').length >= MAX_LIVE_QUEUED_PER_AUTHOR) return error(429, 'queue-full');
      const dayAgo = deps.now() - 24 * 3600 * 1000;
      const counted = (entry: OrgSessionMessage) => entry.status === 'queued' || entry.status === 'claimed' || entry.status === 'done';
      const today = record.inbox.filter((entry) => entry.author === caller && isInstruction(entry) && counted(entry) && Date.parse(entry.at) > dayAgo).length;
      if (today >= (record.liveBudget ?? DEFAULT_PARTICIPANT_TURNS_PER_DAY)) return error(429, 'turn-budget-spent');
    }
    const message = addMessage(record, { author: caller, source: sourceOf(init), role, clientMsgId: request.clientMsgId, text: request.text, status: 'queued' });
    return json(202, postedOf(record, message));
  }

  function liveRoute(id: string, caller: UserPrincipal, method: string, body: unknown): Response {
    const found = getSession(id, caller);
    if (found instanceof Response) return found;
    const { record } = found;
    const answer = () => ({
      enabled: record.live === true,
      participantTurnsPerDay: record.liveBudget ?? DEFAULT_PARTICIPANT_TURNS_PER_DAY,
      ...(found.role === 'owner' && record.liveHost !== undefined ? { host: record.liveHost } : {}),
    });
    if (method === 'GET') return json(200, answer());
    if (method !== 'PUT') return error(405, 'method-not-allowed');
    if (found.role !== 'owner') return error(403, 'forbidden');
    const request = parseOrgSessionLiveRequest(body);
    if (request.host !== undefined && reserved(request.host)) return error(403, 'forbidden');
    const { enabled } = request;
    record.live = enabled;
    if (request.host !== undefined) record.liveHost = request.host;
    if (request.participantTurnsPerDay !== undefined) record.liveBudget = request.participantTurnsPerDay;
    if (!enabled) {
      // Off: what others queued for the owner's desktop waits for the owner again, as on a cloud session.
      for (const entry of record.inbox) if (entry.status === 'queued' && entry.author !== record.envelope.owner) entry.status = 'held';
    }
    return json(200, answer());
  }

  function tenureOf(state: LeaseState): ClaimTenure {
    return { holder: state.lease.holder, acquiredAt: state.lease.acquiredAt };
  }

  const sameTenure = (a: ClaimTenure, b: ClaimTenure) => sameLeaseHolder(a.holder, b.holder) && a.acquiredAt === b.acquiredAt;

  function claimMessages(id: string, caller: UserPrincipal, body: unknown): Response {
    const found = getSession(id, caller);
    if (found instanceof Response) return found;
    if (!roleAllows(found.role, 'driver')) return error(403, 'forbidden');
    const request = parseOrgClaimMessagesRequest(body);
    if (reserved(request.host)) return error(403, 'forbidden');
    const { record } = found;
    const state = liveLease(record);
    if (!state || !sameLeaseHolder(state.lease.holder, { host: request.host, principal: caller })) return lostLease();
    const tenure = tenureOf(state);
    for (const entry of record.inbox) {
      const claim = claims.get(entry.id);
      if (entry.status !== 'claimed' || !claim || sameTenure(claim, tenure)) continue;
      // Claimed by an earlier tenure that never said done: back to the queue, rejected at the third claim.
      claims.delete(entry.id);
      entry.status = (claimAttempts.get(entry.id) ?? 0) >= MAX_CLAIM_ATTEMPTS ? 'rejected' : 'queued';
    }
    const owner = record.envelope.owner;
    // Only the owner's desktop of a live session runs other authors; any other claim runs the owner's messages only.
    const everyone = liveDesktop(record) && caller === owner && request.host === record.liveHost;
    const taken: OrgSessionMessage[] = [];
    let bytes = 0;
    for (const entry of record.inbox) {
      if (taken.length >= request.max) break;
      if (entry.status !== 'queued' || !isInstruction(entry)) continue;
      if (entry.author !== owner) {
        if (!everyone) continue;
        const role = roleOf(record, entry.author);
        if (!role || !roleAllows(role, 'collaborator')) {
          entry.status = 'rejected';
          continue;
        }
      }
      const size = utf8Length(entry.text);
      if (taken.length > 0 && bytes + size > MAX_CLAIM_BYTES) break;
      bytes += size;
      entry.status = 'claimed';
      claims.set(entry.id, tenure);
      claimAttempts.set(entry.id, (claimAttempts.get(entry.id) ?? 0) + 1);
      taken.push(entry);
    }
    return json(200, { messages: taken.map((entry) => ({ ...entry })) });
  }

  function completeMessages(id: string, caller: UserPrincipal, body: unknown): Response {
    const found = getSession(id, caller);
    if (found instanceof Response) return found;
    if (!roleAllows(found.role, 'driver')) return error(403, 'forbidden');
    const request = parseOrgCompleteMessagesRequest(body);
    if (reserved(request.host)) return error(403, 'forbidden');
    const { record } = found;
    const state = liveLease(record);
    if (!state || !sameLeaseHolder(state.lease.holder, { host: request.host, principal: caller })) return lostLease();
    const tenure = tenureOf(state);
    let done = 0;
    for (const entry of record.inbox) {
      const claim = claims.get(entry.id);
      if (entry.status !== 'claimed' || !claim || !sameTenure(claim, tenure)) continue;
      claims.delete(entry.id);
      entry.status = 'done';
      entry.turnId = request.turnId;
      done += 1;
    }
    const more = record.inbox.filter((entry) => entry.status === 'queued' && isInstruction(entry)).length;
    return json(200, { done, more });
  }

  function livePending(caller: UserPrincipal, url: URL): Response {
    const host = url.searchParams.get('host');
    if (!isLeaseHostId(host) || reserved(host)) return error(400, 'invalid-request');
    presence.set(`${caller}|${host}`, deps.now());
    const pending = [...sessions.values()]
      .filter((record) => record.envelope.owner === caller && liveDesktop(record) && record.liveHost === host)
      .map((record) => {
        const queued = record.inbox.filter((entry) => entry.status === 'queued' && isInstruction(entry));
        return { id: record.envelope.id, queued: queued.length, oldest: queued[0]?.at ?? '' };
      })
      .filter((entry) => entry.queued > 0)
      .sort((a, b) => a.oldest.localeCompare(b.oldest) || a.id.localeCompare(b.id))
      .slice(0, MAX_LIVE_PENDING);
    return json(200, { sessions: pending.map(({ id, queued }) => ({ id, queued })), pollSeconds: DEFAULT_LIVE_POLL_SECONDS });
  }

  /** A grant of `author` on a live session went away (`role` undefined) or became `viewer`: what they queued is rejected, as on the server. */
  function rejectAuthorRows(record: SessionRecord, author: UserPrincipal, role: SessionRole | undefined): void {
    if (!liveOn() || record.live === undefined) return;
    for (const entry of record.inbox) {
      if (entry.author !== author) continue;
      if (entry.status === 'queued') entry.status = 'rejected';
      else if (entry.status === 'held' && (role === undefined || isInstruction(entry))) entry.status = 'rejected';
    }
  }

  function listMessages(id: string, caller: UserPrincipal, url: URL): Response {
    const found = getSession(id, caller);
    if (found instanceof Response) return found;
    const afterText = url.searchParams.get('after') ?? '0';
    if (!/^\d{1,9}$/.test(afterText)) return error(400, 'invalid-request');
    const limit = readPageLimit(url.searchParams.get('limit'), DEFAULT_MESSAGE_LIST, MAX_MESSAGE_LIST);
    const { record } = found;
    const everyInstruction = liveDesktop(record);
    const messages = record.inbox
      .filter((entry) => entry.seq > Number(afterText) && (found.role === 'owner' || entry.author === caller || (everyInstruction && isInstruction(entry))))
      .slice(0, limit);
    return json(200, { messages, executor: executorOf(record) });
  }

  function cancelMessage(id: string, messageId: string, caller: UserPrincipal): Response {
    const found = getSession(id, caller);
    if (found instanceof Response) return found;
    const target = isMessageId(messageId) ? found.record.inbox.find((entry) => entry.id === messageId) : undefined;
    if (!target) return error(404, 'not-found');
    if (target.author !== caller && found.role !== 'owner') return error(403, 'forbidden');
    if (target.status !== 'queued' && target.status !== 'held') return error(409, 'conflict');
    target.status = 'cancelled';
    return json(200, target);
  }

  function runHeld(id: string, messageId: string, caller: UserPrincipal, body: unknown): Response {
    const found = getSession(id, caller);
    if (found instanceof Response) return found;
    if (found.role !== 'owner') return error(403, 'forbidden');
    const target = isMessageId(messageId) ? found.record.inbox.find((entry) => entry.id === messageId) : undefined;
    if (!target) return error(404, 'not-found');
    const request = parseOrgRunHeldMessageRequest(body);
    if (target.status !== 'held' || target.kind === 'comment') return error(409, 'conflict');
    if (found.record.home !== 'cloud') return error(409, 'not-in-cloud');
    if (queuedCount(found.record) >= MAX_QUEUED_MESSAGES) return error(429, 'queue-full');
    target.status = 'done';
    const message = addMessage(found.record, { author: caller, source: target.source, role: 'owner', clientMsgId: request.clientMsgId, text: target.text, status: 'queued', quotes: target.id });
    return json(202, postedOf(found.record, message));
  }

  function giveBackQueued(record: SessionRecord): OrgSessionMessage[] {
    const returned = record.inbox.filter((entry) => entry.status === 'queued' && entry.source !== 'slack').map((entry) => ({ ...entry }));
    for (const entry of record.inbox) {
      if (entry.status === 'queued') entry.status = entry.source === 'slack' ? 'rejected' : 'cancelled';
    }
    return returned;
  }

  /** The owner's desktop takes a live session: the owner's own queued messages come back to it, everyone else's stay queued for the claim. */
  function giveBackOwnerQueued(record: SessionRecord): OrgSessionMessage[] {
    const owner = record.envelope.owner;
    const returned: OrgSessionMessage[] = [];
    for (const entry of record.inbox) {
      // Another author's claim of an earlier tenure is left for the next claim, which requeues it and counts the attempt.
      if (entry.author !== owner) continue;
      if (entry.status === 'claimed') {
        claims.delete(entry.id);
        entry.status = 'queued';
      }
      if (entry.status !== 'queued') continue;
      if (entry.source === 'slack') entry.status = 'rejected';
      else {
        returned.push({ ...entry });
        entry.status = 'cancelled';
      }
    }
    return returned;
  }

  function leaseView(record: SessionRecord): OrgLeaseView {
    const state = liveLease(record);
    const view: OrgLeaseView = { lease: state?.lease ?? null };
    if (state?.handover) view.handoverRequest = state.handover;
    if (record.checkpoint) view.checkpoint = record.checkpoint;
    return view;
  }

  function lostLease(): Response {
    return error(410, 'lease-lost');
  }

  function getLease(id: string, caller: UserPrincipal): Response {
    const found = getSession(id, caller);
    return found instanceof Response ? found : json(200, leaseView(found.record));
  }

  function acquireLease(id: string, caller: UserPrincipal, body: unknown): Response {
    const found = getSession(id, caller);
    if (found instanceof Response) return found;
    const request = parseOrgLeaseAcquireRequest(body);
    if (!roleAllows(found.role, 'driver')) return error(403, 'forbidden');
    if (request.force && found.role !== 'owner') return error(403, 'forbidden');
    if (reserved(request.host)) return error(403, 'forbidden');
    const { record } = found;
    const me: OrgLeaseHolder = { host: request.host, principal: caller };
    const state = liveLease(record);
    const ttlMs = (request.ttlSeconds ?? DEFAULT_LEASE_TTL_SECONDS) * 1000;
    if (state && sameLeaseHolder(state.lease.holder, me)) {
      state.ttlMs = ttlMs;
      state.lease = { ...state.lease, expiresAt: new Date(deps.now() + ttlMs).toISOString(), heartbeatIntervalSeconds: heartbeatSeconds(ttlMs) };
      return json(200, leaseView(record));
    }
    if (state && !request.force) {
      return json(409, { error: 'lease-held', holder: state.lease.holder, expiresAt: state.lease.expiresAt });
    }
    if (state) settleCloudRun(record, 'lease-forced');
    const ownerTakes = messagesOn() && !reserved(request.host) && found.role === 'owner';
    if (ownerTakes) record.home = 'desktop';
    const returned = ownerTakes ? (record.live === true && liveOn() ? giveBackOwnerQueued(record) : giveBackQueued(record)) : [];
    const at = deps.now();
    record.lease = {
      ttlMs,
      lease: { holder: me, acquiredAt: new Date(at).toISOString(), expiresAt: new Date(at + ttlMs).toISOString(), heartbeatIntervalSeconds: heartbeatSeconds(ttlMs) },
    };
    return json(200, returned.length > 0 ? { ...leaseView(record), returnedMessages: returned } : leaseView(record));
  }

  function heartbeatLease(id: string, caller: UserPrincipal, body: unknown): Response {
    const found = getSession(id, caller);
    if (found instanceof Response) return found;
    const request = parseOrgLeaseHeartbeatRequest(body);
    if (reserved(request.host)) return error(403, 'forbidden');
    const { record } = found;
    const state = liveLease(record);
    if (!state || !sameLeaseHolder(state.lease.holder, { host: request.host, principal: caller })) return lostLease();
    if (!roleAllows(found.role, 'driver')) {
      delete record.lease;
      return lostLease();
    }
    state.lease = { ...state.lease, expiresAt: new Date(deps.now() + state.ttlMs).toISOString() };
    return json(200, leaseView(record));
  }

  function releaseLease(id: string, caller: UserPrincipal, body: unknown): Response {
    const found = getSession(id, caller);
    if (found instanceof Response) return found;
    const request = parseOrgLeaseReleaseRequest(body);
    if (reserved(request.host)) return error(403, 'forbidden');
    const { record } = found;
    const state = liveLease(record);
    if (!state || !sameLeaseHolder(state.lease.holder, { host: request.host, principal: caller })) return lostLease();
    if (cloudOn() && request.checkpoint?.stateRef?.startsWith('sha256:') && request.checkpoint.stateRef !== (record.native ? envelopeStateRef(record.native.info.sha256) : '')) {
      return json(422, { error: 'envelope-mismatch' });
    }
    if (request.checkpoint) record.checkpoint = { ...request.checkpoint, releasedBy: state.lease.holder, at: iso() };
    delete record.lease;
    return json(200, leaseView(record));
  }

  function requestHandover(id: string, caller: UserPrincipal, body: unknown): Response {
    const found = getSession(id, caller);
    if (found instanceof Response) return found;
    const request = parseOrgLeaseHandoverRequest(body);
    if (reserved(request.host)) return error(403, 'forbidden');
    if (!roleAllows(found.role, 'driver')) return error(403, 'forbidden');
    const { record } = found;
    const state = liveLease(record);
    if (!state) return error(409, 'lease-free');
    const me: OrgLeaseHolder = { host: request.host, principal: caller };
    if (sameLeaseHolder(state.lease.holder, me)) return error(409, 'conflict');
    if (state.handover && !sameLeaseHolder(state.handover.requestedBy, me)) return error(409, 'conflict');
    const handover: OrgHandoverRequest = { requestedBy: me, at: iso() };
    if (request.note !== undefined) handover.note = request.note;
    const first = state.handover === undefined;
    state.handover = handover;
    if (first && deps.features.has('notifications')) pushNotification(state.lease.holder.principal, 'handover-request', id, caller);
    return json(200, leaseView(record));
  }

  function cloudCapabilities(): Response {
    const cloud = deps.cloud!;
    const body: OrgCloudCapabilities = { cloudHost: cloud.host, formats: cloud.formats, maxEnvelopeBytes: cloud.maxEnvelopeBytes, available: cloud.available() };
    if (placementOn()) body.placement = { manifestVersions: [PLACEMENT_MANIFEST_VERSION], maxBundleBytes: cloud.maxBundleBytes };
    return json(200, body);
  }

  async function putEnvelope(id: string, caller: UserPrincipal, init: RequestInit | undefined): Promise<Response> {
    const found = getSession(id, caller);
    if (found instanceof Response) return found;
    if (!roleAllows(found.role, 'driver')) return error(403, 'forbidden');
    const headers = new Headers(init?.headers);
    const host = headers.get(ENVELOPE_HEADERS.host);
    const format = headers.get(ENVELOPE_HEADERS.format);
    const sha256 = headers.get(ENVELOPE_HEADERS.sha256);
    const messages = Number(headers.get(ENVELOPE_HEADERS.messages));
    const declared = Number(headers.get('content-length'));
    if (!host || !isEnvelopeFormat(format) || !isSha256Hex(sha256) || !Number.isInteger(messages) || messages < 0 || !Number.isInteger(declared) || declared < 1) {
      return error(400, 'invalid-request');
    }
    if (reserved(host)) return error(403, 'forbidden');
    const max = deps.cloud!.maxEnvelopeBytes;
    if (declared > max) return error(413, 'envelope-too-large');
    if (!deps.cloud!.formats.includes(format)) return error(415, 'unsupported-format');
    const state = liveLease(found.record);
    if (!state || !sameLeaseHolder(state.lease.holder, { host, principal: caller })) return lostLease();
    const bytes = await readBinary(init, max);
    if (bytes.length !== declared || sha256Hex(bytes) !== sha256) return json(422, { error: 'envelope-mismatch' });
    if (!looksLikeGzip(bytes)) return error(400, 'invalid-request');
    const info: OrgEnvelopeInfo = { format, sha256, bytes: bytes.length, messageCount: messages, uploadedBy: state.lease.holder, at: iso() };
    found.record.native = { info, bytes };
    return json(200, info);
  }

  async function putMountBundle(id: string, mountId: string, caller: UserPrincipal, init: RequestInit | undefined): Promise<Response> {
    const found = getSession(id, caller);
    if (found instanceof Response) return found;
    if (!roleAllows(found.role, 'driver')) return error(403, 'forbidden');
    const headers = new Headers(init?.headers);
    const host = headers.get(BUNDLE_HEADERS.host);
    const sha256 = headers.get(BUNDLE_HEADERS.sha256);
    const declared = Number(headers.get('content-length'));
    if (!host || !isMountId(mountId) || !isSha256Hex(sha256) || !Number.isInteger(declared) || declared < 1) return error(400, 'invalid-request');
    if (reserved(host)) return error(403, 'forbidden');
    if (headers.get('content-type')?.split(';')[0]?.trim().toLowerCase() !== BUNDLE_CONTENT_TYPE) return error(400, 'invalid-request');
    const max = deps.cloud!.maxBundleBytes;
    if (declared > max) return error(413, 'bundle-too-large');
    const state = liveLease(found.record);
    if (!state || !sameLeaseHolder(state.lease.holder, { host, principal: caller })) return lostLease();
    const bundles = (found.record.bundles ??= new Map());
    if (!bundles.has(mountId) && bundles.size >= MAX_PLACEMENT_MOUNTS) return error(409, 'conflict');
    const bytes = await readBinary(init, max);
    if (bytes.length !== declared || sha256Hex(bytes) !== sha256) return json(422, { error: 'bundle-mismatch' });
    if (!looksLikeGitBundle(bytes)) return error(400, 'invalid-request');
    const info: OrgMountBundleInfo = { mountId, sha256, bytes: bytes.length, uploadedBy: state.lease.holder, at: iso() };
    bundles.set(mountId, { info, bytes });
    return json(200, info);
  }

  function getPlacement(id: string, caller: UserPrincipal): Response {
    const found = getSession(id, caller);
    if (found instanceof Response) return found;
    if (!roleAllows(found.role, 'driver')) return error(403, 'forbidden');
    return json(200, { placement: found.record.placement ?? null });
  }

  /** Checks the manifest of a cloud run request against what was uploaded; returns the stored manifest (with each `wip.object`) or the refusal. */
  function acceptPlacement(id: string, record: SessionRecord, request: OrgCloudRunRequest, holder: OrgLeaseHolder, leaseAcquiredAt: string): OrgPlacementManifest | Response {
    const manifest = request.placement!;
    if (manifest.sessionId !== id || manifest.createdBy !== request.host || manifest.boundary !== record.envelope.workspaceId) return json(422, { error: 'invalid-placement' });
    // A repository that is not one of the session's workspace is refused, whether the workspace spells it as owner/name or as a clone URL; a workspace the server does not know, or one that lists no repository, refuses every git mount.
    const workspace = deps.workspaces.find((entry) => entry.id === record.envelope.workspaceId);
    if (manifest.mounts.some((mount) => mount.kind === 'git' && (!workspace || !isOrgWorkspaceRepository(mount.repo, workspace.repositories)))) return json(422, { error: 'invalid-placement' });
    const mounts = manifest.mounts.map((mount) => {
      if (mount.kind !== 'git' || !mount.wip) return mount;
      const stored = record.bundles?.get(mount.id);
      if (!stored) return error(409, 'no-bundle');
      const { info } = stored;
      if (info.sha256 !== mount.wip.sha256 || info.bytes !== mount.wip.bytes) return json(422, { error: 'bundle-mismatch' });
      if (!sameLeaseHolder(info.uploadedBy, holder) || Date.parse(info.at) < Date.parse(leaseAcquiredAt)) return json(422, { error: 'bundle-mismatch' });
      return { ...mount, wip: { ...mount.wip, object: `org-sessions/${id}/mounts/${mount.id}-${info.sha256}.bundle` } };
    });
    const refused = mounts.find((mount): mount is Response => mount instanceof Response);
    return refused ?? { ...manifest, mounts: mounts as OrgPlacementManifest['mounts'] };
  }

  function getEnvelopeInfo(id: string, caller: UserPrincipal): Response {
    const found = getSession(id, caller);
    if (found instanceof Response) return found;
    return found.record.native ? json(200, found.record.native.info) : error(409, 'no-envelope');
  }

  function getEnvelope(id: string, caller: UserPrincipal, init: RequestInit | undefined): Response {
    const found = getSession(id, caller);
    if (found instanceof Response) return found;
    if (!roleAllows(found.role, 'driver')) return error(403, 'forbidden');
    const host = new Headers(init?.headers).get(ENVELOPE_HEADERS.host);
    if (!host) return error(400, 'invalid-request');
    if (reserved(host)) return error(403, 'forbidden');
    const state = liveLease(found.record);
    if (!state) return error(409, 'lease-free');
    if (!sameLeaseHolder(state.lease.holder, { host, principal: caller })) {
      return json(409, { error: 'lease-held', holder: state.lease.holder, expiresAt: state.lease.expiresAt });
    }
    const stored = found.record.native;
    if (!stored) return error(409, 'no-envelope');
    return new Response(stored.bytes as never, {
      status: 200,
      headers: {
        'content-type': ENVELOPE_CONTENT_TYPE,
        'content-length': String(stored.bytes.length),
        [ENVELOPE_HEADERS.format]: stored.info.format,
        [ENVELOPE_HEADERS.sha256]: stored.info.sha256,
        [ENVELOPE_HEADERS.messages]: String(stored.info.messageCount),
      },
    });
  }

  const forksOn = () => deps.features.has('forks') && cloudOn();
  const forkIndex = new Map<string, { id: string; sourceId: string }>();
  let forkCounter = 0;

  /** The checkpointed envelope: the stored one is what the last release left (uploaded by that holder no later than the release, and the one a `sha256:` stateRef names). */
  function checkpointedEnvelope(record: SessionRecord): { info: OrgEnvelopeInfo; bytes: Uint8Array } | undefined {
    const checkpoint = record.checkpoint;
    const native = record.native;
    if (!checkpoint || !native) return undefined;
    const named = checkpoint.stateRef === undefined || !checkpoint.stateRef.startsWith('sha256:') || checkpoint.stateRef === envelopeStateRef(native.info.sha256);
    const fromReleaser = sameLeaseHolder(native.info.uploadedBy, checkpoint.releasedBy) && Date.parse(native.info.at) <= Date.parse(checkpoint.at);
    const covered = native.info.messageCount <= checkpoint.messageCount && native.info.messageCount <= record.messages.length;
    return named && fromReleaser && covered ? native : undefined;
  }

  function forkSession(id: string, caller: UserPrincipal, body: unknown): Response {
    const found = getSession(id, caller);
    if (found instanceof Response) return found;
    if (!roleAllows(found.role, 'driver')) return error(403, 'forbidden');
    const request = parseOrgForkRequest(body);
    const { record } = found;
    const earlier = forkIndex.get(`${caller}|${request.clientForkId}`);
    if (earlier) {
      const made = sessions.get(earlier.id);
      if (earlier.sourceId !== id || !made) return error(409, 'conflict');
      const kept = made.native && made.native.info.sha256 === made.envelope.forkedFrom!.envelopeSha256 ? made.native.info : undefined;
      const replay: OrgForkResult = { session: envelopeOf(made), role: 'owner', forkedFrom: made.envelope.forkedFrom!, ...(kept ? { envelope: kept } : {}) };
      return json(200, replay);
    }
    const source = checkpointedEnvelope(record);
    if (!source) return error(409, 'no-checkpoint');
    forkCounter += 1;
    let newId = `fk-${forkCounter}`;
    while (sessions.has(newId)) {
      forkCounter += 1;
      newId = `fk-${forkCounter}`;
    }
    const at = iso();
    const messages = record.messages.slice(0, source.info.messageCount);
    const forkedFrom = { sessionId: id, envelopeSha256: source.info.sha256, messageCount: source.info.messageCount, at };
    const info: OrgEnvelopeInfo = { ...source.info, uploadedBy: { host: 'fork', principal: caller }, at };
    const made: SessionRecord = {
      envelope: { ...record.envelope, id: newId, title: `Fork of ${record.envelope.title}`.slice(0, 256), owner: caller, createdAt: at, updatedAt: at, forkedFrom },
      messages,
      bytes: messages.reduce((sum, message) => sum + utf8Length(message.text), 0),
      grants: new Map(),
      inbox: [],
      native: { info, bytes: new Uint8Array(source.bytes) },
    };
    sessions.set(newId, made);
    forkIndex.set(`${caller}|${request.clientForkId}`, { id: newId, sourceId: id });
    if (caller !== record.envelope.owner && deps.features.has('notifications')) pushNotification(record.envelope.owner, 'fork', id, caller);
    const result: OrgForkResult = { session: envelopeOf(made), role: 'owner', forkedFrom, envelope: info };
    return json(200, result);
  }

  function getForkEnvelope(id: string, caller: UserPrincipal): Response {
    const found = getSession(id, caller);
    if (found instanceof Response) return found;
    if (found.role !== 'owner') return error(403, 'forbidden');
    const origin = found.record.envelope.forkedFrom;
    const stored = found.record.native;
    if (!origin || !stored || stored.info.sha256 !== origin.envelopeSha256) return error(409, 'no-envelope');
    return new Response(stored.bytes as never, {
      status: 200,
      headers: {
        'content-type': ENVELOPE_CONTENT_TYPE,
        'content-length': String(stored.bytes.length),
        [ENVELOPE_HEADERS.format]: stored.info.format,
        [ENVELOPE_HEADERS.sha256]: stored.info.sha256,
        [ENVELOPE_HEADERS.messages]: String(stored.info.messageCount),
      },
    });
  }

  function startCloudRun(id: string, caller: UserPrincipal, body: unknown): Response {
    const found = getSession(id, caller);
    if (found instanceof Response) return found;
    if (!roleAllows(found.role, 'driver')) return error(403, 'forbidden');
    const request = parseOrgCloudRunRequest(body);
    const maxBundle = deps.cloud!.maxBundleBytes;
    if (request.placement?.mounts.some((mount) => mount.kind === 'git' && mount.wip !== undefined && mount.wip.bytes > maxBundle)) return error(413, 'bundle-too-large');
    if (reserved(request.host)) return error(403, 'forbidden');
    const { record } = found;
    const state = liveLease(record);
    if (!state || !sameLeaseHolder(state.lease.holder, { host: request.host, principal: caller })) return lostLease();
    if (!deps.cloud!.available()) return error(503, 'cloud-unavailable');
    if (!record.native) return error(409, 'no-envelope');
    if (record.native.info.sha256 !== request.envelopeSha256) return json(422, { error: 'envelope-mismatch' });
    if (!sameLeaseHolder(record.native.info.uploadedBy, state.lease.holder) || Date.parse(record.native.info.at) < Date.parse(state.lease.acquiredAt)) {
      return json(422, { error: 'envelope-mismatch' });
    }
    let placement: OrgPlacementManifest | undefined;
    if (request.placement) {
      if (!placementOn()) return error(400, 'invalid-request');
      const accepted = acceptPlacement(id, record, request, state.lease.holder, state.lease.acquiredAt);
      if (accepted instanceof Response) return accepted;
      placement = accepted;
    }
    runCounter += 1;
    const at = deps.now();
    const run: OrgCloudRun = { id: `run-${runCounter}`, sessionId: id, status: 'running', startedAt: new Date(at).toISOString(), link: `https://chat.fake.test/threads/${encodeURIComponent(id)}` };
    record.run = run;
    record.home = 'cloud';
    // A live session that moves to the cloud: what others queued for the owner's desktop waits for the owner again.
    if (record.live === true) for (const entry of record.inbox) if (entry.status === 'queued' && entry.author !== record.envelope.owner) entry.status = 'held';
    if (placement) record.placement = placement;
    else delete record.placement;
    delete record.bundles;
    if (request.instruction !== undefined) record.runInstruction = request.instruction;
    else delete record.runInstruction;
    const ttlMs = 3600_000;
    record.lease = {
      ttlMs,
      lease: { holder: { host: `${deps.cloud!.host}:${run.id}`, principal: state.lease.holder.principal }, acquiredAt: new Date(at).toISOString(), expiresAt: new Date(at + ttlMs).toISOString(), heartbeatIntervalSeconds: heartbeatSeconds(ttlMs) },
    };
    return json(200, { run, lease: leaseView(record) });
  }

  function getCloudRun(id: string, caller: UserPrincipal): Response {
    const found = getSession(id, caller);
    if (found instanceof Response) return found;
    liveLease(found.record);
    return json(200, { run: found.record.run ?? null });
  }

  /** Test hook: the fake cloud host does one turn (appends a message, uploads a new envelope) and releases when asked to hand over or to finish. */
  function advanceCloud(sessionId: string, options: { finish?: boolean; uploadEnvelope?: boolean } = {}): CloudAdvance {
    const record = sessions.get(sessionId);
    const state = record ? liveLease(record) : undefined;
    if (!record || !state || !cloudOn() || !isCloudHolder(state.lease.holder) || !record.native || !record.run) {
      throw new Error('the cloud host does not hold this session');
    }
    const at = iso();
    const turnId = `fake-turn-${record.inbox.filter((entry) => entry.turnId !== undefined).length + 1}`;
    const finishedAuthors = new Set<UserPrincipal>();
    for (const entry of record.inbox) {
      if (entry.status === 'queued') {
        entry.status = 'done';
        entry.turnId = turnId;
        finishedAuthors.add(entry.author);
      }
    }
    for (const author of finishedAuthors) pushMultiUserNotification(author, 'turn-finished', sessionId, record.envelope.owner);
    if (finishedAuthors.size > 0 && queuedCount(record) === 0 && record.inbox.some((entry) => entry.status === 'held' && entry.kind !== 'comment')) {
      pushMultiUserNotification(record.envelope.owner, 'needs-you', sessionId, record.envelope.owner);
    }
    const text = `cloud: ${record.runInstruction ?? 'continued'}`;
    record.messages.push({ role: 'assistant', text, at });
    record.bytes += utf8Length(text);
    if (options.uploadEnvelope === false) return { released: false };
    const payload = gzipSync(Buffer.from(`${record.native.info.sha256}:${record.messages.length}`));
    const info: OrgEnvelopeInfo = {
      format: record.native.info.format,
      sha256: sha256Hex(payload),
      bytes: payload.length,
      messageCount: record.messages.length,
      uploadedBy: state.lease.holder,
      at,
    };
    record.native = { info, bytes: new Uint8Array(payload) };
    if (!options.finish && !state.handover) return { released: false };
    record.checkpoint = { messageCount: record.messages.length, stateRef: envelopeStateRef(info.sha256), releasedBy: state.lease.holder, at };
    record.run = { ...record.run, status: 'released', finishedAt: at };
    delete record.lease;
    return { released: true };
  }

  /** Test hook: the fake cloud host dies without releasing; its lease lapses at the next read. */
  function crashCloud(sessionId: string): void {
    const record = sessions.get(sessionId);
    if (!record?.lease || !isCloudHolder(record.lease.lease.holder)) throw new Error('the cloud host does not hold this session');
    record.lease.lease = { ...record.lease.lease, expiresAt: new Date(deps.now() - 1).toISOString() };
  }

  function revoke(id: string, caller: UserPrincipal, rawPrincipal: string): Response {
    const found = getSession(id, caller);
    if (found instanceof Response) return found;
    const target = found.record.grants.get(rawPrincipal as UserPrincipal);
    if (!target) return error(404, 'not-found');
    if (found.role !== 'owner' && target.principal !== caller && target.grantedBy !== caller) return error(403, 'forbidden');
    found.record.grants.delete(target.principal);
    rejectAuthorRows(found.record, target.principal, undefined);
    if (liveLease(found.record)?.lease.holder.principal === target.principal) {
      settleCloudRun(found.record, 'lease-revoked');
      delete found.record.lease;
    }
    return new Response(null, { status: 204 });
  }

  function listNotifications(caller: UserPrincipal, url: URL): Response {
    if (!deps.features.has('notifications')) return error(404, 'not-found');
    const unread = url.searchParams.get('unread');
    if (unread !== null && unread !== 'true' && unread !== 'false') return error(400, 'invalid-request');
    const limit = readPageLimit(url.searchParams.get('limit'), DEFAULT_SESSION_PAGE, MAX_NOTIFICATIONS_PAGE);
    const start = readOffset(readCursorParam(url.searchParams.get('cursor')));
    const mine = [...(notifications.get(caller) ?? [])].reverse().filter((entry) => unread === null || entry.read === (unread === 'false'));
    const slice = mine.slice(start, start + limit);
    const end = start + slice.length;
    return json(200, { notifications: slice, ...(end < mine.length ? { nextCursor: String(end) } : {}) });
  }

  function markRead(id: string, caller: UserPrincipal): Response {
    if (!deps.features.has('notifications')) return error(404, 'not-found');
    const entry = isNotificationId(id) ? notifications.get(caller)?.find((candidate) => candidate.id === id) : undefined;
    if (!entry) return error(404, 'not-found');
    entry.read = true;
    return json(200, entry);
  }

  /** Returns undefined when the path is not a sessions, grants or notifications route. */
  const handle = async function handle(method: string, path: string, url: URL, init: RequestInit | undefined, caller: UserPrincipal): Promise<Response | undefined> {
    const segments = path.split('/').slice(1);
    if (segments[0] !== 'v1') return undefined;
    let decoded: string[];
    try {
      decoded = segments.map(decodeURIComponent);
    } catch {
      return error(404, 'not-found');
    }
    const [, area, id, sub, extra] = decoded;
    const isSessions = area === 'sessions';
    const isNotifications = area === 'notifications';
    if (area === 'live-sessions') {
      if (!deps.features.has('sessions') || !liveOn() || id !== 'pending' || segments.length !== 3) return error(404, 'not-found');
      return method === 'GET' ? livePending(caller, url) : error(405, 'method-not-allowed');
    }
    if (area === 'cloud') {
      if (!cloudOn()) return error(404, 'not-found');
      return id === 'capabilities' && sub === undefined && segments.length === 3
        ? method === 'GET' ? cloudCapabilities() : error(405, 'method-not-allowed')
        : error(404, 'not-found');
    }
    if (!isSessions && !isNotifications) return undefined;
    if (isSessions && !deps.features.has('sessions')) return error(404, 'not-found');
    if (isNotifications && !deps.features.has('notifications')) return error(404, 'not-found');
    const cloudBody = isSessions && sub === 'envelope' && method === 'PUT';
    const bundleBody = isSessions && sub === 'mounts' && method === 'PUT';
    try {
      if (isSessions) {
        if (id === undefined) return method === 'GET' ? listSessions(caller, url) : error(405, 'method-not-allowed');
        if (sub === undefined) {
          if (method === 'GET') {
            const found = getSession(id, caller);
            return found instanceof Response ? found : json(200, viewOf(found.record, found.role, true));
          }
          return method === 'PUT' ? putSession(id, caller, await readBody(init)) : error(405, 'method-not-allowed');
        }
        if (sub === 'watch' && segments.length === 4) {
          if (!deps.features.has('sessionWatch')) return error(404, 'not-found');
          return method === 'GET' ? watch(id, caller, url, init?.signal ?? undefined) : error(405, 'method-not-allowed');
        }
        if (sub === 'transcript' && extra === undefined) {
          if (method === 'GET') return getTranscript(id, caller, url);
          return method === 'PUT' ? putTranscript(id, caller, await readBody(init)) : error(405, 'method-not-allowed');
        }
        if (sub === 'lease') {
          if (!deps.features.has('leases')) return error(404, 'not-found');
          if (extra === undefined) {
            if (method === 'GET') return getLease(id, caller);
            return method === 'POST' ? acquireLease(id, caller, await readBody(init)) : error(405, 'method-not-allowed');
          }
          if (segments.length !== 5) return error(404, 'not-found');
          const action = new Map([['heartbeat', heartbeatLease], ['release', releaseLease], ['handover', requestHandover]]).get(extra!);
          if (!action) return error(404, 'not-found');
          return method === 'POST' ? action(id, caller, await readBody(init)) : error(405, 'method-not-allowed');
        }
        if (sub === 'envelope' || sub === 'cloud-runs' || sub === 'cloud-run') {
          if (!cloudOn()) return error(404, 'not-found');
          if (sub === 'envelope' && extra === undefined) {
            if (method === 'GET') return getEnvelope(id, caller, init);
            return method === 'PUT' ? await putEnvelope(id, caller, init) : error(405, 'method-not-allowed');
          }
          if (sub === 'envelope' && extra === 'info' && segments.length === 5) return method === 'GET' ? getEnvelopeInfo(id, caller) : error(405, 'method-not-allowed');
          if (sub === 'cloud-runs' && extra === undefined) return method === 'POST' ? startCloudRun(id, caller, await readBody(init)) : error(405, 'method-not-allowed');
          if (sub === 'cloud-run' && extra === undefined) return method === 'GET' ? getCloudRun(id, caller) : error(405, 'method-not-allowed');
          return error(404, 'not-found');
        }
        if (sub === 'mounts' || sub === 'placement') {
          if (!placementOn()) return error(404, 'not-found');
          if (sub === 'placement' && extra === undefined) return method === 'GET' ? getPlacement(id, caller) : error(405, 'method-not-allowed');
          if (sub === 'mounts' && extra !== undefined && segments.length === 6 && decoded[5] === 'bundle') return method === 'PUT' ? await putMountBundle(id, extra, caller, init) : error(405, 'method-not-allowed');
          return error(404, 'not-found');
        }
        if (sub === 'fork') {
          if (!forksOn() || extra !== undefined) return error(404, 'not-found');
          if (method === 'POST') return forkSession(id, caller, await readBody(init));
          return method === 'GET' ? getForkEnvelope(id, caller) : error(405, 'method-not-allowed');
        }
        if (sub === 'mute' && segments.length === 4) return muteRoute(id, caller, method, method === 'PUT' ? await readBody(init) : undefined);
        if (sub === 'live' && segments.length === 4) {
          if (!liveOn()) return error(404, 'not-found');
          return liveRoute(id, caller, method, method === 'PUT' ? await readBody(init) : undefined);
        }
        if (sub === 'messages') {
          if (!messagesOn()) return error(404, 'not-found');
          if (extra === undefined) {
            if (method === 'GET') return listMessages(id, caller, url);
            return method === 'POST' ? postMessage(id, caller, await readBody(init), init) : error(405, 'method-not-allowed');
          }
          if (segments.length === 5 && (extra === 'claim' || extra === 'done')) {
            if (!liveOn()) return error(404, 'not-found');
            if (method !== 'POST') return error(405, 'method-not-allowed');
            return extra === 'claim' ? claimMessages(id, caller, await readBody(init)) : completeMessages(id, caller, await readBody(init));
          }
          if (segments.length === 5) return method === 'DELETE' ? cancelMessage(id, extra, caller) : error(405, 'method-not-allowed');
          if (segments.length === 6 && decoded[5] === 'run') return method === 'POST' ? runHeld(id, extra, caller, await readBody(init)) : error(405, 'method-not-allowed');
          return error(404, 'not-found');
        }
        if (sub === 'grants' && extra === undefined) return method === 'POST' ? grant(id, caller, await readBody(init)) : error(405, 'method-not-allowed');
        if (sub === 'grants' && segments.length === 5) return method === 'DELETE' ? revoke(id, caller, extra!) : error(405, 'method-not-allowed');
        return error(404, 'not-found');
      }
      if (id === undefined) return method === 'GET' ? listNotifications(caller, url) : error(405, 'method-not-allowed');
      if (sub === 'read' && extra === undefined) return method === 'POST' ? markRead(id, caller) : error(405, 'method-not-allowed');
      return error(404, 'not-found');
    } catch (failure) {
      if (failure instanceof TooLarge) return error(413, cloudBody ? 'envelope-too-large' : bundleBody ? 'bundle-too-large' : 'too-large');
      if (failure instanceof OrgContractError) return error(400, 'invalid-request');
      throw failure;
    }
  };
  return Object.assign(handle, { advanceCloud, crashCloud });
}
