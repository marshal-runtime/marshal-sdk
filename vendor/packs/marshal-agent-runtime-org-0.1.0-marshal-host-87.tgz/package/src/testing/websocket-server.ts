import { createHash } from 'node:crypto';
import type { IncomingMessage } from 'node:http';
import type { Duplex } from 'node:stream';

/**
 * A minimal RFC 6455 server side for the in-memory rooms provider: text frames, fragmentation, ping/pong and close.
 * No extensions, no binary messages. Enough to speak to Node's and browsers' WebSocket clients in tests.
 */
export type TestWebSocket = {
  send(text: string): void;
  close(code?: number): void;
  readonly closed: boolean;
  onMessage(listener: (text: string) => void): void;
  onClose(listener: () => void): void;
};

const GUID = '258EAFA5-E914-47DA-95CA-C5AB0DC85B11';
const MAX_MESSAGE_BYTES = 1024 * 1024;

export function acceptTestWebSocket(request: IncomingMessage, socket: Duplex, head: Buffer): TestWebSocket | undefined {
  const key = request.headers['sec-websocket-key'];
  if (typeof key !== 'string' || String(request.headers.upgrade).toLowerCase() !== 'websocket') {
    socket.end('HTTP/1.1 400 Bad Request\r\n\r\n');
    return undefined;
  }
  const accept = createHash('sha1').update(key + GUID).digest('base64');
  socket.write(`HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Accept: ${accept}\r\n\r\n`);

  const messageListeners: ((text: string) => void)[] = [];
  const closeListeners: (() => void)[] = [];
  let buffer: Buffer = head.length > 0 ? Buffer.from(head) : Buffer.alloc(0);
  let fragments: Buffer[] = [];
  let fragmentBytes = 0;
  let closed = false;

  const writeFrame = (opcode: number, payload: Buffer) => {
    if (socket.destroyed) return;
    const length = payload.length;
    let header: Buffer;
    if (length < 126) header = Buffer.from([0x80 | opcode, length]);
    else if (length < 65536) {
      header = Buffer.alloc(4);
      header[0] = 0x80 | opcode;
      header[1] = 126;
      header.writeUInt16BE(length, 2);
    } else {
      header = Buffer.alloc(10);
      header[0] = 0x80 | opcode;
      header[1] = 127;
      header.writeBigUInt64BE(BigInt(length), 2);
    }
    socket.write(Buffer.concat([header, payload]));
  };

  const finish = () => {
    if (closed) return;
    closed = true;
    for (const listener of closeListeners) listener();
  };

  const close = (code = 1000) => {
    if (closed) return;
    const payload = Buffer.alloc(2);
    payload.writeUInt16BE(code, 0);
    writeFrame(0x8, payload);
    socket.end();
    finish();
  };

  const parse = () => {
    while (buffer.length >= 2) {
      const first = buffer[0]!;
      const second = buffer[1]!;
      const fin = (first & 0x80) !== 0;
      const opcode = first & 0x0f;
      const masked = (second & 0x80) !== 0;
      let length = second & 0x7f;
      let offset = 2;
      if (length === 126) {
        if (buffer.length < 4) return;
        length = buffer.readUInt16BE(2);
        offset = 4;
      } else if (length === 127) {
        if (buffer.length < 10) return;
        const big = buffer.readBigUInt64BE(2);
        if (big > BigInt(MAX_MESSAGE_BYTES)) return close(1009);
        length = Number(big);
        offset = 10;
      }
      if (length > MAX_MESSAGE_BYTES) return close(1009);
      if (!masked) return close(1002);
      if (buffer.length < offset + 4 + length) return;
      const mask = buffer.subarray(offset, offset + 4);
      const payload = Buffer.from(buffer.subarray(offset + 4, offset + 4 + length));
      for (let index = 0; index < payload.length; index += 1) payload[index] = payload[index]! ^ mask[index % 4]!;
      buffer = buffer.subarray(offset + 4 + length);
      if (opcode === 0x8) return close(1000);
      if (opcode === 0x9) {
        writeFrame(0xa, payload);
        continue;
      }
      if (opcode === 0xa) continue;
      if (opcode === 0x2) return close(1003);
      if (opcode === 0x1 || opcode === 0x0) {
        fragments.push(payload);
        fragmentBytes += payload.length;
        if (fragmentBytes > MAX_MESSAGE_BYTES) return close(1009);
        if (!fin) continue;
        const text = Buffer.concat(fragments).toString('utf8');
        fragments = [];
        fragmentBytes = 0;
        for (const listener of messageListeners) listener(text);
      }
    }
  };

  socket.on('data', (chunk: Buffer) => {
    buffer = buffer.length === 0 ? chunk : Buffer.concat([buffer, chunk]);
    parse();
  });
  socket.on('close', finish);
  socket.on('error', finish);
  if (buffer.length > 0) queueMicrotask(parse);

  return {
    send: (text: string) => {
      if (!closed) writeFrame(0x1, Buffer.from(text, 'utf8'));
    },
    close,
    get closed() {
      return closed;
    },
    onMessage: (listener) => messageListeners.push(listener),
    onClose: (listener) => closeListeners.push(listener),
  };
}
