import { isSessionId, parseOrgSessionEnvelope, readForkedFrom, type OrgForkedFrom, type OrgSessionEnvelope } from './sessions.js';
import { parseOrgEnvelopeInfo, type OrgEnvelopeInfo } from './cloud.js';
import { fail, readObject, readString, type Reader } from './validate.js';

const RESPONSE: Reader = { code: 'invalid-response' };
const REQUEST: Reader = { code: 'invalid-request' };

/** Error codes the fork routes add to the shared set: `no-checkpoint` (409, the session has no completed checkpoint to fork from). */
export const FORK_ERROR_CODES = ['no-checkpoint'] as const;
/** Longest retry key of a fork request. */
export const MAX_CLIENT_FORK_ID = 128;

/**
 * Body of `POST /v1/sessions/:id/fork`. `clientForkId` is the retry key: the same caller sending it again for the same source gets the fork
 * already made, so reuse one `clientForkId` for every retry of the same fork. The client sends no id for the new session: a server names the fork itself and ignores a `newId` in the body (a server that honours one is not conforming).
 */
export type OrgForkRequest = {
  clientForkId: string;
};

/**
 * The answer of a fork: a new session owned by the caller, holding the source's transcript up to the messages its last checkpointed envelope
 * covers. The fork has no grants, no lease and no inbox of its own yet; the source is untouched. `envelope` describes the copy of the checkpointed
 * envelope the fork starts from; download it with `OrgClient.getForkEnvelope`. It is absent when the caller repeats a request after the fork's
 * own state has replaced the copy.
 */
export type OrgForkResult = {
  session: OrgSessionEnvelope;
  role: 'owner';
  forkedFrom: OrgForkedFrom;
  envelope?: OrgEnvelopeInfo;
};

export function parseOrgForkRequest(value: unknown): OrgForkRequest {
  const root = readObject(REQUEST, value, 'fork');
  const clientForkId = readString(REQUEST, root.clientForkId, 'fork.clientForkId', { max: MAX_CLIENT_FORK_ID });
  if (!isSessionId(clientForkId)) fail(REQUEST, 'fork.clientForkId', 'must be 1 to 128 letters, digits, dot, dash or underscore');
  return { clientForkId };
}

export function parseOrgForkResult(value: unknown): OrgForkResult {
  const root = readObject(RESPONSE, value, 'fork');
  if (root.role !== 'owner') fail(RESPONSE, 'fork.role', 'must be owner');
  const result: OrgForkResult = {
    session: parseOrgSessionEnvelope(root.session, 'fork.session'),
    role: 'owner',
    forkedFrom: readForkedFrom(RESPONSE, root.forkedFrom, 'fork.forkedFrom'),
  };
  if (root.envelope !== undefined && root.envelope !== null) result.envelope = parseOrgEnvelopeInfo(root.envelope, 'fork.envelope');
  return result;
}
