import { SESSION_ROLES, isOrgWorkspaceId, type OrgWorkspaceId, type SessionRole } from './model.js';
import { readUserPrincipal, type UserPrincipal } from './principals.js';
import {
  MAX_LONG_TEXT,
  MAX_SHORT_TEXT,
  fail,
  readArray,
  readObject,
  readOptionalString,
  readString,
  readUrl,
  type Reader,
} from './validate.js';

const RESPONSE: Reader = { code: 'invalid-response' };
const TRANSCRIPT_ID_PATTERN = /^[A-Za-z0-9][A-Za-z0-9._:-]{0,127}$/;
const MESSAGE_ID_PATTERN = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/;
const REQUEST: Reader = { code: 'invalid-request' };

export const MAX_SESSION_PAGE = 100;
export const DEFAULT_SESSION_PAGE = 50;
export const MAX_TRANSCRIPT_PAGE_MESSAGES = 200;
export const MAX_TRANSCRIPT_MESSAGE_BYTES = 64 * 1024;
/** UTF-8 bytes of message text in one transcript request or response page. */
export const MAX_TRANSCRIPT_PAGE_BYTES = 256 * 1024;
/** UTF-8 bytes of message text in one whole transcript. */
export const MAX_TRANSCRIPT_BYTES = 32 * 1024 * 1024;
export const MAX_SESSION_GRANTS = 256;
export const MAX_NOTIFICATIONS_PAGE = 100;
export const MAX_CURSOR = 256;

export const SESSION_LABELS = ['public', 'team', 'restricted'] as const;
/** The data-label high-water mark of a session, ordered from least to most sensitive. */
export type OrgSessionLabel = (typeof SESSION_LABELS)[number];

export const TRANSCRIPT_ROLES = ['user', 'assistant', 'system', 'tool'] as const;
export type OrgTranscriptRole = (typeof TRANSCRIPT_ROLES)[number];

export const NOTIFICATION_KINDS = ['mention', 'share', 'handover-request', 'fork', 'turn-finished', 'needs-you', 'cloud-failed', 'held-message'] as const;
/** One notification of a kind per person and session in this many seconds (`multiUser`). */
export const NOTIFICATION_THROTTLE_SECONDS = 10 * 60;
export type OrgNotificationKind = (typeof NOTIFICATION_KINDS)[number];

export type OrgSessionTranscriptRef = {
  messageCount: number;
  /** UTF-8 bytes of all message text. */
  bytes: number;
};

export type OrgSessionEnvelope = {
  id: string;
  workspaceId: OrgWorkspaceId;
  title: string;
  owner: UserPrincipal;
  createdAt: string;
  updatedAt: string;
  labels: OrgSessionLabel;
  /** The runtime that produced the transcript, for example `claude` or `codex`. */
  runtime: string;
  transcript: OrgSessionTranscriptRef;
  /** Present on a session made by forking another (the `forks` feature); absent otherwise. */
  forkedFrom?: OrgForkedFrom;
};

/** Where a fork came from: the source session, the envelope it started from, and how many transcript messages it kept. */
export type OrgForkedFrom = {
  sessionId: string;
  /** SHA-256 of the checkpointed envelope the fork started from (gzip bytes, as stored). */
  envelopeSha256: string;
  /** Transcript messages the fork kept: those the checkpointed envelope covers. */
  messageCount: number;
  at: string;
};

/** What the owner uploads with `PUT /v1/sessions/:id`. The server owns `transcript`. */
export type OrgSessionUpload = Omit<OrgSessionEnvelope, 'transcript'>;

export type OrgSessionGrant = {
  principal: UserPrincipal;
  role: SessionRole;
  grantedBy: UserPrincipal;
  grantedAt: string;
};

export const SESSION_PLACEMENTS = ['local', 'cloud'] as const;
/** Where a session lives: `cloud` while the organization's cloud host holds it or it was moved there and not taken back. */
export type OrgSessionPlacement = (typeof SESSION_PLACEMENTS)[number];

export const SESSION_TURN_STATES = ['idle', 'queued', 'running', 'hot', 'stalled', 'needs-you', 'failed'] as const;
/**
 * What the session is doing now: a turn `running`, an executor kept `hot` but idle, the cloud `stalled`, messages `queued`,
 * `failed` when the last cloud run failed, `needs-you` for held messages the owner must run. When several apply, the first
 * of that order wins, so a failed run with messages waiting reads `queued` (the cloud will start another run).
 * `needs-you` is for the owner only, and a `local` session is always `idle`.
 */
export type OrgSessionTurnState = (typeof SESSION_TURN_STATES)[number];

/**
 * What a list row shows without further calls. Present when the organization declares `cloudList`; absent otherwise.
 */
export type OrgSessionSummary = {
  placement: OrgSessionPlacement;
  turnState: OrgSessionTurnState;
  /** Messages waiting for the executor (queued or claimed). */
  queued: number;
  /** The latest of the session's update, transcript, inbox and run activity. */
  lastActivityAt: string;
  /** A human link to follow the latest cloud run, when it has one. */
  runLink?: string;
};

/** A session as one caller sees it. `grants` is present only when the caller is the owner. */
export type OrgSessionView = Partial<OrgSessionSummary> & {
  session: OrgSessionEnvelope;
  /** The caller's own role on this session. */
  role: SessionRole;
  grants?: OrgSessionGrant[];
  /** Present when the organization serves `liveSessions` and the owner turned live collaboration on or off; absent means off. */
  live?: { enabled: boolean };
};


export type OrgSessionPage = {
  sessions: OrgSessionView[];
  nextCursor?: string;
};

export type OrgTranscriptMessage = {
  role: OrgTranscriptRole;
  text: string;
  at: string;
  /**
   * Read only: the person who wrote the message, set by the server; a client never asserts it (the request parser drops it).
   * Without `sharedTranscript`: set only on a `user` message (the author of the inbox message named by `messageId`, else the owner).
   * With `sharedTranscript`: set on a message of any role, the authenticated caller who wrote it (the inbox message's author for a
   * `user` message whose `messageId` names an inbox message).
   */
  author?: UserPrincipal;
  /**
   * Chosen by the writer, any role (needs `sharedTranscript`): stored and returned unchanged so a desktop recognises the messages it
   * wrote. The server does not deduplicate on it.
   */
  id?: string;
  /** On a `user` message: the inbox message (live sessions) this message ran. */
  messageId?: string;
};

export type OrgTranscriptPage = {
  messages: OrgTranscriptMessage[];
  /** Messages in the whole transcript. */
  total: number;
  /** The decimal index of the first message this page did not carry; `String(n)` as a `cursor` reads from message `n` on. */
  nextCursor?: string;
};

/** Body of `PUT /v1/sessions/:id/transcript`. */
export type OrgTranscriptWrite = {
  /** `replace` clears the transcript first; `append` adds to the end. Upload a long transcript as one replace, then appends. */
  mode: 'append' | 'replace';
  messages: OrgTranscriptMessage[];
  /** For `append`: the message count the writer believes the transcript has. A mismatch is a 409 `conflict`. */
  expectedCount?: number;
};

export type OrgMention = {
  from: UserPrincipal;
  to: UserPrincipal;
  sessionId: string;
  role: SessionRole;
  note?: string;
};

/** Body of `POST /v1/sessions/:id/grants`. */
export type OrgGrantRequest = {
  principal: UserPrincipal;
  /** `owner` cannot be granted. */
  role: Exclude<SessionRole, 'owner'>;
  /** Records an @mention and notifies the grantee with a `mention` notification. Needs the `mentions` and `notifications` features. */
  mention?: { note?: string };
  /** Notifies the grantee with a `share` notification. Needs the `notifications` feature. Ignored when `mention` is set. */
  notify?: boolean;
};

export type OrgGrantResult = {
  grant: OrgSessionGrant;
  mention?: OrgMention;
  notificationId?: string;
};

export type OrgNotification = {
  id: string;
  kind: OrgNotificationKind;
  sessionId: string;
  from: UserPrincipal;
  at: string;
  read: boolean;
};

export type OrgNotificationPage = {
  notifications: OrgNotification[];
  nextCursor?: string;
};

const SESSION_ID_PATTERN = /^[A-Za-z0-9][A-Za-z0-9._-]{0,127}$/;
const NOTIFICATION_ID_PATTERN = /^[A-Za-z0-9][A-Za-z0-9._-]{0,127}$/;
const RUNTIME_PATTERN = /^[a-z][a-z0-9._-]{0,31}$/;
const ISO_PATTERN = /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(\.\d{1,9})?(Z|[+-]\d{2}:\d{2})$/;

export function isSessionId(value: unknown): value is string {
  return typeof value === 'string' && SESSION_ID_PATTERN.test(value);
}

export function isNotificationId(value: unknown): value is string {
  return typeof value === 'string' && NOTIFICATION_ID_PATTERN.test(value);
}

export function labelAllows(clearance: OrgSessionLabel, label: OrgSessionLabel): boolean {
  return SESSION_LABELS.indexOf(clearance) >= SESSION_LABELS.indexOf(label);
}

export function utf8Length(text: string): number {
  return new TextEncoder().encode(text).length;
}

function readSessionId(reader: Reader, value: unknown, path: string): string {
  const id = readString(reader, value, path, { max: 128 });
  if (!SESSION_ID_PATTERN.test(id)) fail(reader, path, 'must be 1 to 128 letters, digits, dot, dash or underscore');
  return id;
}

function readIso(reader: Reader, value: unknown, path: string): string {
  const text = readString(reader, value, path, { max: 40 });
  if (!ISO_PATTERN.test(text) || Number.isNaN(Date.parse(text))) fail(reader, path, 'must be an ISO 8601 timestamp');
  return text;
}

function readEnum<T extends string>(reader: Reader, value: unknown, path: string, allowed: readonly T[]): T {
  if (typeof value !== 'string' || !(allowed as readonly string[]).includes(value)) {
    fail(reader, path, `must be one of ${allowed.join(', ')}`);
  }
  return value as T;
}

function readCount(reader: Reader, value: unknown, path: string, max = Number.MAX_SAFE_INTEGER): number {
  if (typeof value !== 'number' || !Number.isInteger(value) || value < 0 || value > max) {
    fail(reader, path, 'must be a non-negative integer');
  }
  return value;
}

function readCursor(reader: Reader, value: unknown, path: string): string | undefined {
  return readOptionalString(reader, value, path, { max: MAX_CURSOR });
}

function readUploadFields(reader: Reader, root: Record<string, unknown>, path: string): OrgSessionUpload {
  const workspaceId = readString(reader, root.workspaceId, `${path}.workspaceId`, { max: 66 });
  if (!isOrgWorkspaceId(workspaceId)) fail(reader, `${path}.workspaceId`, 'must look like ws:<lowercase-name>');
  return {
    id: readSessionId(reader, root.id, `${path}.id`),
    workspaceId,
    title: readString(reader, root.title, `${path}.title`, { max: MAX_SHORT_TEXT }),
    owner: readUserPrincipal(reader, root.owner, `${path}.owner`),
    createdAt: readIso(reader, root.createdAt, `${path}.createdAt`),
    updatedAt: readIso(reader, root.updatedAt, `${path}.updatedAt`),
    labels: readEnum(reader, root.labels, `${path}.labels`, SESSION_LABELS),
    runtime: readString(reader, root.runtime, `${path}.runtime`, { max: 32, pattern: RUNTIME_PATTERN }),
  };
}

function readTranscriptRef(reader: Reader, value: unknown, path: string): OrgSessionTranscriptRef {
  const root = readObject(reader, value, path);
  return {
    messageCount: readCount(reader, root.messageCount, `${path}.messageCount`),
    bytes: readCount(reader, root.bytes, `${path}.bytes`, MAX_TRANSCRIPT_BYTES),
  };
}

const SHA256_PATTERN = /^[0-9a-f]{64}$/;

export function readForkedFrom(reader: Reader, value: unknown, path: string): OrgForkedFrom {
  const root = readObject(reader, value, path);
  return {
    sessionId: readSessionId(reader, root.sessionId, `${path}.sessionId`),
    envelopeSha256: readString(reader, root.envelopeSha256, `${path}.envelopeSha256`, { max: 64, pattern: SHA256_PATTERN }),
    messageCount: readCount(reader, root.messageCount, `${path}.messageCount`),
    at: readIso(reader, root.at, `${path}.at`),
  };
}

function readEnvelope(reader: Reader, value: unknown, path: string): OrgSessionEnvelope {
  const root = readObject(reader, value, path);
  const envelope: OrgSessionEnvelope = { ...readUploadFields(reader, root, path), transcript: readTranscriptRef(reader, root.transcript, `${path}.transcript`) };
  if (root.forkedFrom !== undefined && root.forkedFrom !== null) envelope.forkedFrom = readForkedFrom(reader, root.forkedFrom, `${path}.forkedFrom`);
  return envelope;
}

function readGrant(reader: Reader, value: unknown, path: string): OrgSessionGrant {
  const root = readObject(reader, value, path);
  return {
    principal: readUserPrincipal(reader, root.principal, `${path}.principal`),
    role: readEnum(reader, root.role, `${path}.role`, SESSION_ROLES),
    grantedBy: readUserPrincipal(reader, root.grantedBy, `${path}.grantedBy`),
    grantedAt: readIso(reader, root.grantedAt, `${path}.grantedAt`),
  };
}

function readMessage(reader: Reader, value: unknown, path: string): OrgTranscriptMessage {
  const root = readObject(reader, value, path);
  const text = readString(reader, root.text, `${path}.text`, { min: 0, max: MAX_TRANSCRIPT_MESSAGE_BYTES });
  if (utf8Length(text) > MAX_TRANSCRIPT_MESSAGE_BYTES) fail(reader, `${path}.text`, `must be at most ${MAX_TRANSCRIPT_MESSAGE_BYTES} bytes`);
  const message: OrgTranscriptMessage = { role: readEnum(reader, root.role, `${path}.role`, TRANSCRIPT_ROLES), text, at: readIso(reader, root.at, `${path}.at`) };
  const request = reader.code === 'invalid-request';
  // The author is the server's to set: a request's is dropped. An older server sets it on user messages only.
  if (!request && root.author !== undefined && root.author !== null) message.author = readUserPrincipal(reader, root.author, `${path}.author`);
  if (root.id !== undefined && root.id !== null) message.id = readString(reader, root.id, `${path}.id`, { max: 128, pattern: TRANSCRIPT_ID_PATTERN });
  if (root.messageId !== undefined && root.messageId !== null) {
    if (message.role === 'user') message.messageId = readString(reader, root.messageId, `${path}.messageId`, { max: 36, pattern: MESSAGE_ID_PATTERN });
    else if (request) fail(reader, `${path}.messageId`, 'is only valid on a user message');
  }
  return message;
}

function readMessages(reader: Reader, value: unknown, path: string): OrgTranscriptMessage[] {
  const messages = readArray(reader, value, path, MAX_TRANSCRIPT_PAGE_MESSAGES, (entry, entryPath) => readMessage(reader, entry, entryPath));
  const bytes = messages.reduce((sum, message) => sum + utf8Length(message.text), 0);
  if (bytes > MAX_TRANSCRIPT_PAGE_BYTES) fail(reader, path, `must carry at most ${MAX_TRANSCRIPT_PAGE_BYTES} bytes of text`);
  return messages;
}

function readMention(reader: Reader, value: unknown, path: string): OrgMention {
  const root = readObject(reader, value, path);
  const mention: OrgMention = {
    from: readUserPrincipal(reader, root.from, `${path}.from`),
    to: readUserPrincipal(reader, root.to, `${path}.to`),
    sessionId: readSessionId(reader, root.sessionId, `${path}.sessionId`),
    role: readEnum(reader, root.role, `${path}.role`, SESSION_ROLES),
  };
  const note = readOptionalString(reader, root.note, `${path}.note`, { max: MAX_LONG_TEXT });
  if (note !== undefined) mention.note = note;
  return mention;
}

function readNotification(reader: Reader, value: unknown, path: string): OrgNotification {
  const root = readObject(reader, value, path);
  if (typeof root.read !== 'boolean') fail(reader, `${path}.read`, 'must be a boolean');
  const id = readString(reader, root.id, `${path}.id`, { max: 128 });
  if (!NOTIFICATION_ID_PATTERN.test(id)) fail(reader, `${path}.id`, 'must be 1 to 128 letters, digits, dot, dash or underscore');
  return {
    id,
    kind: readEnum(reader, root.kind, `${path}.kind`, NOTIFICATION_KINDS),
    sessionId: readSessionId(reader, root.sessionId, `${path}.sessionId`),
    from: readUserPrincipal(reader, root.from, `${path}.from`),
    at: readIso(reader, root.at, `${path}.at`),
    read: root.read,
  };
}

function withCursor<T extends object>(reader: Reader, root: Record<string, unknown>, path: string, page: T): T & { nextCursor?: string } {
  const nextCursor = readCursor(reader, root.nextCursor, `${path}.nextCursor`);
  return nextCursor === undefined ? page : { ...page, nextCursor };
}

/* Responses: parsed by clients, invalid-response on failure. */

export function parseOrgSessionEnvelope(value: unknown, path = 'session'): OrgSessionEnvelope {
  return readEnvelope(RESPONSE, value, path);
}

/** A display-only enum of the summary: a value this client does not know (a newer server) is dropped, not an error. */
function optionalKnown<T extends string>(value: unknown, allowed: readonly T[]): T | undefined {
  return typeof value === 'string' && (allowed as readonly string[]).includes(value) ? (value as T) : undefined;
}

export function parseOrgSessionView(value: unknown, path = 'sessionView'): OrgSessionView {
  const root = readObject(RESPONSE, value, path);
  const view: OrgSessionView = {
    session: readEnvelope(RESPONSE, root.session, `${path}.session`),
    role: readEnum(RESPONSE, root.role, `${path}.role`, SESSION_ROLES),
  };
  if (root.grants !== undefined && root.grants !== null) {
    view.grants = readArray(RESPONSE, root.grants, `${path}.grants`, MAX_SESSION_GRANTS, (entry, entryPath) => readGrant(RESPONSE, entry, entryPath));
  }
  const placement = optionalKnown(root.placement, SESSION_PLACEMENTS);
  if (placement !== undefined) view.placement = placement;
  const turnState = optionalKnown(root.turnState, SESSION_TURN_STATES);
  if (turnState !== undefined) view.turnState = turnState;
  if (root.queued !== undefined && root.queued !== null) view.queued = readCount(RESPONSE, root.queued, `${path}.queued`, 1_000_000);
  if (root.lastActivityAt !== undefined && root.lastActivityAt !== null) view.lastActivityAt = readIso(RESPONSE, root.lastActivityAt, `${path}.lastActivityAt`);
  if (root.runLink !== undefined && root.runLink !== null) view.runLink = readUrl(RESPONSE, root.runLink, `${path}.runLink`);
  if (root.live !== undefined && root.live !== null) {
    const live = readObject(RESPONSE, root.live, `${path}.live`);
    if (typeof live.enabled !== 'boolean') fail(RESPONSE, `${path}.live.enabled`, 'must be a boolean');
    view.live = { enabled: live.enabled };
  }
  return view;
}

export function parseOrgSessionPage(value: unknown): OrgSessionPage {
  const root = readObject(RESPONSE, value, 'sessions');
  const sessions = readArray(RESPONSE, root.sessions, 'sessions.sessions', MAX_SESSION_PAGE, (entry, path) => parseOrgSessionView(entry, path));
  return withCursor(RESPONSE, root, 'sessions', { sessions });
}

export function parseOrgTranscriptRefResponse(value: unknown): OrgSessionTranscriptRef {
  const root = readObject(RESPONSE, value, 'transcriptWrite');
  return readTranscriptRef(RESPONSE, root.transcript, 'transcriptWrite.transcript');
}

export function parseOrgTranscriptPage(value: unknown): OrgTranscriptPage {
  const root = readObject(RESPONSE, value, 'transcript');
  const page = {
    messages: readMessages(RESPONSE, root.messages, 'transcript.messages'),
    total: readCount(RESPONSE, root.total, 'transcript.total'),
  };
  return withCursor(RESPONSE, root, 'transcript', page);
}

export function parseOrgGrantResult(value: unknown): OrgGrantResult {
  const root = readObject(RESPONSE, value, 'grantResult');
  const result: OrgGrantResult = { grant: readGrant(RESPONSE, root.grant, 'grantResult.grant') };
  if (root.mention !== undefined && root.mention !== null) result.mention = readMention(RESPONSE, root.mention, 'grantResult.mention');
  const notificationId = readOptionalString(RESPONSE, root.notificationId, 'grantResult.notificationId', { max: 128 });
  if (notificationId !== undefined) result.notificationId = notificationId;
  return result;
}

export function parseOrgNotification(value: unknown): OrgNotification {
  return readNotification(RESPONSE, value, 'notification');
}

/** Longest kind a skipped notification reports to `onUnknownKind`. */
const MAX_REPORTED_KIND = 64;

/**
 * Parses a page of notifications. An entry whose `kind` is a string this version does not know is skipped, not rejected, so a server can add a kind
 * without breaking older clients; `onUnknownKind` is told the kind (and nothing else of the entry). Any other malformed entry still rejects the page.
 */
export function parseOrgNotificationPage(value: unknown, options: { onUnknownKind?: (kind: string) => void } = {}): OrgNotificationPage {
  const root = readObject(RESPONSE, value, 'notifications');
  const known: readonly string[] = NOTIFICATION_KINDS;
  const entries = readArray(RESPONSE, root.notifications, 'notifications.notifications', MAX_NOTIFICATIONS_PAGE, (entry, path): OrgNotification | null => {
    const kind = typeof entry === 'object' && entry !== null ? (entry as Record<string, unknown>).kind : undefined;
    if (typeof kind === 'string' && !known.includes(kind)) {
      options.onUnknownKind?.(kind.slice(0, MAX_REPORTED_KIND));
      return null;
    }
    return readNotification(RESPONSE, entry, path);
  });
  const notifications = entries.filter((entry): entry is OrgNotification => entry !== null);
  return withCursor(RESPONSE, root, 'notifications', { notifications });
}

/* Requests: parsed by servers (and by the client before sending), invalid-request on failure. */

export function parseOrgSessionUpload(value: unknown): OrgSessionUpload {
  const upload = readUploadFields(REQUEST, readObject(REQUEST, value, 'session'), 'session');
  if (Date.parse(upload.updatedAt) < Date.parse(upload.createdAt)) fail(REQUEST, 'session.updatedAt', 'must not be before createdAt');
  return upload;
}

export function parseOrgTranscriptWrite(value: unknown): OrgTranscriptWrite {
  const root = readObject(REQUEST, value, 'transcriptWrite');
  const mode = readEnum(REQUEST, root.mode, 'transcriptWrite.mode', ['append', 'replace'] as const);
  const write: OrgTranscriptWrite = { mode, messages: readMessages(REQUEST, root.messages, 'transcriptWrite.messages') };
  if (root.expectedCount !== undefined && root.expectedCount !== null) {
    if (mode !== 'append') fail(REQUEST, 'transcriptWrite.expectedCount', 'is only valid with mode append');
    write.expectedCount = readCount(REQUEST, root.expectedCount, 'transcriptWrite.expectedCount');
  }
  return write;
}

export function parseOrgGrantRequest(value: unknown): OrgGrantRequest {
  const root = readObject(REQUEST, value, 'grant');
  const role = readEnum(REQUEST, root.role, 'grant.role', SESSION_ROLES);
  if (role === 'owner') fail(REQUEST, 'grant.role', 'owner cannot be granted');
  const request: OrgGrantRequest = { principal: readUserPrincipal(REQUEST, root.principal, 'grant.principal'), role };
  if (root.mention !== undefined && root.mention !== null) {
    const mention = readObject(REQUEST, root.mention, 'grant.mention');
    const note = readOptionalString(REQUEST, mention.note, 'grant.mention.note', { max: MAX_LONG_TEXT });
    request.mention = note === undefined ? {} : { note };
  }
  if (root.notify !== undefined && root.notify !== null) {
    if (typeof root.notify !== 'boolean') fail(REQUEST, 'grant.notify', 'must be a boolean');
    request.notify = root.notify;
  }
  return request;
}

/** Reads a `limit` query value: absent means `fallback`, otherwise a positive integer clamped to `max`. */
export function readPageLimit(value: string | null, fallback: number, max: number): number {
  if (value === null) return fallback;
  const parsed = Number(value);
  if (!Number.isFinite(parsed) || parsed < 1) fail(REQUEST, 'limit', 'must be a positive integer');
  return Math.min(Math.trunc(parsed), max);
}

export function readCursorParam(value: string | null): string | undefined {
  return value === null ? undefined : readString(REQUEST, value, 'cursor', { max: MAX_CURSOR });
}
