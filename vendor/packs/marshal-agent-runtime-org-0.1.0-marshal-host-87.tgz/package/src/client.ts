import { orgDiscoveryUrl, parseOrgDiscoveryDocument, orgSupports, type OrgDiscoveryDocument, type OrgFeature } from './discovery.js';
import {
  MAX_DIRECTORY_RESULTS,
  isOrgWorkspaceId,
  parseDirectoryResults,
  parseOrgIdentity,
  parseOrgWorkspace,
  parseOrgWorkspaceList,
  type DirectoryEntry,
  type OrgIdentity,
  type OrgWorkspace,
  type OrgWorkspaceId,
} from './model.js';
import type { FetchLike } from './oidc.js';
import type { UserPrincipal } from './principals.js';
import {
  DEFAULT_SESSION_PAGE,
  MAX_CURSOR,
  MAX_NOTIFICATIONS_PAGE,
  MAX_SESSION_PAGE,
  SESSION_PLACEMENTS,
  MAX_TRANSCRIPT_PAGE_MESSAGES,
  isNotificationId,
  isSessionId,
  parseOrgGrantRequest,
  parseOrgGrantResult,
  parseOrgNotification,
  parseOrgNotificationPage,
  parseOrgSessionEnvelope,
  parseOrgSessionPage,
  parseOrgSessionUpload,
  parseOrgSessionView,
  parseOrgTranscriptPage,
  parseOrgTranscriptRefResponse,
  parseOrgTranscriptWrite,
  type OrgGrantRequest,
  type OrgGrantResult,
  type OrgNotification,
  type OrgNotificationPage,
  type OrgSessionEnvelope,
  type OrgSessionPage,
  type OrgSessionPlacement,
  type OrgSessionTranscriptRef,
  type OrgSessionUpload,
  type OrgSessionView,
  type OrgTranscriptPage,
  type OrgTranscriptWrite,
} from './sessions.js';
import {
  parseOrgClaimedMessages,
  parseOrgClaimMessagesRequest,
  parseOrgCompletedMessages,
  parseOrgCompleteMessagesRequest,
  parseOrgLivePending,
  parseOrgSessionLive,
  parseOrgSessionLiveRequest,
  type OrgClaimedMessages,
  type OrgClaimMessagesRequest,
  type OrgCompletedMessages,
  type OrgCompleteMessagesRequest,
  type OrgLivePending,
  type OrgSessionLive,
  type OrgSessionLiveRequest,
} from './live.js';
import {
  isLeaseHostId,
  parseOrgLeaseAcquireRequest,
  parseOrgLeaseHandoverRequest,
  parseOrgLeaseHeartbeatRequest,
  parseOrgLeaseHeld,
  parseOrgLeaseReleaseRequest,
  parseOrgLeaseView,
  type OrgLeaseAcquireRequest,
  type OrgLeaseHandoverRequest,
  type OrgLeaseHeld,
  type OrgLeaseReleaseRequest,
  type OrgLeaseView,
} from './leases.js';
import {
  ENVELOPE_CONTENT_TYPE,
  ENVELOPE_HEADERS,
  MAX_ENVELOPE_BYTES_CEILING,
  isEnvelopeFormat,
  isSha256Hex,
  parseOrgCloudCapabilities,
  parseOrgCloudRunRequest,
  parseOrgCloudRunStarted,
  parseOrgCloudRunView,
  parseOrgEnvelopeInfo,
  type EnvelopeBody,
  type OrgCloudCapabilities,
  type OrgCloudRunRequest,
  type OrgCloudRunStarted,
  type OrgCloudRunView,
  type OrgEnvelopeInfo,
} from './cloud.js';
import {
  BUNDLE_CONTENT_TYPE,
  BUNDLE_HEADERS,
  MAX_BUNDLE_BYTES_CEILING,
  isMountId,
  parseOrgMountBundleInfo,
  parseOrgPlacementView,
  type OrgMountBundleInfo,
  type OrgPlacementView,
} from './placement.js';
import {
  MAX_RUN_PAGE,
  auditTargetRunId,
  isRunId,
  isRunSessionName,
  orgRunQueryParams,
  parseOrgAuditPage,
  parseOrgRunDetail,
  parseOrgRunEventPage,
  parseOrgRunGrepRequest,
  parseOrgRunGrepResult,
  parseOrgRunMessagesPage,
  parseOrgRunPage,
  type OrgAuditPage,
  type OrgAuditQuery,
  type OrgRunDetail,
  type OrgRunEventPage,
  type OrgRunEventsQuery,
  type OrgRunGrepRequest,
  type OrgRunGrepResult,
  type OrgRunMessagesPage,
  type OrgRunMessagesQuery,
  type OrgRunPage,
  type OrgRunQuery,
} from './runs.js';
import {
  MAX_ROUTINE_EVENTS_PAGE,
  parseOrgRoutineDispatch,
  parseOrgRoutineEnabled,
  parseOrgRoutineEventPage,
  parseOrgRoutineList,
  parseOrgRoutinePromotion,
  parseOrgRoutinePullRequest,
  parseOrgRoutineTest,
  ORG_DEFINED_ROUTINE_ID_PATTERN,
  type OrgRoutinePullRequest,
  type OrgRoutineTest,
  type OrgRoutine,
  type OrgRoutineDispatch,
  type OrgRoutineEventFilters,
  type OrgRoutineEventPage,
} from './routines.js';
import {
  CLIENT_MESSAGE_SOURCES,
  DEFAULT_MESSAGE_LIST,
  MAX_MESSAGE_LIST,
  MESSAGE_SOURCE_HEADER,
  isMessageId,
  parseOrgPostMessageRequest,
  parseOrgPostedMessage,
  parseOrgRunHeldMessageRequest,
  parseOrgSessionMessage,
  parseOrgSessionMessagePage,
  type OrgPostMessageRequest,
  type OrgPostedMessage,
  type OrgRunHeldMessageRequest,
  type OrgSessionMessage,
  type OrgSessionMessagePage,
} from './messages.js';
import { parseOrgForkRequest, parseOrgForkResult, type OrgForkRequest, type OrgForkResult } from './forks.js';
import { createHash } from 'node:crypto';
import {
  DEFAULT_WATCH_POLL_MS,
  MAX_WATCH_RETRY_MS,
  MIN_WATCH_RETRY_MS,
  WATCH_CONTENT_TYPE,
  isWatchVersion,
  readWatchEvents,
  type OrgFollowEvent,
  type OrgWatchEvent,
  WATCH_KINDS,
} from './watch.js';
import { parseOrgOnboardingManifest, type OrgOnboardingManifest } from './onboarding.js';
import {
  CATALOG_PUBLISH_CONTENT_TYPE,
  CATALOG_PUBLISH_HEADERS,
  parseCatalogEntryResponse,
  parseOrgExtensionCatalog,
  validateCatalogEntryUpdate,
  validateCatalogPublishMetadata,
  validateCatalogReview,
  type OrgCatalogEntry,
  type OrgCatalogEntryUpdate,
  type OrgCatalogPublishInput,
  type OrgCatalogReview,
  type OrgExtensionCatalog,
} from './extension-catalog.js';
import { isOnboardingExtensionId, isOnboardingVersion } from './onboarding.js';
import { OrgContractError, readObject } from './validate.js';

/** Routes of the organization API, relative to the discovery document's `apiBase`. */
export const ORG_ROUTES = {
  whoami: '/v1/whoami',
  workspaces: '/v1/workspaces',
  workspace: (id: OrgWorkspaceId) => `/v1/workspaces/${encodeURIComponent(id)}`,
  workspaceRoutines: (id: OrgWorkspaceId) => `/v1/workspaces/${encodeURIComponent(id)}/routines`,
  routineEvents: (id: OrgWorkspaceId, routine: string) =>
    `/v1/workspaces/${encodeURIComponent(id)}/routines/${encodeURIComponent(routine)}/events`,
  routineDispatch: (id: OrgWorkspaceId, routine: string) =>
    `/v1/workspaces/${encodeURIComponent(id)}/routines/${encodeURIComponent(routine)}/dispatch`,
  routineTest: (id: OrgWorkspaceId) => `/v1/workspaces/${encodeURIComponent(id)}/routines/test`,
  routinePromote: (id: OrgWorkspaceId) => `/v1/workspaces/${encodeURIComponent(id)}/routines/promote`,
  routineEnabled: (id: OrgWorkspaceId, routine: string) =>
    `/v1/workspaces/${encodeURIComponent(id)}/routines/${encodeURIComponent(routine)}/enabled`,
  directory: '/v1/directory',
  sessions: '/v1/sessions',
  session: (id: string) => `/v1/sessions/${encodeURIComponent(id)}`,
  sessionWatch: (id: string) => `/v1/sessions/${encodeURIComponent(id)}/watch`,
  sessionTranscript: (id: string) => `/v1/sessions/${encodeURIComponent(id)}/transcript`,
  sessionGrants: (id: string) => `/v1/sessions/${encodeURIComponent(id)}/grants`,
  sessionMute: (id: string) => `/v1/sessions/${encodeURIComponent(id)}/mute`,
  sessionGrant: (id: string, principal: string) => `/v1/sessions/${encodeURIComponent(id)}/grants/${encodeURIComponent(principal)}`,
  sessionLease: (id: string) => `/v1/sessions/${encodeURIComponent(id)}/lease`,
  sessionLeaseHeartbeat: (id: string) => `/v1/sessions/${encodeURIComponent(id)}/lease/heartbeat`,
  sessionLeaseRelease: (id: string) => `/v1/sessions/${encodeURIComponent(id)}/lease/release`,
  sessionLeaseHandover: (id: string) => `/v1/sessions/${encodeURIComponent(id)}/lease/handover`,
  cloudCapabilities: '/v1/cloud/capabilities',
  sessionEnvelope: (id: string) => `/v1/sessions/${encodeURIComponent(id)}/envelope`,
  sessionEnvelopeInfo: (id: string) => `/v1/sessions/${encodeURIComponent(id)}/envelope/info`,
  sessionMountBundle: (id: string, mountId: string) => `/v1/sessions/${encodeURIComponent(id)}/mounts/${encodeURIComponent(mountId)}/bundle`,
  sessionPlacement: (id: string) => `/v1/sessions/${encodeURIComponent(id)}/placement`,
  sessionCloudRuns: (id: string) => `/v1/sessions/${encodeURIComponent(id)}/cloud-runs`,
  sessionCloudRun: (id: string) => `/v1/sessions/${encodeURIComponent(id)}/cloud-run`,
  sessionFork: (id: string) => `/v1/sessions/${encodeURIComponent(id)}/fork`,
  sessionMessages: (id: string) => `/v1/sessions/${encodeURIComponent(id)}/messages`,
  sessionMessage: (id: string, messageId: string) => `/v1/sessions/${encodeURIComponent(id)}/messages/${encodeURIComponent(messageId)}`,
  sessionMessageRun: (id: string, messageId: string) => `/v1/sessions/${encodeURIComponent(id)}/messages/${encodeURIComponent(messageId)}/run`,
  sessionMessagesClaim: (id: string) => `/v1/sessions/${encodeURIComponent(id)}/messages/claim`,
  sessionMessagesDone: (id: string) => `/v1/sessions/${encodeURIComponent(id)}/messages/done`,
  sessionLive: (id: string) => `/v1/sessions/${encodeURIComponent(id)}/live`,
  livePending: '/v1/live-sessions/pending',
  runs: '/v1/runs',
  run: (id: string) => `/v1/runs/${encodeURIComponent(id)}`,
  runEvents: (id: string) => `/v1/runs/${encodeURIComponent(id)}/events`,
  runMessages: (id: string, session: string) => `/v1/runs/${encodeURIComponent(id)}/sessions/${encodeURIComponent(session)}/messages`,
  runEnvelope: (id: string, session: string) => `/v1/runs/${encodeURIComponent(id)}/sessions/${encodeURIComponent(session)}/envelope`,
  runSubagents: (id: string, session: string) => `/v1/runs/${encodeURIComponent(id)}/sessions/${encodeURIComponent(session)}/subagents`,
  runSubagent: (id: string, session: string, agent: string) =>
    `/v1/runs/${encodeURIComponent(id)}/sessions/${encodeURIComponent(session)}/subagents/${encodeURIComponent(agent)}`,
  runsGrep: '/v1/runs/grep',
  audit: '/v1/audit',
  notifications: '/v1/notifications',
  onboarding: '/v1/onboarding',
  catalog: '/v1/onboarding/catalog',
  catalogPublish: '/v1/onboarding/catalog/publish',
  catalogEntry: (id: string) => `/v1/onboarding/catalog/${encodeURIComponent(id)}`,
  catalogReview: (id: string, version: string) => `/v1/onboarding/catalog/${encodeURIComponent(id)}/${encodeURIComponent(version)}/review`,
  notificationRead: (id: string) => `/v1/notifications/${encodeURIComponent(id)}/read`,
} as const;

/** The most bytes of a run's transcript the gateway serves in one answer: its request body cap leaves room for 24 MiB of gzip. */
export const MAX_RUN_ENVELOPE_BYTES = 24 * 1024 * 1024;
/** The most subagents one run session lists. */
export const MAX_RUN_SUBAGENTS = 256;
const SUBAGENT_ID = /^[A-Za-z0-9_-]{1,64}$/;

/** Whether the text is a subagent id as the run routes serve it (the `<id>` of `agent-<id>.jsonl`). */
export const isRunSubagentId = (value: unknown): value is string => typeof value === 'string' && SUBAGENT_ID.test(value);

/** A run transcript as downloaded: the verified gzip bytes and what the server said about them. */
export type OrgRunEnvelope = { envelope: { format: string; sha256: string; bytes: number; messageCount: number }; body: Uint8Array };
export const DEFAULT_ORG_TIMEOUT_MS = 15_000;
export const DEFAULT_ENVELOPE_TRANSFER_TIMEOUT_MS = 10 * 60_000;
const MAX_RESPONSE_BYTES = 2 * 1024 * 1024;
const MAX_REQUEST_BYTES = 2 * 1024 * 1024;

export class OrgApiError extends Error {
  readonly status: number;
  readonly code: string;
  /** Present on a 409 `lease-held`: who holds the lease and until when. */
  readonly leaseHeld?: OrgLeaseHeld;
  /** The server's one line on why it refused, when it sent one (a routine test or promotion). */
  readonly problem?: string;
  /** Present on a 409 `routine-exists` whose promotion is already open. */
  readonly pullRequest?: OrgRoutinePullRequest;

  constructor(status: number, code: string, message: string, leaseHeld?: OrgLeaseHeld, details: { problem?: string; pullRequest?: OrgRoutinePullRequest } = {}) {
    super(details.problem ? `${message}: ${details.problem}` : message);
    this.name = 'OrgApiError';
    this.status = status;
    this.code = code;
    if (leaseHeld) this.leaseHeld = leaseHeld;
    if (details.problem) this.problem = details.problem;
    if (details.pullRequest) this.pullRequest = details.pullRequest;
  }
}

export class OrgFeatureUnavailableError extends Error {
  readonly feature: OrgFeature;

  constructor(feature: OrgFeature) {
    super(`the organization does not serve the ${feature} feature`);
    this.name = 'OrgFeatureUnavailableError';
    this.feature = feature;
  }
}

export async function fetchOrgDiscovery(
  orgUrl: string,
  options: { fetch?: FetchLike; timeoutMs?: number } = {},
): Promise<OrgDiscoveryDocument> {
  const body = await getJson(orgDiscoveryUrl(orgUrl), {}, options.fetch ?? fetch, options.timeoutMs ?? DEFAULT_ORG_TIMEOUT_MS);
  return parseOrgDiscoveryDocument(body);
}

export type OrgClientOptions = {
  discovery: OrgDiscoveryDocument;
  /** Returns a current access token for the signed-in person or service; refreshing is the caller's job. */
  accessToken: () => Promise<string>;
  fetch?: FetchLike;
  timeoutMs?: number;
  /** Whole-transfer limit for envelope upload and download. Default 10 minutes. */
  transferTimeoutMs?: number;
  /** Told about things the client tolerated, such as a notification of a kind it does not know. Receives a short message with no session content. */
  onDebug?: (message: string) => void;
};

/** The input of `putMountBundle`. `bytes` and `sha256` describe the git bundle bytes of `body` and must be known before sending. */
export type OrgMountBundleUpload = {
  host: string;
  sha256: string;
  bytes: number;
  body: EnvelopeBody;
};

/** The input of `putEnvelope`. `bytes` and `sha256` describe the gzip bytes of `body` and must be known before sending. */
export type OrgEnvelopeUpload = {
  host: string;
  format: string;
  messageCount: number;
  sha256: string;
  bytes: number;
  body: EnvelopeBody;
};

export type OrgEnvelopeDownload = {
  envelope: { format: string; sha256: string; bytes: number; messageCount: number };
  /** Verified while it is read: it errors if the size or sha256 differs from the headers, or if it exceeds `maxBytes`. */
  body: ReadableStream<Uint8Array>;
};

/** A client for one organization's API. It never stores tokens and never reads organization-specific settings. */
export class OrgClient {
  readonly discovery: OrgDiscoveryDocument;
  readonly #accessToken: () => Promise<string>;
  readonly #fetch: FetchLike;
  readonly #timeoutMs: number;
  readonly #transferTimeoutMs: number;
  readonly #onDebug: ((message: string) => void) | undefined;

  constructor(options: OrgClientOptions) {
    this.#onDebug = options.onDebug;
    this.discovery = options.discovery;
    this.#accessToken = options.accessToken;
    this.#fetch = options.fetch ?? fetch;
    this.#timeoutMs = options.timeoutMs ?? DEFAULT_ORG_TIMEOUT_MS;
    this.#transferTimeoutMs = options.transferTimeoutMs ?? DEFAULT_ENVELOPE_TRANSFER_TIMEOUT_MS;
  }

  supports(feature: OrgFeature): boolean {
    return orgSupports(this.discovery, feature);
  }

  async whoami(): Promise<OrgIdentity> {
    this.#require('signIn');
    return parseOrgIdentity(await this.#get(ORG_ROUTES.whoami));
  }

  /** The organization's onboarding manifest for the signed-in person. Needs the `onboarding` feature. */
  async getOnboardingManifest(): Promise<OrgOnboardingManifest> {
    this.#require('onboarding');
    const manifest = parseOrgOnboardingManifest(await this.#get(ORG_ROUTES.onboarding));
    const origin = new URL(this.discovery.apiBase).origin;
    manifest.extensions.forEach((extension, index) => {
      if (extension.delivery.kind === 'archive' && new URL(extension.delivery.url).origin !== origin) {
        throw new OrgContractError('invalid-response', `onboarding.extensions[${index}].delivery.url`, 'must be on the same origin as the organization API');
      }
    });
    return manifest;
  }

  /** The extension catalog: recommended, available, and the caller's pending entries (every pending one for an admin). */
  async getExtensionCatalog(): Promise<OrgExtensionCatalog> {
    this.#require('extensionCatalog');
    const catalog = parseOrgExtensionCatalog(await this.#get(ORG_ROUTES.catalog));
    this.#requireSameOriginArchives([...catalog.recommended, ...catalog.available, ...catalog.pending], 'catalog');
    return catalog;
  }

  /** Admin: change an entry's tier, pin its version, or remove it. Returns the entry, or null when removed. */
  async updateCatalogEntry(id: string, update: OrgCatalogEntryUpdate): Promise<OrgCatalogEntry | null> {
    this.#require('extensionCatalog');
    if (!isOnboardingExtensionId(id)) throw new OrgContractError('invalid-request', 'id', 'must look like @scope/name');
    const body = validateCatalogEntryUpdate(update);
    const answer = await this.#send('PUT', ORG_ROUTES.catalogEntry(id), body);
    if (body.remove) return null;
    const entry = parseCatalogEntryResponse(answer);
    this.#requireSameOriginArchives([entry], 'entry');
    return entry;
  }

  /** Any member: uploads a packed extension archive. It lands as `pending` until an admin approves it. */
  async publishExtension(input: OrgCatalogPublishInput): Promise<OrgCatalogEntry> {
    this.#require('extensionCatalog');
    const { body: archive, ...metadata } = input;
    validateCatalogPublishMetadata(metadata);
    const body = boundedBody(archive, metadata.bytes);
    const token = await this.#accessToken();
    const headers = {
      authorization: `Bearer ${token}`,
      'content-type': CATALOG_PUBLISH_CONTENT_TYPE,
      'content-length': String(metadata.bytes),
      [CATALOG_PUBLISH_HEADERS.id]: metadata.id,
      [CATALOG_PUBLISH_HEADERS.version]: metadata.version,
      [CATALOG_PUBLISH_HEADERS.title]: encodeURIComponent(metadata.title),
      [CATALOG_PUBLISH_HEADERS.why]: encodeURIComponent(metadata.why),
      [CATALOG_PUBLISH_HEADERS.sha256]: metadata.sha256,
    };
    const url = `${this.discovery.apiBase.replace(/\/+$/, '')}${ORG_ROUTES.catalogPublish}`;
    const entry = parseCatalogEntryResponse(await requestJson(url, 'POST', headers, body, this.#fetch, this.#transferTimeoutMs));
    this.#requireSameOriginArchives([entry], 'entry');
    return entry;
  }

  /** Admin: approve or reject a pending entry. */
  async reviewCatalogEntry(id: string, version: string, review: OrgCatalogReview): Promise<OrgCatalogEntry> {
    this.#require('extensionCatalog');
    if (!isOnboardingExtensionId(id)) throw new OrgContractError('invalid-request', 'id', 'must look like @scope/name');
    if (!isOnboardingVersion(version)) throw new OrgContractError('invalid-request', 'version', 'must be a semantic version');
    const entry = parseCatalogEntryResponse(await this.#send('POST', ORG_ROUTES.catalogReview(id, version), validateCatalogReview(review)));
    this.#requireSameOriginArchives([entry], 'entry');
    return entry;
  }

  async listWorkspaces(): Promise<OrgWorkspace[]> {
    this.#require('workspaces');
    return parseOrgWorkspaceList(await this.#get(ORG_ROUTES.workspaces));
  }

  async getWorkspace(id: OrgWorkspaceId): Promise<OrgWorkspace> {
    this.#require('workspaces');
    if (!isOrgWorkspaceId(id)) throw new OrgContractError('invalid-request', 'id', 'must look like ws:<lowercase-name>');
    const workspace = parseOrgWorkspace(await this.#get(ORG_ROUTES.workspace(id)));
    if (workspace.id !== id) throw new OrgContractError('invalid-response', 'workspace.id', 'does not match the requested id');
    return workspace;
  }

  /** The agent routines of a workspace the caller may read. Needs the `routines` feature. */
  async listWorkspaceRoutines(id: OrgWorkspaceId): Promise<OrgRoutine[]> {
    this.#require('routines');
    if (!isOrgWorkspaceId(id)) throw new OrgContractError('invalid-request', 'id', 'must look like ws:<lowercase-name>');
    return parseOrgRoutineList(await this.#get(ORG_ROUTES.workspaceRoutines(id)), id);
  }

  /** The events that woke a routine, newest first, filtered and paged. Needs the `routineEvents` feature. */
  async listRoutineEvents(id: OrgWorkspaceId, routineId: string, filters: OrgRoutineEventFilters = {}): Promise<OrgRoutineEventPage> {
    this.#require('routineEvents');
    this.#checkRoutine(id, routineId);
    const params = new URLSearchParams();
    for (const key of ['since', 'until', 'channel', 'role', 'q', 'severity', 'status', 'cursor'] as const) {
      const value = filters[key];
      if (value !== undefined && value !== '') params.set(key, value);
    }
    if (filters.limit !== undefined) params.set('limit', String(Math.min(Math.max(Math.trunc(filters.limit), 1), MAX_ROUTINE_EVENTS_PAGE)));
    const query = params.toString();
    return parseOrgRoutineEventPage(await this.#get(`${ORG_ROUTES.routineEvents(id, routineId)}${query ? `?${query}` : ''}`));
  }

  /** Runs a routine now, or replays one of its events. Needs the `routineActions` feature. */
  async dispatchRoutine(id: OrgWorkspaceId, routineId: string, input: { eventId?: string } = {}): Promise<OrgRoutineDispatch> {
    this.#require('routineActions');
    this.#checkRoutine(id, routineId);
    return parseOrgRoutineDispatch(
      await this.#send('POST', ORG_ROUTES.routineDispatch(id, routineId), input.eventId === undefined ? {} : { eventId: input.eventId }),
    );
  }

  /** Turns a routine's workflow on or off. Needs the `routineActions` feature. */
  async setRoutineEnabled(id: OrgWorkspaceId, routineId: string, enabled: boolean): Promise<{ enabled: boolean }> {
    this.#require('routineActions');
    this.#checkRoutine(id, routineId);
    return parseOrgRoutineEnabled(await this.#send('POST', ORG_ROUTES.routineEnabled(id, routineId), { enabled }));
  }

  /** Runs a routine that Marshal defines once in the cloud, as a dry run, from its inline definition. Needs the `routinePromote` feature. */
  async testRoutine(id: OrgWorkspaceId, routineId: string, definition: Record<string, unknown>): Promise<OrgRoutineTest> {
    this.#require('routinePromote');
    this.#checkDefinedRoutine(id, routineId, definition);
    return parseOrgRoutineTest(await this.#send('POST', ORG_ROUTES.routineTest(id), { id: routineId, definition }));
  }

  /** Opens the pull request that adds a routine that Marshal defines to the workspace's cloud routines. Needs the `routinePromote` feature. */
  async promoteRoutine(id: OrgWorkspaceId, routineId: string, definition: Record<string, unknown>): Promise<{ pullRequest: OrgRoutinePullRequest }> {
    this.#require('routinePromote');
    this.#checkDefinedRoutine(id, routineId, definition);
    return parseOrgRoutinePromotion(await this.#send('POST', ORG_ROUTES.routinePromote(id), { id: routineId, definition }));
  }

  #checkDefinedRoutine(id: OrgWorkspaceId, routineId: string, definition: Record<string, unknown>): void {
    if (!isOrgWorkspaceId(id)) throw new OrgContractError('invalid-request', 'id', 'must look like ws:<lowercase-name>');
    if (!ORG_DEFINED_ROUTINE_ID_PATTERN.test(routineId)) throw new OrgContractError('invalid-request', 'routineId', 'must be a routine id');
    if (typeof definition !== 'object' || definition === null || Array.isArray(definition)) throw new OrgContractError('invalid-request', 'definition', 'must be an object');
  }

  #checkRoutine(id: OrgWorkspaceId, routineId: string): void {
    if (!isOrgWorkspaceId(id)) throw new OrgContractError('invalid-request', 'id', 'must look like ws:<lowercase-name>');
    if (!/^[a-z0-9][a-z0-9._-]{0,94}$/.test(routineId)) throw new OrgContractError('invalid-request', 'routineId', 'must be a routine id');
  }

  async searchDirectory(input: { query: string; limit?: number }): Promise<DirectoryEntry[]> {
    this.#require('directory');
    const query = input.query.trim();
    if (query.length === 0 || query.length > 128) {
      throw new OrgContractError('invalid-request', 'query', 'must be 1 to 128 characters');
    }
    const limit = Math.min(Math.max(Math.trunc(input.limit ?? 10), 1), MAX_DIRECTORY_RESULTS);
    const params = new URLSearchParams({ q: query, limit: String(limit) });
    return parseDirectoryResults(await this.#get(`${ORG_ROUTES.directory}?${params.toString()}`));
  }

  /** The owner uploads or updates a session envelope. Returns the stored envelope. */
  async putSession(upload: OrgSessionUpload): Promise<OrgSessionEnvelope> {
    this.#require('sessions');
    const body = parseOrgSessionUpload(upload);
    const stored = parseOrgSessionEnvelope(await this.#send('PUT', ORG_ROUTES.session(body.id), body));
    if (stored.id !== body.id) throw new OrgContractError('invalid-response', 'session.id', 'does not match the requested id');
    return stored;
  }

  /**
   * The owner appends to or replaces the transcript, at most one bounded page per call. With `sharedTranscript` a collaborator or driver
   * may also append `user` and `assistant` messages (never replace), and the server stamps the caller as the author of every message
   * it stores; a `replace` by the owner answers 409 `conflict` once someone else's message is in the transcript. Message `id`s are sent
   * only to an organization that serves `sharedTranscript`.
   */
  async putTranscript(sessionId: string, write: OrgTranscriptWrite): Promise<OrgSessionTranscriptRef> {
    this.#require('sessions');
    requireSessionId(sessionId);
    const parsed = parseOrgTranscriptWrite(write);
    const body = this.supports('sharedTranscript') ? parsed : { ...parsed, messages: parsed.messages.map(({ id: _id, ...message }) => message) };
    return parseOrgTranscriptRefResponse(await this.#send('PUT', ORG_ROUTES.sessionTranscript(sessionId), body));
  }

  async listSessions(input: { workspace?: OrgWorkspaceId; limit?: number; cursor?: string; placement?: OrgSessionPlacement; owner?: 'me' } = {}): Promise<OrgSessionPage> {
    this.#require('sessions');
    const params = new URLSearchParams();
    if (input.workspace !== undefined) {
      if (!isOrgWorkspaceId(input.workspace)) throw new OrgContractError('invalid-request', 'workspace', 'must look like ws:<lowercase-name>');
      params.set('workspace', input.workspace);
    }
    if (input.placement !== undefined || input.owner !== undefined) {
      this.#require('cloudList');
      if (input.placement !== undefined) {
        if (!(SESSION_PLACEMENTS as readonly string[]).includes(input.placement)) throw new OrgContractError('invalid-request', 'placement', 'must be local or cloud');
        params.set('placement', input.placement);
      }
      if (input.placement !== undefined && input.owner !== 'me') throw new OrgContractError('invalid-request', 'placement', 'needs owner=me');
      if (input.owner !== undefined) {
        if (input.owner !== 'me') throw new OrgContractError('invalid-request', 'owner', 'must be me');
        params.set('owner', input.owner);
      }
    }
    params.set('limit', String(clampLimit(input.limit, DEFAULT_SESSION_PAGE, MAX_SESSION_PAGE)));
    if (input.cursor !== undefined) params.set('cursor', requireCursor(input.cursor));
    return parseOrgSessionPage(await this.#get(`${ORG_ROUTES.sessions}?${params.toString()}`));
  }

  async getSession(sessionId: string): Promise<OrgSessionView> {
    this.#require('sessions');
    requireSessionId(sessionId);
    const view = parseOrgSessionView(await this.#get(ORG_ROUTES.session(sessionId)));
    if (view.session.id !== sessionId) throw new OrgContractError('invalid-response', 'sessionView.session.id', 'does not match the requested id');
    return view;
  }

  /**
   * One page of the transcript. The `cursor` of a transcript is the decimal index of the next message: `String(n)` reads the messages
   * from index `n` on, and `nextCursor` is that index for the first message the page did not carry.
   */
  async getTranscript(sessionId: string, input: { cursor?: string; limit?: number } = {}): Promise<OrgTranscriptPage> {
    this.#require('sessions');
    requireSessionId(sessionId);
    const params = new URLSearchParams();
    if (input.cursor !== undefined) params.set('cursor', requireCursor(input.cursor));
    if (input.limit !== undefined) params.set('limit', String(clampLimit(input.limit, MAX_TRANSCRIPT_PAGE_MESSAGES, MAX_TRANSCRIPT_PAGE_MESSAGES)));
    const query = params.size > 0 ? `?${params.toString()}` : '';
    return parseOrgTranscriptPage(await this.#get(`${ORG_ROUTES.sessionTranscript(sessionId)}${query}`));
  }

  /** Whether the caller muted the session's notifications. Any role may ask. Needs the `multiUser` feature. */
  async getSessionMute(sessionId: string): Promise<{ muted: boolean }> {
    this.#requireMute(sessionId);
    return parseMuteState(await this.#get(ORG_ROUTES.sessionMute(sessionId)));
  }

  /** Mutes or unmutes the session's notifications for the caller only; the server then records none of the four multi-user kinds for them. Needs the `multiUser` feature. */
  async setSessionMute(sessionId: string, muted: boolean): Promise<{ muted: boolean }> {
    this.#requireMute(sessionId);
    if (typeof muted !== 'boolean') throw new OrgContractError('invalid-request', 'muted', 'must be a boolean');
    return parseMuteState(await this.#send('PUT', ORG_ROUTES.sessionMute(sessionId), { muted }));
  }

  /** Grants a role, optionally recording an @mention or sending a share notification. */
  async grantSession(sessionId: string, request: OrgGrantRequest): Promise<OrgGrantResult> {
    this.#require('sessions');
    requireSessionId(sessionId);
    const body = parseOrgGrantRequest(request);
    if (body.mention) this.#require('mentions');
    if (body.mention || body.notify) this.#require('notifications');
    return parseOrgGrantResult(await this.#send('POST', ORG_ROUTES.sessionGrants(sessionId), body));
  }

  async revokeSessionGrant(sessionId: string, principal: UserPrincipal): Promise<void> {
    this.#require('sessions');
    requireSessionId(sessionId);
    parseOrgGrantRequest({ principal, role: 'viewer' });
    await this.#send('DELETE', ORG_ROUTES.sessionGrant(sessionId, principal));
  }

  async listNotifications(input: { unread?: boolean; limit?: number; cursor?: string } = {}): Promise<OrgNotificationPage> {
    this.#require('notifications');
    const params = new URLSearchParams();
    if (input.unread !== undefined) params.set('unread', String(input.unread));
    params.set('limit', String(clampLimit(input.limit, DEFAULT_SESSION_PAGE, MAX_NOTIFICATIONS_PAGE)));
    if (input.cursor !== undefined) params.set('cursor', requireCursor(input.cursor));
    return parseOrgNotificationPage(await this.#get(`${ORG_ROUTES.notifications}?${params.toString()}`), {
      onUnknownKind: (kind) => {
        try {
          this.#onDebug?.(`skipped a notification of unknown kind ${JSON.stringify(kind)}`);
        } catch {
          // a failing debug hook must not turn a tolerated entry into an error
        }
      },
    });
  }

  async markNotificationRead(id: string): Promise<OrgNotification> {
    this.#require('notifications');
    if (!isNotificationId(id)) throw new OrgContractError('invalid-request', 'id', 'must be a notification id');
    const notification = parseOrgNotification(await this.#send('POST', ORG_ROUTES.notificationRead(id)));
    if (notification.id !== id) throw new OrgContractError('invalid-response', 'notification.id', 'does not match the requested id');
    return notification;
  }

  /** Who drives the session now. Any role on the session may read it. */
  async getLease(sessionId: string): Promise<OrgLeaseView> {
    this.#requireLeases(sessionId);
    return parseOrgLeaseView(await this.#get(ORG_ROUTES.sessionLease(sessionId)), 'lease');
  }

  /** Takes a free or expired lease. A held lease throws `OrgApiError` 409 `lease-held` with `leaseHeld`; `force` is owner only. */
  async acquireLease(sessionId: string, request: OrgLeaseAcquireRequest): Promise<OrgLeaseView> {
    this.#requireLeases(sessionId);
    const body = parseOrgLeaseAcquireRequest(request);
    return parseOrgLeaseView(await this.#send('POST', ORG_ROUTES.sessionLease(sessionId), body), 'lease');
  }

  /** Renews the lease. 410 `lease-lost` means this host no longer holds it and must stop driving. */
  async heartbeatLease(sessionId: string, host: string): Promise<OrgLeaseView> {
    this.#requireLeases(sessionId);
    const body = parseOrgLeaseHeartbeatRequest({ host });
    return parseOrgLeaseView(await this.#send('POST', ORG_ROUTES.sessionLeaseHeartbeat(sessionId), body), 'lease');
  }

  /** The holder gives the lease up at a safe point, optionally leaving a checkpoint for the next host. */
  async releaseLease(sessionId: string, request: OrgLeaseReleaseRequest): Promise<OrgLeaseView> {
    this.#requireLeases(sessionId);
    const body = parseOrgLeaseReleaseRequest(request);
    return parseOrgLeaseView(await this.#send('POST', ORG_ROUTES.sessionLeaseRelease(sessionId), body), 'lease');
  }

  /** Asks the holder to release at its next safe point. The holder also gets a `handover-request` notification when the organization serves notifications. */
  async requestLeaseHandover(sessionId: string, request: OrgLeaseHandoverRequest): Promise<OrgLeaseView> {
    this.#requireLeases(sessionId);
    const body = parseOrgLeaseHandoverRequest(request);
    return parseOrgLeaseView(await this.#send('POST', ORG_ROUTES.sessionLeaseHandover(sessionId), body), 'lease');
  }

  /** What the cloud host can resume from and whether it is taking runs. */
  async getCloudCapabilities(): Promise<OrgCloudCapabilities> {
    this.#require('cloudRuns');
    return parseOrgCloudCapabilities(await this.#get(ORG_ROUTES.cloudCapabilities));
  }

  /** The lease holder uploads the native envelope (gzip bytes). Streams are never buffered. */
  async putEnvelope(sessionId: string, upload: OrgEnvelopeUpload): Promise<OrgEnvelopeInfo> {
    this.#requireCloud(sessionId);
    if (!isEnvelopeFormat(upload.format)) throw new OrgContractError('invalid-request', 'format', 'must be a lowercase format id');
    if (!isSha256Hex(upload.sha256)) throw new OrgContractError('invalid-request', 'sha256', 'must be 64 lowercase hex characters');
    if (!Number.isInteger(upload.bytes) || upload.bytes < 1 || upload.bytes > MAX_ENVELOPE_BYTES_CEILING) {
      throw new OrgContractError('invalid-request', 'bytes', `must be an integer from 1 to ${MAX_ENVELOPE_BYTES_CEILING}`);
    }
    if (!Number.isInteger(upload.messageCount) || upload.messageCount < 0) throw new OrgContractError('invalid-request', 'messageCount', 'must be a non-negative integer');
    const body = boundedBody(upload.body, upload.bytes);
    const token = await this.#accessToken();
    const headers = {
      authorization: `Bearer ${token}`,
      'content-type': ENVELOPE_CONTENT_TYPE,
      'content-length': String(upload.bytes),
      [ENVELOPE_HEADERS.host]: upload.host,
      [ENVELOPE_HEADERS.format]: upload.format,
      [ENVELOPE_HEADERS.sha256]: upload.sha256,
      [ENVELOPE_HEADERS.messages]: String(upload.messageCount),
    };
    const url = `${this.discovery.apiBase.replace(/\/+$/, '')}${ORG_ROUTES.sessionEnvelope(sessionId)}`;
    return parseOrgEnvelopeInfo(await requestJson(url, 'PUT', headers, body, this.#fetch, this.#transferTimeoutMs));
  }

  /** Metadata of the stored envelope; 409 `no-envelope` when none was uploaded. Needs a role on the session. */
  async getEnvelopeInfo(sessionId: string): Promise<OrgEnvelopeInfo> {
    this.#requireCloud(sessionId);
    return parseOrgEnvelopeInfo(await this.#get(ORG_ROUTES.sessionEnvelopeInfo(sessionId)));
  }

  /** The lease holder downloads the envelope as a verified stream. Acquire the lease first. */
  async getEnvelope(sessionId: string, input: { host: string; maxBytes?: number }): Promise<OrgEnvelopeDownload> {
    this.#requireCloud(sessionId);
    return this.#downloadEnvelope(ORG_ROUTES.sessionEnvelope(sessionId), { [ENVELOPE_HEADERS.host]: input.host }, input.maxBytes);
  }

  /**
   * Forks the session from its last completed checkpoint into a new session the caller owns: the transcript the checkpointed envelope covers
   * and a copy of that envelope. The source keeps running and nobody's lease changes; no grant is copied. Needs a `driver` or `owner` role on
   * the source (403 otherwise), and answers 409 `no-checkpoint` while the session has no completed checkpoint (never from the middle of a turn)
   * The server names the fork (the request carries no id for it). A `clientForkId` already used by the caller on another source answers 409 `conflict`. The same `clientForkId` returns the fork already made, so reuse it when retrying. Needs the `forks` feature.
   */
  async forkSession(sessionId: string, request: OrgForkRequest): Promise<OrgForkResult> {
    this.#requireForks(sessionId);
    return parseOrgForkResult(await this.#send('POST', ORG_ROUTES.sessionFork(sessionId), parseOrgForkRequest(request)));
  }

  /** The envelope a fork started from, as a verified stream, for the fork's owner and without a lease; 409 `no-envelope` once the fork's own state has replaced it. Needs the `forks` feature. */
  async getForkEnvelope(sessionId: string, input: { maxBytes?: number } = {}): Promise<OrgEnvelopeDownload> {
    this.#requireForks(sessionId);
    return this.#downloadEnvelope(ORG_ROUTES.sessionFork(sessionId), {}, input.maxBytes);
  }

  async #downloadEnvelope(route: string, extraHeaders: Record<string, string>, requestedMax: number | undefined): Promise<OrgEnvelopeDownload> {
    const maxBytes = Math.min(requestedMax ?? MAX_ENVELOPE_BYTES_CEILING, MAX_ENVELOPE_BYTES_CEILING);
    const token = await this.#accessToken();
    const url = `${this.discovery.apiBase.replace(/\/+$/, '')}${route}`;
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), this.#transferTimeoutMs);
    let response: Response;
    try {
      response = await this.#fetch(url, {
        method: 'GET',
        headers: { accept: ENVELOPE_CONTENT_TYPE, authorization: `Bearer ${token}`, ...extraHeaders },
        signal: controller.signal,
      });
    } catch {
      clearTimeout(timer);
      throw new OrgApiError(0, controller.signal.aborted ? 'timeout' : 'unreachable', `request to ${new URL(url).origin} failed`);
    }
    if (!response.ok) {
      clearTimeout(timer);
      throw await apiErrorFrom(response);
    }
    const format = response.headers.get(ENVELOPE_HEADERS.format) ?? '';
    const sha256 = response.headers.get(ENVELOPE_HEADERS.sha256) ?? '';
    const messages = Number(response.headers.get(ENVELOPE_HEADERS.messages));
    const bytes = Number(response.headers.get('content-length'));
    if (!isEnvelopeFormat(format) || !isSha256Hex(sha256) || !Number.isInteger(messages) || messages < 0 || !Number.isInteger(bytes) || bytes < 1 || !response.body) {
      clearTimeout(timer);
      await response.body?.cancel().catch(() => undefined);
      throw new OrgContractError('invalid-response', 'envelope', 'headers or body are missing or malformed');
    }
    if (bytes > maxBytes) {
      clearTimeout(timer);
      await response.body.cancel().catch(() => undefined);
      throw new OrgApiError(413, 'envelope-too-large', 'envelope exceeds the size the caller accepts');
    }
    return { envelope: { format, sha256, bytes, messageCount: messages }, body: verifiedBody(response.body, { sha256, bytes }, timer, controller) };
  }

  /** The lease holder uploads the git bundle of one mount (`git bundle create <base>..<wip>`). Streams are never buffered. Needs the `placement` feature. */
  async putMountBundle(sessionId: string, mountId: string, upload: OrgMountBundleUpload): Promise<OrgMountBundleInfo> {
    this.#requireCloud(sessionId);
    this.#require('placement');
    if (!isMountId(mountId)) throw new OrgContractError('invalid-request', 'mountId', 'must look like m1');
    if (!isSha256Hex(upload.sha256)) throw new OrgContractError('invalid-request', 'sha256', 'must be 64 lowercase hex characters');
    if (!Number.isInteger(upload.bytes) || upload.bytes < 1 || upload.bytes > MAX_BUNDLE_BYTES_CEILING) {
      throw new OrgContractError('invalid-request', 'bytes', `must be an integer from 1 to ${MAX_BUNDLE_BYTES_CEILING}`);
    }
    const body = boundedBody(upload.body, upload.bytes);
    const token = await this.#accessToken();
    const headers = {
      authorization: `Bearer ${token}`,
      'content-type': BUNDLE_CONTENT_TYPE,
      'content-length': String(upload.bytes),
      [BUNDLE_HEADERS.host]: upload.host,
      [BUNDLE_HEADERS.sha256]: upload.sha256,
    };
    const url = `${this.discovery.apiBase.replace(/\/+$/, '')}${ORG_ROUTES.sessionMountBundle(sessionId, mountId)}`;
    return parseOrgMountBundleInfo(await requestJson(url, 'PUT', headers, body, this.#fetch, this.#transferTimeoutMs));
  }

  /** The manifest the latest cloud run started with (with the organization's `wip.object`), or null. The owner or a driver may read it. */
  async getPlacement(sessionId: string): Promise<OrgPlacementView> {
    this.#requireCloud(sessionId);
    this.#require('placement');
    return parseOrgPlacementView(await this.#get(ORG_ROUTES.sessionPlacement(sessionId)));
  }

  /** The lease holder hands the lease to the cloud host and starts a run from the uploaded envelope (and the uploaded bundles of `request.placement`). */
  async moveToCloud(sessionId: string, request: OrgCloudRunRequest): Promise<OrgCloudRunStarted> {
    this.#requireCloud(sessionId);
    if (request.placement !== undefined) this.#require('placement');
    const body = parseOrgCloudRunRequest(request);
    return parseOrgCloudRunStarted(await this.#send('POST', ORG_ROUTES.sessionCloudRuns(sessionId), body));
  }

  /** The latest cloud run of the session, or null. Any role on the session may read it. */
  async getCloudRun(sessionId: string): Promise<OrgCloudRunView> {
    this.#requireCloud(sessionId);
    return parseOrgCloudRunView(await this.#get(ORG_ROUTES.sessionCloudRun(sessionId)));
  }

  /**
   * Opens the session's change feed: content-free `ping` events (`version`, `kinds`) and a final `end`. The first ping names every kind unless
   * `after` is the current version; a ping means "fetch again", never carries content. A stream lasts at most a few minutes (`end` with reason `cap`):
   * reconnect with the last version. Needs `sessions` and `sessionWatch`; 404 means no role, 429 `too-many-watches` means the server holds as many streams for this person as it allows.
   */
  async *watchSession(sessionId: string, input: { after?: string; signal?: AbortSignal } = {}): AsyncGenerator<OrgWatchEvent> {
    this.#require('sessions');
    this.#require('sessionWatch');
    requireSessionId(sessionId);
    if (input.after !== undefined && !isWatchVersion(input.after)) throw new OrgContractError('invalid-request', 'after', 'must be a watch version');
    const token = await this.#accessToken();
    const query = input.after === undefined ? '' : `?after=${input.after}`;
    const url = `${this.discovery.apiBase.replace(/\/+$/, '')}${ORG_ROUTES.sessionWatch(sessionId)}${query}`;
    let response: Response;
    try {
      response = await this.#fetch(url, {
        method: 'GET',
        headers: { accept: WATCH_CONTENT_TYPE, authorization: `Bearer ${token}` },
        ...(input.signal ? { signal: input.signal } : {}),
      });
    } catch {
      throw new OrgApiError(0, input.signal?.aborted ? 'aborted' : 'unreachable', `request to ${new URL(url).origin} failed`);
    }
    if (!response.ok) throw await apiErrorFrom(response);
    if (!(response.headers.get('content-type') ?? '').startsWith(WATCH_CONTENT_TYPE) || !response.body) {
      await response.body?.cancel().catch(() => undefined);
      throw new OrgContractError('invalid-response', 'watch', 'answer is not an event stream');
    }
    try {
      yield* readWatchEvents(response.body);
    } catch (failure) {
      if (input.signal?.aborted) return;
      if (failure instanceof OrgContractError) throw failure;
      throw new OrgApiError(0, 'unreachable', 'the event stream broke');
    }
  }

  /**
   * Yields one event whenever the session may have changed, forever, until `signal` aborts. It streams when the server offers `sessionWatch`,
   * reconnects by version after a cap or a drop, and otherwise (feature absent, 404, 429, network error) yields a synthetic `polled` event every
   * `pollMs` so the caller fetches on a timer. A 429 (the server's stream limit for this person) is not a failure: it keeps that `pollMs` cadence and tries the stream again each time; other
   * failures back off from `retryMs` up to 60 s. The caller treats both kinds the same: fetch, then wait for the next event.
   */
  async *followSession(sessionId: string, input: { signal?: AbortSignal; pollMs?: number; retryMs?: number } = {}): AsyncGenerator<OrgFollowEvent> {
    requireSessionId(sessionId);
    const pollMs = Math.max(input.pollMs ?? DEFAULT_WATCH_POLL_MS, 1);
    const retryMs = Math.min(Math.max(input.retryMs ?? MIN_WATCH_RETRY_MS, 1), MAX_WATCH_RETRY_MS);
    let after: string | undefined;
    let version: string | null = null;
    let failures = 0;
    let refused = false;
    while (!input.signal?.aborted) {
      if (!this.supports('sessions') || !this.supports('sessionWatch') || failures > 0 || refused) {
        await sleepUnlessAborted(failures > 0 && !refused ? Math.min(retryMs * 2 ** (failures - 1), MAX_WATCH_RETRY_MS) : pollMs, input.signal);
        if (input.signal?.aborted) return;
        if (!this.supports('sessionWatch')) {
          yield { version: null, kinds: [...WATCH_KINDS], polled: true };
          continue;
        }
        if (failures > 0 || refused) yield { version, kinds: [...WATCH_KINDS], polled: true };
      }
      try {
        refused = false;
        let ended = false;
        const openedAt = Date.now();
        for await (const event of this.watchSession(sessionId, { ...(after ? { after } : {}), ...(input.signal ? { signal: input.signal } : {}) })) {
          if (event.type === 'end') {
            ended = true;
            if (event.reason !== 'cap') failures = 1;
            break;
          }
          after = event.version;
          version = event.version;
          failures = 0;
          yield { version: event.version, kinds: event.kinds, polled: false };
        }
        if (!ended && failures === 0) failures = 1;
        if (failures === 0) await sleepUnlessAborted(retryMs - (Date.now() - openedAt), input.signal);
      } catch (failure) {
        if (input.signal?.aborted) return;
        if (failure instanceof OrgApiError && failure.status === 429) {
          refused = true;
          failures = 0;
        } else failures += 1;
      }
    }
  }

  /**
   * Posts a message to the session's inbox; a cloud executor runs it. Posting the same `clientMsgId` again returns the stored message, so a retry is safe.
   * A collaborator's message is `held` until the owner runs it; a viewer gets 403. A full queue answers 429 `queue-full`, a text over 64 KiB 413 `too-large`.
   * `source` says which client wrote it; the server records anything but `desktop` or `web` as `api`. Needs the `messages` feature.
   */
  async postMessage(sessionId: string, request: OrgPostMessageRequest, source?: (typeof CLIENT_MESSAGE_SOURCES)[number]): Promise<OrgPostedMessage> {
    this.#requireMessages(sessionId);
    const body = parseOrgPostMessageRequest(request);
    if (body.kind === 'comment') this.#require('multiUser');
    const headers = source === undefined ? undefined : { [MESSAGE_SOURCE_HEADER]: requireMessageSource(source) };
    return parseOrgPostedMessage(await this.#send('POST', ORG_ROUTES.sessionMessages(sessionId), body, headers));
  }

  /** Lists the session's inbox after `after` (a message `seq`, default 0), oldest first, with how the executor is doing. The owner sees every message, anyone else their own. */
  async listMessages(sessionId: string, input: { after?: number; limit?: number } = {}): Promise<OrgSessionMessagePage> {
    this.#requireMessages(sessionId);
    const params = new URLSearchParams();
    const after = input.after ?? 0;
    if (!Number.isInteger(after) || after < 0) throw new OrgContractError('invalid-request', 'after', 'must be a message seq');
    params.set('after', String(after));
    params.set('limit', String(clampLimit(input.limit, DEFAULT_MESSAGE_LIST, MAX_MESSAGE_LIST)));
    return parseOrgSessionMessagePage(await this.#get(`${ORG_ROUTES.sessionMessages(sessionId)}?${params.toString()}`));
  }

  /** Cancels a `queued` or `held` message; its author or the owner may. Any other status answers 409 `conflict`. */
  async cancelMessage(sessionId: string, messageId: string): Promise<OrgSessionMessage> {
    this.#requireMessages(sessionId);
    requireMessageId(messageId);
    return parseOrgSessionMessage(await this.#send('DELETE', ORG_ROUTES.sessionMessage(sessionId, messageId)));
  }

  /** The owner runs a `held` message: it becomes a new queued owner message that quotes it, written under `clientMsgId`. */
  async runHeldMessage(sessionId: string, messageId: string, request: OrgRunHeldMessageRequest): Promise<OrgPostedMessage> {
    this.#requireMessages(sessionId);
    requireMessageId(messageId);
    const body = parseOrgRunHeldMessageRequest(request);
    return parseOrgPostedMessage(await this.#send('POST', ORG_ROUTES.sessionMessageRun(sessionId, messageId), body));
  }

  /** Whether the owner turned live collaboration on for the session (any role may read it). Needs `liveSessions`. */
  async getSessionLive(sessionId: string): Promise<OrgSessionLive> {
    this.#requireLive(sessionId);
    return parseOrgSessionLive(await this.#get(ORG_ROUTES.sessionLive(sessionId)));
  }

  /**
   * The owner turns live collaboration on or off (anyone else gets 403 `forbidden`). On (with the executor `host`): collaborators' and
   * drivers' instructions to a session that is not in the cloud are queued for that desktop, at most `participantTurnsPerDay` per author
   * (default 20). Off: their queued instructions go back to `held`.
   */
  async setSessionLive(sessionId: string, request: OrgSessionLiveRequest): Promise<OrgSessionLive> {
    this.#requireLive(sessionId);
    const body = parseOrgSessionLiveRequest(request);
    return parseOrgSessionLive(await this.#send('PUT', ORG_ROUTES.sessionLive(sessionId), body));
  }

  /**
   * The lease holder `host` takes up to `max` queued messages, oldest first. For a live session held by its owner's desktop this
   * covers every author; a message whose author lost the collaborator role is rejected instead of returned. 410 `lease-lost` when
   * `host` does not hold the lease.
   */
  async claimMessages(sessionId: string, request: OrgClaimMessagesRequest): Promise<OrgClaimedMessages> {
    this.#requireLive(sessionId);
    const body = parseOrgClaimMessagesRequest(request);
    return parseOrgClaimedMessages(await this.#send('POST', ORG_ROUTES.sessionMessagesClaim(sessionId), body));
  }

  /** The lease holder `host` marks the messages it claimed `done` once the turn `turnId` that ran them ended. */
  async completeMessages(sessionId: string, request: OrgCompleteMessagesRequest): Promise<OrgCompletedMessages> {
    this.#requireLive(sessionId);
    const body = parseOrgCompleteMessagesRequest(request);
    return parseOrgCompletedMessages(await this.#send('POST', ORG_ROUTES.sessionMessagesDone(sessionId), body));
  }

  /**
   * The caller's own live sessions that have queued instructions, oldest waiting first. Asking also tells the server that this
   * desktop (`host`) is online; ask again after `pollSeconds`.
   */
  async listLivePending(input: { host: string }): Promise<OrgLivePending> {
    this.#require('sessions');
    this.#require('messages');
    this.#require('liveSessions');
    if (!isLeaseHostId(input.host)) throw new OrgContractError('invalid-request', 'host', 'must be a lease host id');
    const params = new URLSearchParams({ host: input.host });
    return parseOrgLivePending(await this.#get(`${ORG_ROUTES.livePending}?${params.toString()}`));
  }

  /** Searches the run index. Without auditor rights the server returns only the caller's own runs. Needs the `runIndex` feature. */
  async listRuns(query: OrgRunQuery = {}): Promise<OrgRunPage> {
    this.#require('runIndex');
    const params = orgRunQueryParams({ ...query, limit: clampLimit(query.limit, 50, MAX_RUN_PAGE) });
    return parseOrgRunPage(await this.#get(`${ORG_ROUTES.runs}?${params.toString()}`));
  }

  async getRun(runId: string): Promise<OrgRunDetail> {
    this.#require('runIndex');
    requireRunId(runId);
    const detail = parseOrgRunDetail(await this.#get(ORG_ROUTES.run(runId)));
    if (detail.run.id !== runId) throw new OrgContractError('invalid-response', 'runDetail.run.id', 'does not match the requested id');
    return detail;
  }

  async getRunEvents(runId: string, query: OrgRunEventsQuery = {}): Promise<OrgRunEventPage> {
    this.#require('runIndex');
    requireRunId(runId);
    const params = new URLSearchParams();
    if (query.type !== undefined) params.set('type', query.type);
    if (query.after !== undefined) params.set('after', String(Math.max(Math.trunc(query.after), 0)));
    if (query.limit !== undefined) params.set('limit', String(clampLimit(query.limit, 200, 200)));
    const suffix = params.size > 0 ? `?${params.toString()}` : '';
    return parseOrgRunEventPage(await this.#get(`${ORG_ROUTES.runEvents(runId)}${suffix}`));
  }

  /** One page of a session's messages, tool steps included, each clipped by the server. */
  async getRunMessages(runId: string, session: string, query: OrgRunMessagesQuery = {}): Promise<OrgRunMessagesPage> {
    this.#require('runIndex');
    requireRunId(runId);
    requireRunSession(session);
    const params = new URLSearchParams();
    if (query.from !== undefined) params.set('from', String(Math.max(Math.trunc(query.from), 0)));
    if (query.limit !== undefined) params.set('limit', String(clampLimit(query.limit, 200, 200)));
    const suffix = params.size > 0 ? `?${params.toString()}` : '';
    return parseOrgRunMessagesPage(await this.#get(`${ORG_ROUTES.runMessages(runId, session)}${suffix}`));
  }

  /** The native transcript of one session of a run, gzipped, verified against its size and sha256. At most `maxBytes` (default 24 MiB). Full readers only; needs the `runEnvelopes` feature. */
  async getRunEnvelope(runId: string, session: string, input: { maxBytes?: number } = {}): Promise<OrgRunEnvelope> {
    this.#require('runEnvelopes');
    requireRunId(runId);
    requireRunSession(session);
    return this.#downloadRunEnvelope(ORG_ROUTES.runEnvelope(runId, session), input.maxBytes);
  }

  /** The ids of the subagents one session of a run started, whose native transcripts `getRunSubagentEnvelope` serves. Full readers only; needs the `runEnvelopes` feature. */
  async listRunSubagents(runId: string, session: string): Promise<string[]> {
    this.#require('runEnvelopes');
    requireRunId(runId);
    requireRunSession(session);
    return parseRunSubagents(await this.#get(ORG_ROUTES.runSubagents(runId, session)));
  }

  /** The native transcript of one subagent of a run session, gzipped and verified like `getRunEnvelope`. Needs the `runEnvelopes` feature. */
  async getRunSubagentEnvelope(runId: string, session: string, agent: string, input: { maxBytes?: number } = {}): Promise<OrgRunEnvelope> {
    this.#require('runEnvelopes');
    requireRunId(runId);
    requireRunSession(session);
    requireSubagentId(agent);
    return this.#downloadRunEnvelope(ORG_ROUTES.runSubagent(runId, session, agent), input.maxBytes);
  }

  async #downloadRunEnvelope(route: string, requestedMax: number | undefined): Promise<OrgRunEnvelope> {
    const maxBytes = Math.min(requestedMax ?? MAX_RUN_ENVELOPE_BYTES, MAX_RUN_ENVELOPE_BYTES);
    const download = await this.#downloadEnvelope(route, {}, maxBytes);
    return { envelope: download.envelope, body: await collectEnvelope(download.body, maxBytes) };
  }

  /** A literal search over the transcripts of at most 20 runs. Every grep is audited. */
  async grepRuns(request: OrgRunGrepRequest): Promise<OrgRunGrepResult> {
    this.#require('runIndex');
    const body = parseOrgRunGrepRequest(request);
    return parseOrgRunGrepResult(await this.#send('POST', ORG_ROUTES.runsGrep, body));
  }

  /** Who read what: `target: 'me'` lists reads of the caller's own runs and the caller's own reads; `run:<id>` needs access to that run. */
  async listAudit(query: OrgAuditQuery): Promise<OrgAuditPage> {
    this.#require('runIndex');
    const runId = auditTargetRunId(query.target);
    if (query.target !== 'me' && runId === undefined) throw new OrgContractError('invalid-request', 'target', 'must be me or run:<id>');
    const params = new URLSearchParams({ target: query.target });
    if (query.actor !== undefined) params.set('actor', query.actor);
    if (query.since !== undefined) params.set('since', query.since);
    if (query.limit !== undefined) params.set('limit', String(clampLimit(query.limit, 50, 100)));
    if (query.cursor !== undefined) params.set('cursor', requireCursor(query.cursor));
    return parseOrgAuditPage(await this.#get(`${ORG_ROUTES.audit}?${params.toString()}`));
  }

  #requireCloud(sessionId: string): void {
    this.#requireLeases(sessionId);
    this.#require('cloudRuns');
  }

  #requireMute(sessionId: string): void {
    this.#require('sessions');
    this.#require('multiUser');
    requireSessionId(sessionId);
  }

  #requireMessages(sessionId: string): void {
    this.#require('sessions');
    this.#require('messages');
    requireSessionId(sessionId);
  }

  #requireLive(sessionId: string): void {
    this.#requireMessages(sessionId);
    this.#require('liveSessions');
  }

  #requireForks(sessionId: string): void {
    this.#requireCloud(sessionId);
    this.#require('forks');
  }

  #requireLeases(sessionId: string): void {
    this.#require('sessions');
    this.#require('leases');
    requireSessionId(sessionId);
  }

  #requireSameOriginArchives(entries: { delivery: { kind: string; url?: string } }[], path: string): void {
    const origin = new URL(this.discovery.apiBase).origin;
    entries.forEach((extension, index) => {
      if (extension.delivery.kind === 'archive' && new URL(extension.delivery.url ?? '').origin !== origin) {
        throw new OrgContractError('invalid-response', `${path}[${index}].delivery.url`, 'must be on the same origin as the organization API');
      }
    });
  }

  #require(feature: OrgFeature): void {
    if (!this.supports(feature)) throw new OrgFeatureUnavailableError(feature);
  }

  async #get(route: string): Promise<unknown> {
    return this.#send('GET', route);
  }

  async #send(method: 'GET' | 'PUT' | 'POST' | 'DELETE', route: string, body?: unknown, headers: Record<string, string> = {}): Promise<unknown> {
    const token = await this.#accessToken();
    const url = `${this.discovery.apiBase.replace(/\/+$/, '')}${route}`;
    let payload: string | undefined;
    if (body !== undefined) {
      payload = JSON.stringify(body);
      if (new TextEncoder().encode(payload).length > MAX_REQUEST_BYTES) {
        throw new OrgContractError('invalid-request', 'body', 'exceeds 2 MiB');
      }
    }
    return requestJson(url, method, { ...headers, authorization: `Bearer ${token}` }, payload, this.#fetch, this.#timeoutMs);
  }
}

function parseMuteState(value: unknown): { muted: boolean } {
  const root = readObject({ code: 'invalid-response' }, value, 'mute');
  if (typeof root.muted !== 'boolean') throw new OrgContractError('invalid-response', 'mute.muted', 'must be a boolean');
  return { muted: root.muted };
}

function requireSessionId(value: string): void {
  if (!isSessionId(value)) throw new OrgContractError('invalid-request', 'sessionId', 'must be 1 to 128 letters, digits, dot, dash or underscore');
}

function requireMessageId(value: string): void {
  if (!isMessageId(value)) throw new OrgContractError('invalid-request', 'messageId', 'must be a message id');
}

function requireMessageSource(value: string): string {
  if (!(CLIENT_MESSAGE_SOURCES as readonly string[]).includes(value)) throw new OrgContractError('invalid-request', 'source', 'must be desktop or web');
  return value;
}

function requireRunId(value: string): void {
  if (!isRunId(value)) throw new OrgContractError('invalid-request', 'runId', 'must be a run id');
}

function requireSubagentId(value: string): void {
  if (!isRunSubagentId(value)) throw new OrgContractError('invalid-request', 'agent', 'must be a subagent id');
}

function parseRunSubagents(value: unknown): string[] {
  const agents = typeof value === 'object' && value !== null ? (value as { agents?: unknown }).agents : undefined;
  if (!Array.isArray(agents) || agents.length > MAX_RUN_SUBAGENTS || !agents.every(isRunSubagentId)) {
    throw new OrgContractError('invalid-response', 'agents', 'must be a list of subagent ids');
  }
  return [...agents];
}

function requireRunSession(value: string): void {
  if (!isRunSessionName(value)) throw new OrgContractError('invalid-request', 'session', 'must be a session name');
}

function requireCursor(value: string): string {
  if (value.length < 1 || value.length > MAX_CURSOR) throw new OrgContractError('invalid-request', 'cursor', `must be 1 to ${MAX_CURSOR} characters`);
  return value;
}

function sleepUnlessAborted(ms: number, signal?: AbortSignal): Promise<void> {
  return new Promise((resolve) => {
    if (signal?.aborted) return resolve();
    const timer = setTimeout(done, ms);
    function done(): void {
      clearTimeout(timer);
      signal?.removeEventListener('abort', done);
      resolve();
    }
    signal?.addEventListener('abort', done, { once: true });
  });
}

function clampLimit(value: number | undefined, fallback: number, max: number): number {
  return Math.min(Math.max(Math.trunc(value ?? fallback), 1), max);
}

function getJson(url: string, headers: Record<string, string>, fetchImpl: FetchLike, timeoutMs: number): Promise<unknown> {
  return requestJson(url, 'GET', headers, undefined, fetchImpl, timeoutMs);
}

async function requestJson(
  url: string,
  method: string,
  headers: Record<string, string>,
  payload: string | Uint8Array | ReadableStream<Uint8Array> | undefined,
  fetchImpl: FetchLike,
  timeoutMs: number,
): Promise<unknown> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  let response: Response;
  try {
    response = await fetchImpl(url, {
      method,
      headers: { accept: 'application/json', ...(payload === undefined ? {} : { 'content-type': 'application/json' }), ...headers },
      ...(payload === undefined ? {} : { body: payload as never }),
      ...(payload !== undefined && typeof payload !== 'string' && !(payload instanceof Uint8Array) ? { duplex: 'half' } : {}),
      signal: controller.signal,
    });
  } catch (error) {
    throw new OrgApiError(0, controller.signal.aborted ? 'timeout' : 'unreachable', `request to ${new URL(url).origin} failed`);
  } finally {
    clearTimeout(timer);
  }
  const text = await response.text();
  if (text.length > MAX_RESPONSE_BYTES) throw new OrgApiError(response.status, 'response-too-large', 'response exceeds 2 MiB');
  let body: unknown;
  try {
    body = text.length ? JSON.parse(text) : undefined;
  } catch {
    throw new OrgApiError(response.status, 'invalid-json', 'response is not JSON');
  }
  if (!response.ok) throw errorFrom(response.status, body);
  return body;
}

function errorFrom(status: number, body: unknown): OrgApiError {
  const code =
    typeof body === 'object' && body !== null && typeof (body as { error?: unknown }).error === 'string'
      ? (body as { error: string }).error.slice(0, 64)
      : `http-${status}`;
  let leaseHeld: OrgLeaseHeld | undefined;
  if (code === 'lease-held') {
    try {
      leaseHeld = parseOrgLeaseHeld(body);
    } catch {
      leaseHeld = undefined;
    }
  }
  const record = typeof body === 'object' && body !== null ? (body as Record<string, unknown>) : {};
  const problem = typeof record.problem === 'string' ? record.problem.slice(0, 300) : undefined;
  let pullRequest: OrgRoutinePullRequest | undefined;
  if (code === 'routine-exists' && record.pullRequest !== undefined) {
    try {
      pullRequest = parseOrgRoutinePullRequest(record.pullRequest, 'pullRequest');
    } catch {
      pullRequest = undefined;
    }
  }
  return new OrgApiError(status, code, `organization API answered ${status}`, leaseHeld, { ...(problem ? { problem } : {}), ...(pullRequest ? { pullRequest } : {}) });
}

async function apiErrorFrom(response: Response): Promise<OrgApiError> {
  let body: unknown;
  try {
    const text = await response.text();
    body = text.length && text.length <= MAX_RESPONSE_BYTES ? JSON.parse(text) : undefined;
  } catch {
    body = undefined;
  }
  return errorFrom(response.status, body);
}

/** Wraps an upload body so it can never send more or fewer bytes than declared. */
function boundedBody(body: EnvelopeBody, expected: number): Uint8Array | ReadableStream<Uint8Array> {
  if (body instanceof Uint8Array) {
    if (body.length !== expected) throw new OrgContractError('invalid-request', 'body', 'length differs from the declared bytes');
    return body;
  }
  const iterator: AsyncIterator<Uint8Array> =
    typeof (body as AsyncIterable<Uint8Array>)[Symbol.asyncIterator] === 'function'
      ? (body as AsyncIterable<Uint8Array>)[Symbol.asyncIterator]()
      : (async function* (reader: ReadableStreamDefaultReader<Uint8Array>) {
          for (;;) {
            const next = await reader.read();
            if (next.done) return;
            yield next.value;
          }
        })((body as ReadableStream<Uint8Array>).getReader());
  let sent = 0;
  return new ReadableStream<Uint8Array>({
    async pull(controller) {
      const next = await iterator.next();
      if (next.done) {
        if (sent !== expected) controller.error(new OrgContractError('invalid-request', 'body', 'length differs from the declared bytes'));
        else controller.close();
        return;
      }
      sent += next.value.length;
      if (sent > expected) {
        controller.error(new OrgContractError('invalid-request', 'body', 'length differs from the declared bytes'));
        return;
      }
      controller.enqueue(next.value);
    },
    async cancel() {
      await iterator.return?.();
    },
  });
}

function verifiedBody(
  source: ReadableStream<Uint8Array>,
  expected: { sha256: string; bytes: number },
  timer: ReturnType<typeof setTimeout>,
  controller: AbortController,
): ReadableStream<Uint8Array> {
  const reader = source.getReader();
  const hash = createHash('sha256');
  let seen = 0;
  const finish = () => clearTimeout(timer);
  return new ReadableStream<Uint8Array>({
    async pull(out) {
      try {
        const next = await reader.read();
        if (next.done) {
          finish();
          if (seen !== expected.bytes || hash.digest('hex') !== expected.sha256) {
            out.error(new OrgContractError('invalid-response', 'envelope', 'bytes do not match the declared size and sha256'));
          } else {
            out.close();
          }
          return;
        }
        seen += next.value.length;
        if (seen > expected.bytes) {
          finish();
          controller.abort();
          out.error(new OrgContractError('invalid-response', 'envelope', 'body is longer than the declared size'));
          return;
        }
        hash.update(next.value);
        out.enqueue(next.value);
      } catch (failure) {
        finish();
        out.error(failure);
      }
    },
    async cancel(reason) {
      finish();
      await reader.cancel(reason).catch(() => undefined);
    },
  });
}

/** Reads a verified envelope stream into memory, refusing more than `maxBytes`. For small envelopes and tests; large ones should be piped to disk. */
export async function collectEnvelope(body: ReadableStream<Uint8Array>, maxBytes: number): Promise<Uint8Array> {
  const reader = body.getReader();
  const chunks: Uint8Array[] = [];
  let total = 0;
  for (;;) {
    const next = await reader.read();
    if (next.done) break;
    total += next.value.length;
    if (total > maxBytes) {
      await reader.cancel().catch(() => undefined);
      throw new OrgApiError(413, 'envelope-too-large', 'envelope exceeds the size the caller accepts');
    }
    chunks.push(next.value);
  }
  const out = new Uint8Array(total);
  let offset = 0;
  for (const chunk of chunks) {
    out.set(chunk, offset);
    offset += chunk.length;
  }
  return out;
}
