import { fail, readString, type Reader } from './validate.js';

export const PRINCIPAL_KINDS = ['user', 'group', 'org', 'service'] as const;
export type PrincipalKind = (typeof PRINCIPAL_KINDS)[number];

/**
 * An opaque identity reference issued by an organization provider. Marshal compares and stores
 * principals but never interprets the id part, so any identity provider can sit behind it.
 */
export type Principal = `${PrincipalKind}:${string}`;
export type UserPrincipal = `user:${string}`;

const PRINCIPAL_PATTERN = /^(user|group|org|service):[^\s:][^\s]{0,254}$/;

export function isPrincipal(value: unknown): value is Principal {
  return typeof value === 'string' && PRINCIPAL_PATTERN.test(value);
}

export function principalKind(principal: Principal): PrincipalKind {
  return principal.slice(0, principal.indexOf(':')) as PrincipalKind;
}

export function readPrincipal(reader: Reader, value: unknown, path: string): Principal {
  const text = readString(reader, value, path, { max: 260 });
  if (!isPrincipal(text)) fail(reader, path, 'must be a principal like user:<id>, group:<id>, org:<id> or service:<id>');
  return text;
}

export function readUserPrincipal(reader: Reader, value: unknown, path: string): UserPrincipal {
  const principal = readPrincipal(reader, value, path);
  if (principalKind(principal) !== 'user') fail(reader, path, 'must be a user principal');
  return principal as UserPrincipal;
}
