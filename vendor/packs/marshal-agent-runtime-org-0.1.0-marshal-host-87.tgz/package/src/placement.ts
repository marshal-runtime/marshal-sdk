import { readUserPrincipal } from './principals.js';
import { fail, readArray, readObject, readOptionalString, readString, type Reader } from './validate.js';
import type { OrgLeaseHolder } from './leases.js';

const RESPONSE: Reader = { code: 'invalid-response' };
const REQUEST: Reader = { code: 'invalid-request' };

/** Hard ceiling on the bundle size an organization may advertise. */
export const MAX_BUNDLE_BYTES_CEILING = 512 * 1024 * 1024;
export const PLACEMENT_MANIFEST_VERSION = 1 as const;
export const MAX_PLACEMENT_MOUNTS = 8;
/** Version 1 emits one git mount per job; more is rejected so the number of ways a move fails stays small. */
export const MAX_PLACEMENT_GIT_MOUNTS = 1;
export const MAX_PLACEMENT_SKIPPED = 200;
export const MAX_PLACEMENT_TOOLS = 128;
export const MAX_PLACEMENT_PATH_CHARS = 1024;
/** The body limit of one bundle upload when the organization advertises none. */
export const DEFAULT_MAX_BUNDLE_BYTES = 24 * 1024 * 1024;
export const BUNDLE_CONTENT_TYPE = 'application/octet-stream';

/** Error codes the placement routes add to the shared set. */
export const PLACEMENT_ERROR_CODES = ['bundle-too-large', 'bundle-mismatch', 'no-bundle', 'invalid-placement'] as const;

export const BUNDLE_HEADERS = {
  host: 'x-marshal-host',
  sha256: 'x-marshal-bundle-sha256',
} as const;

/** Why a path or a mount did not move. The set is open: a host may add reasons, and a reader keeps any lowercase-kebab one. */
export const PLACEMENT_SKIP_REASONS = ['secret', 'embedded-repo', 'lfs', 'unreadable', 'excluded-by-user', 'over-budget', 'symlink-loop', 'ignored'] as const;
export const PLACEMENT_LOCAL_ONLY_REASONS = [
  'no-remote',
  'not-a-git-repo',
  'repo-not-in-workspace',
  'extra-mount',
  'over-cap',
  'over-budget',
  'secret',
  'bounded-workspace',
  'submodules',
  'embedded-repo',
  'lfs',
] as const;

const MOUNT_ID_PATTERN = /^m[0-9]{1,3}$/;
const REASON_PATTERN = /^[a-z0-9][a-z0-9-]{0,63}$/;
const SHA256_PATTERN = /^[0-9a-f]{64}$/;
const COMMIT_PATTERN = /^(?:[0-9a-f]{40}|[0-9a-f]{64})$/;
const REPO_PATTERN = /^[A-Za-z0-9][A-Za-z0-9._-]{0,99}\/[A-Za-z0-9][A-Za-z0-9._-]{0,99}$/;
const BRANCH_PATTERN = /^[A-Za-z0-9][A-Za-z0-9._/-]{0,199}$/;
const HOST_PATTERN = /^[A-Za-z0-9][A-Za-z0-9._:-]{0,127}$/;
const WORKSPACE_PATTERN = /^ws:[a-z0-9][a-z0-9-]{0,62}$/;
const ISO_PATTERN = /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(\.\d{1,9})?(Z|[+-]\d{2}:\d{2})$/;
const CLOUD_PATH_PATTERN = /^\/work\/[A-Za-z0-9][A-Za-z0-9._-]{0,63}$/;
const OBJECT_PATTERN = /^org-sessions\/[A-Za-z0-9][A-Za-z0-9._-]{0,127}\/mounts\/[A-Za-z0-9][A-Za-z0-9._-]{0,199}\.bundle$/;
/** A drive letter with or without a slash: `C:\x` and `C:x` both name a Windows location. */
const WINDOWS_DRIVE = /^[A-Za-z]:/;
/** A rooted path through a home folder (`/Users/x/`, `C:\\Users\\x\\`, `\\\\server\\home\\x\\`): it must not continue a name or a path (no letter, digit, `.`, `_`, `~` or `-` before it), so `src/home/x.ts` and `components/Users/List.tsx` pass while text after `,` `;` `[` `{` or a quote is caught. */
const HOME_PATH = /(?<![A-Za-z0-9._~-])(?:(?:[A-Za-z]:)?[\\/]+|\\\\[^\\/\s]+[\\/])(?:Users|home)[\\/]/i;
/** `~name/` or a bare `~name` at the end of the text: another person's home folder. `~/x` (the writer's own) and `~5 min` pass. */
const TILDE_HOME = /(?<![A-Za-z0-9._~\\/-])~[A-Za-z_][A-Za-z0-9._-]*(?=[\\/]|$)/;
// eslint-disable-next-line no-control-regex
const CONTROL_CHARACTERS = /[\u0000-\u001f\u007f]/;
const REPO_URL_TAIL = /(?:^|[:/])([A-Za-z0-9][A-Za-z0-9._-]*)\/([A-Za-z0-9][A-Za-z0-9._-]*?)(?:\.git)?\/?$/;

/**
 * The `owner/name` of a repository the way the organization names it: a workspace lists a repository as a clone URL
 * (`https://host/owner/name.git`, `ssh://git@host/owner/name`, `git@host:owner/name`) or as `owner/name`. Both spellings reduce
 * to the same lowercase `owner/name` (hosts treat the names case-insensitively), or undefined for anything else.
 */
export function normalizeOrgRepository(value: string): string | undefined {
  const match = REPO_URL_TAIL.exec(value.trim());
  if (!match) return undefined;
  const normalized = `${match[1]}/${match[2]}`.toLowerCase();
  return REPO_PATTERN.test(normalized) ? normalized : undefined;
}

/** True when `repo` (a manifest's `owner/name`) is one of the workspace's repositories, whatever spelling either side uses. */
export function isOrgWorkspaceRepository(repo: string, repositories: readonly { repository: string }[]): boolean {
  const wanted = normalizeOrgRepository(repo);
  return wanted !== undefined && repositories.some((entry) => normalizeOrgRepository(entry.repository) === wanted);
}

/** A git branch name by `git check-ref-format`: no `..`, `@{`, empty, dot-leading or `.lock`-ending segment, no trailing slash or dot. */
export function isValidBranchName(value: string): boolean {
  if (!BRANCH_PATTERN.test(value) || value === '@' || value.includes('..') || value.includes('@{') || value.endsWith('/') || value.endsWith('.')) return false;
  return value.split('/').every((segment) => segment !== '' && !segment.startsWith('.') && !segment.endsWith('.lock'));
}

export function isMountId(value: unknown): value is string {
  return typeof value === 'string' && MOUNT_ID_PATTERN.test(value);
}

/** True when the bytes start like a git bundle (`# v2 git bundle` or `# v3 git bundle`). */
export function looksLikeGitBundle(head: Uint8Array): boolean {
  const text = new TextDecoder('utf-8', { fatal: false }).decode(head.subarray(0, 16));
  return text.startsWith('# v2 git bundle\n') || text.startsWith('# v3 git bundle\n');
}

export type OrgPlacementSkip = { path: string; why: string };

/** What the cloud applies on top of the base commit. The git bundle holds `<base>..<wip>`; the cloud checks the WIP tree out and resets the index to the base. */
export type OrgPlacementWip = {
  transport: 'bundle';
  sha256: string;
  bytes: number;
  /** Changed tracked files carried. */
  tracked: number;
  /** Untracked, non-ignored files carried. */
  untracked: number;
  /** Local commits between base and WIP that are not on the upstream. */
  localCommits: number;
  /** Files that stayed on the laptop, with the reason. Paths are relative to the repo root. */
  skipped: OrgPlacementSkip[];
  /** Where the organization keeps the bundle. Set by the organization; a request that names one is refused. */
  object?: string;
};

export type OrgPlacementGitMount = {
  id: string;
  kind: 'git';
  /** A human label; never a local absolute path. */
  localLabel: string;
  /** Where the cloud materializes the mount: `/work/<name>`. */
  cloudPath: string;
  /** `owner/name` of a repository of the workspace the session belongs to. */
  repo: string;
  baseCommit: string;
  baseBranch?: string;
  /** Absent when the work tree is clean and everything is pushed: the cloud checks out the base alone. */
  wip?: OrgPlacementWip;
};

export type OrgPlacementLocalOnlyMount = {
  id: string;
  kind: 'local-only';
  localLabel: string;
  why: string;
};

export type OrgPlacementMount = OrgPlacementGitMount | OrgPlacementLocalOnlyMount;

export type OrgPlacementTools = {
  available: string[];
  unavailable: { name: string; why: string }[];
};

/** A move interrupted a running turn: the transcript ends in a tool call that may or may not have finished. */
export type OrgPlacementMidTurn = { interrupted: boolean; tool?: string; note?: string };

/** The placement manifest (version 1): what execution context a session moved with. */
export type OrgPlacementManifest = {
  version: typeof PLACEMENT_MANIFEST_VERSION;
  sessionId: string;
  /** The desktop lease host that built it. */
  createdBy: string;
  createdAt: string;
  /** The workspace the session belongs to (`ws:<name>`). */
  boundary: string;
  /** The mount the session's working directory is in. Must be a git mount. */
  cwdMount: string;
  mounts: OrgPlacementMount[];
  tools?: OrgPlacementTools;
  midTurn?: OrgPlacementMidTurn;
};

/** Capabilities of the placement feature, under `GET /v1/cloud/capabilities`. */
export type OrgPlacementCapabilities = {
  /** Manifest versions the organization accepts. */
  manifestVersions: number[];
  /** The most bytes of one bundle the organization accepts. */
  maxBundleBytes: number;
};

/** Metadata of an uploaded bundle: `sha256` and `bytes` describe the bytes as stored. */
export type OrgMountBundleInfo = {
  mountId: string;
  sha256: string;
  bytes: number;
  uploadedBy: OrgLeaseHolder;
  at: string;
};

/** `GET /v1/sessions/:id/placement`: the manifest the latest cloud run started with, or null. */
export type OrgPlacementView = { placement: OrgPlacementManifest | null };

function readIso(reader: Reader, value: unknown, path: string): string {
  const text = readString(reader, value, path, { max: 40 });
  if (!ISO_PATTERN.test(text) || Number.isNaN(Date.parse(text))) fail(reader, path, 'must be an ISO 8601 timestamp');
  return text;
}

function readCount(reader: Reader, value: unknown, path: string, max: number): number {
  if (typeof value !== 'number' || !Number.isInteger(value) || value < 0 || value > max) fail(reader, path, `must be an integer from 0 to ${max}`);
  return value;
}

/** A repo-relative path: no leading slash, no drive letter (`C:\x` or `C:x`), no `..` or empty segment, no control characters. */
export function isRelativeRepoPath(value: string): boolean {
  if (value.length === 0 || value.length > MAX_PLACEMENT_PATH_CHARS) return false;
  if (value.startsWith('/') || value.startsWith('\\') || WINDOWS_DRIVE.test(value)) return false;
  if (CONTROL_CHARACTERS.test(value)) return false;
  return value.split(/[\\/]/).every((segment) => segment !== '' && segment !== '..' && segment !== '.');
}

/** Free text a desktop writes about itself: no control characters and no path into a home folder, so a username never reaches the organization. */
function readSafeText(reader: Reader, value: unknown, path: string, max: number): string {
  const text = readString(reader, value, path, { max });
  if (CONTROL_CHARACTERS.test(text)) fail(reader, path, 'must not contain control characters');
  if (HOME_PATH.test(text) || TILDE_HOME.test(text)) fail(reader, path, 'must not contain a local home path');
  return text;
}

function readLabel(reader: Reader, value: unknown, path: string): string {
  const label = readString(reader, value, path, { max: 200 });
  if (label.startsWith('/') || label.startsWith('\\') || WINDOWS_DRIVE.test(label) || /^file:/i.test(label) || /^~[^/\\]/.test(label)) fail(reader, path, 'must not be an absolute local path');
  return readSafeText(reader, label, path, 200);
}

function readReason(reader: Reader, value: unknown, path: string): string {
  return readString(reader, value, path, { max: 64, pattern: REASON_PATTERN });
}

function readSkip(reader: Reader, value: unknown, path: string): OrgPlacementSkip {
  const root = readObject(reader, value, path);
  const skipPath = readString(reader, root.path, `${path}.path`, { max: MAX_PLACEMENT_PATH_CHARS });
  if (!isRelativeRepoPath(skipPath)) fail(reader, `${path}.path`, 'must be a relative path inside the repository');
  return { path: skipPath, why: readReason(reader, root.why, `${path}.why`) };
}

function readWip(reader: Reader, value: unknown, path: string, fromClient: boolean): OrgPlacementWip {
  const root = readObject(reader, value, path);
  if (root.transport !== 'bundle') fail(reader, `${path}.transport`, 'must be "bundle"');
  const bytes = readCount(reader, root.bytes, `${path}.bytes`, MAX_BUNDLE_BYTES_CEILING);
  if (bytes < 1) fail(reader, `${path}.bytes`, 'must be at least 1');
  const wip: OrgPlacementWip = {
    transport: 'bundle',
    sha256: readString(reader, root.sha256, `${path}.sha256`, { max: 64, pattern: SHA256_PATTERN }),
    bytes,
    tracked: readCount(reader, root.tracked, `${path}.tracked`, 1_000_000),
    untracked: readCount(reader, root.untracked, `${path}.untracked`, 1_000_000),
    localCommits: readCount(reader, root.localCommits, `${path}.localCommits`, 1_000_000),
    skipped: readArray(reader, root.skipped, `${path}.skipped`, MAX_PLACEMENT_SKIPPED, (entry, entryPath) => readSkip(reader, entry, entryPath)),
  };
  if (root.object !== undefined && root.object !== null) {
    if (fromClient) fail(reader, `${path}.object`, 'is set by the organization and must not be sent');
    wip.object = readString(reader, root.object, `${path}.object`, { max: 400, pattern: OBJECT_PATTERN });
  }
  return wip;
}

function readMount(reader: Reader, value: unknown, path: string, fromClient: boolean): OrgPlacementMount {
  const root = readObject(reader, value, path);
  const id = readString(reader, root.id, `${path}.id`, { max: 8, pattern: MOUNT_ID_PATTERN });
  const localLabel = readLabel(reader, root.localLabel, `${path}.localLabel`);
  if (root.kind === 'local-only') return { id, kind: 'local-only', localLabel, why: readReason(reader, root.why, `${path}.why`) };
  if (root.kind !== 'git') fail(reader, `${path}.kind`, 'must be "git" or "local-only"');
  const mount: OrgPlacementGitMount = {
    id,
    kind: 'git',
    localLabel,
    cloudPath: readString(reader, root.cloudPath, `${path}.cloudPath`, { max: 80, pattern: CLOUD_PATH_PATTERN }),
    repo: readString(reader, root.repo, `${path}.repo`, { max: 201, pattern: REPO_PATTERN }),
    baseCommit: readString(reader, root.baseCommit, `${path}.baseCommit`, { max: 64, pattern: COMMIT_PATTERN }),
  };
  const baseBranch = readOptionalString(reader, root.baseBranch, `${path}.baseBranch`, { max: 200 });
  if (baseBranch !== undefined) {
    if (!isValidBranchName(baseBranch)) fail(reader, `${path}.baseBranch`, 'must be a branch name');
    mount.baseBranch = baseBranch;
  }
  if (root.wip !== undefined && root.wip !== null) mount.wip = readWip(reader, root.wip, `${path}.wip`, fromClient);
  return mount;
}

function readTools(reader: Reader, value: unknown, path: string): OrgPlacementTools {
  const root = readObject(reader, value, path);
  return {
    available: readArray(reader, root.available, `${path}.available`, MAX_PLACEMENT_TOOLS, (entry, entryPath) => readSafeText(reader, entry, entryPath, 128)),
    unavailable: readArray(reader, root.unavailable, `${path}.unavailable`, MAX_PLACEMENT_TOOLS, (entry, entryPath) => {
      const item = readObject(reader, entry, entryPath);
      return { name: readSafeText(reader, item.name, `${entryPath}.name`, 128), why: readReason(reader, item.why, `${entryPath}.why`) };
    }),
  };
}

function parsePlacement(reader: Reader, value: unknown, path: string, fromClient: boolean): OrgPlacementManifest {
  const root = readObject(reader, value, path);
  if (root.version !== PLACEMENT_MANIFEST_VERSION) fail(reader, `${path}.version`, `must be ${PLACEMENT_MANIFEST_VERSION}`);
  const mounts = readArray(reader, root.mounts, `${path}.mounts`, MAX_PLACEMENT_MOUNTS, (entry, entryPath) => readMount(reader, entry, entryPath, fromClient));
  const ids = new Set<string>();
  const cloudPaths = new Set<string>();
  for (const [index, mount] of mounts.entries()) {
    if (ids.has(mount.id)) fail(reader, `${path}.mounts[${index}].id`, 'must be unique');
    ids.add(mount.id);
    if (mount.kind === 'git') {
      if (cloudPaths.has(mount.cloudPath)) fail(reader, `${path}.mounts[${index}].cloudPath`, 'must be unique');
      cloudPaths.add(mount.cloudPath);
    }
  }
  if (mounts.filter((mount) => mount.kind === 'git').length > MAX_PLACEMENT_GIT_MOUNTS) fail(reader, `${path}.mounts`, `must hold at most ${MAX_PLACEMENT_GIT_MOUNTS} git mount`);
  const cwdMount = readString(reader, root.cwdMount, `${path}.cwdMount`, { max: 8, pattern: MOUNT_ID_PATTERN });
  const cwd = mounts.find((mount) => mount.id === cwdMount);
  if (!cwd) fail(reader, `${path}.cwdMount`, 'must name a mount');
  if (cwd.kind !== 'git') fail(reader, `${path}.cwdMount`, 'must name a git mount: the cloud needs a working directory');
  const manifest: OrgPlacementManifest = {
    version: PLACEMENT_MANIFEST_VERSION,
    sessionId: readString(reader, root.sessionId, `${path}.sessionId`, { max: 128 }),
    createdBy: readString(reader, root.createdBy, `${path}.createdBy`, { max: 128, pattern: HOST_PATTERN }),
    createdAt: readIso(reader, root.createdAt, `${path}.createdAt`),
    boundary: readString(reader, root.boundary, `${path}.boundary`, { max: 66, pattern: WORKSPACE_PATTERN }),
    cwdMount,
    mounts,
  };
  if (root.tools !== undefined && root.tools !== null) manifest.tools = readTools(reader, root.tools, `${path}.tools`);
  if (root.midTurn !== undefined && root.midTurn !== null) {
    const mid = readObject(reader, root.midTurn, `${path}.midTurn`);
    if (typeof mid.interrupted !== 'boolean') fail(reader, `${path}.midTurn.interrupted`, 'must be a boolean');
    const midTurn: OrgPlacementMidTurn = { interrupted: mid.interrupted };
    if (mid.tool !== undefined && mid.tool !== null) midTurn.tool = readSafeText(reader, mid.tool, `${path}.midTurn.tool`, 128);
    if (mid.note !== undefined && mid.note !== null) midTurn.note = readSafeText(reader, mid.note, `${path}.midTurn.note`, 1024);
    manifest.midTurn = midTurn;
  }
  return manifest;
}

/** Parses a manifest a client sends. `wip.object` is the organization's to set, so a client that names one is refused. */
export function parseOrgPlacementRequest(value: unknown, path = 'placement'): OrgPlacementManifest {
  return parsePlacement(REQUEST, value, path, true);
}

/** Parses a manifest an organization returns, `wip.object` included. */
export function parseOrgPlacementManifest(value: unknown, path = 'placement'): OrgPlacementManifest {
  return parsePlacement(RESPONSE, value, path, false);
}

export function parseOrgPlacementView(value: unknown): OrgPlacementView {
  const root = readObject(RESPONSE, value, 'placementView');
  return { placement: root.placement === null ? null : parseOrgPlacementManifest(root.placement, 'placementView.placement') };
}

export function parseOrgPlacementCapabilities(value: unknown, path = 'cloud.placement'): OrgPlacementCapabilities {
  const root = readObject(RESPONSE, value, path);
  const maxBundleBytes = readCount(RESPONSE, root.maxBundleBytes, `${path}.maxBundleBytes`, MAX_BUNDLE_BYTES_CEILING);
  if (maxBundleBytes < 1) fail(RESPONSE, `${path}.maxBundleBytes`, 'must be at least 1');
  return {
    manifestVersions: readArray(RESPONSE, root.manifestVersions, `${path}.manifestVersions`, 8, (entry, entryPath) => readCount(RESPONSE, entry, entryPath, 1000)),
    maxBundleBytes,
  };
}

export function parseOrgMountBundleInfo(value: unknown, path = 'bundle'): OrgMountBundleInfo {
  const root = readObject(RESPONSE, value, path);
  const uploader = readObject(RESPONSE, root.uploadedBy, `${path}.uploadedBy`);
  const bytes = readCount(RESPONSE, root.bytes, `${path}.bytes`, MAX_BUNDLE_BYTES_CEILING);
  return {
    mountId: readString(RESPONSE, root.mountId, `${path}.mountId`, { max: 8, pattern: MOUNT_ID_PATTERN }),
    sha256: readString(RESPONSE, root.sha256, `${path}.sha256`, { max: 64, pattern: SHA256_PATTERN }),
    bytes,
    uploadedBy: {
      host: readString(RESPONSE, uploader.host, `${path}.uploadedBy.host`, { max: 128, pattern: HOST_PATTERN }),
      principal: readUserPrincipal(RESPONSE, uploader.principal, `${path}.uploadedBy.principal`),
    },
    at: readIso(RESPONSE, root.at, `${path}.at`),
  };
}
