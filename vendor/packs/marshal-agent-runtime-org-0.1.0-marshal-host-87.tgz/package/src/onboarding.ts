import {
  MAX_LONG_TEXT,
  MAX_SHORT_TEXT,
  fail,
  readArray,
  readObject,
  readOptionalString,
  readString,
  readUrl,
  type Reader,
} from './validate.js';
import { isSha256Hex } from './cloud.js';

export const ONBOARDING_MANIFEST_VERSION = 1 as const;
export const ONBOARDING_TIERS = ['recommended', 'available'] as const;
export type OnboardingTier = (typeof ONBOARDING_TIERS)[number];
/** The largest extension archive a manifest may declare. */
export const MAX_ONBOARDING_ARCHIVE_BYTES = 256 * 1024 * 1024;

export type OnboardingConnectStep = {
  capability: string;
  input?: Record<string, unknown>;
  statusCapability?: string;
  label: string;
};

export type OnboardingDelivery =
  | { kind: 'bundled' }
  | { kind: 'archive'; url: string; sha256: string; bytes: number };

export type OnboardingExtension = {
  /** Runtime extension identity, for example `@marshal/brain`. */
  id: string;
  version: string;
  tier: OnboardingTier;
  title: string;
  why: string;
  delivery: OnboardingDelivery;
  connect?: OnboardingConnectStep[];
  /** `published` entries were uploaded by a member and approved by an admin; they never join the org-service allowlist. */
  origin?: 'org' | 'published';
  /** Who published it (published entries only). */
  publisher?: string;
  /** Who approved it (published entries only). */
  approver?: string;
};

export const ONBOARDING_TOOL_IDS = ['gcloud', 'coder', 'gh', 'docker'] as const;
export type OnboardingToolId = (typeof ONBOARDING_TOOL_IDS)[number];
/** A developer tool the org names; the installers are fixed code in the desktop, the manifest never carries commands or URLs. */
export type OnboardingTool = {
  id: OnboardingToolId;
  required: boolean;
  why: string;
  /** Coder only: SHA-256 of the CLI binary per CPU, so a plain-HTTP Coder server is safe to download from. It only narrows what is allowed. */
  sha256?: { arm64?: string; amd64?: string };
};

export const AGENT_DEFAULT_EFFORTS = ['low', 'medium', 'high', 'xhigh', 'max'] as const;
export type AgentDefaultEffort = (typeof AGENT_DEFAULT_EFFORTS)[number];
export type AgentModelDefault = { model: string; effort?: AgentDefaultEffort; runtime?: string };
/** Default models the org sets for its members at onboarding; the person can change them afterwards. */
export type OrgAgentDefaults = { main?: AgentModelDefault; subagents?: AgentModelDefault };

export type OrgOnboardingManifest = {
  version: typeof ONBOARDING_MANIFEST_VERSION;
  welcome: { title: string; points: { title: string; body: string }[]; starterPrompts: string[] };
  extensions: OnboardingExtension[];
  projects?: { provider: 'github'; owner: string; preselect: string[]; cloneRoot: string };
  dailySignIn?: { kind: 'google-gcloud'; extension: string; capability: string; defaultTime: string };
  tools?: OnboardingTool[];
  agentDefaults?: OrgAgentDefaults;
};

const RESPONSE: Reader = { code: 'invalid-response' };
const EXTENSION_ID = /^@[a-z0-9][a-z0-9-]{0,63}\/[a-z0-9][a-z0-9._-]{0,63}$/;
const VERSION = /^[0-9]+\.[0-9]+\.[0-9]+(?:[-+][0-9A-Za-z.+-]{1,64})?$/;
const CAPABILITY = /^[A-Za-z][A-Za-z0-9._-]{0,127}$/;
const TIME = /^([01][0-9]|2[0-3]):[0-5][0-9]$/;
const OWNER = /^[A-Za-z0-9][A-Za-z0-9-]{0,38}$/;

/** Whether `value` is an extension identity like `@marshal/brain`. */
export function isOnboardingExtensionId(value: string): boolean {
  return EXTENSION_ID.test(value);
}

/** Whether `value` is an extension version the archive route accepts. */
export function isOnboardingVersion(value: string): boolean {
  return VERSION.test(value);
}

/** Validates an onboarding manifest, throwing `OrgContractError` (`invalid-response`) on the first problem. */
export function parseOrgOnboardingManifest(value: unknown): OrgOnboardingManifest {
  const root = readObject(RESPONSE, value, 'onboarding');
  if (root.version !== ONBOARDING_MANIFEST_VERSION) fail(RESPONSE, 'onboarding.version', `must be ${ONBOARDING_MANIFEST_VERSION}`);
  const welcome = readObject(RESPONSE, root.welcome, 'onboarding.welcome');
  const extensions = readArray(RESPONSE, root.extensions, 'onboarding.extensions', 64, parseExtension);
  const ids = new Set<string>();
  for (const extension of extensions) {
    if (ids.has(extension.id)) fail(RESPONSE, 'onboarding.extensions', `lists ${extension.id} twice`);
    ids.add(extension.id);
  }
  const manifest: OrgOnboardingManifest = {
    version: ONBOARDING_MANIFEST_VERSION,
    welcome: {
      title: readString(RESPONSE, welcome.title, 'onboarding.welcome.title'),
      points: readArray(RESPONSE, welcome.points, 'onboarding.welcome.points', 16, (entry, path) => {
        const point = readObject(RESPONSE, entry, path);
        return {
          title: readString(RESPONSE, point.title, `${path}.title`),
          body: readString(RESPONSE, point.body, `${path}.body`, { max: MAX_LONG_TEXT }),
        };
      }),
      starterPrompts: readArray(RESPONSE, welcome.starterPrompts, 'onboarding.welcome.starterPrompts', 16, (entry, path) =>
        readString(RESPONSE, entry, path, { max: 1024 }),
      ),
    },
    extensions,
  };
  if (root.projects !== undefined && root.projects !== null) {
    const projects = readObject(RESPONSE, root.projects, 'onboarding.projects');
    if (projects.provider !== 'github') fail(RESPONSE, 'onboarding.projects.provider', 'must be github');
    manifest.projects = {
      provider: 'github',
      owner: readString(RESPONSE, projects.owner, 'onboarding.projects.owner', { pattern: OWNER }),
      preselect: readArray(RESPONSE, projects.preselect, 'onboarding.projects.preselect', 64, (entry, path) =>
        readString(RESPONSE, entry, path, { pattern: /^[A-Za-z0-9._-]{1,100}$/ }),
      ),
      cloneRoot: readString(RESPONSE, projects.cloneRoot, 'onboarding.projects.cloneRoot', { max: 512 }),
    };
  }
  if (root.dailySignIn !== undefined && root.dailySignIn !== null) {
    const daily = readObject(RESPONSE, root.dailySignIn, 'onboarding.dailySignIn');
    if (daily.kind !== 'google-gcloud') fail(RESPONSE, 'onboarding.dailySignIn.kind', 'must be google-gcloud');
    manifest.dailySignIn = {
      kind: 'google-gcloud',
      extension: readString(RESPONSE, daily.extension, 'onboarding.dailySignIn.extension', { pattern: EXTENSION_ID }),
      capability: readString(RESPONSE, daily.capability, 'onboarding.dailySignIn.capability', { pattern: CAPABILITY }),
      defaultTime: readString(RESPONSE, daily.defaultTime, 'onboarding.dailySignIn.defaultTime', { pattern: TIME }),
    };
  }
  if (root.tools !== undefined && root.tools !== null) {
    manifest.tools = readArray(RESPONSE, root.tools, 'onboarding.tools', 16, (entry, path) => {
      const tool = readObject(RESPONSE, entry, path);
      if (!(ONBOARDING_TOOL_IDS as readonly unknown[]).includes(tool.id)) fail(RESPONSE, `${path}.id`, `must be one of ${ONBOARDING_TOOL_IDS.join(', ')}`);
      if (typeof tool.required !== 'boolean') fail(RESPONSE, `${path}.required`, 'must be a boolean');
      const parsed: OnboardingTool = { id: tool.id as OnboardingToolId, required: tool.required, why: readString(RESPONSE, tool.why, `${path}.why`, { max: MAX_LONG_TEXT }) };
      if (tool.sha256 !== undefined && tool.sha256 !== null) {
        if (tool.id !== 'coder') fail(RESPONSE, `${path}.sha256`, 'is only allowed on the coder tool');
        const pins = readObject(RESPONSE, tool.sha256, `${path}.sha256`);
        const sha256: { arm64?: string; amd64?: string } = {};
        for (const arch of ['arm64', 'amd64'] as const) {
          if (pins[arch] === undefined) continue;
          const pin = readString(RESPONSE, pins[arch], `${path}.sha256.${arch}`, { max: 64 });
          if (!isSha256Hex(pin)) fail(RESPONSE, `${path}.sha256.${arch}`, 'must be 64 lowercase hex characters');
          sha256[arch] = pin;
        }
        if (sha256.arm64 || sha256.amd64) parsed.sha256 = sha256;
      }
      return parsed;
    });
  }
  if (root.agentDefaults !== undefined && root.agentDefaults !== null) {
    const defaults = readObject(RESPONSE, root.agentDefaults, 'onboarding.agentDefaults');
    const parsed: OrgAgentDefaults = {};
    if (defaults.main !== undefined && defaults.main !== null) parsed.main = parseModelDefault(defaults.main, 'onboarding.agentDefaults.main');
    if (defaults.subagents !== undefined && defaults.subagents !== null) {
      parsed.subagents = parseModelDefault(defaults.subagents, 'onboarding.agentDefaults.subagents');
    }
    manifest.agentDefaults = parsed;
  }
  return manifest;
}

function parseModelDefault(value: unknown, path: string): AgentModelDefault {
  const root = readObject(RESPONSE, value, path);
  const parsed: AgentModelDefault = { model: readString(RESPONSE, root.model, `${path}.model`, { max: MAX_SHORT_TEXT }) };
  if (root.effort !== undefined && root.effort !== null) {
    if (!(AGENT_DEFAULT_EFFORTS as readonly unknown[]).includes(root.effort)) fail(RESPONSE, `${path}.effort`, `must be one of ${AGENT_DEFAULT_EFFORTS.join(', ')}`);
    parsed.effort = root.effort as AgentDefaultEffort;
  }
  const runtime = readOptionalString(RESPONSE, root.runtime, `${path}.runtime`, { max: MAX_SHORT_TEXT });
  if (runtime !== undefined) parsed.runtime = runtime;
  return parsed;
}

/** Parses one catalog/manifest extension entry. */
export function parseOnboardingExtension(entry: unknown, path = 'extension'): OnboardingExtension {
  return parseExtension(entry, path);
}

function parseExtension(entry: unknown, path: string): OnboardingExtension {
  const root = readObject(RESPONSE, entry, path);
  // Servers from before the catalog call the second tier "optional".
  const tier = root.tier === 'optional' ? 'available' : root.tier;
  if (!(ONBOARDING_TIERS as readonly unknown[]).includes(tier)) fail(RESPONSE, `${path}.tier`, 'must be recommended or available');
  const delivery = readObject(RESPONSE, root.delivery, `${path}.delivery`);
  const extension: OnboardingExtension = {
    id: readString(RESPONSE, root.id, `${path}.id`, { pattern: EXTENSION_ID }),
    version: readString(RESPONSE, root.version, `${path}.version`, { pattern: VERSION }),
    tier: tier as OnboardingTier,
    title: readString(RESPONSE, root.title, `${path}.title`),
    why: readString(RESPONSE, root.why, `${path}.why`, { max: MAX_LONG_TEXT }),
    delivery: parseDelivery(delivery, `${path}.delivery`),
  };
  if (root.connect !== undefined && root.connect !== null) {
    extension.connect = readArray(RESPONSE, root.connect, `${path}.connect`, 16, (step, stepPath) => {
      const item = readObject(RESPONSE, step, stepPath);
      const parsed: OnboardingConnectStep = {
        capability: readString(RESPONSE, item.capability, `${stepPath}.capability`, { pattern: CAPABILITY }),
        label: readString(RESPONSE, item.label, `${stepPath}.label`, { max: MAX_SHORT_TEXT }),
      };
      if (item.input !== undefined && item.input !== null) parsed.input = readObject(RESPONSE, item.input, `${stepPath}.input`);
      const status = readOptionalString(RESPONSE, item.statusCapability, `${stepPath}.statusCapability`, { pattern: CAPABILITY });
      if (status !== undefined) parsed.statusCapability = status;
      return parsed;
    });
  }
  if (root.origin !== undefined && root.origin !== null) {
    if (root.origin !== 'org' && root.origin !== 'published') fail(RESPONSE, `${path}.origin`, 'must be org or published');
    extension.origin = root.origin;
  }
  const publisher = readOptionalString(RESPONSE, root.publisher, `${path}.publisher`, { max: MAX_SHORT_TEXT });
  if (publisher !== undefined) extension.publisher = publisher;
  const approver = readOptionalString(RESPONSE, root.approver, `${path}.approver`, { max: MAX_SHORT_TEXT });
  if (approver !== undefined) extension.approver = approver;
  return extension;
}

function parseDelivery(delivery: Record<string, unknown>, path: string): OnboardingDelivery {
  if (delivery.kind === 'bundled') return { kind: 'bundled' };
  if (delivery.kind !== 'archive') fail(RESPONSE, `${path}.kind`, 'must be bundled or archive');
  const sha256 = readString(RESPONSE, delivery.sha256, `${path}.sha256`, { max: 64 });
  if (!isSha256Hex(sha256)) fail(RESPONSE, `${path}.sha256`, 'must be 64 lowercase hex characters');
  const bytes = delivery.bytes;
  if (typeof bytes !== 'number' || !Number.isInteger(bytes) || bytes < 1 || bytes > MAX_ONBOARDING_ARCHIVE_BYTES) {
    fail(RESPONSE, `${path}.bytes`, `must be an integer from 1 to ${MAX_ONBOARDING_ARCHIVE_BYTES}`);
  }
  return { kind: 'archive', url: readUrl(RESPONSE, delivery.url, `${path}.url`, { allowLoopbackHttp: true }), sha256, bytes };
}
