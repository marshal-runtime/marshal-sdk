import { createHash } from 'node:crypto';
import { parseOrgLeaseView, type OrgLeaseCheckpoint, type OrgLeaseHolder, type OrgLeaseView } from './leases.js';
import { parseOrgPlacementCapabilities, parseOrgPlacementRequest, type OrgPlacementCapabilities, type OrgPlacementManifest } from './placement.js';
import { readUserPrincipal } from './principals.js';
import { fail, readArray, readObject, readOptionalString, readString, readUrl, type Reader } from './validate.js';

const RESPONSE: Reader = { code: 'invalid-response' };
const REQUEST: Reader = { code: 'invalid-request' };

/** Hard ceiling on the envelope size an organization may advertise. */
export const MAX_ENVELOPE_BYTES_CEILING = 512 * 1024 * 1024;
export const MAX_CLOUD_INSTRUCTION_CHARS = 16 * 1024;
export const MAX_ENVELOPE_FORMATS = 16;

/** Error codes the cloud routes add to the shared set. */
export const CLOUD_ERROR_CODES = ['envelope-too-large', 'envelope-mismatch', 'unsupported-format', 'no-envelope', 'cloud-unavailable'] as const;

export const ENVELOPE_HEADERS = {
  format: 'x-marshal-envelope-format',
  sha256: 'x-marshal-envelope-sha256',
  messages: 'x-marshal-envelope-messages',
  host: 'x-marshal-host',
} as const;
export const ENVELOPE_CONTENT_TYPE = 'application/octet-stream';

const FORMAT_PATTERN = /^[a-z0-9][a-z0-9._-]{0,63}$/;
const SHA256_PATTERN = /^[0-9a-f]{64}$/;
const RUN_ID_PATTERN = /^[A-Za-z0-9][A-Za-z0-9._-]{0,127}$/;
const HOST_PATTERN = /^[A-Za-z0-9][A-Za-z0-9._:-]{0,127}$/;
const ISO_PATTERN = /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(\.\d{1,9})?(Z|[+-]\d{2}:\d{2})$/;

export function isEnvelopeFormat(value: unknown): value is string {
  return typeof value === 'string' && FORMAT_PATTERN.test(value);
}

export function isSha256Hex(value: unknown): value is string {
  return typeof value === 'string' && SHA256_PATTERN.test(value);
}

/** The checkpoint `stateRef` a host leaves when its last release matches an envelope. */
export function envelopeStateRef(sha256: string): string {
  return `sha256:${sha256}`;
}

/**
 * True for the cloud host's lease holder ids. `cloudHost` (from the capabilities) is a reserved namespace: the id itself, or
 * `<cloudHost>:<anything>` such as a per-run holder. Only the organization takes these holders; a user token that names one
 * as its `host` on any lease, envelope or cloud-run route is refused with 403 `forbidden`.
 */
export function isCloudHostId(host: string, cloudHost: string): boolean {
  return host === cloudHost || host.startsWith(`${cloudHost}:`);
}

export const CLOUD_RUN_FAILURES = ['lease-forced', 'lease-expired', 'lease-revoked'] as const;

export function looksLikeGzip(head: Uint8Array): boolean {
  return head.length >= 2 && head[0] === 0x1f && head[1] === 0x8b;
}

export function sha256Hex(bytes: Uint8Array): string {
  return createHash('sha256').update(bytes).digest('hex');
}

/** `GET /v1/cloud/capabilities`. */
export type OrgCloudCapabilities = {
  /**
   * The reserved lease host namespace of the cloud host: its holders are `cloudHost` or `cloudHost:<suffix>` (see
   * `isCloudHostId`). It is server-internal: users can never act under it, and it is how a desktop recognises the cloud's release.
   */
  cloudHost: string;
  /** Native state formats the cloud host can resume from, for example `claude-jsonl`. Opaque to the organization. */
  formats: string[];
  /** The largest envelope (gzip bytes) the organization accepts. */
  maxEnvelopeBytes: number;
  /** False while the cloud host cannot take runs; moving then answers 503 `cloud-unavailable`. */
  available: boolean;
  /** Present only when the organization serves the `placement` feature. */
  placement?: OrgPlacementCapabilities;
};

/** Metadata of the stored native envelope. `sha256` and `bytes` describe the gzip bytes as stored. */
export type OrgEnvelopeInfo = {
  format: string;
  sha256: string;
  bytes: number;
  /** Transcript messages the native state covers. */
  messageCount: number;
  uploadedBy: OrgLeaseHolder;
  at: string;
};

export const CLOUD_RUN_STATUSES = ['starting', 'running', 'released', 'failed'] as const;
export type OrgCloudRunStatus = (typeof CLOUD_RUN_STATUSES)[number];

/**
 * A run is `running` until its cloud lease ends: `released` when the cloud releases at a safe point with a checkpoint, `failed`
 * (with `error` and `finishedAt`) when the lease ends any other way. The organization settles it on its own, so a polling
 * desktop learns of a crash from `GET /cloud-run` without waiting for the lease read.
 */
export type OrgCloudRun = {
  id: string;
  sessionId: string;
  status: OrgCloudRunStatus;
  startedAt: string;
  finishedAt?: string;
  /**
   * Set when `failed`: `lease-forced` (the owner took the lease from the cloud), `lease-expired` (the cloud stopped
   * heartbeating) or `lease-revoked` (the grant of the person the cloud runs for was revoked).
   */
  error?: string;
  /** A human link to follow the run (for example a chat thread). */
  link?: string;
};

/** Body of `POST /v1/sessions/:id/cloud-runs`. */
export type OrgCloudRunRequest = {
  /** The caller's lease host; it must hold the lease. */
  host: string;
  /** The uploaded envelope the run resumes from. */
  envelopeSha256: string;
  instruction?: string;
  /**
   * What the session carries besides its native state: git mounts, uploaded as bundles beforehand (`putMountBundle`). Needs the
   * `placement` feature. The organization checks every bundle named in it against the upload before it starts the run, so the
   * envelope and the bundles move as one unit.
   */
  placement?: OrgPlacementManifest;
};

export type OrgCloudRunStarted = {
  run: OrgCloudRun;
  /** The lease after the move: holder is the cloud host. */
  lease: OrgLeaseView;
};

/** `GET /v1/sessions/:id/cloud-run`: the latest run, or null. */
export type OrgCloudRunView = { run: OrgCloudRun | null };

function readIso(reader: Reader, value: unknown, path: string): string {
  const text = readString(reader, value, path, { max: 40 });
  if (!ISO_PATTERN.test(text) || Number.isNaN(Date.parse(text))) fail(reader, path, 'must be an ISO 8601 timestamp');
  return text;
}

function readInt(reader: Reader, value: unknown, path: string, max: number): number {
  if (typeof value !== 'number' || !Number.isInteger(value) || value < 0 || value > max) fail(reader, path, `must be an integer from 0 to ${max}`);
  return value;
}

export function parseOrgCloudCapabilities(value: unknown): OrgCloudCapabilities {
  const root = readObject(RESPONSE, value, 'cloud');
  if (typeof root.available !== 'boolean') fail(RESPONSE, 'cloud.available', 'must be a boolean');
  const maxEnvelopeBytes = readInt(RESPONSE, root.maxEnvelopeBytes, 'cloud.maxEnvelopeBytes', MAX_ENVELOPE_BYTES_CEILING);
  if (maxEnvelopeBytes < 1) fail(RESPONSE, 'cloud.maxEnvelopeBytes', 'must be at least 1');
  const capabilities: OrgCloudCapabilities = {
    cloudHost: readString(RESPONSE, root.cloudHost, 'cloud.cloudHost', { max: 128, pattern: HOST_PATTERN }),
    formats: readArray(RESPONSE, root.formats, 'cloud.formats', MAX_ENVELOPE_FORMATS, (entry, path) =>
      readString(RESPONSE, entry, path, { max: 64, pattern: FORMAT_PATTERN }),
    ),
    maxEnvelopeBytes,
    available: root.available,
  };
  if (root.placement !== undefined && root.placement !== null) capabilities.placement = parseOrgPlacementCapabilities(root.placement);
  return capabilities;
}

export function parseOrgEnvelopeInfo(value: unknown, path = 'envelope'): OrgEnvelopeInfo {
  const root = readObject(RESPONSE, value, path);
  const uploader = readObject(RESPONSE, root.uploadedBy, `${path}.uploadedBy`);
  return {
    format: readString(RESPONSE, root.format, `${path}.format`, { max: 64, pattern: FORMAT_PATTERN }),
    sha256: readString(RESPONSE, root.sha256, `${path}.sha256`, { max: 64, pattern: SHA256_PATTERN }),
    bytes: readInt(RESPONSE, root.bytes, `${path}.bytes`, MAX_ENVELOPE_BYTES_CEILING),
    messageCount: readInt(RESPONSE, root.messageCount, `${path}.messageCount`, Number.MAX_SAFE_INTEGER),
    uploadedBy: {
      host: readString(RESPONSE, uploader.host, `${path}.uploadedBy.host`, { max: 128, pattern: HOST_PATTERN }),
      principal: readUserPrincipal(RESPONSE, uploader.principal, `${path}.uploadedBy.principal`),
    },
    at: readIso(RESPONSE, root.at, `${path}.at`),
  };
}

export function parseOrgCloudRun(value: unknown, path = 'run'): OrgCloudRun {
  const root = readObject(RESPONSE, value, path);
  const status = root.status;
  if (typeof status !== 'string' || !(CLOUD_RUN_STATUSES as readonly string[]).includes(status)) fail(RESPONSE, `${path}.status`, 'must be a known run status');
  const run: OrgCloudRun = {
    id: readString(RESPONSE, root.id, `${path}.id`, { max: 128, pattern: RUN_ID_PATTERN }),
    sessionId: readString(RESPONSE, root.sessionId, `${path}.sessionId`, { max: 128 }),
    status: status as OrgCloudRunStatus,
    startedAt: readIso(RESPONSE, root.startedAt, `${path}.startedAt`),
  };
  if (root.finishedAt !== undefined && root.finishedAt !== null) run.finishedAt = readIso(RESPONSE, root.finishedAt, `${path}.finishedAt`);
  const error = readOptionalString(RESPONSE, root.error, `${path}.error`, { max: 64 });
  if (error !== undefined) run.error = error;
  if (root.link !== undefined && root.link !== null) run.link = readUrl(RESPONSE, root.link, `${path}.link`);
  return run;
}

export function parseOrgCloudRunView(value: unknown): OrgCloudRunView {
  const root = readObject(RESPONSE, value, 'cloudRunView');
  return { run: root.run === null ? null : parseOrgCloudRun(root.run, 'cloudRunView.run') };
}

export function parseOrgCloudRunStarted(value: unknown): OrgCloudRunStarted {
  const root = readObject(RESPONSE, value, 'cloudRunStarted');
  return { run: parseOrgCloudRun(root.run, 'cloudRunStarted.run'), lease: parseOrgLeaseView(root.lease, 'cloudRunStarted.lease') };
}

export function parseOrgCloudRunRequest(value: unknown): OrgCloudRunRequest {
  const root = readObject(REQUEST, value, 'cloudRun');
  const request: OrgCloudRunRequest = {
    host: readString(REQUEST, root.host, 'cloudRun.host', { max: 128, pattern: HOST_PATTERN }),
    envelopeSha256: readString(REQUEST, root.envelopeSha256, 'cloudRun.envelopeSha256', { max: 64, pattern: SHA256_PATTERN }),
  };
  const instruction = readOptionalString(REQUEST, root.instruction, 'cloudRun.instruction', { max: MAX_CLOUD_INSTRUCTION_CHARS });
  if (instruction !== undefined) request.instruction = instruction;
  if (root.placement !== undefined && root.placement !== null) request.placement = parseOrgPlacementRequest(root.placement, 'cloudRun.placement');
  return request;
}

export type EnvelopeStateCheck =
  | { status: 'fresh' }
  | { status: 'stale'; reason: string }
  | { status: 'unverified'; reason: string };

/**
 * Decides whether the stored envelope is the state the cloud host left. A checkpoint counts only when the cloud host
 * released it; any other checkpoint is an older release and is ignored, so the envelope is compared with the transcript.
 */
export function checkEnvelopeAgainstCheckpoint(input: {
  envelope: OrgEnvelopeInfo;
  checkpoint: OrgLeaseCheckpoint | undefined;
  cloudHost: string;
  transcriptMessageCount: number;
}): EnvelopeStateCheck {
  const { envelope, checkpoint } = input;
  if (checkpoint && isCloudHostId(checkpoint.releasedBy.host, input.cloudHost)) {
    if (checkpoint.stateRef !== undefined && checkpoint.stateRef !== envelopeStateRef(envelope.sha256)) {
      return { status: 'stale', reason: 'the envelope is not the state the cloud host released with' };
    }
    if (envelope.messageCount < checkpoint.messageCount) return { status: 'stale', reason: 'the envelope covers fewer messages than the cloud checkpoint' };
    return checkpoint.stateRef === undefined ? { status: 'unverified', reason: 'the cloud checkpoint carries no stateRef' } : { status: 'fresh' };
  }
  if (envelope.messageCount < input.transcriptMessageCount) {
    return { status: 'stale', reason: 'no cloud checkpoint, and the transcript has grown past the envelope' };
  }
  return { status: 'unverified', reason: 'no cloud checkpoint to compare with' };
}

/** An envelope body: bytes in memory, or a stream that is read once and never buffered. */
export type EnvelopeBody = Uint8Array | ReadableStream<Uint8Array> | AsyncIterable<Uint8Array>;
