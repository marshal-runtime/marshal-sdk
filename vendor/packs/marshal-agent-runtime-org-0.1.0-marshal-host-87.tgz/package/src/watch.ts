import { OrgContractError, readArray, readObject, readString, type Reader } from './validate.js';

const RESPONSE: Reader = { code: 'invalid-response' };

/** What can change in a watched session; a ping names the kinds that changed since the version the client sent. */
export const WATCH_KINDS = ['transcript', 'message', 'lease', 'run', 'turn'] as const;
export type OrgWatchKind = (typeof WATCH_KINDS)[number];

/** Why a watch ended: the server's hard cap (reconnect with `after`), the session is gone or no longer readable, or the server could not read it (reconnect after a backoff). */
export const WATCH_END_REASONS = ['cap', 'gone', 'error'] as const;
export type OrgWatchEndReason = (typeof WATCH_END_REASONS)[number];

/** A version is 16 lowercase hex characters; it carries no content and is only compared for equality. */
export const WATCH_VERSION_PATTERN = /^[0-9a-f]{16}$/;
/** The content type of the watch answer. */
export const WATCH_CONTENT_TYPE = 'text/event-stream';
/** Most bytes the client buffers for one event before it treats the stream as broken. */
export const MAX_WATCH_EVENT_BYTES = 4096;
/** How often the polling fallback reports a synthetic ping, in milliseconds. */
export const DEFAULT_WATCH_POLL_MS = 15_000;
/** The shortest wait before a reconnect, in milliseconds. */
export const MIN_WATCH_RETRY_MS = 1000;
/** The longest wait before a reconnect, in milliseconds. */
export const MAX_WATCH_RETRY_MS = 60_000;

/** One event of a watch: a content-free change ping or the end of the stream. */
export type OrgWatchEvent =
  | { type: 'ping'; version: string; kinds: OrgWatchKind[] }
  | { type: 'end'; reason: OrgWatchEndReason };

/** What a follower yields: a real ping, or a synthetic one (`polled: true`) that says only "fetch again". */
export type OrgFollowEvent = { version: string | null; kinds: OrgWatchKind[]; polled: boolean };

/** True for a string that can be sent as `after`. */
export function isWatchVersion(value: unknown): value is string {
  return typeof value === 'string' && WATCH_VERSION_PATTERN.test(value);
}

/** Parses the data of one `ping` event. Unknown kinds are dropped; a bad version rejects the event. */
export function parseWatchPing(data: unknown): Extract<OrgWatchEvent, { type: 'ping' }> {
  const root = readObject(RESPONSE, data, 'ping');
  const version = readString(RESPONSE, root.version, 'ping.version', { max: 16, min: 16, pattern: WATCH_VERSION_PATTERN });
  const kinds = readArray<OrgWatchKind | undefined>(RESPONSE, root.kinds, 'ping.kinds', WATCH_KINDS.length * 4, (kind) =>
    (WATCH_KINDS as readonly unknown[]).includes(kind) ? (kind as OrgWatchKind) : undefined,
  ).filter((kind): kind is OrgWatchKind => kind !== undefined);
  return { type: 'ping', version, kinds: [...new Set(kinds)] };
}

/** Parses the data of one `end` event; an unknown reason reads as `gone`. */
export function parseWatchEnd(data: unknown): Extract<OrgWatchEvent, { type: 'end' }> {
  const root = readObject(RESPONSE, data, 'end');
  const reason = (WATCH_END_REASONS as readonly unknown[]).includes(root.reason) ? (root.reason as OrgWatchEndReason) : 'gone';
  return { type: 'end', reason };
}

/** Reads a server-sent events body and yields the `ping` and `end` events; comments, `retry` and unknown events are skipped. */
export async function* readWatchEvents(body: ReadableStream<Uint8Array>): AsyncGenerator<OrgWatchEvent> {
  const reader = body.getReader();
  const decoder = new TextDecoder();
  let buffer = '';
  let pending = '';
  try {
    for (;;) {
      const chunk = await reader.read();
      if (chunk.done) return;
      pending += decoder.decode(chunk.value, { stream: true });
      const held = pending.endsWith('\r') ? '\r' : '';
      buffer += pending.slice(0, pending.length - held.length).replace(/\r\n?/g, '\n');
      pending = held;
      if (buffer.length > MAX_WATCH_EVENT_BYTES && !buffer.includes('\n\n')) throw new OrgContractError('invalid-response', 'watch', 'an event is too large');
      let boundary = buffer.indexOf('\n\n');
      while (boundary !== -1) {
        const parsed = parseBlock(buffer.slice(0, boundary));
        buffer = buffer.slice(boundary + 2);
        if (parsed) yield parsed;
        boundary = buffer.indexOf('\n\n');
      }
    }
  } finally {
    await reader.cancel().catch(() => undefined);
  }
}

function parseBlock(block: string): OrgWatchEvent | undefined {
  let name = 'message';
  const data: string[] = [];
  for (const line of block.split('\n')) {
    if (line.startsWith(':')) continue;
    const colon = line.indexOf(':');
    const field = colon === -1 ? line : line.slice(0, colon);
    const value = colon === -1 ? '' : line.slice(colon + 1).replace(/^ /, '');
    if (field === 'event') name = value;
    else if (field === 'data') data.push(value);
  }
  if (name !== 'ping' && name !== 'end') return undefined;
  let parsed: unknown;
  try {
    parsed = JSON.parse(data.join('\n'));
  } catch {
    throw new OrgContractError('invalid-response', name, 'data is not JSON');
  }
  return name === 'ping' ? parseWatchPing(parsed) : parseWatchEnd(parsed);
}
