import { readPrincipal, readUserPrincipal, type Principal, type UserPrincipal } from './principals.js';
import {
  MAX_LONG_TEXT,
  MAX_SHORT_TEXT,
  fail,
  readArray,
  readObject,
  readOptionalString,
  readString,
  readUrl,
  type Reader,
} from './validate.js';

const RESPONSE: Reader = { code: 'invalid-response' };

export const MAX_WORKSPACES = 500;
export const MAX_DIRECTORY_RESULTS = 50;

export type OrgIdentity = {
  orgId: string;
  principal: UserPrincipal;
  email: string;
  displayName: string;
  groups: Principal[];
  roles: string[];
};

export type OrgWorkspaceId = `ws:${string}`;

export type OrgWorkspaceRepository = {
  /** Clone URL or `owner/name`, as the organization names it. */
  repository: string;
  defaultBranch: string;
};

export type OrgWorkspace = {
  id: OrgWorkspaceId;
  displayName: string;
  description?: string;
  repositories: OrgWorkspaceRepository[];
  /** The knowledge endpoint (for example a Brain URL) sessions in this workspace read from. */
  knowledgeUrl?: string;
  /** A named data boundary; data labelled with it must not leave sessions of this workspace. */
  dataBoundary?: string;
};

export type DirectoryEntryKind = 'user' | 'group';

export type DirectoryEntry = {
  principal: Principal;
  kind: DirectoryEntryKind;
  displayName: string;
  email?: string;
};

export type SessionRole = 'viewer' | 'collaborator' | 'driver' | 'owner';
export const SESSION_ROLES: readonly SessionRole[] = ['viewer', 'collaborator', 'driver', 'owner'];

export function roleAllows(granted: SessionRole, needed: SessionRole): boolean {
  return SESSION_ROLES.indexOf(granted) >= SESSION_ROLES.indexOf(needed);
}

const WORKSPACE_ID_PATTERN = /^ws:[a-z0-9][a-z0-9-]{0,62}$/;
const BRANCH_PATTERN = /^[^\s~^:?*[\\]{1,255}$/;
const ROLE_PATTERN = /^[A-Za-z0-9._:-]{1,128}$/;

export function isOrgWorkspaceId(value: unknown): value is OrgWorkspaceId {
  return typeof value === 'string' && WORKSPACE_ID_PATTERN.test(value);
}

export function parseOrgIdentity(value: unknown): OrgIdentity {
  const root = readObject(RESPONSE, value, 'identity');
  const email = readString(RESPONSE, root.email, 'identity.email', { max: 320 });
  if (!email.includes('@')) fail(RESPONSE, 'identity.email', 'must be an email address');
  return {
    orgId: readString(RESPONSE, root.orgId, 'identity.orgId', { max: 63 }),
    principal: readUserPrincipal(RESPONSE, root.principal, 'identity.principal'),
    email,
    displayName: readString(RESPONSE, root.displayName, 'identity.displayName'),
    groups: readArray(RESPONSE, root.groups ?? [], 'identity.groups', 256, (entry, path) => readPrincipal(RESPONSE, entry, path)),
    roles: readArray(RESPONSE, root.roles ?? [], 'identity.roles', 256, (entry, path) =>
      readString(RESPONSE, entry, path, { max: 128, pattern: ROLE_PATTERN }),
    ),
  };
}

export function parseOrgWorkspace(value: unknown, path = 'workspace'): OrgWorkspace {
  const root = readObject(RESPONSE, value, path);
  const id = readString(RESPONSE, root.id, `${path}.id`, { max: 66 });
  if (!isOrgWorkspaceId(id)) fail(RESPONSE, `${path}.id`, 'must look like ws:<lowercase-name>');
  const workspace: OrgWorkspace = {
    id,
    displayName: readString(RESPONSE, root.displayName, `${path}.displayName`),
    repositories: readArray(RESPONSE, root.repositories ?? [], `${path}.repositories`, 64, (entry, entryPath) => {
      const repository = readObject(RESPONSE, entry, entryPath);
      return {
        repository: readString(RESPONSE, repository.repository, `${entryPath}.repository`, { max: 512 }),
        defaultBranch: readString(RESPONSE, repository.defaultBranch, `${entryPath}.defaultBranch`, {
          pattern: BRANCH_PATTERN,
        }),
      };
    }),
  };
  const description = readOptionalString(RESPONSE, root.description, `${path}.description`, { max: MAX_LONG_TEXT });
  if (description !== undefined) workspace.description = description;
  if (root.knowledgeUrl !== undefined && root.knowledgeUrl !== null) {
    workspace.knowledgeUrl = readUrl(RESPONSE, root.knowledgeUrl, `${path}.knowledgeUrl`, { allowLoopbackHttp: true });
  }
  const dataBoundary = readOptionalString(RESPONSE, root.dataBoundary, `${path}.dataBoundary`, { max: 64 });
  if (dataBoundary !== undefined) workspace.dataBoundary = dataBoundary;
  return workspace;
}

export function parseOrgWorkspaceList(value: unknown): OrgWorkspace[] {
  const root = readObject(RESPONSE, value, 'workspaces');
  return readArray(RESPONSE, root.workspaces, 'workspaces.workspaces', MAX_WORKSPACES, (entry, path) =>
    parseOrgWorkspace(entry, path),
  );
}

export function parseDirectoryResults(value: unknown): DirectoryEntry[] {
  const root = readObject(RESPONSE, value, 'directory');
  return readArray(RESPONSE, root.entries, 'directory.entries', MAX_DIRECTORY_RESULTS, (entry, path) => {
    const item = readObject(RESPONSE, entry, path);
    const kind = item.kind;
    if (kind !== 'user' && kind !== 'group') fail(RESPONSE, `${path}.kind`, 'must be user or group');
    const result: DirectoryEntry = {
      principal: readPrincipal(RESPONSE, item.principal, `${path}.principal`),
      kind,
      displayName: readString(RESPONSE, item.displayName, `${path}.displayName`, { max: MAX_SHORT_TEXT }),
    };
    const email = readOptionalString(RESPONSE, item.email, `${path}.email`, { max: 320 });
    if (email !== undefined) result.email = email;
    return result;
  });
}
