import { randomBytes } from 'node:crypto';
import type { RoomTextUpdate } from './text-types.js';
import type { UserPrincipal } from '../principals.js';
import {
  DEDUPE_RECHECK_MS,
  MAX_ROOM_CHANGES_PER_SECOND,
  PRESENCE_TTL_MS,
  type RoomActor,
  type RoomChange,
  type RoomId,
  type RoomOp,
  type RoomPresenceEntry,
  type RoomRecordKey,
} from './protocol.js';
import { roomIfSeqHolds } from './reducer.js';

/**
 * The room bus orders changes without a database on the path: one atomic step checks the change id for a retry, checks
 * `ifSeq` against the record's last position, takes the next position, appends to the room's short log and fans the
 * change out. It also holds presence. Implementations: memory (this file; tests, the local organization, one instance)
 * and Redis (the rooms service). Everything above the bus is identical between them.
 *
 * Epoch: when the bus has no state for a room (first use, Redis failover, restart) it starts a new epoch whose positions
 * continue from the store's head, and announces it with an `epoch` event. Changes that were ordered but not yet stored are
 * gone from the bus; their authors' desktops still hold them and resend.
 */
export interface RoomBus {
  /** The room's epoch and positions, starting a new epoch when the bus holds nothing for it. */
  state(room: RoomId): Promise<RoomBusRoomState>;
  order(input: RoomBusOrderInput): Promise<RoomBusOrderResult>;
  /** Ordered changes after `afterSeq`, oldest first, or `undefined` when they are older than the short log (read the store). */
  recent(room: RoomId, afterSeq: number): Promise<RoomChange[] | undefined>;
  /** For the drainer: up to `max` ordered changes above the durable position, oldest first. */
  undrained(room: RoomId, max: number): Promise<RoomChange[]>;
  /** Rooms with changes above their durable position. */
  pendingRooms(): Promise<RoomId[]>;
  /** The store has every change of `epoch` through `through`; publishes `durable`. Ignored for another epoch. */
  markDurable(room: RoomId, epoch: string, through: number): Promise<void>;
  setPresence(room: RoomId, entry: RoomPresenceEntry): Promise<void>;
  presence(room: RoomId): Promise<RoomPresenceEntry[]>;
  /** Removes presence older than the expiry and publishes `left` for each. Redis expires keys itself and only publishes. */
  sweepPresence(): Promise<void>;
  subscribe(listener: (event: RoomBusEvent) => void): () => void;
}

export type RoomBusRoomState = { epoch: string; head: number; durable: number };

export type RoomBusOrderInput = {
  room: RoomId;
  id: string;
  author: UserPrincipal;
  actor: RoomActor;
  at: string;
  record: RoomRecordKey;
  type: string;
  op: RoomOp;
  set?: Record<string, unknown>;
  text?: Record<string, RoomTextUpdate>;
  base?: number;
  ifSeq?: number;
};

export type RoomBusOrderResult =
  | { kind: 'ordered'; change: RoomChange }
  /** A retry: the change already has this position (possibly from an earlier epoch, then it is at or below durable). */
  | { kind: 'duplicate'; seq: number; epoch: string }
  | { kind: 'conflict'; lastSeq: number }
  | { kind: 'busy' };

export type RoomBusEvent =
  | { kind: 'change'; room: RoomId; change: RoomChange }
  | { kind: 'durable'; room: RoomId; epoch: string; through: number }
  | { kind: 'presence'; room: RoomId; entry: RoomPresenceEntry }
  | { kind: 'left'; room: RoomId; principal: UserPrincipal; client: string }
  | { kind: 'epoch'; room: RoomId; epoch: string; head: number; durable: number };

/** What the bus reads from the system of record when it starts an epoch or meets a record or change id it does not hold. */
export interface RoomStoreReader {
  /** The last stored position. */
  head(room: RoomId): Promise<number>;
  /** The last stored position that changed this record (`max(updated_seq, deleted_seq)`), if any. */
  recordSeq(room: RoomId, record: RoomRecordKey): Promise<number | undefined>;
  /** The stored position of a change by author and id, if stored. */
  changeSeq(room: RoomId, author: UserPrincipal, id: string): Promise<number | undefined>;
}

export type InMemoryRoomBusOptions = {
  store: RoomStoreReader;
  now?: () => number;
  presenceTtlMs?: number;
  /** How long changes at or below durable stay in the short log. Default 10 minutes. */
  shortLogMs?: number;
  maxChangesPerSecond?: number;
};

type MemoryRoom = {
  epoch: string;
  head: number;
  durable: number;
  startedAt: number;
  log: { change: RoomChange; orderedAt: number }[];
  ids: Map<string, number>;
  records: Map<RoomRecordKey, number>;
  recentOrders: number[];
};

export class InMemoryRoomBus implements RoomBus {
  private readonly rooms = new Map<RoomId, MemoryRoom>();
  private readonly starting = new Map<RoomId, Promise<MemoryRoom>>();
  private readonly presenceEntries = new Map<RoomId, Map<string, RoomPresenceEntry & { seenAt: number }>>();
  private readonly listeners = new Set<(event: RoomBusEvent) => void>();
  private readonly now: () => number;
  private readonly presenceTtlMs: number;
  private readonly shortLogMs: number;
  private readonly maxChangesPerSecond: number;

  constructor(private readonly options: InMemoryRoomBusOptions) {
    this.now = options.now ?? Date.now;
    this.presenceTtlMs = options.presenceTtlMs ?? PRESENCE_TTL_MS;
    this.shortLogMs = options.shortLogMs ?? 10 * 60 * 1000;
    this.maxChangesPerSecond = options.maxChangesPerSecond ?? MAX_ROOM_CHANGES_PER_SECOND;
  }

  /** Forgets everything, as a restart or a failover would. The next use of each room starts a new epoch. */
  loseState(): RoomId[] {
    const known = [...this.rooms.keys()];
    this.rooms.clear();
    this.starting.clear();
    this.presenceEntries.clear();
    return known;
  }

  async state(room: RoomId): Promise<RoomBusRoomState> {
    const state = await this.load(room);
    return { epoch: state.epoch, head: state.head, durable: state.durable };
  }

  async order(input: RoomBusOrderInput): Promise<RoomBusOrderResult> {
    const state = await this.load(input.room);
    const idKey = `${input.author}\u0000${input.id}`;
    if (!state.ids.has(idKey) && this.now() - state.startedAt < DEDUPE_RECHECK_MS) {
      const stored = await this.options.store.changeSeq(input.room, input.author, input.id);
      if (stored !== undefined && !state.ids.has(idKey)) state.ids.set(idKey, stored);
    }
    if (input.ifSeq !== undefined && !state.records.has(input.record)) {
      const stored = await this.options.store.recordSeq(input.room, input.record);
      if (stored !== undefined && !state.records.has(input.record)) state.records.set(input.record, stored);
    }
    // From here on nothing awaits: this is the atomic step.
    if (this.rooms.get(input.room) !== state) return this.order(input);
    const known = state.ids.get(idKey);
    if (known !== undefined) return { kind: 'duplicate', seq: known, epoch: state.epoch };
    const lastSeq = state.records.get(input.record);
    if (!roomIfSeqHolds(lastSeq, input.ifSeq)) return { kind: 'conflict', lastSeq: lastSeq ?? 0 };
    const now = this.now();
    state.recentOrders = state.recentOrders.filter((at) => now - at < 1000);
    if (state.recentOrders.length >= this.maxChangesPerSecond) return { kind: 'busy' };
    state.recentOrders.push(now);
    state.head += 1;
    const change: RoomChange = {
      seq: state.head,
      epoch: state.epoch,
      id: input.id,
      author: input.author,
      actor: input.actor,
      at: input.at,
      record: input.record,
      type: input.type,
      op: input.op,
    };
    if (input.set !== undefined) change.set = input.set;
    if (input.text !== undefined) change.text = input.text;
    if (input.base !== undefined) change.base = input.base;
    state.log.push({ change, orderedAt: now });
    state.ids.set(idKey, change.seq);
    state.records.set(input.record, change.seq);
    this.emit({ kind: 'change', room: input.room, change });
    return { kind: 'ordered', change };
  }

  async recent(room: RoomId, afterSeq: number): Promise<RoomChange[] | undefined> {
    const state = await this.load(room);
    this.trim(state);
    const oldest = state.log[0]?.change.seq ?? state.head + 1;
    if (afterSeq + 1 < oldest && afterSeq < state.head) return undefined;
    return state.log.filter((entry) => entry.change.seq > afterSeq).map((entry) => entry.change);
  }

  async undrained(room: RoomId, max: number): Promise<RoomChange[]> {
    const state = this.rooms.get(room);
    if (!state) return [];
    return state.log.filter((entry) => entry.change.seq > state.durable).slice(0, max).map((entry) => entry.change);
  }

  async pendingRooms(): Promise<RoomId[]> {
    return [...this.rooms].filter(([, state]) => state.head > state.durable).map(([room]) => room);
  }

  async markDurable(room: RoomId, epoch: string, through: number): Promise<void> {
    const state = this.rooms.get(room);
    if (!state || state.epoch !== epoch || through <= state.durable) return;
    state.durable = Math.min(through, state.head);
    this.trim(state);
    this.emit({ kind: 'durable', room, epoch, through: state.durable });
  }

  async setPresence(room: RoomId, entry: RoomPresenceEntry): Promise<void> {
    let entries = this.presenceEntries.get(room);
    if (!entries) this.presenceEntries.set(room, (entries = new Map()));
    entries.set(`${entry.principal}\u0000${entry.client}`, { ...entry, seenAt: this.now() });
    this.emit({ kind: 'presence', room, entry });
  }

  async presence(room: RoomId): Promise<RoomPresenceEntry[]> {
    return [...(this.presenceEntries.get(room)?.values() ?? [])].map(({ seenAt: _seenAt, ...entry }) => entry);
  }

  /** Drops one client's presence at once (its socket closed). */
  async dropPresence(room: RoomId, principal: UserPrincipal, client: string): Promise<void> {
    if (this.presenceEntries.get(room)?.delete(`${principal}\u0000${client}`)) this.emit({ kind: 'left', room, principal, client });
  }

  async sweepPresence(): Promise<void> {
    const now = this.now();
    for (const [room, entries] of this.presenceEntries) {
      for (const [key, entry] of entries) {
        if (now - entry.seenAt < this.presenceTtlMs) continue;
        entries.delete(key);
        this.emit({ kind: 'left', room, principal: entry.principal, client: entry.client });
      }
    }
  }

  subscribe(listener: (event: RoomBusEvent) => void): () => void {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  }

  private emit(event: RoomBusEvent): void {
    for (const listener of [...this.listeners]) listener(event);
  }

  private trim(state: MemoryRoom): void {
    const cutoff = this.now() - this.shortLogMs;
    while (state.log.length > 0 && state.log[0]!.change.seq <= state.durable && state.log[0]!.orderedAt < cutoff) state.log.shift();
  }

  private load(room: RoomId): Promise<MemoryRoom> {
    const existing = this.rooms.get(room);
    if (existing) return Promise.resolve(existing);
    let starting = this.starting.get(room);
    if (!starting) {
      starting = this.options.store.head(room).then((head) => {
        const current = this.rooms.get(room);
        if (current) return current;
        const state: MemoryRoom = {
          epoch: `e-${randomBytes(6).toString('hex')}`,
          head,
          durable: head,
          startedAt: this.now(),
          log: [],
          ids: new Map(),
          records: new Map(),
          recentOrders: [],
        };
        this.rooms.set(room, state);
        this.starting.delete(room);
        this.emit({ kind: 'epoch', room, epoch: state.epoch, head, durable: head });
        return state;
      });
      this.starting.set(room, starting);
    }
    return starting;
  }
}
