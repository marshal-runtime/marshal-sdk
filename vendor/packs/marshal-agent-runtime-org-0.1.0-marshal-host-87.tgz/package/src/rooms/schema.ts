import { isPrincipal } from '../principals.js';
import { isRoomPosition } from './positions.js';
import {
  MAX_ROOM_CHANGE_BYTES,
  isRoomFieldName,
  isRoomRecordKey,
  jsonBytes,
  type RoomOp,
  type RoomRole,
} from './protocol.js';
import { MAX_ROOM_TEXT_UPDATE_BYTES, type RoomTextUpdate } from './text-types.js';
import { CONVERSATION_MESSAGE_ROLES, CONVERSATION_MESSAGE_STATES } from './conversation-types.js';

/**
 * Field types an extension declares for its record types (`contributes.rooms[].records.<type>.fields.<name>`). `text` is
 * mergeable text: written only through `text` entries (Yjs updates), never with `set`.
 */
export const ROOM_FIELD_TYPES = ['value', 'position', 'file', 'text'] as const;
export type RoomFieldType = (typeof ROOM_FIELD_TYPES)[number];

/**
 * One room kind an extension contributes. The same shape `contributes.rooms` has in a runtime extension manifest
 * (validated by `@marshal/agent-runtime-extensions` when the manifest loads). `kind` is the short name; the room's
 * full kind is `<extension identity>/<kind>`.
 */
export type RoomKindSchema = {
  kind: string;
  schemaVersion: number;
  records: Record<string, { fields: Record<string, RoomFieldType> }>;
};

/** Record types every room has without declaring them. */
export const BUILT_IN_ROOM_RECORD_TYPES = ['message', 'comment', 'request'] as const;
export type BuiltInRoomRecordType = (typeof BUILT_IN_ROOM_RECORD_TYPES)[number];

export const ROOM_REQUEST_STATUSES = ['open', 'claimed', 'done', 'failed', 'cancelled'] as const;
export type RoomRequestStatus = (typeof ROOM_REQUEST_STATUSES)[number];

/** The team's cloud agent as a request addressee. */
export const ROOM_TEAM_AGENT = 'agent:team' as const;

/**
 * `message:<id>`: a chat line in the room. `text` is mergeable text (a streaming reply is small appends). `mentions` are
 * principals or `agent:team`. `role`, `author`, `state`, `turn`, `replyTo`, `at` and `truncated` are used by conversation rooms (`ConversationMessageFields`).
 */
export type RoomMessageFields = {
  text: string;
  mentions?: string[];
  role?: string;
  author?: string;
  state?: string;
  turn?: string;
  replyTo?: string;
  at?: string;
  truncated?: boolean;
};
/** `comment:<id>`: a comment on another record. */
export type RoomCommentFields = { on: string; text: string; resolved?: boolean };
/**
 * `request:<id>`: asking a member or the team's agent to do something. Asking is structured; nothing is guessed from text.
 * `about`: the key of the record the request is about (`<type>:<id>`), when there is one.
 */
export type RoomRequestFields = { to: string; text: string; status: RoomRequestStatus; about?: string; claimedBy?: string; result?: string };

export const BUILT_IN_ROOM_SCHEMAS: Record<BuiltInRoomRecordType, { fields: Record<string, RoomFieldType> }> = {
  message: {
    fields: { text: 'text', mentions: 'value', role: 'value', author: 'value', state: 'value', turn: 'value', replyTo: 'value', at: 'value', truncated: 'value' },
  },
  comment: { fields: { on: 'value', text: 'value', resolved: 'value' } },
  request: { fields: { to: 'value', text: 'value', status: 'value', about: 'value', claimedBy: 'value', result: 'value' } },
};

const REQUEST_TRANSITIONS: Record<RoomRequestStatus, readonly RoomRequestStatus[]> = {
  open: ['claimed', 'cancelled'],
  claimed: ['done', 'failed', 'cancelled'],
  done: [],
  failed: [],
  cancelled: [],
};

export function roomRequestTransitionAllowed(from: RoomRequestStatus, to: RoomRequestStatus): boolean {
  return REQUEST_TRANSITIONS[from].includes(to);
}

const ROLE_RANK: Record<RoomRole, number> = { viewer: 0, collaborator: 1, driver: 2, owner: 3 };

export function roomRoleAtLeast(role: RoomRole, minimum: RoomRole): boolean {
  return ROLE_RANK[role] >= ROLE_RANK[minimum];
}

/** What a role may do. Writing a `request` (asking someone or an agent to work) needs driver; other records need collaborator. */
export type RoomAction = { kind: 'read' } | { kind: 'presence' } | { kind: 'write'; type: string } | { kind: 'grant' } | { kind: 'update-room' };

export function roomRoleAllows(role: RoomRole, action: RoomAction): boolean {
  switch (action.kind) {
    case 'read':
    case 'presence':
      return true;
    case 'write':
      return roomRoleAtLeast(role, action.type === 'request' ? 'driver' : 'collaborator');
    case 'grant':
    case 'update-room':
      return role === 'owner';
  }
}

export const ROOM_WRITE_PROBLEMS = [
  'unknown-type',
  'unknown-field',
  'invalid-value',
  /** No longer produced (text fields are writable since pack marshal-host-86); kept so existing switches still compile. */
  'text-not-supported',
  'too-large',
  'invalid-key',
  /** A `set` value for a `text` field: write it through the text handle (`Room.set` does this for a string). */
  'text-needs-edit',
] as const;
export type RoomWriteProblemCode = (typeof ROOM_WRITE_PROBLEMS)[number];
export type RoomWriteCheck = { ok: true } | { ok: false; code: RoomWriteProblemCode; field?: string };

/**
 * Checks a local change against the extension's declared schema before it leaves the desktop. The server does not read
 * fields, so this is where field types are enforced. `text` fields take `text` entries only.
 */
export function checkRoomWrite(
  schema: RoomKindSchema | undefined,
  change: { record: string; type: string; op: RoomOp; set?: Record<string, unknown>; text?: Record<string, RoomTextUpdate> },
): RoomWriteCheck {
  if (!isRoomRecordKey(change.record) || !change.record.startsWith(`${change.type}:`)) return { ok: false, code: 'invalid-key' };
  const declared = (BUILT_IN_ROOM_SCHEMAS as Record<string, { fields: Record<string, RoomFieldType> }>)[change.type] ?? schema?.records[change.type];
  if (!declared) return { ok: false, code: 'unknown-type' };
  if (change.op === 'delete') return { ok: true };
  const set = change.set ?? {};
  if (jsonBytes(set) > MAX_ROOM_CHANGE_BYTES - 1024) return { ok: false, code: 'too-large' };
  for (const [name, value] of Object.entries(set)) {
    if (!isRoomFieldName(name)) return { ok: false, code: 'unknown-field', field: name };
    const fieldType = declared.fields[name];
    if (!fieldType) return { ok: false, code: 'unknown-field', field: name };
    if (fieldType === 'text') return { ok: false, code: 'text-needs-edit', field: name };
    if (value === null) continue;
    if (fieldType === 'position' && !isRoomPosition(value)) return { ok: false, code: 'invalid-value', field: name };
    if (fieldType === 'file' && !isRoomFileRefValue(value)) return { ok: false, code: 'invalid-value', field: name };
  }
  for (const [name, entry] of Object.entries(change.text ?? {})) {
    if (declared.fields[name] !== 'text') return { ok: false, code: 'unknown-field', field: name };
    if ('update' in entry && entry.update.length > MAX_ROOM_TEXT_UPDATE_BYTES) return { ok: false, code: 'too-large', field: name };
  }
  if (change.type in BUILT_IN_ROOM_SCHEMAS) {
    const problem = checkBuiltIn(change.type as BuiltInRoomRecordType, set);
    if (problem) return { ok: false, code: 'invalid-value', field: problem };
  }
  return { ok: true };
}

function isRoomFileRefValue(value: unknown): boolean {
  if (typeof value !== 'object' || value === null || Array.isArray(value)) return false;
  const ref = value as Record<string, unknown>;
  return (
    typeof ref.sha256 === 'string' && /^[0-9a-f]{64}$/.test(ref.sha256)
    && typeof ref.bytes === 'number' && Number.isInteger(ref.bytes) && ref.bytes >= 0
    && typeof ref.contentType === 'string' && ref.contentType.length > 0 && ref.contentType.length <= 256
  );
}

function isAddressee(value: unknown): boolean {
  return value === ROOM_TEAM_AGENT || isPrincipal(value);
}

function checkBuiltIn(type: BuiltInRoomRecordType, set: Record<string, unknown>): string | undefined {
  const isText = (value: unknown) => typeof value === 'string' && value.length <= 32_000;
  for (const [name, value] of Object.entries(set)) {
    if (value === null) continue;
    switch (`${type}.${name}`) {
      case 'comment.text':
      case 'request.text':
      case 'request.result':
        if (!isText(value)) return name;
        break;
      case 'message.mentions':
        if (!Array.isArray(value) || value.length > 64 || !value.every(isAddressee)) return name;
        break;
      case 'comment.on':
      case 'request.about':
        if (!isRoomRecordKey(value)) return name;
        break;
      case 'message.role':
        if (!(CONVERSATION_MESSAGE_ROLES as readonly unknown[]).includes(value)) return name;
        break;
      case 'message.state':
        if (!(CONVERSATION_MESSAGE_STATES as readonly unknown[]).includes(value)) return name;
        break;
      case 'message.author':
        if (!isPrincipal(value)) return name;
        break;
      case 'message.turn':
        if (typeof value !== 'string' || value.length === 0 || value.length > 128) return name;
        break;
      case 'message.replyTo':
        if (!isRoomRecordKey(value)) return name;
        break;
      case 'message.at':
        if (typeof value !== 'string' || value.length > 40 || Number.isNaN(Date.parse(value))) return name;
        break;
      case 'message.truncated':
        if (typeof value !== 'boolean') return name;
        break;
      case 'comment.resolved':
        if (typeof value !== 'boolean') return name;
        break;
      case 'request.to':
      case 'request.claimedBy':
        if (!isAddressee(value)) return name;
        break;
      case 'request.status':
        if (!(ROOM_REQUEST_STATUSES as readonly unknown[]).includes(value)) return name;
        break;
    }
  }
  return undefined;
}
