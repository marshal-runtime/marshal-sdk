import { readUserPrincipal, type UserPrincipal } from '../principals.js';
import { fail, readArray, readObject, readString, type Reader } from '../validate.js';
import { MAX_ROOM_TEXT_RESET_FRAME_BYTES, MAX_ROOM_TEXT_UPDATE_BYTES, type RoomTextState, type RoomTextUpdate } from './text-types.js';

/**
 * Rooms (feature `rooms`): a shared, ordered, authored record set that every member's desktop, and the team's cloud agent,
 * reads and writes live over one socket. The server orders and stores changes; it never reads `set`.
 *
 * Socket: `GET {socketUrl}` upgrades to a WebSocket. Frames are JSON objects with a `t` field, version `ROOMS_PROTOCOL_VERSION`.
 */
export const ROOMS_PROTOCOL_VERSION = 1 as const;

/** Most bytes of one change's JSON as sent in an `op` frame. Larger answers `nack too-large`. */
export const MAX_ROOM_CHANGE_BYTES = 64 * 1024;
/** Most bytes of one record's fields. */
export const MAX_ROOM_RECORD_BYTES = 256 * 1024;
/** Most live (not deleted) records in one room. */
export const MAX_ROOM_RECORDS = 20_000;
/** Most bytes of record data in one room. */
export const MAX_ROOM_DATA_BYTES = 64 * 1024 * 1024;
/** Most members (grants) of one room. */
export const MAX_ROOM_MEMBERS = 256;
/** Largest room file. */
export const MAX_ROOM_FILE_BYTES = 5 * 1024 * 1024 * 1024;
/** Most changes one room accepts per second; more answers `nack busy`. */
export const MAX_ROOM_CHANGES_PER_SECOND = 200;
/** Most presence updates one client sends per second; more are dropped. */
export const MAX_PRESENCE_UPDATES_PER_SECOND = 30;
/** Most bytes of one presence state's JSON. */
export const MAX_PRESENCE_BYTES = 4 * 1024;
/** Presence expires this long after its last update; the others then get `left`. */
export const PRESENCE_TTL_MS = 15_000;
/** The drainer stores a batch at least this often... */
export const DURABLE_BATCH_MS = 25;
/** ...or once this many changes wait. */
export const DURABLE_BATCH_CHANGES = 100;
/** Most changes one `changes` frame carries; `more: true` says another frame follows. */
export const MAX_CHANGES_PER_FRAME = 500;
/** Most rooms one socket has joined at once. */
export const MAX_JOINED_ROOMS = 256;
/** How long a fresh epoch re-checks change ids against the store (the bus forgot the ids of the previous epoch). */
export const DEDUPE_RECHECK_MS = 10 * 60 * 1000;

const ROOM_ID_PATTERN = /^[A-Za-z0-9][A-Za-z0-9._:-]{0,127}$/;
const RECORD_TYPE_PATTERN = /^[a-z][a-z0-9-]{0,63}$/;
const RECORD_KEY_PATTERN = /^([a-z][a-z0-9-]{0,63}):[A-Za-z0-9._:~-]{1,128}$/;
const CHANGE_ID_PATTERN = /^[A-Za-z0-9][A-Za-z0-9._:-]{0,127}$/;
const CLIENT_ID_PATTERN = /^[A-Za-z0-9][A-Za-z0-9._:-]{0,127}$/;
const EPOCH_PATTERN = /^[A-Za-z0-9][A-Za-z0-9._:-]{0,63}$/;
const FIELD_NAME_PATTERN = /^[A-Za-z][A-Za-z0-9_]{0,63}$/;
const BASE64_PATTERN = /^[A-Za-z0-9+/]*={0,2}$/;
/** `<extension identity>/<kind>`, e.g. `@zyg/page-generator/page`. */
const ROOM_KIND_PATTERN = /^(?:@[a-z0-9][a-z0-9._~-]*\/)?[a-z0-9][a-z0-9._~-]*\/[a-z][a-z0-9-]{0,63}$/;
const RUNTIME_PATTERN = /^[A-Za-z0-9][A-Za-z0-9._:-]{0,63}$/;

export const ROOM_ROLES = ['viewer', 'collaborator', 'driver', 'owner'] as const;
export type RoomRole = (typeof ROOM_ROLES)[number];

/** Why a single `op` was refused. A client acts on the code, never on any text. */
export const ROOM_NACK_CODES = ['forbidden', 'conflict', 'too-large', 'busy', 'invalid', 'not-joined', 'room-full'] as const;
export type RoomNackCode = (typeof ROOM_NACK_CODES)[number];

/** Why a socket or a join was refused. `unauthorized` and `unsupported-version` close the socket. */
export const ROOM_ERROR_CODES = ['unauthorized', 'unsupported-version', 'hello-required', 'forbidden', 'not-found', 'invalid', 'too-many-rooms'] as const;
export type RoomErrorCode = (typeof ROOM_ERROR_CODES)[number];

/** Why the server is closing the socket on its own. Every reason means: reconnect now (with backoff), rejoin with `have`. */
export const ROOM_BYE_REASONS = ['deploy', 'max-age', 'overload', 'shutdown'] as const;
export type RoomByeReason = (typeof ROOM_BYE_REASONS)[number];

export type RoomId = string;
export type RoomRecordKey = `${string}:${string}`;

/**
 * Who actually made a change, on behalf of `author` (always a person). Set by the host from the invocation's principal kind;
 * an extension cannot choose it. The server checks its shape only.
 */
export type RoomActor =
  | { kind: 'person' }
  | { kind: 'agent'; host: 'desktop'; session: string; runtime: string; model?: string }
  | { kind: 'agent'; host: 'cloud'; run: string; askedBy: UserPrincipal };

export type RoomOp = 'set' | 'delete';

/** A position in the room's order, as the bus assigned it. */
export type RoomPosition = { epoch: string; seq: number };

/** One ordered change, as stored in the log and sent to every member. */
export type RoomChange = {
  seq: number;
  epoch: string;
  /** Chosen by the sender; a retry with the same id is answered with the first position. Unique per room and author. */
  id: string;
  author: UserPrincipal;
  actor: RoomActor;
  /** When the server received and ordered the change, on the server's clock (never the sender's). */
  at: string;
  record: RoomRecordKey;
  type: string;
  op: RoomOp;
  /** Only the fields this change sets (`op: set`). */
  set?: Record<string, unknown>;
  /** Mergeable text edits, field name -> update (`op: set`). A `set` change carries `set`, `text` or both. */
  text?: Record<string, RoomTextUpdate>;
  /** The record position the sender had seen when it made the change. */
  base?: number;
};

/** A field reference to a room file. */
export type RoomFileRef = { sha256: string; bytes: number; contentType: string };

export type RoomPresenceEntry = {
  principal: UserPrincipal;
  client: string;
  actor: RoomActor;
  state: unknown;
  at: string;
};

// ---- client -> server ----

export type RoomHelloFrame = { t: 'hello'; v: typeof ROOMS_PROTOCOL_VERSION; token: string; client: string };
export type RoomJoinFrame = { t: 'join'; room: RoomId; have?: RoomPosition };
/** One change. `ifSeq`: refuse with `conflict` unless the record's last position is at most this. */
export type RoomOpFrame = {
  t: 'op';
  room: RoomId;
  id: string;
  record: RoomRecordKey;
  type: string;
  op: RoomOp;
  actor: RoomActor;
  set?: Record<string, unknown>;
  /** Mergeable text edits. A `reset` entry requires `ifSeq`. */
  text?: Record<string, RoomTextUpdate>;
  base?: number;
  ifSeq?: number;
};
export type RoomPresenceSetFrame = { t: 'presence'; room: RoomId; actor: RoomActor; state: unknown };
export type RoomLeaveFrame = { t: 'leave'; room: RoomId };
export type RoomPingFrame = { t: 'ping' };
export type RoomClientFrame = RoomHelloFrame | RoomJoinFrame | RoomOpFrame | RoomPresenceSetFrame | RoomLeaveFrame | RoomPingFrame;

// ---- server -> client ----

/** `serverTime`: the server's clock (ISO) when it sent this, so a client can estimate its offset from the server. */
export type RoomWelcomeFrame = { t: 'welcome'; principal: UserPrincipal; heartbeatMs: number; serverTime?: string };
/** A socket-level or join refusal. With `room`, only that join failed. */
export type RoomErrorFrame = { t: 'error'; code: RoomErrorCode; room?: RoomId };
export type RoomJoinedFrame = { t: 'joined'; room: RoomId; role: RoomRole; epoch: string; head: number; durable: number };
/** Changes after the join's `have`, oldest first; `more: true` until the last frame of the catch-up. */
export type RoomChangesFrame = { t: 'changes'; room: RoomId; changes: RoomChange[]; more: boolean };
/**
 * The room is in a new epoch (the bus lost its state). Sent before `joined`. The client drops other people's changes above
 * `durable`, forgets the positions its own outbox changes got above `durable`, and resends them; they get new positions.
 */
export type RoomResetFrame = { t: 'reset'; room: RoomId; epoch: string; durable: number };
export type RoomAckFrame = { t: 'ack'; room: RoomId; id: string; seq: number; epoch: string };
export type RoomChangeFrame = { t: 'change'; room: RoomId; change: RoomChange };
export type RoomNackFrame = { t: 'nack'; room: RoomId; id: string; code: RoomNackCode };
export type RoomPresenceFrame = { t: 'presence'; room: RoomId } & RoomPresenceEntry;
export type RoomLeftFrame = { t: 'left'; room: RoomId; principal: UserPrincipal; client: string };
/** `serverTime`: the server's clock when it answered; with the ping's send and receive times on the client this gives the clock offset. */
export type RoomPongFrame = { t: 'pong'; serverTime?: string };
/** Every change of `epoch` up to `through` is in the system of record. */
export type RoomDurableFrame = { t: 'durable'; room: RoomId; epoch: string; through: number };
export type RoomRoleFrame = { t: 'role'; room: RoomId; role: RoomRole };
export type RoomRevokedFrame = { t: 'revoked'; room: RoomId };
export type RoomByeFrame = { t: 'bye'; reason: RoomByeReason };
export type RoomServerFrame =
  | RoomWelcomeFrame
  | RoomErrorFrame
  | RoomJoinedFrame
  | RoomChangesFrame
  | RoomResetFrame
  | RoomAckFrame
  | RoomChangeFrame
  | RoomNackFrame
  | RoomPresenceFrame
  | RoomLeftFrame
  | RoomPongFrame
  | RoomDurableFrame
  | RoomRoleFrame
  | RoomRevokedFrame
  | RoomByeFrame;

// ---- HTTP beside the socket (same token, Bearer) ----

export const ROOM_ROUTES = {
  rooms: '/v1/rooms',
  room: (id: RoomId) => `/v1/rooms/${encodeURIComponent(id)}`,
  grants: (id: RoomId) => `/v1/rooms/${encodeURIComponent(id)}/grants`,
  grant: (id: RoomId, principal: string) => `/v1/rooms/${encodeURIComponent(id)}/grants/${encodeURIComponent(principal)}`,
  changes: (id: RoomId) => `/v1/rooms/${encodeURIComponent(id)}/changes`,
  records: (id: RoomId) => `/v1/rooms/${encodeURIComponent(id)}/records`,
  files: (id: RoomId) => `/v1/rooms/${encodeURIComponent(id)}/files`,
  file: (id: RoomId, sha256: string) => `/v1/rooms/${encodeURIComponent(id)}/files/${sha256}`,
} as const;

/** Discovery: with feature `rooms`, the document carries these addresses. */
export type OrgRoomsEndpoints = { apiBase: string; socketUrl: string };

/** `POST /v1/rooms`. The id is chosen by the creator, so a retried create returns the same room (200) instead of 201. */
export type RoomCreateRequest = { id: RoomId; workspaceId: string; kind: string; schemaVersion: number; title: string };
/** `PUT /v1/rooms/:id` (owner). */
export type RoomUpdateRequest = { title?: string; archived?: boolean };
/** A room as listed and read. `role` is the caller's. */
export type RoomEnvelope = {
  id: RoomId;
  workspaceId: string;
  kind: string;
  schemaVersion: number;
  title: string;
  owner: UserPrincipal;
  role: RoomRole;
  head: number;
  durable: number;
  epoch: string;
  createdAt: string;
  updatedAt: string;
  archivedAt?: string;
};
/** `GET /v1/rooms?kind=&workspaceId=`: rooms the caller can read. */
export type RoomList = { rooms: RoomEnvelope[] };
/** `POST /v1/rooms/:id/grants` (owner). Granting `owner` is refused; the owner is fixed. */
export type RoomGrantRequest = { principal: UserPrincipal; role: Exclude<RoomRole, 'owner'> };
export type RoomGrant = { principal: UserPrincipal; role: RoomRole; grantedBy: UserPrincipal; grantedAt: string };
/** `GET`, `POST` and `DELETE /v1/rooms/:id/grants[/:principal]` answer the full member list. */
export type RoomGrantList = { grants: RoomGrant[] };
/** `GET /v1/rooms/:id/changes?after=&limit=`: stored changes after `after`, oldest first. Never ahead of `durable`. */
export type RoomChangePage = { changes: RoomChange[]; more: boolean; epoch: string; durable: number };
/** One record's current state, as replayed from the log. */
export type RoomRecordState = {
  key: RoomRecordKey;
  type: string;
  fields: Record<string, unknown>;
  /** Field name -> position that last set it. */
  fieldSeqs: Record<string, number>;
  createdSeq: number;
  updatedSeq: number;
  /** A deleted record stays as a marker so a late edit does not revive it. */
  deletedSeq?: number;
  updatedBy: UserPrincipal;
  /** Merge state of each text field; its current value is also in `fields`. */
  texts?: Record<string, RoomTextState>;
};
/** `GET /v1/rooms/:id/records?after=`: records changed after `after` (all without it), as of `through` (= durable). */
export type RoomRecordPage = { records: RoomRecordState[]; through: number; epoch: string };
/** `POST /v1/rooms/:id/files`: `upload` is absent when the room already has these bytes. */
export type RoomFileUploadRequest = RoomFileRef;
export type RoomFileUpload = { ref: RoomFileRef; upload?: { url: string; method: 'PUT'; headers: Record<string, string> } };
/** `GET /v1/rooms/:id/files/:sha256`. */
export type RoomFileDownload = { ref: RoomFileRef; url: string };

// ---- validation ----

const CLIENT: Reader = { code: 'invalid-request' };
const SERVER: Reader = { code: 'invalid-response' };

export function isRoomId(value: unknown): value is RoomId {
  return typeof value === 'string' && ROOM_ID_PATTERN.test(value);
}
export function isRoomRecordType(value: unknown): value is string {
  return typeof value === 'string' && RECORD_TYPE_PATTERN.test(value);
}
export function isRoomRecordKey(value: unknown): value is RoomRecordKey {
  return typeof value === 'string' && RECORD_KEY_PATTERN.test(value);
}
/** The type part of a record key: `section:hero-2` -> `section`. */
export function roomRecordKeyType(key: RoomRecordKey): string {
  return key.slice(0, key.indexOf(':'));
}
export function isRoomChangeId(value: unknown): value is string {
  return typeof value === 'string' && CHANGE_ID_PATTERN.test(value);
}
export function isRoomKind(value: unknown): value is string {
  return typeof value === 'string' && value.length <= 280 && ROOM_KIND_PATTERN.test(value);
}
export function isRoomRole(value: unknown): value is RoomRole {
  return typeof value === 'string' && (ROOM_ROLES as readonly string[]).includes(value);
}
export function isRoomFieldName(value: unknown): value is string {
  return typeof value === 'string' && FIELD_NAME_PATTERN.test(value);
}

/** Bytes of a value's JSON encoding, as the size limits count them. */
export function jsonBytes(value: unknown): number {
  return Buffer.byteLength(JSON.stringify(value) ?? '', 'utf8');
}

function readInteger(reader: Reader, value: unknown, path: string, min: number, max = Number.MAX_SAFE_INTEGER): number {
  if (typeof value !== 'number' || !Number.isInteger(value) || value < min || value > max) fail(reader, path, `must be an integer from ${min}`);
  return value;
}
function readOptionalInteger(reader: Reader, value: unknown, path: string, min: number): number | undefined {
  return value === undefined || value === null ? undefined : readInteger(reader, value, path, min);
}
function readPattern(reader: Reader, value: unknown, path: string, pattern: RegExp, max = 128): string {
  return readString(reader, value, path, { max, pattern });
}
function readRoomId(reader: Reader, value: unknown, path: string): RoomId {
  return readPattern(reader, value, path, ROOM_ID_PATTERN);
}
function readEpoch(reader: Reader, value: unknown, path: string): string {
  return readPattern(reader, value, path, EPOCH_PATTERN, 64);
}
function readTimestamp(reader: Reader, value: unknown, path: string): string {
  const text = readString(reader, value, path, { max: 40 });
  if (Number.isNaN(Date.parse(text))) fail(reader, path, 'must be an ISO timestamp');
  return text;
}
function readEnum<T extends string>(reader: Reader, value: unknown, path: string, allowed: readonly T[]): T {
  if (typeof value !== 'string' || !(allowed as readonly string[]).includes(value)) fail(reader, path, `must be one of ${allowed.join(', ')}`);
  return value as T;
}

export function readRoomActor(reader: Reader, value: unknown, path: string): RoomActor {
  const root = readObject(reader, value, path);
  if (root.kind === 'person') return { kind: 'person' };
  if (root.kind !== 'agent') fail(reader, `${path}.kind`, 'must be person or agent');
  if (root.host === 'desktop') {
    const actor: RoomActor = {
      kind: 'agent',
      host: 'desktop',
      session: readString(reader, root.session, `${path}.session`, { max: 128 }),
      runtime: readPattern(reader, root.runtime, `${path}.runtime`, RUNTIME_PATTERN, 64),
    };
    if (root.model !== undefined && root.model !== null) actor.model = readString(reader, root.model, `${path}.model`, { max: 128 });
    return actor;
  }
  if (root.host === 'cloud') {
    return {
      kind: 'agent',
      host: 'cloud',
      run: readString(reader, root.run, `${path}.run`, { max: 128 }),
      askedBy: readUserPrincipal(reader, root.askedBy, `${path}.askedBy`),
    };
  }
  fail(reader, `${path}.host`, 'must be desktop or cloud');
}

function readFields(reader: Reader, value: unknown, path: string): Record<string, unknown> {
  const root = readObject(reader, value, path);
  for (const name of Object.keys(root)) if (!FIELD_NAME_PATTERN.test(name)) fail(reader, `${path}.${name}`, 'is not a valid field name');
  return root;
}

function readPosition(reader: Reader, value: unknown, path: string): RoomPosition {
  const root = readObject(reader, value, path);
  return { epoch: readEpoch(reader, root.epoch, `${path}.epoch`), seq: readInteger(reader, root.seq, `${path}.seq`, 0) };
}

/** Shape check of one text entry: `{gen, update}` or `{gen, reset}`, base64, within the reset frame limit (sizes are judged by `roomOpTooLarge`). */
function readTextEntries(reader: Reader, value: unknown, path: string): Record<string, RoomTextUpdate> {
  const root = readObject(reader, value, path);
  const out: Record<string, RoomTextUpdate> = {};
  for (const [name, raw] of Object.entries(root)) {
    if (!FIELD_NAME_PATTERN.test(name)) fail(reader, `${path}.${name}`, 'is not a valid field name');
    const entry = readObject(reader, raw, `${path}.${name}`);
    const gen = readInteger(reader, entry.gen, `${path}.${name}.gen`, 0);
    const keys = Object.keys(entry).filter((key) => key !== 'gen');
    if (keys.length !== 1 || (keys[0] !== 'update' && keys[0] !== 'reset')) fail(reader, `${path}.${name}`, 'must carry exactly one of update or reset');
    const payload = readString(reader, entry[keys[0]], `${path}.${name}.${keys[0]}`, { max: MAX_ROOM_TEXT_RESET_FRAME_BYTES, pattern: BASE64_PATTERN });
    if (!payload) fail(reader, `${path}.${name}.${keys[0]}`, 'must not be empty');
    out[name] = keys[0] === 'update' ? { gen, update: payload } : { gen, reset: payload };
  }
  if (!Object.keys(out).length) fail(reader, path, 'must carry at least one field');
  return out;
}

/**
 * Whether an `op` is over its size limit (answer `nack too-large`). An `op` carrying a text `reset` may be up to
 * `MAX_ROOM_TEXT_RESET_FRAME_BYTES`; every other `op` up to `MAX_ROOM_CHANGE_BYTES`; each text `update` up to
 * `MAX_ROOM_TEXT_UPDATE_BYTES`. A server checks raw frames over the reset limit before parsing.
 */
export function roomOpTooLarge(frame: Pick<RoomOpFrame, 'text'>, frameBytes: number): boolean {
  const entries = Object.values(frame.text ?? {});
  const hasReset = entries.some((entry) => 'reset' in entry);
  if (frameBytes > (hasReset ? MAX_ROOM_TEXT_RESET_FRAME_BYTES : MAX_ROOM_CHANGE_BYTES)) return true;
  return entries.some((entry) => 'update' in entry && entry.update.length > MAX_ROOM_TEXT_UPDATE_BYTES);
}

/** The change part shared by `op` frames and ordered changes. A `set` change carries `set`, `text` or both; a `delete` neither. */
function readChangeBody(reader: Reader, root: Record<string, unknown>, path: string) {
  const record = readPattern(reader, root.record, `${path}.record`, RECORD_KEY_PATTERN, 200) as RoomRecordKey;
  const type = readPattern(reader, root.type, `${path}.type`, RECORD_TYPE_PATTERN, 64);
  if (roomRecordKeyType(record) !== type) fail(reader, `${path}.record`, 'must start with its type');
  const op = readEnum<RoomOp>(reader, root.op, `${path}.op`, ['set', 'delete']);
  let set: Record<string, unknown> | undefined;
  let text: Record<string, RoomTextUpdate> | undefined;
  const hasSet = root.set !== undefined && root.set !== null;
  const hasText = root.text !== undefined && root.text !== null;
  if (op === 'set') {
    if (hasSet || !hasText) set = readFields(reader, root.set, `${path}.set`);
    if (hasText) text = readTextEntries(reader, root.text, `${path}.text`);
  } else if (hasSet || hasText) fail(reader, `${path}.${hasSet ? 'set' : 'text'}`, 'must be absent on a delete');
  return { record, type, op, set, text, base: readOptionalInteger(reader, root.base, `${path}.base`, 0) };
}

export function readRoomChange(reader: Reader, value: unknown, path: string): RoomChange {
  const root = readObject(reader, value, path);
  const body = readChangeBody(reader, root, path);
  const change: RoomChange = {
    seq: readInteger(reader, root.seq, `${path}.seq`, 1),
    epoch: readEpoch(reader, root.epoch, `${path}.epoch`),
    id: readPattern(reader, root.id, `${path}.id`, CHANGE_ID_PATTERN),
    author: readUserPrincipal(reader, root.author, `${path}.author`),
    actor: readRoomActor(reader, root.actor, `${path}.actor`),
    at: readTimestamp(reader, root.at, `${path}.at`),
    record: body.record,
    type: body.type,
    op: body.op,
  };
  if (body.set !== undefined) change.set = body.set;
  if (body.text !== undefined) change.text = body.text;
  if (body.base !== undefined) change.base = body.base;
  return change;
}

/**
 * Parses a frame a client sent. Throws `OrgContractError` with code `invalid-request`; a server answers an invalid `op`
 * with `nack invalid` (when its `room` and `id` were readable) and any other invalid frame with `error invalid`.
 * Size limits are checked by the caller against the raw frame.
 */
export function parseRoomClientFrame(value: unknown): RoomClientFrame {
  const root = readObject(CLIENT, value, 'frame');
  switch (root.t) {
    case 'hello':
      if (root.v !== ROOMS_PROTOCOL_VERSION) fail(CLIENT, 'frame.v', `must be ${ROOMS_PROTOCOL_VERSION}`);
      return {
        t: 'hello',
        v: ROOMS_PROTOCOL_VERSION,
        token: readString(CLIENT, root.token, 'frame.token', { max: 16 * 1024 }),
        client: readPattern(CLIENT, root.client, 'frame.client', CLIENT_ID_PATTERN),
      };
    case 'join': {
      const frame: RoomJoinFrame = { t: 'join', room: readRoomId(CLIENT, root.room, 'frame.room') };
      if (root.have !== undefined && root.have !== null) frame.have = readPosition(CLIENT, root.have, 'frame.have');
      return frame;
    }
    case 'op': {
      const body = readChangeBody(CLIENT, root, 'frame');
      const frame: RoomOpFrame = {
        t: 'op',
        room: readRoomId(CLIENT, root.room, 'frame.room'),
        id: readPattern(CLIENT, root.id, 'frame.id', CHANGE_ID_PATTERN),
        record: body.record,
        type: body.type,
        op: body.op,
        actor: readRoomActor(CLIENT, root.actor, 'frame.actor'),
      };
      if (body.set !== undefined) frame.set = body.set;
      if (body.text !== undefined) frame.text = body.text;
      if (body.base !== undefined) frame.base = body.base;
      const ifSeq = readOptionalInteger(CLIENT, root.ifSeq, 'frame.ifSeq', 0);
      if (ifSeq !== undefined) frame.ifSeq = ifSeq;
      if (ifSeq === undefined && Object.values(body.text ?? {}).some((entry) => 'reset' in entry)) fail(CLIENT, 'frame.ifSeq', 'is required with a text reset');
      return frame;
    }
    case 'presence':
      return { t: 'presence', room: readRoomId(CLIENT, root.room, 'frame.room'), actor: readRoomActor(CLIENT, root.actor, 'frame.actor'), state: root.state ?? null };
    case 'leave':
      return { t: 'leave', room: readRoomId(CLIENT, root.room, 'frame.room') };
    case 'ping':
      return { t: 'ping' };
    default:
      fail(CLIENT, 'frame.t', 'is not a client frame');
  }
}

/** Reads `room` and `id` of an `op` frame that failed validation, so the server can still `nack invalid` it. */
export function roomOpFrameIdentity(value: unknown): { room: RoomId; id: string } | undefined {
  if (typeof value !== 'object' || value === null) return undefined;
  const root = value as Record<string, unknown>;
  return root.t === 'op' && isRoomId(root.room) && isRoomChangeId(root.id) ? { room: root.room, id: root.id } : undefined;
}

/** Parses a frame the server sent. Throws `OrgContractError` with code `invalid-response`. */
export function parseRoomServerFrame(value: unknown): RoomServerFrame {
  const root = readObject(SERVER, value, 'frame');
  const room = () => readRoomId(SERVER, root.room, 'frame.room');
  switch (root.t) {
    case 'welcome':
      return {
        t: 'welcome',
        principal: readUserPrincipal(SERVER, root.principal, 'frame.principal'),
        heartbeatMs: readInteger(SERVER, root.heartbeatMs, 'frame.heartbeatMs', 1000),
        ...(root.serverTime !== undefined && root.serverTime !== null ? { serverTime: readTimestamp(SERVER, root.serverTime, 'frame.serverTime') } : {}),
      };
    case 'error': {
      const frame: RoomErrorFrame = { t: 'error', code: readEnum(SERVER, root.code, 'frame.code', ROOM_ERROR_CODES) };
      if (root.room !== undefined && root.room !== null) frame.room = room();
      return frame;
    }
    case 'joined':
      return {
        t: 'joined',
        room: room(),
        role: readEnum(SERVER, root.role, 'frame.role', ROOM_ROLES),
        epoch: readEpoch(SERVER, root.epoch, 'frame.epoch'),
        head: readInteger(SERVER, root.head, 'frame.head', 0),
        durable: readInteger(SERVER, root.durable, 'frame.durable', 0),
      };
    case 'changes': {
      if (typeof root.more !== 'boolean') fail(SERVER, 'frame.more', 'must be a boolean');
      return {
        t: 'changes',
        room: room(),
        changes: readArray(SERVER, root.changes, 'frame.changes', MAX_CHANGES_PER_FRAME, (entry, path) => readRoomChange(SERVER, entry, path)),
        more: root.more,
      };
    }
    case 'reset':
      return { t: 'reset', room: room(), epoch: readEpoch(SERVER, root.epoch, 'frame.epoch'), durable: readInteger(SERVER, root.durable, 'frame.durable', 0) };
    case 'ack':
      return {
        t: 'ack',
        room: room(),
        id: readPattern(SERVER, root.id, 'frame.id', CHANGE_ID_PATTERN),
        seq: readInteger(SERVER, root.seq, 'frame.seq', 1),
        epoch: readEpoch(SERVER, root.epoch, 'frame.epoch'),
      };
    case 'change':
      return { t: 'change', room: room(), change: readRoomChange(SERVER, root.change, 'frame.change') };
    case 'nack':
      return { t: 'nack', room: room(), id: readPattern(SERVER, root.id, 'frame.id', CHANGE_ID_PATTERN), code: readEnum(SERVER, root.code, 'frame.code', ROOM_NACK_CODES) };
    case 'presence':
      return {
        t: 'presence',
        room: room(),
        principal: readUserPrincipal(SERVER, root.principal, 'frame.principal'),
        client: readPattern(SERVER, root.client, 'frame.client', CLIENT_ID_PATTERN),
        actor: readRoomActor(SERVER, root.actor, 'frame.actor'),
        state: root.state ?? null,
        at: readTimestamp(SERVER, root.at, 'frame.at'),
      };
    case 'left':
      return { t: 'left', room: room(), principal: readUserPrincipal(SERVER, root.principal, 'frame.principal'), client: readPattern(SERVER, root.client, 'frame.client', CLIENT_ID_PATTERN) };
    case 'pong':
      return root.serverTime !== undefined && root.serverTime !== null ? { t: 'pong', serverTime: readTimestamp(SERVER, root.serverTime, 'frame.serverTime') } : { t: 'pong' };
    case 'durable':
      return { t: 'durable', room: room(), epoch: readEpoch(SERVER, root.epoch, 'frame.epoch'), through: readInteger(SERVER, root.through, 'frame.through', 0) };
    case 'role':
      return { t: 'role', room: room(), role: readEnum(SERVER, root.role, 'frame.role', ROOM_ROLES) };
    case 'revoked':
      return { t: 'revoked', room: room() };
    case 'bye':
      return { t: 'bye', reason: readEnum(SERVER, root.reason, 'frame.reason', ROOM_BYE_REASONS) };
    default:
      fail(SERVER, 'frame.t', 'is not a server frame');
  }
}

export function parseRoomCreateRequest(value: unknown): RoomCreateRequest {
  const root = readObject(CLIENT, value, 'room');
  const kind = readString(CLIENT, root.kind, 'room.kind', { max: 280 });
  if (!isRoomKind(kind)) fail(CLIENT, 'room.kind', 'must be <extension identity>/<kind>');
  return {
    id: readRoomId(CLIENT, root.id, 'room.id'),
    workspaceId: readString(CLIENT, root.workspaceId, 'room.workspaceId', { max: 128 }),
    kind,
    schemaVersion: readInteger(CLIENT, root.schemaVersion, 'room.schemaVersion', 1, 1_000_000),
    title: readString(CLIENT, root.title, 'room.title', { max: 256 }),
  };
}

export function parseRoomGrantRequest(value: unknown): RoomGrantRequest {
  const root = readObject(CLIENT, value, 'grant');
  return {
    principal: readUserPrincipal(CLIENT, root.principal, 'grant.principal'),
    role: readEnum(CLIENT, root.role, 'grant.role', ['viewer', 'collaborator', 'driver'] as const),
  };
}

export function parseRoomEnvelope(value: unknown, path = 'room'): RoomEnvelope {
  const root = readObject(SERVER, value, path);
  const envelope: RoomEnvelope = {
    id: readRoomId(SERVER, root.id, `${path}.id`),
    workspaceId: readString(SERVER, root.workspaceId, `${path}.workspaceId`, { max: 128 }),
    kind: readString(SERVER, root.kind, `${path}.kind`, { max: 280 }),
    schemaVersion: readInteger(SERVER, root.schemaVersion, `${path}.schemaVersion`, 1),
    title: readString(SERVER, root.title, `${path}.title`, { max: 256 }),
    owner: readUserPrincipal(SERVER, root.owner, `${path}.owner`),
    role: readEnum(SERVER, root.role, `${path}.role`, ROOM_ROLES),
    head: readInteger(SERVER, root.head, `${path}.head`, 0),
    durable: readInteger(SERVER, root.durable, `${path}.durable`, 0),
    epoch: readEpoch(SERVER, root.epoch, `${path}.epoch`),
    createdAt: readTimestamp(SERVER, root.createdAt, `${path}.createdAt`),
    updatedAt: readTimestamp(SERVER, root.updatedAt, `${path}.updatedAt`),
  };
  if (root.archivedAt !== undefined && root.archivedAt !== null) envelope.archivedAt = readTimestamp(SERVER, root.archivedAt, `${path}.archivedAt`);
  return envelope;
}

export function parseRoomList(value: unknown): RoomList {
  const root = readObject(SERVER, value, 'rooms');
  return { rooms: readArray(SERVER, root.rooms, 'rooms.rooms', 10_000, (entry, path) => parseRoomEnvelope(entry, path)) };
}

export function parseRoomGrantList(value: unknown): RoomGrantList {
  const root = readObject(SERVER, value, 'grants');
  return {
    grants: readArray(SERVER, root.grants, 'grants.grants', MAX_ROOM_MEMBERS + 1, (entry, path) => {
      const grant = readObject(SERVER, entry, path);
      return {
        principal: readUserPrincipal(SERVER, grant.principal, `${path}.principal`),
        role: readEnum(SERVER, grant.role, `${path}.role`, ROOM_ROLES),
        grantedBy: readUserPrincipal(SERVER, grant.grantedBy, `${path}.grantedBy`),
        grantedAt: readTimestamp(SERVER, grant.grantedAt, `${path}.grantedAt`),
      };
    }),
  };
}

export function parseRoomChangePage(value: unknown): RoomChangePage {
  const root = readObject(SERVER, value, 'page');
  if (typeof root.more !== 'boolean') fail(SERVER, 'page.more', 'must be a boolean');
  return {
    changes: readArray(SERVER, root.changes, 'page.changes', MAX_CHANGES_PER_FRAME, (entry, path) => readRoomChange(SERVER, entry, path)),
    more: root.more,
    epoch: readEpoch(SERVER, root.epoch, 'page.epoch'),
    durable: readInteger(SERVER, root.durable, 'page.durable', 0),
  };
}
