import type { SessionRole } from '../model.js';
import { isRoomRecordKey, isRoomId, jsonBytes, MAX_PRESENCE_BYTES, type RoomRole } from './protocol.js';
import type { RoomWriteCheck } from './schema.js';
import {
  CONVERSATION_PRESENCE_VERSION,
  CONVERSATION_ROOM_PREFIX,
  CONVERSATION_TASK_STATUSES,
  MAX_CONVERSATION_TASKS,
  type ConversationAgentStrip,
  type ConversationPresenceState,
} from './conversation-types.js';

/** The room id of an org session's conversation room. Throws `RangeError` when the session id cannot form a room id. */
export function conversationRoomId(orgSessionId: string): string {
  const id = `${CONVERSATION_ROOM_PREFIX}${orgSessionId}`;
  if (!orgSessionId || !isRoomId(id)) throw new RangeError('org session id cannot form a conversation room id');
  return id;
}

/** The org session id of a conversation room, or null for any other room. */
export function conversationSessionId(roomId: string): string | null {
  return roomId.startsWith(CONVERSATION_ROOM_PREFIX) && roomId.length > CONVERSATION_ROOM_PREFIX.length
    ? roomId.slice(CONVERSATION_ROOM_PREFIX.length)
    : null;
}

/** A session grant's role is the conversation room role, one to one. */
export function conversationRoomRole(sessionRole: SessionRole): RoomRole {
  return sessionRole;
}

/**
 * What may be written in a conversation room: only `message` records (no tool calls, tool output, system text or files).
 * Field values are checked by `checkRoomWrite` with the built-in message schema; run both.
 */
export function checkConversationWrite(change: { type: string }): RoomWriteCheck {
  return change.type === 'message' ? { ok: true } : { ok: false, code: 'unknown-type' };
}

function isShortString(value: unknown, max: number): value is string {
  return typeof value === 'string' && value.length > 0 && value.length <= max;
}
function isCount(value: unknown): value is number {
  return typeof value === 'number' && Number.isInteger(value) && value >= 0 && value <= 100_000;
}

function readAgentStrip(value: unknown): ConversationAgentStrip | null {
  if (typeof value !== 'object' || value === null || Array.isArray(value)) return null;
  const root = value as Record<string, unknown>;
  if (typeof root.busy !== 'boolean') return null;
  const strip: ConversationAgentStrip = { busy: root.busy };
  if (root.step !== undefined) {
    if (!isShortString(root.step, 200)) return null;
    strip.step = root.step;
  }
  if (root.tasks !== undefined) {
    if (!Array.isArray(root.tasks) || root.tasks.length > MAX_CONVERSATION_TASKS) return null;
    const tasks: NonNullable<ConversationAgentStrip['tasks']> = [];
    for (const task of root.tasks) {
      const entry = task as Record<string, unknown> | null;
      if (!entry || !isShortString(entry.title, 200) || !(CONVERSATION_TASK_STATUSES as readonly unknown[]).includes(entry.status)) return null;
      tasks.push({ title: entry.title, status: entry.status as (typeof CONVERSATION_TASK_STATUSES)[number] });
    }
    strip.tasks = tasks;
  }
  if (root.filesChanged !== undefined) {
    if (!isCount(root.filesChanged)) return null;
    strip.filesChanged = root.filesChanged;
  }
  if (root.subagentsRunning !== undefined) {
    if (!isCount(root.subagentsRunning)) return null;
    strip.subagentsRunning = root.subagentsRunning;
  }
  return strip;
}

/**
 * Reads a conversation presence state, or null when it is not one (a screen then ignores the entry). Unknown keys are
 * dropped. The whole state must fit `MAX_PRESENCE_BYTES`.
 */
export function parseConversationPresenceState(value: unknown): ConversationPresenceState | null {
  if (typeof value !== 'object' || value === null || Array.isArray(value)) return null;
  if (jsonBytes(value) > MAX_PRESENCE_BYTES) return null;
  const root = value as Record<string, unknown>;
  if (root.v !== CONVERSATION_PRESENCE_VERSION) return null;
  const state: ConversationPresenceState = { v: CONVERSATION_PRESENCE_VERSION };
  for (const flag of ['open', 'composing'] as const) {
    if (root[flag] === undefined || root[flag] === null) continue;
    if (typeof root[flag] !== 'boolean') return null;
    state[flag] = root[flag];
  }
  if (root.agent !== undefined && root.agent !== null) {
    const agent = readAgentStrip(root.agent);
    if (!agent) return null;
    state.agent = agent;
  }
  if (root.selection !== undefined && root.selection !== null) {
    const selection = root.selection as Record<string, unknown>;
    if (
      typeof selection !== 'object'
      || !isRoomRecordKey(selection.record)
      || !isShortString(selection.field, 64)
      || !isShortString(selection.anchor, 512)
      || !isShortString(selection.head, 512)
    ) return null;
    state.selection = { record: selection.record, field: selection.field, anchor: selection.anchor, head: selection.head };
  }
  return state;
}
