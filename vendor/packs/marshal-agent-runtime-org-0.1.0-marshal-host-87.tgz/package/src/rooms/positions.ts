/**
 * Positions for ordered lists (`position` fields): strings that sort with plain `<` comparison, over the digits
 * `0-9A-Za-z` (ASCII order), never empty and never ending in `0`, so there is always room between two of them.
 * Two people inserting between the same neighbours at once can get the same position; `compareRoomPositions` then orders
 * by record key, so every replica shows the same stable order.
 */
const DIGITS = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';
const POSITION_PATTERN = /^[0-9A-Za-z]{0,255}[1-9A-Za-z]$/;

export class RoomPositionError extends Error {
  readonly code: 'invalid-position' | 'unordered-positions';
  constructor(code: RoomPositionError['code'], message: string) {
    super(message);
    this.name = 'RoomPositionError';
    this.code = code;
  }
}

export function isRoomPosition(value: unknown): value is string {
  return typeof value === 'string' && POSITION_PATTERN.test(value);
}

/** A position strictly between `before` and `after` (either may be absent: start or end of the list). */
export function roomPositionBetween(before?: string, after?: string): string {
  if (before !== undefined && !isRoomPosition(before)) throw new RoomPositionError('invalid-position', 'before is not a position');
  if (after !== undefined && !isRoomPosition(after)) throw new RoomPositionError('invalid-position', 'after is not a position');
  if (before !== undefined && after !== undefined && before >= after) throw new RoomPositionError('unordered-positions', 'before must sort before after');
  if (before !== undefined && after === undefined) return increment(before);
  if (before === undefined && after !== undefined) return decrement(after);
  return midpoint(before ?? '', after);
}

// Appending and prepending step one digit at a time, so a list that grows at one end gains one character per ~60 items.
function increment(position: string): string {
  const digit = DIGITS.indexOf(position[0]!);
  if (digit < DIGITS.length - 1) return DIGITS[digit + 1]!;
  return 'z' + (position.length > 1 ? increment(position.slice(1)) : 'V');
}

function decrement(position: string): string {
  const digit = DIGITS.indexOf(position[0]!);
  if (digit > 1) return DIGITS[digit - 1]!;
  if (position.length > 1) return position[0]! + decrement(position.slice(1));
  return '0V';
}

function midpoint(a: string, b: string | undefined): string {
  if (b !== undefined) {
    let shared = 0;
    while ((a[shared] ?? '0') === b[shared]) shared += 1;
    if (shared > 0) return b.slice(0, shared) + midpoint(a.slice(shared), b.slice(shared));
  }
  const digitA = a ? DIGITS.indexOf(a[0]!) : 0;
  const digitB = b !== undefined ? DIGITS.indexOf(b[0]!) : DIGITS.length;
  if (digitB - digitA > 1) return DIGITS[Math.round((digitA + digitB) / 2)]!;
  if (b !== undefined && b.length > 1) return b.slice(0, 1);
  return DIGITS[digitA]! + midpoint(a.slice(1), undefined);
}

/** Order of two list items: by position, then by record key. Items without a valid position sort last. */
export function compareRoomPositions(a: { position?: unknown; key: string }, b: { position?: unknown; key: string }): number {
  const pa = isRoomPosition(a.position) ? a.position : undefined;
  const pb = isRoomPosition(b.position) ? b.position : undefined;
  if (pa !== pb) {
    if (pa === undefined) return 1;
    if (pb === undefined) return -1;
    return pa < pb ? -1 : 1;
  }
  return a.key < b.key ? -1 : a.key > b.key ? 1 : 0;
}
