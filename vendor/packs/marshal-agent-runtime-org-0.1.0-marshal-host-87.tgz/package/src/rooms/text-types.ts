import type { RoomActor, RoomRecordKey } from './protocol.js';

/**
 * Mergeable text (`text` fields). A text field is a Yjs `Y.Text` (sequence CRDT): every edit is a small binary Yjs update,
 * base64 in JSON, carried inside an ordered change (`RoomChange.text`). The server orders and stores updates and never reads
 * them; every replica (desktop, service, cloud agent) merges them with the shared reducer, which converges to the same text
 * whatever order updates arrive in, keeping every person's characters. A text field is never written with `set`.
 *
 * Compaction: a field's merged state grows with editing history. Once it passes `roomTextNeedsCompaction`, the next writer
 * replaces it with a fresh state of the same text (`reset`, generation + 1), sent with `ifSeq` so it only lands when no one
 * else changed the record in between. Updates made against an older generation are ignored by the reducer; their author's
 * host rebases them onto the new generation (`rebaseRoomTextUpdates`) and resends, so no characters are lost.
 */

/** Most UTF-8 bytes of one text field's value. Longer edits are refused locally (`too-large`). */
export const MAX_ROOM_TEXT_BYTES = 64 * 1024;
/** Most bytes (base64 characters) of one text update inside a change; a host splits a larger paste into several changes. */
export const MAX_ROOM_TEXT_UPDATE_BYTES = 32 * 1024;
/** Most bytes of an `op` frame that carries a `reset` (a whole compacted state); every other `op` keeps `MAX_ROOM_CHANGE_BYTES`. */
export const MAX_ROOM_TEXT_RESET_FRAME_BYTES = 128 * 1024;
/** A field's state is compacted once its encoded bytes exceed this floor and twice the value's UTF-8 bytes. */
export const ROOM_TEXT_COMPACT_FLOOR_BYTES = 32 * 1024;
/** A host batches local keystrokes into one change at most this often. */
export const ROOM_TEXT_BATCH_MS = 50;
/** History groups one person's consecutive text changes on one field into a run until they pause this long. */
export const ROOM_TEXT_RUN_IDLE_MS = 30_000;

/** One text field's edit inside a change: an update against generation `gen`, or a compacted `reset` that starts `gen`. */
export type RoomTextUpdate = { gen: number; update: string } | { gen: number; reset: string };

/** A text field as the reducer keeps it. `value` is also in `fields[name]`, so readers that only need the text need no Yjs. */
export type RoomTextState = {
  gen: number;
  /** Base64 Yjs state of this generation (deleted content garbage-collected). */
  state: string;
  /** Position of the reset that started this generation; 0 for generation 0. */
  resetSeq: number;
  /** Updates for a later generation whose reset this replica has not applied yet (out-of-order replay). */
  ahead?: { gen: number; update: string; seq: number }[];
};

/** One edit as a screen applies it: at `index` (UTF-16 code units, like `String.prototype.slice`), remove `deleteCount`, insert `insert`. */
export type RoomTextSplice = { index: number; deleteCount: number; insert: string };

/** A caret position that survives other people's edits (base64 Yjs relative position). Resolve it on the current text. */
export type RoomTextCursor = string;

/** A selection in one text field, for presence. `anchor === head` is a caret. */
export type RoomTextSelection = { record: RoomRecordKey; field: string; anchor: RoomTextCursor; head: RoomTextCursor };

/** What a text subscriber hears: the splices to apply, in order, and who made them. */
export type RoomTextEvent = {
  splices: RoomTextSplice[];
  /** `local` for this desktop's own edits, `remote` for others', `rebuilt` after an epoch reset or a compaction. */
  origin: 'local' | 'remote' | 'rebuilt';
  value: string;
};

/** A run of one person's typing in one field, for history: consecutive changes until they pause `ROOM_TEXT_RUN_IDLE_MS`. */
export type RoomTextRun = {
  record: RoomRecordKey;
  field: string;
  author: string;
  actor: RoomActor;
  firstSeq: number;
  lastSeq: number;
  from: string;
  to: string;
  changes: number;
  inserted: number;
  deleted: number;
};
