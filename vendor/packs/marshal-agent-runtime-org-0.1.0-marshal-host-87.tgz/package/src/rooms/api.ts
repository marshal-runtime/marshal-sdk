import type { UserPrincipal } from '../principals.js';
import type { RoomActor, RoomChange, RoomFileRef, RoomNackCode, RoomRecordKey, RoomRole } from './protocol.js';
import type { RoomWriteProblemCode } from './schema.js';
import type { RoomTextCursor, RoomTextEvent, RoomTextRun } from './text-types.js';

/** Runtime service key under which a host binds `RoomsService` (`createRuntimeServiceToken(ROOMS_SERVICE_KEY)`). */
export const ROOMS_SERVICE_KEY = '@marshal/org:rooms' as const;

/** The part of the runtime `InvocationContext` the rooms service reads (structural, so this package needs no runtime dependency). */
export type RoomsInvocationContext = {
  principal: { id: string; kind: string };
  scope?: { sessionId?: string; workspaceId?: string };
  organization?: { orgId: string; person: string; displayName?: string; workspaceId?: string };
};

/**
 * What a host binds at `ROOMS_SERVICE_KEY`. An extension passes the invocation context its own capability received; the
 * host derives the actor from it (`deriveRoomActor`) and the extension identity from its own stamp, never from the caller.
 */
export type RoomsService = (context: RoomsInvocationContext) => RoomsApi;

/**
 * The rooms API a runtime host hands to extensions. The host implements it on its local replica and socket client; an
 * extension never talks to the server and never chooses the author or the actor of its changes.
 */
export interface RoomsApi {
  /** Creates a room of one of this extension's declared kinds (`kind` is the short name from `contributes.rooms`). */
  create(input: { kind: string; workspaceId: string; title: string }): Promise<Room>;
  open(roomId: string): Promise<Room>;
  list(filter?: { kind?: string; workspaceId?: string }): Promise<RoomSummary[]>;
}

export type RoomStatus = 'active' | 'offline' | 'revoked' | 'gone';

export type RoomSummary = {
  id: string;
  kind: string;
  workspaceId: string;
  title: string;
  owner: UserPrincipal;
  role: RoomRole;
  status: RoomStatus;
  updatedAt: string;
};

/** A record as a screen reads it. `pending`: it carries local changes the server has not ordered yet. */
export type RoomRecord = {
  key: RoomRecordKey;
  type: string;
  fields: Record<string, unknown>;
  /** Position of the last ordered change to this record; 0 for a record that exists only locally so far. */
  seq: number;
  updatedBy: UserPrincipal;
  pending: boolean;
};

/**
 * A change as screens and history see it: an ordered change, or (with `pending: true`, `seq` and `epoch` null) this
 * desktop's own change before the server ordered it, so the screen shows it at once.
 */
export type RoomApiChange = Omit<RoomChange, 'seq' | 'epoch'> & { seq: number | null; epoch: string | null; pending: boolean };

export type RoomPresence = {
  principal: UserPrincipal;
  name?: string;
  client: string;
  actor: RoomActor;
  state: unknown;
  at: string;
  /** This desktop's own entry. */
  self: boolean;
};

export type RoomMember = { principal: UserPrincipal; name: string; role: RoomRole };

export interface Room {
  readonly id: string;
  readonly role: RoomRole;
  readonly status: RoomStatus;
  members(): Promise<RoomMember[]>;
  get(key: string): RoomRecord | undefined;
  query(filter: { type: string }): RoomRecord[];
  /**
   * Writes the given fields (others are untouched). A string given for a `text` field is turned into the smallest edit
   * from the current value (`text(key, field).setValue`), never a later-wins overwrite. Resolves once the change is in the local replica and visible; with
   * `ifSeq` it resolves only after the server ordered it. Rejects with `RoomWriteError`.
   */
  set(key: string, fields: Record<string, unknown>, options?: { ifSeq?: number }): Promise<void>;
  delete(key: string): Promise<void>;
  /** A position between two others, for `position` fields. */
  between(before?: string, after?: string): string;
  history(key?: string): Promise<RoomApiChange[]>;
  /** Who typed what in a record's text fields: consecutive changes by one person grouped into runs (`ROOM_TEXT_RUN_IDLE_MS`). */
  textHistory(key: string, field?: string): Promise<RoomTextRun[]>;
  /** A live handle on one `text` field of a record (the record need not exist yet; the first edit creates it). */
  text(key: string, field: string): RoomTextHandle;
  files: { put(path: string, contentType: string): Promise<RoomFileRef>; path(ref: RoomFileRef): Promise<string> };
  presence: { set(state: unknown): void; all(): RoomPresence[] };
  subscribe(listener: (event: RoomEvent) => void): () => void;
}

/**
 * One text field, live. Edits apply locally at once and merge with everyone else's; a subscriber gets every change as
 * splices, so a screen keeps its caret by mapping it through them (or by holding a `cursor`).
 */
export interface RoomTextHandle {
  readonly record: string;
  readonly field: string;
  value(): string;
  /** A local edit at `index` (UTF-16 code units). Rejects with `RoomWriteError` (`read-only`, `too-large`, ...). */
  splice(index: number, deleteCount: number, insert: string): Promise<void>;
  /** For a plain textarea: the field's new full value, sent as the smallest splice from the current value. */
  setValue(next: string): Promise<void>;
  subscribe(listener: (event: RoomTextEvent) => void): () => void;
  /** A caret position that stays attached to the character after it while others edit. */
  cursor(index: number): RoomTextCursor;
  /** The current index of a cursor, or null when it no longer resolves (its generation was compacted away). */
  resolve(cursor: RoomTextCursor): number | null;
}

export type RoomEvent =
  /** The changes themselves, oldest first: other people's as they arrive, this desktop's own at once (pending). */
  | { kind: 'records'; changes: RoomApiChange[] }
  | { kind: 'presence'; presence: RoomPresence[] }
  | { kind: 'status'; status: RoomStatus }
  /** The server refused one of this desktop's changes after it was shown; the record is back to the ordered state. */
  | { kind: 'refused'; changeId: string; record: RoomRecordKey; code: RoomNackCode };

export type RoomWriteErrorCode = RoomWriteProblemCode | RoomNackCode | 'read-only' | 'revoked' | 'gone';

export class RoomWriteError extends Error {
  readonly code: RoomWriteErrorCode;
  readonly field?: string;
  constructor(code: RoomWriteErrorCode, options: { field?: string; message?: string } = {}) {
    super(options.message ?? `room write refused: ${code}${options.field ? ` (${options.field})` : ''}`);
    this.name = 'RoomWriteError';
    this.code = code;
    if (options.field !== undefined) this.field = options.field;
  }
}

/** Who the invocation acts as in an organization. Filled by the harness on the invocation context; never by an extension. */
export type OrgInvocationIdentity = {
  orgId: string;
  person: UserPrincipal;
  displayName?: string;
};

/**
 * What the host knows, from its own invocation context, about who is acting. `principalKind` is the invocation principal's
 * kind (`user` for a person's click, `agent` for a model's tool call); `placement` is where this host runs. Neither comes
 * from the extension.
 */
export type RoomActorSource = {
  principalKind: string;
  placement: 'desktop' | 'cloud';
  sessionId?: string;
  runtime?: string;
  model?: string;
  run?: string;
  askedBy?: UserPrincipal;
};

export type RoomActorDerivation = { ok: true; actor: RoomActor } | { ok: false; code: 'unsupported-principal' | 'missing-session' | 'missing-run' };

/** The actor a host stamps on a change. A person's own action is `person`; a model acting is an `agent` of this host. */
export function deriveRoomActor(source: RoomActorSource): RoomActorDerivation {
  if (source.principalKind === 'user') {
    if (source.placement === 'cloud') return { ok: false, code: 'unsupported-principal' };
    return { ok: true, actor: { kind: 'person' } };
  }
  if (source.principalKind !== 'agent') return { ok: false, code: 'unsupported-principal' };
  if (source.placement === 'desktop') {
    if (!source.sessionId || !source.runtime) return { ok: false, code: 'missing-session' };
    const actor: RoomActor = { kind: 'agent', host: 'desktop', session: source.sessionId, runtime: source.runtime };
    if (source.model) actor.model = source.model;
    return { ok: true, actor };
  }
  if (!source.run || !source.askedBy) return { ok: false, code: 'missing-run' };
  return { ok: true, actor: { kind: 'agent', host: 'cloud', run: source.run, askedBy: source.askedBy } };
}
