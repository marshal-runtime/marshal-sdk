import * as Y from 'yjs';
import type { RoomChange, RoomRecordKey } from './protocol.js';
import {
  MAX_ROOM_TEXT_BYTES,
  MAX_ROOM_TEXT_RESET_FRAME_BYTES,
  MAX_ROOM_TEXT_UPDATE_BYTES,
  ROOM_TEXT_COMPACT_FLOOR_BYTES,
  ROOM_TEXT_RUN_IDLE_MS,
  type RoomTextCursor,
  type RoomTextEvent,
  type RoomTextRun,
  type RoomTextSplice,
  type RoomTextState,
  type RoomTextUpdate,
} from './text-types.js';

const TEXT_NAME = 't';
const BASE64_PATTERN = /^[A-Za-z0-9+/]*={0,2}$/;

function toBase64(bytes: Uint8Array): string {
  return Buffer.from(bytes.buffer, bytes.byteOffset, bytes.byteLength).toString('base64');
}
function fromBase64(text: string): Uint8Array {
  return new Uint8Array(Buffer.from(text, 'base64'));
}

export function utf8Bytes(text: string): number {
  return Buffer.byteLength(text, 'utf8');
}

/** Shape check only (what a server may do): a generation and one base64 payload within its limit. */
export function isRoomTextUpdate(value: unknown): value is RoomTextUpdate {
  if (typeof value !== 'object' || value === null || Array.isArray(value)) return false;
  const entry = value as Record<string, unknown>;
  if (typeof entry.gen !== 'number' || !Number.isInteger(entry.gen) || entry.gen < 0) return false;
  const keys = Object.keys(entry).filter((key) => key !== 'gen');
  if (keys.length !== 1) return false;
  const payload = keys[0] === 'update' ? entry.update : keys[0] === 'reset' ? entry.reset : undefined;
  if (typeof payload !== 'string' || payload.length === 0 || !BASE64_PATTERN.test(payload)) return false;
  return payload.length <= (keys[0] === 'update' ? MAX_ROOM_TEXT_UPDATE_BYTES : MAX_ROOM_TEXT_RESET_FRAME_BYTES);
}

export function isRoomTextReset(update: RoomTextUpdate): update is { gen: number; reset: string } {
  return 'reset' in update;
}

function docFrom(state: string | undefined): Y.Doc {
  const doc = new Y.Doc();
  if (state) Y.applyUpdate(doc, fromBase64(state));
  return doc;
}

/** Decodes without applying, so a malformed update is refused before it can half-apply. */
function decodable(update: string): boolean {
  try {
    Y.decodeUpdate(fromBase64(update));
    return true;
  } catch {
    return false;
  }
}

/** The text of a field state. */
export function readRoomText(state: string | undefined): string {
  return docFrom(state).getText(TEXT_NAME).toString();
}

/**
 * Merges updates into a field state. Commutative and idempotent: any order, any repetition, same text. Returns null when an
 * update is malformed (every replica refuses the same bytes, so they still agree).
 */
export function mergeRoomTextState(state: string | undefined, updates: readonly string[]): { state: string; value: string } | null {
  if (!updates.every(decodable)) return null;
  try {
    const doc = docFrom(state);
    for (const update of updates) Y.applyUpdate(doc, fromBase64(update));
    return { state: toBase64(Y.encodeStateAsUpdate(doc)), value: doc.getText(TEXT_NAME).toString() };
  } catch {
    return null;
  }
}

/** A fresh state holding exactly `value`: the payload of a `reset`. */
export function createRoomTextReset(value: string): string {
  const doc = new Y.Doc();
  doc.getText(TEXT_NAME).insert(0, value);
  return toBase64(Y.encodeStateAsUpdate(doc));
}

/** The compaction rule: compact once the state passes the floor and twice the value's UTF-8 bytes. */
export function roomTextNeedsCompaction(text: Pick<RoomTextState, 'state'>, value: string): boolean {
  const bytes = Math.ceil((text.state.length * 3) / 4);
  return bytes > Math.max(ROOM_TEXT_COMPACT_FLOOR_BYTES, 2 * utf8Bytes(value));
}

/**
 * Applies one text update to a field state, the reducer's rule. Order-independent across generations: an update for the
 * current generation merges; an older one is ignored (its author rebases); a later one waits in `ahead` until its reset.
 * Of two resets for one generation (only possible if `ifSeq` was skipped) the lower position wins on every replica.
 */
export function applyRoomTextUpdate(
  current: RoomTextState | undefined,
  update: RoomTextUpdate,
  seq: number,
): { kind: 'applied'; text: RoomTextState; value: string } | { kind: 'ignored'; reason: 'stale-generation' | 'invalid' | 'waiting' } {
  const gen = current?.gen ?? 0;
  if (isRoomTextReset(update)) {
    if (update.gen < gen || update.gen === 0) return { kind: 'ignored', reason: 'stale-generation' };
    if (update.gen === gen && current && current.resetSeq <= seq) return { kind: 'ignored', reason: 'stale-generation' };
    const ahead = (current?.ahead ?? []).filter((entry) => entry.gen >= update.gen);
    const now = ahead.filter((entry) => entry.gen === update.gen);
    const merged = mergeRoomTextState(update.reset, now.map((entry) => entry.update));
    if (!merged) return { kind: 'ignored', reason: 'invalid' };
    const text: RoomTextState = { gen: update.gen, state: merged.state, resetSeq: seq };
    const later = ahead.filter((entry) => entry.gen > update.gen);
    if (later.length) text.ahead = later;
    return { kind: 'applied', text, value: merged.value };
  }
  if (update.gen < gen) return { kind: 'ignored', reason: 'stale-generation' };
  if (update.gen > gen) {
    if (!decodable(update.update)) return { kind: 'ignored', reason: 'invalid' };
    const base: RoomTextState = current ?? { gen: 0, state: createEmptyState(), resetSeq: 0 };
    const text: RoomTextState = { ...base, ahead: [...(base.ahead ?? []), { gen: update.gen, update: update.update, seq }] };
    return { kind: 'applied', text, value: readRoomText(base.state) };
  }
  if (!decodable(update.update)) return { kind: 'ignored', reason: 'invalid' };
  // The live doc moves from the old state object to the new one, so a stream of small appends costs one apply each
  // instead of rebuilding the doc from the whole state. A reused old object misses the cache and rebuilds: still correct.
  let doc = current ? liveDocs.get(current) : undefined;
  if (current) liveDocs.delete(current);
  try {
    doc ??= docFrom(current?.state);
    Y.applyUpdate(doc, fromBase64(update.update));
  } catch {
    return { kind: 'ignored', reason: 'invalid' };
  }
  const text: RoomTextState = { gen, state: toBase64(Y.encodeStateAsUpdate(doc)), resetSeq: current?.resetSeq ?? 0 };
  if (current?.ahead?.length) text.ahead = current.ahead;
  liveDocs.set(text, doc);
  return { kind: 'applied', text, value: doc.getText(TEXT_NAME).toString() };
}

const liveDocs = new WeakMap<RoomTextState, Y.Doc>();

let emptyState: string | undefined;
function createEmptyState(): string {
  emptyState ??= toBase64(Y.encodeStateAsUpdate(new Y.Doc()));
  return emptyState;
}

/**
 * Rebases updates made against an older generation onto a reset. `previous` is the old generation's state the updates were
 * merged into (with `ifSeq` on the reset it holds the same text as the reset). The edits are replayed as the exact
 * insertions and deletions they made, so concurrent edits by others stay intact. Returns null when there is nothing to send.
 */
export function rebaseRoomTextUpdates(input: { previous: string | undefined; reset: string; updates: readonly string[] }): string | null {
  const before = docFrom(input.previous);
  const text = before.getText(TEXT_NAME);
  const deltas: unknown[][] = [];
  text.observe((event) => deltas.push(event.delta as unknown[]));
  for (const update of input.updates) if (decodable(update)) Y.applyUpdate(before, fromBase64(update));
  if (!deltas.length) return null;
  const after = docFrom(input.reset);
  const vector = Y.encodeStateVector(after);
  const target = after.getText(TEXT_NAME);
  after.transact(() => {
    for (const delta of deltas) target.applyDelta(clampDelta(delta as DeltaOp[], target.length));
  });
  const update = Y.encodeStateAsUpdate(after, vector);
  return update.byteLength > 2 ? toBase64(update) : null;
}

type DeltaOp = { insert?: string | object; delete?: number; retain?: number };

/** Keeps a replayed delta inside the target text when the reset differs from the old generation. */
function clampDelta(delta: DeltaOp[], length: number): DeltaOp[] {
  const out: DeltaOp[] = [];
  let at = 0;
  for (const op of delta) {
    if (op.retain !== undefined) {
      const retain = Math.min(op.retain, length - at);
      if (retain > 0) out.push({ retain });
      at += Math.max(retain, 0);
    } else if (op.delete !== undefined) {
      const remove = Math.min(op.delete, length - at);
      if (remove > 0) out.push({ delete: remove });
      length -= Math.max(remove, 0);
    } else if (typeof op.insert === 'string') {
      out.push({ insert: op.insert });
      at += op.insert.length;
      length += op.insert.length;
    }
  }
  return out;
}

function isHighSurrogate(code: number): boolean {
  return code >= 0xd800 && code <= 0xdbff;
}
function isLowSurrogate(code: number): boolean {
  return code >= 0xdc00 && code <= 0xdfff;
}

/** The smallest single splice that turns `previous` into `next` (common prefix and suffix), never splitting a surrogate pair. */
export function roomTextSpliceFor(previous: string, next: string): RoomTextSplice | null {
  if (previous === next) return null;
  let start = 0;
  const shortest = Math.min(previous.length, next.length);
  while (start < shortest && previous.charCodeAt(start) === next.charCodeAt(start)) start += 1;
  if (start > 0 && isHighSurrogate(previous.charCodeAt(start - 1))) start -= 1;
  let end = 0;
  while (
    end < shortest - start
    && previous.charCodeAt(previous.length - 1 - end) === next.charCodeAt(next.length - 1 - end)
  ) end += 1;
  if (end > 0 && isLowSurrogate(previous.charCodeAt(previous.length - end))) end -= 1;
  return { index: start, deleteCount: previous.length - start - end, insert: next.slice(start, next.length - end) };
}

export function applyRoomTextSplices(value: string, splices: readonly RoomTextSplice[]): string {
  let text = value;
  for (const splice of splices) text = text.slice(0, splice.index) + splice.insert + text.slice(splice.index + splice.deleteCount);
  return text;
}

/** Converts a Yjs delta into splices applied in order. */
function deltaToSplices(delta: readonly DeltaOp[]): RoomTextSplice[] {
  const splices: RoomTextSplice[] = [];
  let index = 0;
  for (const op of delta) {
    if (op.retain !== undefined) index += op.retain;
    else if (op.delete !== undefined) {
      splices.push({ index, deleteCount: op.delete, insert: '' });
    } else if (typeof op.insert === 'string') {
      splices.push({ index, deleteCount: 0, insert: op.insert });
      index += op.insert.length;
    }
  }
  return splices;
}

/** Inserted characters and deleted characters an update carries, for history. */
export function roomTextUpdateStats(update: string): { inserted: number; deleted: number } {
  try {
    const decoded = Y.decodeUpdate(fromBase64(update));
    let inserted = 0;
    for (const struct of decoded.structs) {
      if (struct instanceof Y.Item && struct.content instanceof Y.ContentString) inserted += struct.length;
    }
    let deleted = 0;
    for (const ranges of decoded.ds.clients.values()) for (const range of ranges) deleted += range.len;
    return { inserted, deleted };
  } catch {
    return { inserted: 0, deleted: 0 };
  }
}

/**
 * Groups text changes into runs of one person's typing in one field: a run continues while the same author (and actor kind)
 * keeps editing the same field with pauses shorter than `idleMs`. Changes must be in order (history order).
 */
export function summarizeRoomTextHistory(
  changes: readonly Pick<RoomChange, 'seq' | 'author' | 'actor' | 'at' | 'record' | 'text'>[],
  options: { idleMs?: number; field?: string } = {},
): RoomTextRun[] {
  const idleMs = options.idleMs ?? ROOM_TEXT_RUN_IDLE_MS;
  const runs: RoomTextRun[] = [];
  const open = new Map<string, RoomTextRun>();
  for (const change of changes) {
    for (const [field, update] of Object.entries(change.text ?? {})) {
      if (options.field !== undefined && field !== options.field) continue;
      const stats = isRoomTextReset(update) ? { inserted: 0, deleted: 0 } : roomTextUpdateStats(update.update);
      const key = `${change.record}\u0000${field}`;
      const run = open.get(key);
      const sameHand = run && run.author === change.author && JSON.stringify(run.actor) === JSON.stringify(change.actor);
      if (run && sameHand && Date.parse(change.at) - Date.parse(run.to) < idleMs) {
        run.lastSeq = change.seq;
        run.to = change.at;
        run.changes += 1;
        run.inserted += stats.inserted;
        run.deleted += stats.deleted;
        continue;
      }
      const next: RoomTextRun = {
        record: change.record,
        field,
        author: change.author,
        actor: change.actor,
        firstSeq: change.seq,
        lastSeq: change.seq,
        from: change.at,
        to: change.at,
        changes: 1,
        inserted: stats.inserted,
        deleted: stats.deleted,
      };
      runs.push(next);
      open.set(key, next);
    }
  }
  return runs;
}

/**
 * One field's live text on a desktop: confirmed state plus this desktop's edits, which a host keeps per open text field.
 * `splice` returns the updates to send (several when a paste exceeds `MAX_ROOM_TEXT_UPDATE_BYTES`); `receive` merges
 * someone else's update and tells subscribers the exact splices, so a screen keeps its caret.
 */
export class RoomTextReplica {
  readonly record: RoomRecordKey;
  readonly field: string;
  private doc: Y.Doc;
  private generation: number;
  private readonly listeners = new Set<(event: RoomTextEvent) => void>();

  constructor(input: { record: RoomRecordKey; field: string; text?: Pick<RoomTextState, 'gen' | 'state'> }) {
    this.record = input.record;
    this.field = input.field;
    this.generation = input.text?.gen ?? 0;
    this.doc = this.attach(docFrom(input.text?.state));
  }

  get gen(): number {
    return this.generation;
  }

  value(): string {
    return this.doc.getText(TEXT_NAME).toString();
  }

  /** The merged state (confirmed plus local), base64. */
  state(): string {
    return toBase64(Y.encodeStateAsUpdate(this.doc));
  }

  /**
   * A local edit. Returns the updates to send, in order, each within `MAX_ROOM_TEXT_UPDATE_BYTES`. Throws `RangeError` for an
   * index outside the text and `RoomTextTooLargeError` when the value would pass `MAX_ROOM_TEXT_BYTES`.
   */
  splice(index: number, deleteCount: number, insert: string): RoomTextUpdate[] {
    const text = this.doc.getText(TEXT_NAME);
    if (!Number.isInteger(index) || index < 0 || index > text.length) throw new RangeError('splice index outside the text');
    const remove = Math.max(0, Math.min(deleteCount, text.length - index));
    const after = this.value().slice(0, index) + insert + this.value().slice(index + remove);
    if (utf8Bytes(after) > MAX_ROOM_TEXT_BYTES) throw new RoomTextTooLargeError();
    const updates: RoomTextUpdate[] = [];
    const capture = (update: Uint8Array, origin: unknown) => {
      if (origin === LOCAL) updates.push({ gen: this.generation, update: toBase64(update) });
    };
    this.doc.on('update', capture);
    try {
      if (remove > 0) this.doc.transact(() => text.delete(index, remove), LOCAL);
      for (const [offset, piece] of chunks(insert)) this.doc.transact(() => text.insert(index + offset, piece), LOCAL);
    } finally {
      this.doc.off('update', capture);
    }
    return updates;
  }

  /** The field's new full value as the smallest splice. */
  setValue(next: string): RoomTextUpdate[] {
    const splice = roomTextSpliceFor(this.value(), next);
    return splice ? this.splice(splice.index, splice.deleteCount, splice.insert) : [];
  }

  /** Merges an update from the room (someone else's, or this desktop's echoed back: idempotent). */
  receive(update: RoomTextUpdate): void {
    if (isRoomTextReset(update)) throw new Error('a reset is applied with rebuild()');
    if (update.gen !== this.generation || !decodable(update.update)) return;
    Y.applyUpdate(this.doc, fromBase64(update.update), REMOTE);
  }

  /**
   * Replaces the replica with a new confirmed state (a new epoch, or a compaction) and re-applies local updates on top.
   * Subscribers get one `rebuilt` event with the splice from the old value to the new.
   */
  rebuild(text: Pick<RoomTextState, 'gen' | 'state'>, local: readonly string[] = []): void {
    const previous = this.value();
    this.doc.destroy();
    this.generation = text.gen;
    const doc = docFrom(text.state);
    for (const update of local) if (decodable(update)) Y.applyUpdate(doc, fromBase64(update));
    this.doc = this.attach(doc);
    const splice = roomTextSpliceFor(previous, this.value());
    if (splice) this.emit({ splices: [splice], origin: 'rebuilt', value: this.value() });
  }

  subscribe(listener: (event: RoomTextEvent) => void): () => void {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  }

  cursor(index: number): RoomTextCursor {
    const text = this.doc.getText(TEXT_NAME);
    const position = Y.createRelativePositionFromTypeIndex(text, Math.max(0, Math.min(index, text.length)));
    return toBase64(Y.encodeRelativePosition(position));
  }

  resolve(cursor: RoomTextCursor): number | null {
    try {
      const absolute = Y.createAbsolutePositionFromRelativePosition(Y.decodeRelativePosition(fromBase64(cursor)), this.doc);
      return absolute ? absolute.index : null;
    } catch {
      return null;
    }
  }

  destroy(): void {
    this.doc.destroy();
    this.listeners.clear();
  }

  private attach(doc: Y.Doc): Y.Doc {
    doc.getText(TEXT_NAME).observe((event, transaction) => {
      const splices = deltaToSplices(event.delta as DeltaOp[]);
      if (splices.length) this.emit({ splices, origin: transaction.origin === LOCAL ? 'local' : 'remote', value: this.value() });
    });
    return doc;
  }

  private emit(event: RoomTextEvent): void {
    for (const listener of this.listeners) listener(event);
  }
}

const LOCAL = Symbol('room-text-local');
const REMOTE = Symbol('room-text-remote');

/** Splits an insert so each resulting update stays within `MAX_ROOM_TEXT_UPDATE_BYTES` (base64 of the UTF-8 plus overhead). */
function chunks(insert: string): [number, string][] {
  if (!insert) return [];
  const maxBytes = Math.floor((MAX_ROOM_TEXT_UPDATE_BYTES * 3) / 4) - 256;
  const out: [number, string][] = [];
  let start = 0;
  while (start < insert.length) {
    let end = Math.min(insert.length, start + Math.floor(maxBytes / 4));
    while (end < insert.length && utf8Bytes(insert.slice(start, end + 1024)) <= maxBytes) end = Math.min(insert.length, end + 1024);
    if (end < insert.length && isHighSurrogate(insert.charCodeAt(end - 1))) end -= 1;
    out.push([start, insert.slice(start, end)]);
    start = end;
  }
  return out;
}

export class RoomTextTooLargeError extends Error {
  readonly code = 'too-large' as const;
  constructor() {
    super(`room text would exceed ${MAX_ROOM_TEXT_BYTES} bytes`);
    this.name = 'RoomTextTooLargeError';
  }
}
