import type { UserPrincipal } from '../principals.js';
import type { RoomChange, RoomOp, RoomRecordKey, RoomRecordState } from './protocol.js';
import { applyRoomTextUpdate, isRoomTextReset, mergeRoomTextState } from './text.js';
import type { RoomTextState, RoomTextUpdate } from './text-types.js';

/**
 * The pure reducer: replays ordered changes into current records. Every replica (desktop, service, cloud agent) uses this
 * one, so they converge. It does not depend on the order changes arrive in: each field keeps the position that last set it
 * and only a higher position replaces it, so replaying, re-delivering or catching up out of order give the same records.
 *
 * - `set` writes only the fields it carries; per field the higher position wins (later write wins, the earlier stays in the log).
 * - `delete` leaves a marker (`deletedSeq`). A deleted record ignores every `set`, before or after, so a late edit made
 *   without seeing the delete never revives it. To re-create, use a new record key.
 * - A `set` whose type differs from the record's type is ignored.
 * - `text` entries merge into the field's text state (`applyRoomTextUpdate`): never later-wins, every character kept. A
 *   field that has text state ignores plain `set` values.
 */
export type RoomRecords = Map<RoomRecordKey, RoomRecordState>;

export type RoomApplyOutcome =
  | { kind: 'applied'; record: RoomRecordState }
  | { kind: 'ignored'; reason: 'deleted' | 'type-mismatch' | 'stale' };

/** The last position that changed a record, for the `ifSeq` check. 0 for a record that does not exist. */
export function roomRecordLastSeq(record: RoomRecordState | undefined): number {
  if (!record) return 0;
  return Math.max(record.updatedSeq, record.deletedSeq ?? 0);
}

/** `ifSeq` holds when the record has not changed after the position the sender saw. */
export function roomIfSeqHolds(lastSeq: number | undefined, ifSeq: number | undefined): boolean {
  return ifSeq === undefined || (lastSeq ?? 0) <= ifSeq;
}

/** Applies one ordered change to `records` (replacing the record object, never mutating it). */
export function applyRoomChange(records: RoomRecords, change: RoomChange): RoomApplyOutcome {
  const current = records.get(change.record);
  if (current && current.type !== change.type) return { kind: 'ignored', reason: 'type-mismatch' };
  if (change.op === 'delete') {
    if (current?.deletedSeq !== undefined && current.deletedSeq <= change.seq) return { kind: 'ignored', reason: 'deleted' };
    // The marker depends only on the earliest delete, so replicas that saw the record's sets in any order agree on it.
    const record: RoomRecordState = {
      key: change.record,
      type: change.type,
      fields: {},
      fieldSeqs: {},
      createdSeq: change.seq,
      updatedSeq: change.seq,
      deletedSeq: change.seq,
      updatedBy: change.author,
    };
    records.set(change.record, record);
    return { kind: 'applied', record };
  }
  if (current?.deletedSeq !== undefined) return { kind: 'ignored', reason: 'deleted' };
  const fields = { ...(current?.fields ?? {}) };
  const fieldSeqs = { ...(current?.fieldSeqs ?? {}) };
  let texts: Record<string, RoomTextState> | undefined = current?.texts ? { ...current.texts } : undefined;
  let applied = false;
  for (const [name, update] of Object.entries(change.text ?? {})) {
    const outcome = applyRoomTextUpdate(texts?.[name], update, change.seq);
    if (outcome.kind !== 'applied') continue;
    texts = { ...(texts ?? {}), [name]: outcome.text };
    fields[name] = outcome.value;
    fieldSeqs[name] = Math.max(fieldSeqs[name] ?? 0, change.seq);
    applied = true;
  }
  for (const [name, value] of Object.entries(change.set ?? {})) {
    if (texts?.[name] || (fieldSeqs[name] ?? 0) >= change.seq) continue;
    fields[name] = value;
    fieldSeqs[name] = change.seq;
    applied = true;
  }
  const createdSeq = Math.min(current?.createdSeq ?? change.seq, change.seq);
  if (!applied && current && createdSeq === current.createdSeq) return { kind: 'ignored', reason: 'stale' };
  const newest = !current || change.seq > current.updatedSeq;
  const record: RoomRecordState = {
    key: change.record,
    type: change.type,
    fields,
    fieldSeqs,
    createdSeq,
    updatedSeq: newest ? change.seq : current.updatedSeq,
    updatedBy: newest ? change.author : current.updatedBy,
  };
  if (texts) record.texts = texts;
  records.set(change.record, record);
  return { kind: 'applied', record };
}

/** Replays changes into a new record set. */
export function replayRoomChanges(changes: Iterable<RoomChange>, into: RoomRecords = new Map()): RoomRecords {
  for (const change of changes) applyRoomChange(into, change);
  return into;
}

/** A local change not yet ordered by the server (in the outbox). */
export type RoomPendingChange = { record: RoomRecordKey; type: string; op: RoomOp; set?: Record<string, unknown>; text?: Record<string, RoomTextUpdate> };

/**
 * What a screen shows: confirmed records with this desktop's pending changes on top, oldest first. Pending changes are
 * newer than anything confirmed from this desktop's point of view, so they win; once ordered they come back as changes.
 * Records deleted (confirmed or pending) are left out.
 */
export function viewRoomRecords(
  confirmed: ReadonlyMap<RoomRecordKey, RoomRecordState>,
  pending: readonly RoomPendingChange[] = [],
  /** This desktop's person: the author of records that exist only in the outbox so far. */
  self: UserPrincipal = 'user:local',
): Map<RoomRecordKey, RoomRecordState> {
  const view = new Map(confirmed);
  for (const change of pending) {
    const current = view.get(change.record);
    if (current && current.type !== change.type) continue;
    if (change.op === 'delete') {
      if (current) view.set(change.record, { ...current, deletedSeq: current.deletedSeq ?? Number.MAX_SAFE_INTEGER });
      continue;
    }
    if (current?.deletedSeq !== undefined) continue;
    const fields = { ...(current?.fields ?? {}) };
    let texts = current?.texts;
    for (const [name, value] of Object.entries(change.set ?? {})) if (!texts?.[name]) fields[name] = value;
    for (const [name, update] of Object.entries(change.text ?? {})) {
      const text = texts?.[name];
      if (isRoomTextReset(update)) {
        const merged = mergeRoomTextState(update.reset, []);
        if (!merged || update.gen <= (text?.gen ?? 0)) continue;
        texts = { ...(texts ?? {}), [name]: { gen: update.gen, state: merged.state, resetSeq: 0 } };
        fields[name] = merged.value;
        continue;
      }
      if (update.gen !== (text?.gen ?? 0)) continue;
      const merged = mergeRoomTextState(text?.state, [update.update]);
      if (!merged) continue;
      texts = { ...(texts ?? {}), [name]: { gen: update.gen, state: merged.state, resetSeq: text?.resetSeq ?? 0 } };
      fields[name] = merged.value;
    }
    const next: RoomRecordState = {
      key: change.record,
      type: change.type,
      fields,
      fieldSeqs: current?.fieldSeqs ?? {},
      createdSeq: current?.createdSeq ?? 0,
      updatedSeq: current?.updatedSeq ?? 0,
      updatedBy: current?.updatedBy ?? self,
    };
    if (texts) next.texts = texts;
    view.set(change.record, next);
  }
  for (const [key, record] of view) if (record.deletedSeq !== undefined) view.delete(key);
  return view;
}
