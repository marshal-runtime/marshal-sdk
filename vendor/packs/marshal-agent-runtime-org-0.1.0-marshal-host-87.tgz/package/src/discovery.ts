import {
  MAX_SHORT_TEXT,
  OrgContractError,
  fail,
  isLoopbackHost,
  readArray,
  readObject,
  readString,
  readUrl,
  type Reader,
} from './validate.js';

export const ORG_DISCOVERY_PATH = '/.well-known/marshal-org.json';
export const ORG_CONTRACT_VERSION = 1 as const;

export const ORG_FEATURES = [
  'signIn',
  'directory',
  'workspaces',
  'sessions',
  'mentions',
  'events',
  'knowledge',
  'notifications',
  'connections',
  'leases',
  'cloudRuns',
  'runIndex',
  'runEnvelopes',
  'messages',
  'cloudList',
  'placement',
  'forks',
  'sessionWatch',
  'multiUser',
  'onboarding',
  'extensionCatalog',
  'routines',
  'routineEvents',
  'routineActions',
  'routinePromote',
  'liveSessions',
  'sharedTranscript',
  'rooms',
] as const;
export type OrgFeature = (typeof ORG_FEATURES)[number];

export type OrgOidcSettings = {
  /** The OIDC issuer; its `/.well-known/openid-configuration` describes the endpoints. */
  issuer: string;
  /** The public client id Marshal signs in with (authorization code + PKCE, loopback redirect). */
  clientId: string;
  scopes: string[];
};

export type OrgDiscoveryDocument = {
  version: typeof ORG_CONTRACT_VERSION;
  orgId: string;
  displayName: string;
  oidc: OrgOidcSettings;
  /** Base URL of the organization API; every route in this contract is relative to it. */
  apiBase: string;
  /** Features the organization serves. Marshal enables only these. Unknown names are dropped. */
  features: OrgFeature[];
  /** With feature `rooms`: where the rooms service answers. Without valid addresses the `rooms` feature is dropped. */
  rooms?: { apiBase: string; socketUrl: string };
};

const DOCUMENT: Reader = { code: 'invalid-document' };
const ORG_ID_PATTERN = /^[a-z0-9][a-z0-9-]{0,62}$/;
const SCOPE_PATTERN = /^[\x21\x23-\x5b\x5d-\x7e]{1,128}$/;

/** The discovery document URL for an organization URL the user or an admin policy supplied. */
export function orgDiscoveryUrl(orgUrl: string): string {
  let parsed: URL;
  try {
    parsed = new URL(orgUrl);
  } catch {
    throw new OrgContractError('invalid-request', 'orgUrl', 'must be an absolute URL');
  }
  const secure = parsed.protocol === 'https:' || (parsed.protocol === 'http:' && isLoopbackHost(parsed.hostname));
  if (!secure) throw new OrgContractError('invalid-request', 'orgUrl', 'must be https, or http on a loopback host');
  return new URL(ORG_DISCOVERY_PATH, parsed.origin).toString();
}

export function parseOrgDiscoveryDocument(value: unknown): OrgDiscoveryDocument {
  const root = readObject(DOCUMENT, value, 'discovery');
  if (root.version !== ORG_CONTRACT_VERSION) fail(DOCUMENT, 'discovery.version', `must be ${ORG_CONTRACT_VERSION}`);
  const oidc = readObject(DOCUMENT, root.oidc, 'discovery.oidc');
  const known = new Set<string>(ORG_FEATURES);
  const features = readArray(DOCUMENT, root.features, 'discovery.features', 64, (entry, path) =>
    readString(DOCUMENT, entry, path, { max: 64 }),
  ).filter((feature): feature is OrgFeature => known.has(feature));
  const document: OrgDiscoveryDocument = {
    version: ORG_CONTRACT_VERSION,
    orgId: readString(DOCUMENT, root.orgId, 'discovery.orgId', { max: 63, pattern: ORG_ID_PATTERN }),
    displayName: readString(DOCUMENT, root.displayName, 'discovery.displayName', { max: MAX_SHORT_TEXT }),
    oidc: {
      issuer: readUrl(DOCUMENT, oidc.issuer, 'discovery.oidc.issuer'),
      clientId: readString(DOCUMENT, oidc.clientId, 'discovery.oidc.clientId', { max: MAX_SHORT_TEXT }),
      scopes: readArray(DOCUMENT, oidc.scopes, 'discovery.oidc.scopes', 32, (entry, path) =>
        readString(DOCUMENT, entry, path, { max: 128, pattern: SCOPE_PATTERN }),
      ),
    },
    apiBase: readUrl(DOCUMENT, root.apiBase, 'discovery.apiBase', { allowLoopbackHttp: true }),
    features: [...new Set(features)],
  };
  if (document.features.includes('rooms')) {
    const rooms = readRoomsEndpoints(root.rooms);
    if (rooms) document.rooms = rooms;
    else document.features = document.features.filter((feature) => feature !== 'rooms');
  }
  return document;
}

function readRoomsEndpoints(value: unknown): { apiBase: string; socketUrl: string } | undefined {
  try {
    const rooms = readObject(DOCUMENT, value, 'discovery.rooms');
    const apiBase = readUrl(DOCUMENT, rooms.apiBase, 'discovery.rooms.apiBase', { allowLoopbackHttp: true });
    const socketUrl = readString(DOCUMENT, rooms.socketUrl, 'discovery.rooms.socketUrl', { max: 2048 });
    const parsed = new URL(socketUrl);
    if (parsed.protocol !== 'wss:' && !(parsed.protocol === 'ws:' && isLoopbackHost(parsed.hostname))) return undefined;
    return { apiBase, socketUrl };
  } catch (error) {
    if (error instanceof OrgContractError || error instanceof TypeError) return undefined;
    throw error;
  }
}

export function orgSupports(document: OrgDiscoveryDocument, feature: OrgFeature): boolean {
  return document.features.includes(feature);
}
