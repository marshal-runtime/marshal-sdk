import {
  MAX_SHORT_TEXT,
  fail,
  readArray,
  readObject,
  readOptionalString,
  readString,
  type Reader,
} from './validate.js';
import { isSha256Hex } from './cloud.js';
import {
  ONBOARDING_TIERS,
  isOnboardingExtensionId,
  isOnboardingVersion,
  parseOnboardingExtension,
  type OnboardingExtension,
  type OnboardingTier,
} from './onboarding.js';

export const CATALOG_ENTRY_STATUSES = ['approved', 'pending', 'rejected'] as const;
export type CatalogEntryStatus = (typeof CATALOG_ENTRY_STATUSES)[number];

/** One catalog row: the manifest entry plus its review state. Archive urls are on the organization API origin. */
export type OrgCatalogEntry = OnboardingExtension & {
  status: CatalogEntryStatus;
  /** ISO timestamp of the publish (published entries only). */
  publishedAt?: string;
};

/** `GET /v1/onboarding/catalog`. Members see approved entries and their own pending or rejected ones; admins see every pending one. */
export type OrgExtensionCatalog = {
  version: 1;
  /** Whether the caller may change the catalog and review pending entries. */
  isAdmin: boolean;
  recommended: OrgCatalogEntry[];
  available: OrgCatalogEntry[];
  pending: OrgCatalogEntry[];
};

/** `PUT /v1/onboarding/catalog/{id}` (admin). Set the tier and/or pin a version, or remove the entry. */
export type OrgCatalogEntryUpdate = { tier?: OnboardingTier; version?: string; remove?: boolean };

/** `POST /v1/onboarding/catalog/publish` metadata; the archive bytes are the request body. */
export type OrgCatalogPublishMetadata = {
  /** The `runtime-extension.json` identity inside the archive. */
  id: string;
  version: string;
  title: string;
  why: string;
  sha256: string;
  bytes: number;
};

export type OrgCatalogPublishInput = OrgCatalogPublishMetadata & {
  body: Uint8Array | ReadableStream<Uint8Array> | AsyncIterable<Uint8Array>;
};

export const CATALOG_REVIEW_DECISIONS = ['approve', 'reject'] as const;
export type CatalogReviewDecision = (typeof CATALOG_REVIEW_DECISIONS)[number];
export type OrgCatalogReview = { decision: CatalogReviewDecision; reason?: string };

/** Headers that carry `OrgCatalogPublishMetadata` on the publish upload. Text values are URI-encoded. */
export const CATALOG_PUBLISH_HEADERS = {
  id: 'x-marshal-extension-id',
  version: 'x-marshal-extension-version',
  title: 'x-marshal-extension-title',
  why: 'x-marshal-extension-why',
  sha256: 'x-marshal-archive-sha256',
} as const;
export const CATALOG_PUBLISH_CONTENT_TYPE = 'application/gzip';
/** The org server refuses publish uploads above 25 MiB, well under the 256 MiB onboarding archive cap. */
export const MAX_CATALOG_PUBLISH_BYTES = 25 * 1024 * 1024;

const RESPONSE: Reader = { code: 'invalid-response' };
const REQUEST: Reader = { code: 'invalid-request' };

export function parseOrgExtensionCatalog(value: unknown): OrgExtensionCatalog {
  const root = readObject(RESPONSE, value, 'catalog');
  if (root.version !== 1) fail(RESPONSE, 'catalog.version', 'must be 1');
  if (typeof root.isAdmin !== 'boolean') fail(RESPONSE, 'catalog.isAdmin', 'must be a boolean');
  const list = (key: 'recommended' | 'available' | 'pending'): OrgCatalogEntry[] =>
    readArray(RESPONSE, root[key], `catalog.${key}`, 256, parseCatalogEntry);
  return { version: 1, isAdmin: root.isAdmin, recommended: list('recommended'), available: list('available'), pending: list('pending') };
}

function parseCatalogEntry(value: unknown, path: string): OrgCatalogEntry {
  const root = readObject(RESPONSE, value, path);
  if (!(CATALOG_ENTRY_STATUSES as readonly unknown[]).includes(root.status)) fail(RESPONSE, `${path}.status`, 'must be approved, pending or rejected');
  const entry: OrgCatalogEntry = { ...parseOnboardingExtension(root, path), status: root.status as CatalogEntryStatus };
  const publishedAt = readOptionalString(RESPONSE, root.publishedAt, `${path}.publishedAt`, { max: 64 });
  if (publishedAt !== undefined) entry.publishedAt = publishedAt;
  return entry;
}

/** Checks an admin update before it is sent. Throws `OrgContractError` (`invalid-request`). */
export function validateCatalogEntryUpdate(update: OrgCatalogEntryUpdate): OrgCatalogEntryUpdate {
  const root = readObject(REQUEST, update, 'update');
  const out: OrgCatalogEntryUpdate = {};
  if (root.remove !== undefined) {
    if (typeof root.remove !== 'boolean') fail(REQUEST, 'update.remove', 'must be a boolean');
    if (root.remove) {
      if (root.tier !== undefined || root.version !== undefined) fail(REQUEST, 'update', 'remove cannot be combined with tier or version');
      return { remove: true };
    }
  }
  if (root.tier !== undefined) {
    if (!(ONBOARDING_TIERS as readonly unknown[]).includes(root.tier)) fail(REQUEST, 'update.tier', 'must be recommended or available');
    out.tier = root.tier as OnboardingTier;
  }
  if (root.version !== undefined) out.version = readString(REQUEST, root.version, 'update.version', { pattern: /^[0-9]+\.[0-9]+\.[0-9]+(?:[-+][0-9A-Za-z.+-]{1,64})?$/ });
  if (out.tier === undefined && out.version === undefined) fail(REQUEST, 'update', 'needs a tier, a version or remove');
  return out;
}

/** Checks publish metadata before the upload starts. */
export function validateCatalogPublishMetadata(input: OrgCatalogPublishMetadata): OrgCatalogPublishMetadata {
  if (!isOnboardingExtensionId(input.id)) fail(REQUEST, 'id', 'must look like @scope/name');
  if (!isOnboardingVersion(input.version)) fail(REQUEST, 'version', 'must be a semantic version');
  if (!isSha256Hex(input.sha256)) fail(REQUEST, 'sha256', 'must be 64 lowercase hex characters');
  if (!Number.isInteger(input.bytes) || input.bytes < 1 || input.bytes > MAX_CATALOG_PUBLISH_BYTES) {
    fail(REQUEST, 'bytes', `must be an integer from 1 to ${MAX_CATALOG_PUBLISH_BYTES}`);
  }
  readString(REQUEST, input.title, 'title', { max: MAX_SHORT_TEXT });
  readString(REQUEST, input.why, 'why', { max: 1024 });
  return input;
}

export function validateCatalogReview(review: OrgCatalogReview): OrgCatalogReview {
  const root = readObject(REQUEST, review, 'review');
  if (!(CATALOG_REVIEW_DECISIONS as readonly unknown[]).includes(root.decision)) fail(REQUEST, 'review.decision', 'must be approve or reject');
  const out: OrgCatalogReview = { decision: root.decision as CatalogReviewDecision };
  const reason = readOptionalString(REQUEST, root.reason, 'review.reason', { max: 1024 });
  if (reason !== undefined) out.reason = reason;
  return out;
}

/** Reads the entry the publish and review calls answer with. */
export function parseCatalogEntryResponse(value: unknown): OrgCatalogEntry {
  return parseCatalogEntry(value, 'entry');
}
