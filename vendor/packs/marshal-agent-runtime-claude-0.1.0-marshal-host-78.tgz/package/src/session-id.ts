const SESSION_ID_KEY = "sessionId";

/** The ids Claude Code accepts as a session id; a path or anything longer is refused before it reaches the file system. */
export const CLAUDE_SESSION_ID_PATTERN = /^[A-Za-z0-9][A-Za-z0-9_-]{0,127}$/;

/** True when `sessionId` is safe to use as a Claude session file name. */
export function isClaudeSessionId(sessionId: string): boolean {
  return CLAUDE_SESSION_ID_PATTERN.test(sessionId);
}

/**
 * Points a Claude session file at a new session id: every line that carries a top-level `sessionId` gets
 * the new one. Lines that are not JSON objects, or carry no session id, are kept byte for byte.
 */
export function rewriteClaudeSessionId(bytes: Uint8Array, sessionId: string): Uint8Array {
  const lines = new TextDecoder().decode(bytes).split("\n");
  let rewritten = 0;
  const out = lines.map((line) => {
    if (line.trim() === "") return line;
    let parsed: unknown;
    try {
      parsed = JSON.parse(line) as unknown;
    } catch {
      return line;
    }
    if (
      typeof parsed !== "object" ||
      parsed === null ||
      Array.isArray(parsed) ||
      !(SESSION_ID_KEY in parsed) ||
      typeof (parsed as Record<string, unknown>)[SESSION_ID_KEY] !== "string"
    ) {
      return line;
    }
    rewritten += 1;
    return JSON.stringify({ ...parsed, [SESSION_ID_KEY]: sessionId });
  });
  if (rewritten === 0) throw new Error("no-session-id");
  return new TextEncoder().encode(out.join("\n"));
}
