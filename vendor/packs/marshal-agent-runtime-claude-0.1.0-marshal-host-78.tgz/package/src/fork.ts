import { randomUUID } from "node:crypto";
import fs from "node:fs";

import {
  findClaudeSessionFile,
  MAX_NATIVE_STATE_BYTES,
  writeClaudeSessionFile,
  type WrittenClaudeSession,
} from "./session-file.js";
import { isClaudeSessionId, rewriteClaudeSessionId } from "./session-id.js";

/** Marshal's own request captures: debugging copies of what was sent, never part of the conversation. */
const CAPTURE_TYPES = new Set(["api-request", "api-request-shape", "api-request-blob"]);
/** Fields copied from the tail entry so the appended entry looks like one the CLI wrote itself. */
const CARRIED_FIELDS = ["userType", "entrypoint", "cwd", "version", "gitBranch"] as const;
const MCP_NAME_SEPARATOR = "__";
const MARSHAL_CAPABILITY_PREFIX = "marshal.tool.";
/** How long a fork waits for the CLI to write the assistant entry that holds the fork call. */
export const FORK_CALL_FLUSH_TIMEOUT_MS = 5_000;
const FORK_CALL_POLL_MS = 100;
/** The error thrown while the session file does not yet hold an open fork call. */
export const FORK_CALL_NOT_FOUND = "fork-call-not-found";

/** A tool that can carry the fork call inside its input: the call matches when `field` of the input equals (or, for `includes`, contains) the fork capability. */
export interface ForkCallWrapper {
  tool: string;
  field: string;
  match: "equals" | "includes";
}

/** Marshal's wrappers: a capability called through `runtimeInvoke`, or named in a `runtimeExecuteTypeScript` script. */
export const MARSHAL_FORK_WRAPPERS: readonly ForkCallWrapper[] = [
  { tool: "runtimeInvoke", field: "capability", match: "equals" },
  { tool: "runtimeExecuteTypeScript", field: "source", match: "includes" },
];

/** How to find the fork call in a session and what to answer it with. */
export interface ClaudeForkRequest {
  /** The child's session id. */
  sessionId: string;
  /** Tool whose open call started the fork (matched with or without an MCP prefix). */
  toolName: string;
  /** Result of the fork call as the child sees it. */
  result: string;
  /** Result of every other call left open in the same assistant message. */
  otherResult: string;
  /** The capability name a wrapper tool carries for the fork; `marshal.tool.<toolName>` when unset. */
  capability?: string;
  /** Tools that can carry the fork call; Marshal's when unset. */
  wrappers?: readonly ForkCallWrapper[];
}

type Entry = Record<string, unknown>;

function isRecord(value: unknown): value is Entry {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

function contentBlocks(entry: Entry): Entry[] {
  const message = entry["message"];
  if (!isRecord(message) || !Array.isArray(message["content"])) return [];
  return message["content"].filter(isRecord);
}

function isNamed(name: unknown, toolName: string): boolean {
  return (
    typeof name === "string" &&
    (name === toolName || name.endsWith(`${MCP_NAME_SEPARATOR}${toolName}`))
  );
}

function matchesTool(block: Entry, request: ClaudeForkRequest): boolean {
  if (isNamed(block["name"], request.toolName)) return true;
  const input = block["input"];
  if (!isRecord(input)) return false;
  const capability = request.capability ?? `${MARSHAL_CAPABILITY_PREFIX}${request.toolName}`;
  return (request.wrappers ?? MARSHAL_FORK_WRAPPERS).some((wrapper) => {
    if (!isNamed(block["name"], wrapper.tool)) return false;
    const value = input[wrapper.field];
    if (typeof value !== "string") return false;
    return wrapper.match === "equals" ? value === capability : value.includes(capability);
  });
}

/**
 * Copies a Claude session file into a fork that resumes exactly where the source stands: the
 * conversation entries are kept as they are (so the prompt cache still matches), and the fork tool
 * call that is still open at the end gets the child's own result, written as the CLI writes tool
 * results. Calls left open beside it get `otherResult`. Throws when no open fork call exists or
 * the assistant message that made it has no id.
 */
export function forkClaudeJsonl(bytes: Uint8Array, request: ClaudeForkRequest): Uint8Array {
  const lines = new TextDecoder().decode(bytes).split("\n");
  const kept: string[] = [];
  const entries: Entry[] = [];
  for (const line of lines) {
    if (!line.trim()) continue;
    let parsed: unknown;
    try {
      parsed = JSON.parse(line) as unknown;
    } catch {
      kept.push(line);
      continue;
    }
    if (isRecord(parsed) && typeof parsed["type"] === "string" && CAPTURE_TYPES.has(parsed["type"]))
      continue;
    kept.push(line);
    if (isRecord(parsed)) entries.push(parsed);
  }

  const chain = entries.filter(
    (entry) => typeof entry["uuid"] === "string" && entry["isSidechain"] !== true,
  );
  const forkEntryIndex = chain.findLastIndex(
    (entry) =>
      entry["type"] === "assistant" &&
      contentBlocks(entry).some(
        (block) => block["type"] === "tool_use" && matchesTool(block, request),
      ),
  );
  if (forkEntryIndex < 0) throw new Error(FORK_CALL_NOT_FOUND);
  const forkAssistant = chain[forkEntryIndex] as Entry;
  const forkMessage = forkAssistant["message"];
  const messageId = isRecord(forkMessage) ? forkMessage["id"] : undefined;
  if (typeof messageId !== "string" || !messageId) throw new Error("fork-message-id-missing");

  const calls = chain
    .filter((entry) => {
      if (entry["type"] !== "assistant") return false;
      const message = entry["message"];
      return isRecord(message) && message["id"] === messageId;
    })
    .flatMap(contentBlocks)
    .filter((block) => block["type"] === "tool_use" && typeof block["id"] === "string");
  const answered = new Set(
    chain
      .filter((entry) => entry["type"] === "user")
      .flatMap(contentBlocks)
      .filter((block) => block["type"] === "tool_result")
      .map((block) => block["tool_use_id"]),
  );
  const open = calls.filter((call) => !answered.has(call["id"]));
  if (!open.some((call) => matchesTool(call, request))) throw new Error(FORK_CALL_NOT_FOUND);

  const tail = chain[chain.length - 1] as Entry;
  const content = open.map((call) => {
    const text = matchesTool(call, request) ? request.result : request.otherResult;
    return { tool_use_id: call["id"], type: "tool_result", content: [{ type: "text", text }] };
  });
  const carried = Object.fromEntries(
    CARRIED_FIELDS.filter((field) => field in tail).map((field) => [field, tail[field]]),
  );
  const appended = {
    parentUuid: tail["uuid"],
    isSidechain: false,
    type: "user",
    message: { role: "user", content },
    uuid: randomUUID(),
    timestamp: new Date().toISOString(),
    toolUseResult: content.length === 1 ? content[0]?.content : content.map((c) => c.content),
    sourceToolAssistantUUID: forkAssistant["uuid"],
    ...carried,
    sessionId: request.sessionId,
  };
  kept.push(JSON.stringify(appended));
  return rewriteClaudeSessionId(
    new TextEncoder().encode(`${kept.join("\n")}\n`),
    request.sessionId,
  );
}

/**
 * Writes a fork of a live session as `request.sessionId`: the source file is copied as it is with the
 * open fork call answered for the child. The CLI can run a tool before it has written the assistant
 * entry that called it, so the file is read again until that call is in it or `timeoutMs` passes.
 */
export async function forkClaudeSessionFile(
  configDir: string,
  sourceId: string,
  workingDirectory: string,
  request: ClaudeForkRequest,
  timeoutMs = FORK_CALL_FLUSH_TIMEOUT_MS,
): Promise<WrittenClaudeSession> {
  if (!isClaudeSessionId(sourceId)) throw new Error("Invalid Claude session id");
  const file = await findClaudeSessionFile(configDir, sourceId, workingDirectory);
  if (!file) throw new Error("fork-source-missing");
  const deadline = Date.now() + timeoutMs;
  for (;;) {
    const stat = await fs.promises.stat(file);
    if (stat.size > MAX_NATIVE_STATE_BYTES) throw new Error("native-state-too-large");
    try {
      const bytes = forkClaudeJsonl(await fs.promises.readFile(file), request);
      return await writeClaudeSessionFile(configDir, request.sessionId, workingDirectory, bytes);
    } catch (error) {
      if (!(error instanceof Error) || error.message !== FORK_CALL_NOT_FOUND) throw error;
      if (Date.now() >= deadline) throw error;
      await new Promise((resolve) => setTimeout(resolve, FORK_CALL_POLL_MS));
    }
  }
}
