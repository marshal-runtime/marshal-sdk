# `@marshal/agent-runtime-typescript`

Workflow-free execution of agent-authored TypeScript and JavaScript modules.
Source is compiled with esbuild and evaluated in a dedicated Node child process
with cooperative, defense-in-depth restrictions. This package is not a security
boundary for malicious code.

It also exposes the authoring surface for bounded schema-validated drafts,
content-addressed candidates, and lifecycle delegation through the canonical
Runtime service accessor. Draft ownership and scope come from the host context,
and native activation remains the authority for installed contributions.

```ts
import { createInlineModuleExecutionProvider } from '@marshal/agent-runtime-typescript';

const inlineModules = createInlineModuleExecutionProvider();
const result = await inlineModules.execute(
  {
    source: `
      export default async (input, context) => {
        const discovery = await context.runtime.search({ query: input.question });
        const selected = discovery.matches[0]?.capability.name;
        if (!selected) throw new Error('No matching capability.');
        const exact = await context.runtime.search({ name: selected });
        return context.runtime.invoke(exact.matches[0].capability.name, input);
      };
    `,
    input: { question: 'find relevant code' },
  },
  { broker },
);
await inlineModules.dispose();
```

For editable source, resolve a workspace or runtime-artifact reference before
execution. Artifact access is supplied as a port, so this package has no
dependency on a particular artifact implementation or harness:

```ts
const module = await resolveTypeScriptModuleSource(
  { kind: 'workspace_file', path: '.agent/execution/analyze.ts', export: 'run' },
  { workspaceRoot },
);

const result = await executor.execute({
  source: module.source,
  filename: module.filename,
  entrypoint: module.entrypoint,
  sourceIdentity: module.identity,
  input,
});
```

Workspace paths are relative and containment-checked. Symbolic links are
rejected for the entry and every relative import. Inline and artifact source do
not gain ambient filesystem imports.

## Execution policies

- `brokered` (default) rejects all file, package, URL, and Node builtin imports.
  The VM context does not expose `process` or `require`, and the child uses the
  Node permission model plus a scrubbed environment to reduce accidental
  filesystem/process access. Input, broker responses, console writes, and timer
  handles cross a context-realm JSON bridge; authored code is not handed
  host-realm functions or objects. Modules reach the host only through
  serializable `context.runtime.search` and `context.runtime.invoke` RPC calls.
  Broad search is compact; an exact-name search returns the selected
  capability's complete schemas. Node's VM and permission model do not protect
  against actively malicious code; run untrusted source in an external
  OS/container/VM sandbox.
- `trusted` permits only packages in `allowedPackages` and Node builtins in
  `allowedBuiltins`. This mode exposes normal Node process facilities and is for
  locally trusted code, not hostile input.

Every invocation has a wall-clock timeout, `AbortSignal` cancellation, a combined
stdout/stderr byte limit, a fresh worker process and module cache, and a structured
result containing diagnostics and timing. The executor retains a bounded LRU of
digest-keyed esbuild contexts by default. A cache hit still rebuilds incrementally,
so esbuild validates the complete dependency graph and never executes stale bundled
behavior after an imported workspace file changes. Set `compilationCache: false`
to force cold compilation or `maxCompilationCacheEntries` to bound the retained
contexts. The result's compilation receipt distinguishes `miss`, `hit`, and
`disabled` and records dependency-graph validation.
Call `dispose()` when an executor or provider reaches the end of its lifecycle;
this closes retained esbuild contexts and terminates idle prewarmed workers.

TypeScript source is type-checked (not strict) before it runs, and a type error
still stops the module with `compile_failed` diagnostics carrying source lines.
The parsed TypeScript default libraries are shared by every check in the
process (they ship with the installed `typescript` package and never change
while it runs, and `@typescript/lib-*` replacement packages are not looked up);
authored and workspace sources are always parsed fresh. A cache hit repeats the
check only when a source the check reads changed. A check that read any other
file (a `/// <reference path>` or `<reference types>` target, or a probe for
one) is never reused, so the next call checks again.

The executor keeps a few idle prewarmed workers so a call does not pay process
startup on the critical path. A worker runs exactly one invocation: every call
still gets a process that has never run anything, with a fresh VM/module record,
and the replacement is started in parallel for the next call. A trusted worker is
prewarmed only for the exact working directory, Node executable and environment
it would have been started with on demand, and is used only if the directory at
that path is still the one it started in (same device, inode and birth time), so
trusted code observes the same process state as before, `process.argv` included.
At most `maxPreparedWorkers` idle workers (default 2, `0` disables prewarming)
are kept across all modes and working directories; the least recently used is
stopped first. An idle worker is stopped after `preparedWorkerIdleMs` (default
60 s), leaves the pool at once if it dies, exits if its host goes away, and does
not keep the host process alive. Its temporary directory is removed when it
exits, or when the host exits normally; if the host is killed (for example by
SIGTERM), an idle trusted worker removes its own directory as it exits, while an
idle brokered worker, which may not write files, leaves its one directory behind
(as before prewarming covered trusted mode), as does a worker killed mid-call.

Node 22.13 or newer is required because execution uses the stable
`--permission` flag. Earlier Node 20/22 releases used experimental flag names and
are not supported by this package.

Results also include the source SHA-256, the digest of every bundled workspace
source file, imported package names and resolved versions, imported Node
builtins, Node/platform identity, a module digest, and an environment
fingerprint. Runtime failures retain source-mapped file/line diagnostics.
