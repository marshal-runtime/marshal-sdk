import {
  RUNTIME_PROTOCOL_VERSION,
  type CapabilityDescriptor,
  type CapabilityProvider,
  type InvocationContext,
} from '@marshal/agent-runtime-core';

/**
 * `marshal.agent.*`: start and drive ordinary Marshal child sessions from any capability
 * (an extension's generation pipeline, a TypeScript block). The runtime owns the capabilities;
 * a host registers how sessions really run by implementing {@link MarshalRuntimeAgentPort}:
 * the desktop over its session manager, a headless host over an agent SDK.
 * Names, fields and schemas match the desktop's original provider, so extensions written
 * against the desktop call the same capabilities on any host.
 */

export const MARSHAL_RUNTIME_AGENT_PROVIDER_ID = 'marshal.agent-orchestration';
export const MARSHAL_RUNTIME_AGENT_CAPABILITY_PREFIX = 'marshal.agent.';
export const MARSHAL_RUNTIME_AGENT_PERMISSION = Object.freeze({
  launch: 'marshal.agent.launch',
  read: 'marshal.agent.read',
  message: 'marshal.agent.message',
  cancel: 'marshal.agent.cancel',
} as const);

export const MARSHAL_RUNTIME_AGENT_REASONING_EFFORTS = ['low', 'medium', 'high', 'xhigh', 'max'] as const;
export const MARSHAL_RUNTIME_AGENT_ROLES = [
  'planner', 'worker', 'reviewer', 'validator', 'reconciler', 'brain', 'swarm',
] as const;
export const MARSHAL_RUNTIME_AGENT_MAX_SYSTEM_PROMPT_CHARS = 65_536;
export const MARSHAL_RUNTIME_AGENT_MAX_ATTACHMENTS = 20;
export const MARSHAL_RUNTIME_AGENT_MAX_ATTACHMENT_PATH_CHARS = 4_096;
export const MARSHAL_RUNTIME_AGENT_MAX_MCP_SERVERS = 32;
export const MARSHAL_RUNTIME_AGENT_MAX_SKILLS = 64;
export const MARSHAL_RUNTIME_AGENT_MAX_EXTENSIONS = 64;
export const MARSHAL_RUNTIME_AGENT_MAX_NATIVE_TOOLS = 64;
/** An extension identity (`@scope/name` or a bare name): what a launch's `extensions` allowlist names. */
export const MARSHAL_RUNTIME_AGENT_EXTENSION_PATTERN = '^[A-Za-z0-9@][A-Za-z0-9_.@:/-]*$';
/** A runtime built-in tool name (Read, Bash, ...). */
export const MARSHAL_RUNTIME_AGENT_NATIVE_TOOL_PATTERN = '^[A-Za-z][A-Za-z0-9_.-]*$';
/** A host MCP server key: the configured server name (custom servers may contain spaces). */
export const MARSHAL_RUNTIME_AGENT_MCP_SERVER_PATTERN = '^[A-Za-z0-9][A-Za-z0-9 _.@:/()-]*$';
/** A skill name, including plugin-qualified (`plugin:skill`) and directory-scoped (`apps/web:deploy`) names. */
export const MARSHAL_RUNTIME_AGENT_SKILL_NAME_PATTERN = '^[A-Za-z0-9][A-Za-z0-9_.:/@-]*$';

const DELIVERY_MODES = ['queue', 'interrupt'] as const;
const MAX_ALLOWED_TOOLS = 64;
const ALLOWED_TOOL_NAME_SOURCE = '^[A-Za-z][A-Za-z0-9_.-]*$';
const ALLOWED_TOOL_NAME = new RegExp(ALLOWED_TOOL_NAME_SOURCE);
const MAX_SCOPE_NAME_CHARS = 128;
const MCP_SERVER_NAME = new RegExp(MARSHAL_RUNTIME_AGENT_MCP_SERVER_PATTERN);
const SKILL_NAME = new RegExp(MARSHAL_RUNTIME_AGENT_SKILL_NAME_PATTERN);

const LAUNCH_LIST_RULES = {
  mcpServers: { maximum: MARSHAL_RUNTIME_AGENT_MAX_MCP_SERVERS, pattern: MCP_SERVER_NAME, noun: 'MCP server keys' },
  skills: { maximum: MARSHAL_RUNTIME_AGENT_MAX_SKILLS, pattern: SKILL_NAME, noun: 'skill names' },
  extensions: { maximum: MARSHAL_RUNTIME_AGENT_MAX_EXTENSIONS, pattern: new RegExp(MARSHAL_RUNTIME_AGENT_EXTENSION_PATTERN), noun: 'extension identities' },
  nativeTools: { maximum: MARSHAL_RUNTIME_AGENT_MAX_NATIVE_TOOLS, pattern: new RegExp(MARSHAL_RUNTIME_AGENT_NATIVE_TOOL_PATTERN), noun: 'native tool names' },
} as const;
export type MarshalRuntimeAgentLaunchList = keyof typeof LAUNCH_LIST_RULES;

export type MarshalRuntimeAgentReasoningEffort = (typeof MARSHAL_RUNTIME_AGENT_REASONING_EFFORTS)[number];
export type MarshalRuntimeAgentRole = (typeof MARSHAL_RUNTIME_AGENT_ROLES)[number];
/** A failed turn leaves the agent idle with an error message in its transcript. */
export type MarshalRuntimeAgentState = 'running' | 'idle';

/** The calling session: the owner of every agent it launches. */
export interface MarshalRuntimeAgentScope {
  readonly sessionId: string;
  readonly workspaceName: string;
}

export interface MarshalRuntimeAgentUsage {
  readonly inputTokens?: number;
  readonly outputTokens?: number;
  readonly cachedInputTokens?: number;
  readonly costUsd?: number;
}

/** A turn receipt: references and counters, never copied conversation text. */
export interface MarshalRuntimeAgentExecutionEvidence {
  readonly executionId: string;
  readonly sessionId: string;
  readonly transcriptRef: string;
  readonly model?: string;
  readonly reasoningEffort?: MarshalRuntimeAgentReasoningEffort;
  readonly usage?: MarshalRuntimeAgentUsage;
  readonly usageByModel?: readonly { readonly model?: string; readonly usage: MarshalRuntimeAgentUsage }[];
  readonly callIds?: readonly string[];
}

export interface MarshalRuntimeAgentSummary extends Partial<MarshalRuntimeAgentExecutionEvidence> {
  readonly id: string;
  readonly name: string;
  readonly state: MarshalRuntimeAgentState;
  readonly createdAt: string;
  readonly updatedAt: string;
  readonly workspaceName?: string;
  readonly repoPath?: string;
  readonly model?: string;
  readonly reasoningEffort?: MarshalRuntimeAgentReasoningEffort;
  readonly soul?: string;
  readonly runtimeAgentRole?: MarshalRuntimeAgentRole;
  readonly runtimeDelegationId?: string;
  readonly runtimeTaskController?: string;
}

export interface MarshalRuntimeAgentLaunchRequest {
  readonly scope: MarshalRuntimeAgentScope;
  readonly task: string;
  readonly idempotencyKey: string;
  /** Adopt an already running session instead of starting one. */
  readonly sessionId?: string;
  readonly workspaceName?: string;
  readonly repoPath?: string;
  readonly name?: string;
  readonly agentName?: string;
  readonly model?: string;
  /** Execution runtime, optionally with an account (`claude@work`); hosts with one backend may ignore it. */
  readonly runtime?: string;
  readonly reasoningEffort?: MarshalRuntimeAgentReasoningEffort;
  readonly soul?: string;
  readonly runtimeAgentRole?: MarshalRuntimeAgentRole;
  readonly runtimeDelegationId?: string;
  readonly runtimeTaskController?: string;
  /** Wake the owner session with a readiness notice whenever the agent goes idle. */
  readonly wakeParentOnIdle?: boolean;
  /** Host tool names the child may call; every other tool, MCP server, and skill is excluded unless listed below. */
  readonly allowedTools?: readonly string[];
  /** Host MCP server keys the child may use, applied even with `allowedTools`; absent keeps the host default. */
  readonly mcpServers?: readonly string[];
  /** Skill names the child may use, applied even with `allowedTools`; absent keeps the host default. */
  readonly skills?: readonly string[];
  /** Extension identities whose capabilities and skills the child sees (a profile's allowlist); host essentials stay. Absent keeps every installed extension. */
  readonly extensions?: readonly string[];
  /** Runtime built-in tools the child keeps (Read, Bash, ...); absent keeps all. Hosts that cannot restrict them refuse the launch. */
  readonly nativeTools?: readonly string[];
  /** Replaces the host's assembled system prompt and excludes repository context. */
  readonly systemPrompt?: string;
  /** Appended as the last section of the host's normal system prompt; not combined with `systemPrompt`. */
  readonly systemPromptAppend?: string;
  /** Absolute file paths attached to the child's first message. */
  readonly attachments?: readonly string[];
  readonly createWorktree?: boolean;
  readonly worktreeName?: string;
  readonly branchName?: string;
  readonly baseRef?: string;
  readonly signal?: AbortSignal;
}

export interface MarshalRuntimeAgentMessageResult {
  readonly agent: MarshalRuntimeAgentSummary;
  readonly accepted: true;
  readonly messageId?: string;
  readonly deliveryState?: string;
}

export interface MarshalRuntimeAgentTranscriptMessage {
  readonly id: string;
  readonly role: 'user' | 'assistant' | 'system';
  readonly content: string;
  readonly timestamp: string;
  readonly error?: boolean;
}

export interface MarshalRuntimeAgentTranscript {
  readonly agent: MarshalRuntimeAgentSummary;
  readonly messageCount: number;
  readonly showing: number;
  readonly messages: readonly MarshalRuntimeAgentTranscriptMessage[];
  readonly result?: string;
}

export interface MarshalRuntimeAgentWaitResult
  extends Omit<Partial<MarshalRuntimeAgentExecutionEvidence>, 'usage'> {
  readonly state: 'completed' | 'timeout';
  readonly agent: MarshalRuntimeAgentSummary;
  readonly result?: string;
  readonly usage?: MarshalRuntimeAgentUsage & { readonly tokens?: number };
}

/** What a host implements so `marshal.agent.*` runs its sessions. Agents are owned by `scope.sessionId`. */
export interface MarshalRuntimeAgentPort {
  launch(request: MarshalRuntimeAgentLaunchRequest): Promise<MarshalRuntimeAgentSummary>;
  list(scope: MarshalRuntimeAgentScope, signal?: AbortSignal): Promise<readonly MarshalRuntimeAgentSummary[]>;
  get(scope: MarshalRuntimeAgentScope, agentId: string, signal?: AbortSignal): Promise<MarshalRuntimeAgentSummary | null>;
  send(
    scope: MarshalRuntimeAgentScope,
    agentId: string,
    message: string,
    deliveryMode: 'queue' | 'interrupt',
    signal?: AbortSignal,
  ): Promise<MarshalRuntimeAgentMessageResult>;
  transcript(
    scope: MarshalRuntimeAgentScope,
    agentId: string,
    limit?: number,
    signal?: AbortSignal,
  ): Promise<MarshalRuntimeAgentTranscript>;
  wait(
    scope: MarshalRuntimeAgentScope,
    agentId: string,
    options?: { readonly messageId?: string; readonly timeoutMs?: number; readonly signal?: AbortSignal },
  ): Promise<MarshalRuntimeAgentWaitResult>;
  cancel(scope: MarshalRuntimeAgentScope, agentId: string, signal?: AbortSignal): Promise<MarshalRuntimeAgentSummary>;
  /** Switch an idle owned agent's model in place; the summary reports the effective model. */
  setModel(
    scope: MarshalRuntimeAgentScope,
    agentId: string,
    model: string,
    reasoningEffort?: MarshalRuntimeAgentReasoningEffort,
    signal?: AbortSignal,
  ): Promise<MarshalRuntimeAgentSummary>;
}

export interface RuntimeAgentProviderOptions {
  readonly providerId?: string;
  /**
   * Who is calling. Defaults to the invocation's `scope.sessionId` and
   * `metadata.marshalWorkspaceName` (falling back to `defaultWorkspaceName`); a call without
   * both is denied, so an agent always has an owner.
   */
  readonly resolveScope?: (context: InvocationContext) => MarshalRuntimeAgentScope | undefined;
  /** Workspace name for hosts whose invocations carry no `marshalWorkspaceName` (one checkout per host). */
  readonly defaultWorkspaceName?: string;
}

const USAGE_SCHEMA = {
  type: 'object',
  properties: {
    inputTokens: { type: 'number' },
    outputTokens: { type: 'number' },
    cachedInputTokens: { type: 'number' },
    costUsd: { type: 'number' },
  },
} as const;
const USAGE_BY_MODEL_SCHEMA = {
  type: 'array',
  items: { type: 'object', properties: { model: { type: 'string' }, usage: { type: 'object' } } },
} as const;

export const MARSHAL_RUNTIME_AGENT_SCHEMA = {
  type: 'object',
  additionalProperties: false,
  required: ['id', 'name', 'state', 'createdAt', 'updatedAt'],
  properties: {
    sessionId: { type: 'string' },
    executionId: { type: 'string' },
    transcriptRef: { type: 'string' },
    usage: USAGE_SCHEMA,
    usageByModel: USAGE_BY_MODEL_SCHEMA,
    callIds: { type: 'array', items: { type: 'string' } },
    id: { type: 'string' },
    name: { type: 'string' },
    state: { enum: ['running', 'idle'] },
    createdAt: { type: 'string' },
    updatedAt: { type: 'string' },
    workspaceName: { type: 'string' },
    repoPath: { type: 'string' },
    model: { type: 'string' },
    reasoningEffort: { enum: MARSHAL_RUNTIME_AGENT_REASONING_EFFORTS },
    soul: { type: 'string' },
    runtimeAgentRole: { enum: MARSHAL_RUNTIME_AGENT_ROLES },
  },
} as const;

export const MARSHAL_RUNTIME_TRANSCRIPT_MESSAGE_SCHEMA = {
  type: 'object',
  additionalProperties: false,
  required: ['id', 'role', 'content', 'timestamp'],
  properties: {
    id: { type: 'string' },
    role: { enum: ['user', 'assistant', 'system'] },
    content: { type: 'string' },
    timestamp: { type: 'string' },
    error: { type: 'boolean' },
  },
} as const;

const AGENT_OUTPUT = {
  type: 'object',
  additionalProperties: false,
  required: ['agent'],
  properties: { agent: MARSHAL_RUNTIME_AGENT_SCHEMA },
} as const;

export const MARSHAL_RUNTIME_AGENT_DESCRIPTORS: readonly CapabilityDescriptor[] = Object.freeze([
  descriptor(
    'launch',
    'Launch an ordinary Marshal child agent',
    {
      type: 'object',
      additionalProperties: false,
      required: ['task', 'idempotencyKey'],
      properties: {
        task: { type: 'string', minLength: 1, maxLength: 32_768 },
        idempotencyKey: { type: 'string', minLength: 1, maxLength: 256 },
        sessionId: { type: 'string', minLength: 1, maxLength: 256 },
        name: { type: 'string', minLength: 1, maxLength: 256 },
        agentName: { type: 'string', minLength: 1, maxLength: 256 },
        model: { type: 'string', minLength: 1, maxLength: 256 },
        runtime: {
          type: 'string',
          minLength: 1,
          maxLength: 64,
          description:
            'Execution runtime, optionally with an account: claude, cursor, codex, or claude@work. Omit to use configured defaults.',
        },
        reasoningEffort: { enum: MARSHAL_RUNTIME_AGENT_REASONING_EFFORTS },
        soul: { type: 'string', minLength: 1, maxLength: 256 },
        workspaceName: { type: 'string', minLength: 1, maxLength: 256 },
        repoPath: { type: 'string', minLength: 1, maxLength: 4096 },
        runtimeAgentRole: { enum: MARSHAL_RUNTIME_AGENT_ROLES },
        allowedTools: {
          type: 'array',
          maxItems: MAX_ALLOWED_TOOLS,
          uniqueItems: true,
          items: { type: 'string', pattern: ALLOWED_TOOL_NAME_SOURCE, maxLength: 128 },
        },
        mcpServers: {
          type: 'array',
          maxItems: MARSHAL_RUNTIME_AGENT_MAX_MCP_SERVERS,
          uniqueItems: true,
          items: { type: 'string', pattern: MARSHAL_RUNTIME_AGENT_MCP_SERVER_PATTERN, maxLength: MAX_SCOPE_NAME_CHARS },
          description: 'Host MCP server keys the agent may use, even with allowedTools. Omit to keep the host default.',
        },
        skills: {
          type: 'array',
          maxItems: MARSHAL_RUNTIME_AGENT_MAX_SKILLS,
          uniqueItems: true,
          items: { type: 'string', pattern: MARSHAL_RUNTIME_AGENT_SKILL_NAME_PATTERN, maxLength: MAX_SCOPE_NAME_CHARS },
          description: 'Skill names the agent may use, even with allowedTools. Omit to keep the host default.',
        },
        extensions: {
          type: 'array',
          maxItems: MARSHAL_RUNTIME_AGENT_MAX_EXTENSIONS,
          uniqueItems: true,
          items: { type: 'string', pattern: MARSHAL_RUNTIME_AGENT_EXTENSION_PATTERN, maxLength: MAX_SCOPE_NAME_CHARS },
          description: 'Extension identities whose capabilities and skills the agent sees. Host essentials stay visible. Omit to keep every installed extension.',
        },
        nativeTools: {
          type: 'array',
          maxItems: MARSHAL_RUNTIME_AGENT_MAX_NATIVE_TOOLS,
          uniqueItems: true,
          items: { type: 'string', pattern: MARSHAL_RUNTIME_AGENT_NATIVE_TOOL_PATTERN, maxLength: MAX_SCOPE_NAME_CHARS },
          description: 'Runtime built-in tools the agent keeps. Omit to keep all. A host that cannot restrict them refuses the launch.',
        },
        systemPrompt: { type: 'string', minLength: 1, maxLength: MARSHAL_RUNTIME_AGENT_MAX_SYSTEM_PROMPT_CHARS },
        systemPromptAppend: {
          type: 'string',
          minLength: 1,
          maxLength: MARSHAL_RUNTIME_AGENT_MAX_SYSTEM_PROMPT_CHARS,
          description: 'Text appended as the last section of the host\'s normal system prompt. Not with systemPrompt or sessionId.',
        },
        attachments: {
          type: 'array',
          maxItems: MARSHAL_RUNTIME_AGENT_MAX_ATTACHMENTS,
          items: { type: 'string', minLength: 1, maxLength: MARSHAL_RUNTIME_AGENT_MAX_ATTACHMENT_PATH_CHARS },
        },
        createWorktree: { type: 'boolean' },
        worktreeName: { type: 'string', minLength: 1, maxLength: 256 },
        branchName: { type: 'string', minLength: 1, maxLength: 256 },
        baseRef: { type: 'string', minLength: 1, maxLength: 4096 },
      },
    },
    AGENT_OUTPUT,
    MARSHAL_RUNTIME_AGENT_PERMISSION.launch,
    'high',
  ),
  descriptor(
    'list',
    'List ordinary child agents owned by the current Marshal session',
    { type: 'object', additionalProperties: false },
    {
      type: 'object',
      additionalProperties: false,
      required: ['agents'],
      properties: { agents: { type: 'array', items: MARSHAL_RUNTIME_AGENT_SCHEMA } },
    },
    MARSHAL_RUNTIME_AGENT_PERMISSION.read,
    'low',
  ),
  descriptor(
    'get',
    'Get one ordinary child agent owned by the current Marshal session',
    agentIdSchema(),
    {
      type: 'object',
      additionalProperties: false,
      required: ['agent'],
      properties: { agent: { anyOf: [MARSHAL_RUNTIME_AGENT_SCHEMA, { type: 'null' }] } },
    },
    MARSHAL_RUNTIME_AGENT_PERMISSION.read,
    'low',
  ),
  descriptor(
    'send',
    'Send a message to an ordinary child agent owned by the current Marshal session',
    {
      type: 'object',
      additionalProperties: false,
      required: ['agentId', 'message'],
      properties: {
        agentId: idProperty(),
        message: { type: 'string', minLength: 1 },
        deliveryMode: { enum: DELIVERY_MODES },
      },
    },
    {
      type: 'object',
      additionalProperties: false,
      required: ['agent', 'accepted'],
      properties: {
        agent: MARSHAL_RUNTIME_AGENT_SCHEMA,
        accepted: { const: true },
        messageId: { type: 'string' },
        deliveryState: { type: 'string' },
      },
    },
    MARSHAL_RUNTIME_AGENT_PERMISSION.message,
    'medium',
  ),
  descriptor(
    'transcript',
    'Read a bounded transcript and latest result from an owned ordinary child agent',
    {
      type: 'object',
      additionalProperties: false,
      required: ['agentId'],
      properties: { agentId: idProperty(), limit: { type: 'integer', minimum: 1, maximum: 20 } },
    },
    {
      type: 'object',
      additionalProperties: false,
      required: ['agent', 'messageCount', 'showing', 'messages'],
      properties: {
        agent: MARSHAL_RUNTIME_AGENT_SCHEMA,
        messageCount: { type: 'integer', minimum: 0 },
        showing: { type: 'integer', minimum: 0 },
        messages: { type: 'array', items: MARSHAL_RUNTIME_TRANSCRIPT_MESSAGE_SCHEMA },
        result: { type: 'string' },
      },
    },
    MARSHAL_RUNTIME_AGENT_PERMISSION.read,
    'low',
  ),
  descriptor(
    'wait',
    'Wait for an owned ordinary child agent to become idle or reach a bounded timeout',
    {
      type: 'object',
      additionalProperties: false,
      required: ['agentId'],
      properties: {
        agentId: idProperty(),
        messageId: { type: 'string', minLength: 1, maxLength: 256 },
        timeoutMs: { type: 'integer', minimum: 1, maximum: 300_000 },
      },
    },
    {
      type: 'object',
      additionalProperties: false,
      required: ['state', 'agent'],
      properties: {
        sessionId: { type: 'string' },
        executionId: { type: 'string' },
        transcriptRef: { type: 'string' },
        model: { type: 'string' },
        reasoningEffort: { enum: MARSHAL_RUNTIME_AGENT_REASONING_EFFORTS },
        usageByModel: USAGE_BY_MODEL_SCHEMA,
        callIds: { type: 'array', items: { type: 'string' } },
        state: { enum: ['completed', 'timeout'] },
        agent: MARSHAL_RUNTIME_AGENT_SCHEMA,
        result: { type: 'string' },
        usage: {
          type: 'object',
          additionalProperties: false,
          properties: {
            inputTokens: { type: 'integer', minimum: 0 },
            outputTokens: { type: 'integer', minimum: 0 },
            cachedInputTokens: { type: 'integer', minimum: 0 },
            tokens: { type: 'integer', minimum: 0 },
            costUsd: { type: 'number', minimum: 0 },
          },
        },
      },
    },
    MARSHAL_RUNTIME_AGENT_PERMISSION.read,
    'low',
  ),
  descriptor(
    'cancel',
    'Cancel the current turn of an owned ordinary child agent',
    agentIdSchema(),
    AGENT_OUTPUT,
    MARSHAL_RUNTIME_AGENT_PERMISSION.cancel,
    'medium',
  ),
  descriptor(
    'setModel',
    "Switch an idle ordinary child agent owned by the current Marshal session to another model, including one that runs on another runtime; plain model ids follow the app's model runtime routing",
    {
      type: 'object',
      additionalProperties: false,
      required: ['agentId', 'model'],
      properties: {
        agentId: idProperty(),
        model: { type: 'string', minLength: 1, maxLength: 256 },
        reasoningEffort: { enum: MARSHAL_RUNTIME_AGENT_REASONING_EFFORTS },
      },
    },
    AGENT_OUTPUT,
    MARSHAL_RUNTIME_AGENT_PERMISSION.message,
    'medium',
  ),
]);

const LAUNCH_KEYS = [
  'task', 'idempotencyKey', 'sessionId', 'name', 'agentName', 'model', 'runtime', 'reasoningEffort',
  'soul', 'workspaceName', 'repoPath', 'runtimeAgentRole', 'allowedTools', 'mcpServers', 'skills', 'extensions', 'nativeTools',
  'systemPrompt', 'systemPromptAppend', 'attachments', 'createWorktree', 'worktreeName', 'branchName', 'baseRef',
] as const;

export function createRuntimeAgentProvider(
  port: MarshalRuntimeAgentPort,
  options: RuntimeAgentProviderOptions = {},
): CapabilityProvider {
  const byName = new Map(MARSHAL_RUNTIME_AGENT_DESCRIPTORS.map((entry) => [entry.name, entry]));
  return {
    id: options.providerId ?? MARSHAL_RUNTIME_AGENT_PROVIDER_ID,
    version: '1.0.0',
    list: () => MARSHAL_RUNTIME_AGENT_DESCRIPTORS,
    get: (name) => byName.get(name),
    async invoke(name, input, context) {
      const scope = callerScope(context, options);
      const signal = context.signal instanceof AbortSignal ? context.signal : undefined;
      const value = inputRecord(input);
      switch (name.slice(MARSHAL_RUNTIME_AGENT_CAPABILITY_PREFIX.length)) {
        case 'launch': {
          const controller = context.metadata?.runtimeTaskController;
          if (typeof controller === 'string' && context.metadata?.runtimeExtensionIdentity !== controller) {
            throw new Error('Task-managed sessions must launch work through their owning extension task operations.');
          }
          assertKeys(value, LAUNCH_KEYS);
          return { output: { agent: await port.launch(launchRequest(value, scope, context, signal)) } };
        }
        case 'list':
          assertKeys(value, []);
          return { output: { agents: await port.list(scope, signal) } };
        case 'get':
          assertKeys(value, ['agentId']);
          return { output: { agent: await port.get(scope, text(value, 'agentId', 256), signal) } };
        case 'send':
          assertKeys(value, ['agentId', 'message', 'deliveryMode']);
          return {
            output: await port.send(
              scope,
              text(value, 'agentId', 256),
              text(value, 'message'),
              value.deliveryMode === undefined ? 'queue' : enumValue(value, 'deliveryMode', DELIVERY_MODES),
              signal,
            ),
          };
        case 'transcript':
          assertKeys(value, ['agentId', 'limit']);
          return {
            output: await port.transcript(
              scope,
              text(value, 'agentId', 256),
              optionalInteger(value, 'limit', 1, 20),
              signal,
            ),
          };
        case 'wait': {
          assertKeys(value, ['agentId', 'messageId', 'timeoutMs']);
          const messageId = optionalText(value, 'messageId', 256);
          const timeoutMs = optionalInteger(value, 'timeoutMs', 1, 300_000);
          return {
            output: await port.wait(scope, text(value, 'agentId', 256), {
              ...(messageId ? { messageId } : {}),
              ...(timeoutMs === undefined ? {} : { timeoutMs }),
              ...(signal ? { signal } : {}),
            }),
          };
        }
        case 'cancel':
          assertKeys(value, ['agentId']);
          return { output: { agent: await port.cancel(scope, text(value, 'agentId', 256), signal) } };
        case 'setModel':
          assertKeys(value, ['agentId', 'model', 'reasoningEffort']);
          return {
            output: {
              agent: await port.setModel(
                scope,
                text(value, 'agentId', 256),
                text(value, 'model', 256),
                value.reasoningEffort === undefined
                  ? undefined
                  : enumValue(value, 'reasoningEffort', MARSHAL_RUNTIME_AGENT_REASONING_EFFORTS),
                signal,
              ),
            },
          };
        default:
          throw Object.assign(new Error(`Marshal agent capability not found: ${name}.`), { code: 'not_found' });
      }
    },
  };
}

function launchRequest(
  value: Record<string, unknown>,
  scope: MarshalRuntimeAgentScope,
  context: InvocationContext,
  signal: AbortSignal | undefined,
): MarshalRuntimeAgentLaunchRequest {
  const sessionId = optionalText(value, 'sessionId', 256);
  const allowedTools = optionalToolNames(value, 'allowedTools');
  if (allowedTools && sessionId) {
    throw invalidRequest(new TypeError('allowedTools cannot restrict an already running session.'));
  }
  const toolScope = launchToolScope(value);
  if (sessionId && (toolScope.mcpServers || toolScope.skills || toolScope.extensions || toolScope.nativeTools)) {
    throw invalidRequest(new TypeError('mcpServers, skills, extensions and nativeTools cannot change an already running session.'));
  }
  if (sessionId && value.systemPromptAppend !== undefined) {
    throw invalidRequest(new TypeError('systemPromptAppend cannot change an already running session.'));
  }
  const strings = {
    name: optionalText(value, 'name', 256),
    agentName: optionalText(value, 'agentName', 256),
    model: optionalText(value, 'model', 256),
    runtime: optionalText(value, 'runtime', 64),
    soul: optionalText(value, 'soul', 256),
    workspaceName: optionalText(value, 'workspaceName', 256),
    repoPath: optionalText(value, 'repoPath', 4096),
    worktreeName: optionalText(value, 'worktreeName', 256),
    branchName: optionalText(value, 'branchName', 256),
    baseRef: optionalText(value, 'baseRef', 4096),
  };
  const metadata = context.metadata ?? {};
  return {
    scope,
    task: text(value, 'task', 32_768),
    idempotencyKey: text(value, 'idempotencyKey', 256),
    ...(typeof metadata.marshalLaunchDelegationId === 'string'
      ? { runtimeDelegationId: metadata.marshalLaunchDelegationId }
      : {}),
    ...(typeof metadata.marshalLaunchTaskController === 'string'
      ? { runtimeTaskController: metadata.marshalLaunchTaskController }
      : {}),
    ...(metadata.marshalLaunchWakeParent === true ? { wakeParentOnIdle: true } : {}),
    ...(sessionId ? { sessionId } : {}),
    ...Object.fromEntries(Object.entries(strings).filter(([, entry]) => entry !== undefined)),
    ...(value.reasoningEffort === undefined
      ? {}
      : { reasoningEffort: enumValue(value, 'reasoningEffort', MARSHAL_RUNTIME_AGENT_REASONING_EFFORTS) }),
    ...(value.runtimeAgentRole === undefined
      ? {}
      : { runtimeAgentRole: enumValue(value, 'runtimeAgentRole', MARSHAL_RUNTIME_AGENT_ROLES) }),
    ...(allowedTools ? { allowedTools } : {}),
    ...toolScope,
    ...launchOverride(value),
    ...(value.createWorktree === undefined ? {} : { createWorktree: booleanValue(value, 'createWorktree') }),
    ...(signal ? { signal } : {}),
  };
}

/** The shape of systemPrompt, systemPromptAppend and attachments; whether the files exist is the host's check at launch. */
function launchOverride(
  value: Record<string, unknown>,
): Pick<MarshalRuntimeAgentLaunchRequest, 'systemPrompt' | 'systemPromptAppend' | 'attachments'> {
  const { systemPrompt, attachments } = value;
  if (systemPrompt !== undefined && typeof systemPrompt !== 'string') {
    throw invalidRequest(new TypeError('systemPrompt must be a string.'));
  }
  let systemPromptAppend: string | undefined;
  try {
    systemPromptAppend = validateSystemPromptAppend(value.systemPromptAppend, systemPrompt);
  } catch (error) {
    throw error instanceof TypeError ? invalidRequest(error) : error;
  }
  if (attachments !== undefined && (!Array.isArray(attachments) || !attachments.every((entry) => typeof entry === 'string'))) {
    throw invalidRequest(new TypeError('attachments must be an array of file paths.'));
  }
  return {
    ...(systemPrompt !== undefined ? { systemPrompt } : {}),
    ...(systemPromptAppend !== undefined ? { systemPromptAppend } : {}),
    ...(attachments !== undefined ? { attachments: [...attachments] } : {}),
  };
}

/**
 * Shape check for a launch's `systemPromptAppend`, shared with `runtime.delegation.spawn`: a non-empty
 * string within the system prompt bound, never combined with a replacing `systemPrompt`. Throws TypeError.
 */
export function validateSystemPromptAppend(candidate: unknown, systemPrompt: unknown): string | undefined {
  if (candidate === undefined) return undefined;
  if (typeof candidate !== 'string' || candidate.length === 0 || candidate.length > MARSHAL_RUNTIME_AGENT_MAX_SYSTEM_PROMPT_CHARS) {
    throw new TypeError(`systemPromptAppend must be a string of 1 to ${MARSHAL_RUNTIME_AGENT_MAX_SYSTEM_PROMPT_CHARS} characters.`);
  }
  if (systemPrompt !== undefined) {
    throw new TypeError('systemPromptAppend cannot be combined with systemPrompt, which replaces the host prompt.');
  }
  return candidate;
}

function callerScope(context: InvocationContext, options: RuntimeAgentProviderOptions): MarshalRuntimeAgentScope {
  if (options.resolveScope) {
    const resolved = options.resolveScope(context);
    if (resolved?.sessionId?.trim() && resolved.workspaceName?.trim()) return resolved;
  } else {
    const sessionId = context.scope?.sessionId?.trim();
    const named = context.metadata?.marshalWorkspaceName;
    const workspaceName = typeof named === 'string' && named.trim() ? named.trim() : options.defaultWorkspaceName?.trim();
    if (sessionId && workspaceName) return { sessionId, workspaceName };
  }
  throw Object.assign(
    new Error('Marshal agent invocation requires a parent session and workspace scope.'),
    { code: 'permission_denied' },
  );
}

function descriptor(
  suffix: string,
  title: string,
  inputSchema: CapabilityDescriptor['inputSchema'],
  outputSchema: CapabilityDescriptor['outputSchema'],
  permission: string,
  risk: 'low' | 'medium' | 'high',
): CapabilityDescriptor {
  return Object.freeze({
    protocolVersion: RUNTIME_PROTOCOL_VERSION,
    name: `${MARSHAL_RUNTIME_AGENT_CAPABILITY_PREFIX}${suffix}`,
    version: '1.0.0',
    title,
    description: title,
    tags: ['marshal', 'agent', 'orchestration'],
    inputSchema,
    outputSchema,
    permissions: [{ permission, risk }],
  });
}

function idProperty() {
  return { type: 'string', minLength: 1, maxLength: 256 } as const;
}

function agentIdSchema(): CapabilityDescriptor['inputSchema'] {
  return { type: 'object', additionalProperties: false, required: ['agentId'], properties: { agentId: idProperty() } };
}

function invalidRequest<T extends TypeError | RangeError>(error: T): T & { readonly code: 'invalid_request' } {
  return Object.assign(error, { code: 'invalid_request' as const });
}

function inputRecord(input: unknown): Record<string, unknown> {
  if (input === undefined) return {};
  if (typeof input !== 'object' || input === null || Array.isArray(input)) {
    throw invalidRequest(new TypeError('Marshal agent capability input must be an object.'));
  }
  return Object.fromEntries(Object.entries(input));
}

function assertKeys(value: Record<string, unknown>, allowed: readonly string[]): void {
  const unexpected = Object.keys(value).find((key) => !allowed.includes(key));
  if (unexpected) throw invalidRequest(new TypeError(`Unexpected Marshal agent input property: ${unexpected}.`));
}

function text(value: Record<string, unknown>, key: string, maxLength?: number): string {
  const candidate = value[key];
  if (typeof candidate !== 'string' || !candidate.trim()) {
    throw invalidRequest(new TypeError(`${key} must be a non-empty string.`));
  }
  const normalized = candidate.trim();
  if (maxLength !== undefined && normalized.length > maxLength) {
    throw invalidRequest(new RangeError(`${key} must be at most ${maxLength} characters.`));
  }
  return normalized;
}

function optionalText(value: Record<string, unknown>, key: string, maxLength: number): string | undefined {
  return value[key] === undefined ? undefined : text(value, key, maxLength);
}

function optionalToolNames(value: Record<string, unknown>, key: string): readonly string[] | undefined {
  const candidate = value[key];
  if (candidate === undefined) return undefined;
  if (!Array.isArray(candidate) || candidate.length > MAX_ALLOWED_TOOLS) {
    throw invalidRequest(new TypeError(`${key} must be an array of at most ${MAX_ALLOWED_TOOLS} tool names.`));
  }
  const names = candidate.map((entry) => {
    if (typeof entry !== 'string' || entry.length > 128 || !ALLOWED_TOOL_NAME.test(entry)) {
      throw invalidRequest(new TypeError(`${key} entries must be valid tool names.`));
    }
    return entry;
  });
  if (new Set(names).size !== names.length) throw invalidRequest(new TypeError(`${key} entries must be unique.`));
  return names;
}

/** The MCP servers and skills a launch grants; whether they exist on this host is the port's check. */
function launchToolScope(
  value: Record<string, unknown>,
): Pick<MarshalRuntimeAgentLaunchRequest, 'mcpServers' | 'skills' | 'extensions' | 'nativeTools'> {
  try {
    const mcpServers = validateLaunchScopeNames(value.mcpServers, 'mcpServers');
    const skills = validateLaunchScopeNames(value.skills, 'skills');
    const extensions = validateLaunchScopeNames(value.extensions, 'extensions');
    const nativeTools = validateLaunchScopeNames(value.nativeTools, 'nativeTools');
    return {
      ...(mcpServers ? { mcpServers } : {}),
      ...(skills ? { skills } : {}),
      ...(extensions ? { extensions } : {}),
      ...(nativeTools ? { nativeTools } : {}),
    };
  } catch (error) {
    throw error instanceof TypeError ? invalidRequest(error) : error;
  }
}

/**
 * Shape check for a launch's `mcpServers`, `skills`, `extensions` or `nativeTools` list, shared with `runtime.delegation.spawn`:
 * bounded, unique, and each entry a well-formed server key or skill name. Throws TypeError.
 */
export function validateLaunchScopeNames(
  candidate: unknown,
  key: MarshalRuntimeAgentLaunchList,
): readonly string[] | undefined {
  if (candidate === undefined) return undefined;
  const { maximum, pattern, noun } = LAUNCH_LIST_RULES[key];
  if (!Array.isArray(candidate) || candidate.length > maximum) {
    throw new TypeError(`${key} must be an array of at most ${maximum} ${noun}.`);
  }
  const names = candidate.map((entry) => {
    if (typeof entry !== 'string' || entry.length > MAX_SCOPE_NAME_CHARS || !pattern.test(entry)) {
      throw new TypeError(`${key} entries must be valid ${noun}.`);
    }
    return entry;
  });
  if (new Set(names).size !== names.length) throw new TypeError(`${key} entries must be unique.`);
  return names;
}

function booleanValue(value: Record<string, unknown>, key: string): boolean {
  if (typeof value[key] !== 'boolean') throw invalidRequest(new TypeError(`${key} must be a boolean.`));
  return value[key];
}

function optionalInteger(value: Record<string, unknown>, key: string, minimum: number, maximum: number): number | undefined {
  const candidate = value[key];
  if (candidate === undefined) return undefined;
  if (!Number.isInteger(candidate) || Number(candidate) < minimum || Number(candidate) > maximum) {
    throw invalidRequest(new RangeError(`${key} must be an integer between ${minimum} and ${maximum}.`));
  }
  return Number(candidate);
}

function enumValue<const T extends readonly string[]>(value: Record<string, unknown>, key: string, allowed: T): T[number] {
  const candidate = value[key];
  if (typeof candidate !== 'string' || !allowed.includes(candidate)) {
    throw invalidRequest(new TypeError(`${key} must be one of: ${allowed.join(', ')}.`));
  }
  return candidate;
}
