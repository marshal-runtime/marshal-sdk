import type { UserPrincipal } from '../principals.js';
import type { RoomTextSelection } from './text-types.js';

/**
 * Conversation rooms: a shared org session as a room, so several people watch one conversation live and a streaming reply
 * arrives as small text appends. The room id derives from the org session id (`conversationRoomId`).
 *
 * Membership is the session's grants, not a second list: the room's members are exactly the session's owner and grantees,
 * with the same role (viewer, collaborator, driver, owner map one to one). The service answers room grant routes for a
 * conversation room (`POST`, `DELETE`) with 409 `{error: "session-room"}`; sharing is changed through the session's grants and the room follows. Any member
 * with collaborator or higher creates the room on first use (`POST /v1/rooms`, idempotent); the owner is the session owner.
 *
 * Only what already leaves a computer may be written: the scrubbed `user` and `assistant` text of the transcript. Nothing for
 * tool calls, tool output, system text or files; `checkConversationWrite` refuses anything else.
 */

/** The built-in room kind of a shared session. */
export const ROOM_CONVERSATION_KIND = 'marshal/conversation' as const;
/** Schema version of the built-in conversation kind. */
export const ROOM_CONVERSATION_SCHEMA_VERSION = 1 as const;
/** The room id prefix of a conversation room: `session:<org session id>`. */
export const CONVERSATION_ROOM_PREFIX = 'session:' as const;

export const CONVERSATION_MESSAGE_ROLES = ['user', 'assistant'] as const;
export type ConversationMessageRole = (typeof CONVERSATION_MESSAGE_ROLES)[number];

export const CONVERSATION_MESSAGE_STATES = ['streaming', 'final'] as const;
export type ConversationMessageState = (typeof CONVERSATION_MESSAGE_STATES)[number];

/**
 * `message:<org message id>` in a conversation room. `text` is a mergeable text field, so a streaming reply is a series of
 * small appends; `state` is `final` once the reply (or the user's message) is complete.
 */
export type ConversationMessageFields = {
  role: ConversationMessageRole;
  /** The person the message belongs to: who wrote a `user` message; the session owner whose agent wrote an `assistant` one. */
  author: UserPrincipal;
  text: string;
  state: ConversationMessageState;
  /** The turn this message belongs to (the org turn id); a turn's user message and reply share it. */
  turn: string;
  /** On a reply: the key of the user message it answers. */
  replyTo?: string;
  /** When the message was written on its author's computer (ISO), as in the transcript. */
  at?: string;
  /** The text was cut to fit; the transcript holds the full text. */
  truncated?: boolean;
};

/** Most entries of the agent strip's task list. */
export const MAX_CONVERSATION_TASKS = 50;
export const CONVERSATION_TASK_STATUSES = ['pending', 'in-progress', 'done', 'blocked'] as const;
export type ConversationTaskStatus = (typeof CONVERSATION_TASK_STATUSES)[number];

/** The agent strip: what the session's agent is doing right now, published by the desktop that runs it. */
export type ConversationAgentStrip = {
  busy: boolean;
  /** One line on the current step, at most 200 characters. */
  step?: string;
  tasks?: { title: string; status: ConversationTaskStatus }[];
  filesChanged?: number;
  subagentsRunning?: number;
};

/** Version of `ConversationPresenceState`. */
export const CONVERSATION_PRESENCE_VERSION = 1 as const;

/** Presence state in a conversation room (`presence.set(state)`), at most `MAX_PRESENCE_BYTES`. Written by the host only. */
export type ConversationPresenceState = {
  v: typeof CONVERSATION_PRESENCE_VERSION;
  /** The session is shown in a window on this desktop. */
  open?: boolean;
  /** The composer had input in the last few seconds. */
  composing?: boolean;
  /** Present only on the entry of the desktop running the session's agent. */
  agent?: ConversationAgentStrip;
  /** Caret or selection in a text field, when the screen offers one. */
  selection?: RoomTextSelection;
};
