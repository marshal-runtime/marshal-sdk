import type {
  RuntimeCatalogEntry,
  RuntimeCatalogProvider,
} from '@marshal/agent-runtime-core';
import type {
  RuntimeResourceDescriptor,
  RuntimeScopedResourcePort,
} from '@marshal/agent-runtime-composer';
import type {
  RuntimeExtensionManifest,
  RuntimeExtensionSkill,
  RuntimeExtensionSkillReference,
} from './contracts.js';

export const RUNTIME_EXTENSION_SKILL_FILENAME = 'SKILL.md';
export const RUNTIME_EXTENSION_MAX_SKILLS = 64;
const MAX_REFERENCES_PER_SKILL = 64;
const MAX_SKILL_FILE_BYTES = 262_144;
const MAX_DESCRIPTION_LENGTH = 1_024;
const SKILL_NAME_PATTERN = /^[a-z0-9][a-z0-9._-]{0,63}$/;
const REFERENCE_EXTENSIONS = ['.md', '.markdown', '.txt'];

/** The catalog contribution prefix that declares a skill folder: `skill:<package-relative folder>`. */
export const RUNTIME_EXTENSION_SKILL_CATALOG_PREFIX = 'skill:';
const FOLDER_SEGMENT_PATTERN = /^[A-Za-z0-9@._+-]+$/;

/**
 * `skill:<folder>` declares a skill folder. `skill://...` is not one: it is the id of a skill catalog entry the
 * extension registers in code, which packages already list in `contributes.catalog`.
 */
export function isRuntimeExtensionSkillDeclaration(entry: string): boolean {
  return entry.startsWith(RUNTIME_EXTENSION_SKILL_CATALOG_PREFIX) && !entry.startsWith(`${RUNTIME_EXTENSION_SKILL_CATALOG_PREFIX}//`);
}

/** The skill folders a manifest declares (`skill:` entries of `contributes.catalog`), validated as portable paths. */
export function declaredRuntimeExtensionSkillFolders(manifest: RuntimeExtensionManifest): readonly string[] {
  const folders = (manifest.contributes?.catalog ?? [])
    .filter(isRuntimeExtensionSkillDeclaration)
    .map((entry) => entry.slice(RUNTIME_EXTENSION_SKILL_CATALOG_PREFIX.length));
  if (folders.length > RUNTIME_EXTENSION_MAX_SKILLS) {
    throw new TypeError(`Runtime extension declares more than ${RUNTIME_EXTENSION_MAX_SKILLS} skills.`);
  }
  for (const folder of folders) {
    const segments = folder.split('/');
    if (!folder || folder.includes('\\') || folder.startsWith('/') || segments.some((segment) =>
      !segment || segment === '.' || segment === '..' || !FOLDER_SEGMENT_PATTERN.test(segment)
      || segment === 'node_modules' || segment === '.git')) {
      throw new TypeError(`Runtime extension skill folder "${folder}" must be a portable package-relative path.`);
    }
  }
  if (new Set(folders).size !== folders.length) throw new TypeError('Runtime extension skill folders repeat.');
  return Object.freeze(folders);
}

/**
 * Reads the skills a package declares (`skill:<folder>` catalog contributions) from the integrity-checked package files:
 * each folder holds `SKILL.md` (frontmatter `name`, `description`), and every other Markdown or text file under it is a
 * reference the skill may point to.
 */
export function readRuntimeExtensionSkills(
  manifest: RuntimeExtensionManifest,
  files: ReadonlyMap<string, Buffer>,
): readonly RuntimeExtensionSkill[] {
  const folders = declaredRuntimeExtensionSkillFolders(manifest);
  const prefixOf = (folder: string) => `${folder}/`;
  // A file belongs to the deepest declared skill folder that contains it.
  const ownerOf = (file: string) => folders
    .filter((folder) => file.startsWith(prefixOf(folder)))
    .sort((left, right) => prefixOf(right).length - prefixOf(left).length)[0];
  const names = new Set<string>();
  return Object.freeze(folders.map((folder) => {
    const prefix = prefixOf(folder);
    const bytes = files.get(`${prefix}${RUNTIME_EXTENSION_SKILL_FILENAME}`);
    if (!bytes) {
      throw new TypeError(`Runtime extension skill folder "${folder}" has no ${RUNTIME_EXTENSION_SKILL_FILENAME}.`);
    }
    const content = skillText(bytes, `${prefix}${RUNTIME_EXTENSION_SKILL_FILENAME}`);
    const frontmatter = parseSkillFrontmatter(content);
    const name = frontmatter.name ?? folder.split('/').pop() ?? '';
    if (!SKILL_NAME_PATTERN.test(name)) {
      throw new TypeError(`Runtime extension skill "${folder}" needs a lowercase name (frontmatter name or folder name).`);
    }
    if (names.has(name)) throw new TypeError(`Runtime extension skill name "${name}" repeats.`);
    names.add(name);
    const description = frontmatter.description?.trim();
    if (!description || description.length > MAX_DESCRIPTION_LENGTH) {
      throw new TypeError(
        `Runtime extension skill "${name}" needs a frontmatter description of at most ${MAX_DESCRIPTION_LENGTH} characters.`,
      );
    }
    const references: RuntimeExtensionSkillReference[] = [];
    for (const [file, referenceBytes] of files) {
      if (ownerOf(file) !== folder || file === `${prefix}${RUNTIME_EXTENSION_SKILL_FILENAME}`) continue;
      const relative = file.slice(prefix.length);
      if (!REFERENCE_EXTENSIONS.some((extension) => relative.toLowerCase().endsWith(extension))) continue;
      if (references.length >= MAX_REFERENCES_PER_SKILL) {
        throw new TypeError(`Runtime extension skill "${name}" has more than ${MAX_REFERENCES_PER_SKILL} reference files.`);
      }
      references.push(Object.freeze({ path: relative, content: skillText(referenceBytes, file) }));
    }
    return Object.freeze({
      name,
      title: frontmatter.title?.trim() || name,
      description,
      path: folder,
      content,
      references: Object.freeze(references),
    });
  }));
}

/** `skill://<identity>/<name>`; references live under it. */
export function runtimeExtensionSkillUri(identity: string, name: string, referencePath?: string): string {
  return `skill://${identity}/${name}${referencePath ? `/${referencePath}` : ''}`;
}

/** The catalog (runtime_search `skill` entries) and resources (the SKILL.md text and its references) of one extension. */
export function createRuntimeExtensionSkillContributions(
  identity: string,
  skills: readonly RuntimeExtensionSkill[],
): { readonly catalog: RuntimeCatalogProvider; readonly resources: RuntimeScopedResourcePort } {
  const entries: readonly RuntimeCatalogEntry[] = Object.freeze(skills.map((skill) => Object.freeze({
    id: runtimeExtensionSkillUri(identity, skill.name),
    kind: 'skill' as const,
    title: skill.title,
    description: skill.description,
    tags: Object.freeze(['skill', 'extension']),
    action: Object.freeze({ type: 'resource_read' as const, uri: runtimeExtensionSkillUri(identity, skill.name) }),
    metadata: Object.freeze({
      packageId: identity,
      extensionIdentity: identity,
      skillId: skill.name,
      references: Object.freeze(skill.references.map((reference) =>
        runtimeExtensionSkillUri(identity, skill.name, reference.path))),
    }),
  })));
  const texts = new Map<string, string>();
  const descriptors: RuntimeResourceDescriptor[] = [];
  for (const skill of skills) {
    const uri = runtimeExtensionSkillUri(identity, skill.name);
    texts.set(uri, skill.content);
    descriptors.push({
      uri,
      name: skill.title,
      description: skill.description,
      mimeType: 'text/markdown',
    });
    for (const reference of skill.references) {
      const referenceUri = runtimeExtensionSkillUri(identity, skill.name, reference.path);
      texts.set(referenceUri, reference.content);
      descriptors.push({
        uri: referenceUri,
        name: `${skill.title}: ${reference.path}`,
        mimeType: reference.path.toLowerCase().endsWith('.txt') ? 'text/plain' : 'text/markdown',
      });
    }
  }
  Object.freeze(descriptors);
  return {
    catalog: {
      id: `runtime.extension.skills.${identity}`,
      list: () => entries,
      get: (id) => entries.find((entry) => entry.id === id),
    },
    resources: {
      listResources: () => descriptors,
      readResource: (uri) => {
        const text = texts.get(uri);
        if (text === undefined) throw new Error(`Runtime extension skill resource not found: ${uri}`);
        return { uri, mimeType: uri.toLowerCase().endsWith('.txt') ? 'text/plain' : 'text/markdown', text };
      },
    },
  };
}

/**
 * The frontmatter subset skills use: `key: value` lines (plain, single- or double-quoted) and `|` / `>` block scalars,
 * between a leading `---` line and the next one. Unknown keys are ignored.
 */
export function parseSkillFrontmatter(content: string): Readonly<Record<string, string>> {
  const lines = content.replace(/^﻿/, '').split(/\r?\n/);
  if (lines[0]?.trim() !== '---') return {};
  const end = lines.findIndex((line, index) => index > 0 && line.trim() === '---');
  if (end < 0) return {};
  const result: Record<string, string> = {};
  for (let index = 1; index < end; index += 1) {
    const match = /^([A-Za-z][A-Za-z0-9_-]*):\s*(.*)$/.exec(lines[index]!);
    if (!match) continue;
    const key = match[1]!;
    let value = match[2]!.trim();
    if (value === '|' || value === '>' || value === '|-' || value === '>-') {
      const block: string[] = [];
      while (index + 1 < end && (/^\s+\S/.test(lines[index + 1]!) || !lines[index + 1]!.trim())) {
        index += 1;
        block.push(lines[index]!.trim());
      }
      value = value.startsWith('|') ? block.join('\n').trim() : block.join(' ').replace(/\s+/g, ' ').trim();
    } else if (/^".*"$/.test(value)) {
      try {
        value = JSON.parse(value) as string;
      } catch {
        value = value.slice(1, -1);
      }
    } else if (/^'.*'$/.test(value)) {
      value = value.slice(1, -1).replace(/''/g, "'");
    }
    result[key] = value;
  }
  return result;
}

function skillText(bytes: Buffer, file: string): string {
  if (bytes.length > MAX_SKILL_FILE_BYTES) {
    throw new TypeError(`Runtime extension skill file "${file}" exceeds ${MAX_SKILL_FILE_BYTES} bytes.`);
  }
  return new TextDecoder('utf-8', { fatal: true }).decode(bytes);
}
