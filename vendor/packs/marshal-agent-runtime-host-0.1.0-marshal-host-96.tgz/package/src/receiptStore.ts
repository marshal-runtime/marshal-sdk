import * as fs from 'node:fs/promises';
import * as path from 'node:path';
import {
  buildRuntimeReceiptForest,
  normalizeRuntimeExecutionCorrelations,
  type RuntimeExecutionReceipt,
  type RuntimeReceiptForest,
  type RuntimeReceiptQuery,
  type RuntimeReceiptStore,
} from '@marshal/agent-runtime-core';

export interface BoundedFileRuntimeReceiptStoreOptions {
  readonly filePath: string;
  readonly maxEntries?: number;
  readonly maxEntryBytes?: number;
}

const NEWLINE = 0x0a;

/**
 * Restart-safe, idempotent JSONL receipt journal for the portable local host.
 *
 * The journal reaches tens of megabytes, so it is never held as one string or one parsed array:
 * lines are read from the bytes one at a time, and compaction copies the retained bytes.
 */
export class BoundedFileRuntimeReceiptStore implements RuntimeReceiptStore {
  private readonly maxEntries: number;
  private readonly maxEntryBytes: number;
  private queue: Promise<void> = Promise.resolve();
  private knownReceiptIds: Set<string> | undefined;

  constructor(private readonly options: BoundedFileRuntimeReceiptStoreOptions) {
    if (!path.isAbsolute(options.filePath)) throw new TypeError('Receipt filePath must be absolute.');
    this.maxEntries = boundedInteger(options.maxEntries, 50_000, 1, 1_000_000, 'maxEntries');
    this.maxEntryBytes = boundedInteger(
      options.maxEntryBytes,
      1_048_576,
      1_024,
      16_777_216,
      'maxEntryBytes',
    );
  }

  record(receipt: RuntimeExecutionReceipt): Promise<void> {
    const operation = this.queue.then(() => this.recordNow(receipt));
    this.queue = operation.catch(() => undefined);
    return operation;
  }

  async list(query: RuntimeReceiptQuery = {}): Promise<readonly RuntimeExecutionReceipt[]> {
    await this.queue;
    const limit = boundedInteger(query.limit, this.maxEntries, 1, this.maxEntries, 'limit');
    // A queried id is in a matching line as the same JSON text this store wrote, so lines
    // without it are skipped before they are parsed.
    const needles = [query.rootExecutionId, query.parentExecutionId, query.principalId]
      .filter((value): value is string => value !== undefined)
      .map((value) => Buffer.from(JSON.stringify(value).slice(1, -1), 'utf8'));
    const entries: RuntimeExecutionReceipt[] = [];
    for (const { line } of journalLines(await this.readBytes())) {
      if (needles.some((needle) => !line.includes(needle))) continue;
      const receipt = parseReceipt(line);
      if (
        query.rootExecutionId !== undefined &&
        receipt.lineage.rootExecutionId !== query.rootExecutionId
      ) {
        continue;
      }
      if (
        query.parentExecutionId !== undefined &&
        receipt.lineage.parentExecutionId !== query.parentExecutionId
      ) {
        continue;
      }
      if (query.principalId !== undefined && receipt.principalId !== query.principalId) continue;
      entries.push(receipt);
    }
    return entries.slice(Math.max(0, entries.length - limit));
  }

  async tree(rootExecutionId: string): Promise<RuntimeReceiptForest> {
    if (!rootExecutionId.trim()) throw new TypeError('rootExecutionId is required.');
    return buildRuntimeReceiptForest(await this.list({ rootExecutionId, limit: this.maxEntries }));
  }

  private async recordNow(receipt: RuntimeExecutionReceipt): Promise<void> {
    await fs.mkdir(path.dirname(this.options.filePath), { recursive: true });
    if (!this.knownReceiptIds) this.knownReceiptIds = receiptIdsOf(await this.readBytes());
    if (this.knownReceiptIds.has(receipt.receiptId)) return;
    const correlations = normalizeRuntimeExecutionCorrelations(receipt.correlations);
    const storedReceipt = correlations ? { ...receipt, correlations } : receipt;
    const encoded = `${JSON.stringify(storedReceipt)}\n`;
    if (Buffer.byteLength(encoded) > this.maxEntryBytes) {
      throw new RangeError(`Receipt ${receipt.receiptId} exceeds maxEntryBytes.`);
    }
    await fs.appendFile(this.options.filePath, encoded, 'utf8');
    this.knownReceiptIds.add(receipt.receiptId);
    // The file keeps up to 10% slack past the bound (list() still returns only maxEntries),
    // so compaction rereads the journal once per slack window instead of on every record.
    if (this.knownReceiptIds.size <= this.maxEntries + compactionSlack(this.maxEntries)) return;
    const bytes = await this.readBytes();
    const starts: number[] = [];
    for (const { start } of journalLines(bytes)) starts.push(start);
    const retained = bytes.subarray(starts[Math.max(0, starts.length - this.maxEntries)] ?? 0);
    const complete = retained.length === 0 || retained[retained.length - 1] === NEWLINE;
    await fs.writeFile(
      this.options.filePath,
      complete ? retained : Buffer.concat([retained, Buffer.from([NEWLINE])]),
    );
    this.knownReceiptIds = receiptIdsOf(retained);
  }

  private async readBytes(): Promise<Buffer> {
    try {
      return await fs.readFile(this.options.filePath);
    } catch (error) {
      if ((error as NodeJS.ErrnoException).code === 'ENOENT') return Buffer.alloc(0);
      throw error;
    }
  }
}

/** The journal's entries in file order, each with its byte offset; blank lines are skipped. */
function* journalLines(bytes: Buffer): Generator<{ readonly start: number; readonly line: Buffer }> {
  let start = 0;
  while (start < bytes.length) {
    let end = bytes.indexOf(NEWLINE, start);
    if (end < 0) end = bytes.length;
    const line = bytes.subarray(start, end);
    if (!isBlank(line)) yield { start, line };
    start = end + 1;
  }
}

function isBlank(line: Buffer): boolean {
  for (const byte of line) {
    if (byte !== 0x20 && byte !== 0x09 && byte !== 0x0d) return false;
  }
  return true;
}

function parseEntry(line: Buffer): RuntimeExecutionReceipt {
  const value = JSON.parse(line.toString('utf8')) as RuntimeExecutionReceipt;
  if (!value || typeof value !== 'object' || typeof value.receiptId !== 'string') {
    throw new TypeError('Receipt journal contains an invalid entry.');
  }
  return value;
}

function parseReceipt(line: Buffer): RuntimeExecutionReceipt {
  const value = parseEntry(line);
  const correlations = normalizeRuntimeExecutionCorrelations(value.correlations);
  const legacyParent = value.scope?.parentExecutionId;
  const normalizedValue = correlations ? { ...value, correlations } : value;
  return normalizedValue.lineage
    ? normalizedValue
    : {
        ...normalizedValue,
        lineage: legacyParent
          ? { rootExecutionId: legacyParent, parentExecutionId: legacyParent, depth: 1 }
          : { rootExecutionId: normalizedValue.executionId, depth: 0 },
      };
}

function receiptIdsOf(bytes: Buffer): Set<string> {
  const ids = new Set<string>();
  for (const { line } of journalLines(bytes)) ids.add(parseEntry(line).receiptId);
  return ids;
}

function compactionSlack(maxEntries: number): number {
  return Math.max(1, Math.floor(maxEntries / 10));
}

function boundedInteger(
  value: number | undefined,
  fallback: number,
  minimum: number,
  maximum: number,
  label: string,
): number {
  const resolved = value ?? fallback;
  if (!Number.isSafeInteger(resolved) || resolved < minimum || resolved > maximum) {
    throw new RangeError(`${label} must be a safe integer from ${minimum} through ${maximum}.`);
  }
  return resolved;
}
