# @marshal/agent-runtime-prompt

One prompt assembler for every Marshal host. A session prompt is four layers, in a fixed order:

1. **core**: a host-neutral behavior core (`full`, `lean`, or `compact` for single-shot classifier, judge and extractor roles) and an optional Claude native tool adapter (ground rules, file tools, shell, deferred-tool discovery; `full`, `lean` or `deep`, with opt-in `web` and `notebooks` packs). The core says who the agent is and how it works, not where it runs.
2. **surface**: where the agent runs and which tools exist there. Built in: `cloud-slack`, `cloud-github`, `cloud-headless`. The desktop surface is not in this package: the desktop passes it as an injected layer (`{ id: 'desktop', sections, roleDelta?, coreSlots? }`).
3. **role**: `main`, `worker`, `subagent`, `reviewer`, `extractor`, `watchdog`, `router`. Additive: every role keeps the core.
4. **deltas**: an optional workspace delta (plain markdown from an organization workspace manifest), an optional org delta (who is in the session, how the reasoning trail is cited), the host's tool list, and host-owned extra sections.

```ts
import { assembleAgentPrompt } from '@marshal/agent-runtime-prompt';

const { content, sections } = assembleAgentPrompt({
  core: { behavior: 'lean', claudeTooling: 'deep' },
  surface: 'cloud-slack',
  role: 'main',
  workspaceDelta: manifest.prompt,
  orgDelta,
  tools: [{ name: 'slackReply', description: 'Post a reply in the current thread.' }],
  extraSections: [{ id: 'session', text: sessionContext }],
});
```

`sections` is `{ id, text }[]` in order: `core.behavior`, `core.adapter.claude`, `surface.<id>` (desktop: `surface.desktop.<id>`), `role.<role>`, `workspace`, `org`, `tools`, `extra.<id>`. Pieces are trimmed, empty pieces dropped, and joined with a blank line. Output is deterministic.

Host-dependent wording in the full and lean core and adapter (the desktop identity paragraph, "Marshal's permission policy", the live progress plan sentence, the desktop-tool sections of the adapter such as subagents, skills, scheduling and review findings) is a `⟦id⟧` span in the template. A host without an override gets the neutral text or nothing. The desktop supplies its original text through `coreSlots` (`coreSlotIds()` lists the ids), and then core plus its layer reproduce the desktop prompt byte for byte; the tests prove this against the desktop's own golden prompts. Cloud surfaces state only that the agent runs on a cloud host for that surface.

| Core | Characters | Approx. tokens (chars / 4) |
|---|---|---|
| `full` | 51,823 | 12,956 |
| `lean` | 38,070 | 9,518 |
| `compact` | 7,406 | 1,852 |
| adapter `full` / `lean` / `deep` | 7,065 / 5,535 / 4,168 | 1,766 / 1,384 / 1,042 |

## Marshal agent prompt v2 (`behavior: 'v2'`)

The v2 core is Marshal agent prompt v2: one text for the desktop and cloud hosts (`src/v2/templates.ts`, taken from the desktop's `electron/prompt/v2/sections`). It is several pieces, `core.v2.<section>`, chosen by what the session holds (`core.v2`: `delegation`, `runtime: 'trusted' | 'brokered' | false`, `hostTools`, `memoryBlock`). Host-dependent spans are `⟦v2.<section>.<span>⟧` (`v2SlotIds()`): the desktop passes its own words through `coreSlots` and renders byte for byte what it rendered from its files; a cloud host gets the neutral cloud wording (`V2_NEUTRAL_SLOT_DEFAULTS`) or its own through `core.slots`. A cloud surface renders only the shared sections; delegation, trusted blocks, showing results, the request ledger, long-running work, the desktop tool list and extension management (`V2_DESKTOP_ONLY_SECTIONS`) are desktop-only. The Brain section (`renderV2Section('knowledge')`) is rendered by the host when a Brain serves the session.

```ts
const { content } = assembleAgentPrompt({
  core: { behavior: 'v2', v2: { runtime: 'brokered' } },
  surface: 'cloud-slack',
  role: 'main',
});
```

| v2 core (cloud) | Characters | Approx. tokens |
|---|---|---|
| brokered runtime | 22,639 | 5,660 |
| brokered runtime, memory block | 23,294 | 5,824 |
| no runtime | 20,391 | 5,098 |

On a cloud host the text never tells the agent to merge or approve a pull request (people review and merge; a run's role may say otherwise), and it speaks of a memory block only when the host says it renders one (`memoryBlock`).

Tests prove desktop parity for every combination of the flags against the desktop's own files (`__tests__/fixtures/v2`) and pin the cloud core to goldens (`__tests__/golden-v2`). The `full`, `lean` and `compact` cores are unchanged. The v2 core is Marshal's own text and names Marshal's tools; organization text stays out of it.

The package holds no organization-specific text; organization specifics arrive only through `workspaceDelta` and `orgDelta`. Tests pin the core to fixtures copied from the desktop (`__tests__/fixtures`) and pin every surface and role combination to goldens (`__tests__/golden`; refresh with `UPDATE_GOLDEN=1 pnpm test`).
