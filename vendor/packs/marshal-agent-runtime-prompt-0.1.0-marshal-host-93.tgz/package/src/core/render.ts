import { CLAUDE_TOOL_PACKS } from './tool-packs.js';
import { NEUTRAL_SLOT_DEFAULTS } from './slot-defaults.js';

export type CoreSlotValues = Readonly<Record<string, string>>;

const MARKER = /⟦([^⟧]+)⟧/g;

/**
 * Fills a template's `⟦id⟧` spans. Per id: the host's value if it gave one, else the opted-in tool pack
 * text, else the neutral default, else an empty string.
 */
export function renderTemplate(
  template: string,
  options: { slots?: CoreSlotValues; packs?: readonly string[]; variant: string },
): string {
  const slots = options.slots ?? {};
  const packs = new Set(options.packs ?? []);
  return template.replace(MARKER, (_match, id: string) => {
    const supplied = slots[id];
    if (supplied !== undefined) return supplied;
    const packName = /\.pack-([a-z0-9-]+)$/.exec(id)?.[1];
    if (packName !== undefined) {
      return packs.has(packName) ? (CLAUDE_TOOL_PACKS[packName]?.[options.variant] ?? '') : '';
    }
    return NEUTRAL_SLOT_DEFAULTS[id] ?? '';
  });
}

/** Ids of every host-dependent span in a template. */
export function templateSlotIds(template: string): string[] {
  return [...new Set([...template.matchAll(MARKER)].map((match) => match[1] as string))];
}
