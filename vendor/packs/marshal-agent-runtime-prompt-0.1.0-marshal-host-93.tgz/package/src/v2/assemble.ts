import type { CoreSlotValues } from '../core/render.js';
import type { PromptSection } from '../types.js';
import { V2_NEUTRAL_SLOT_DEFAULTS, V2_NO_MEMORY_BLOCK_SLOT_DEFAULTS } from './slot-defaults.js';
import { V2_SECTION_TEMPLATES } from './templates.js';
import { V2_DESKTOP_ONLY_SECTIONS, type V2CoreOptions, type V2Host, type V2SectionId } from './types.js';

const MARKER = /⟦([^⟧]+)⟧/g;
const SECTION_PREFIX = 'core.v2.';

/** Ids of every host-dependent span of the v2 sections. */
export function v2SlotIds(): string[] {
  return [
    ...new Set(Object.values(V2_SECTION_TEMPLATES).flatMap((text) => [...text.matchAll(MARKER)].map((m) => m[1] as string))),
  ];
}

/**
 * One v2 section as the host renders it, trimmed. Per span: the host's value if it gave one, else the neutral cloud
 * text, else nothing. A cloud host may not render a desktop-only section.
 */
export function renderV2Section(id: V2SectionId, slots: CoreSlotValues = {}, host: V2Host = 'cloud'): string {
  if (host === 'cloud' && V2_DESKTOP_ONLY_SECTIONS.includes(id)) {
    throw new Error(`v2 section "${id}" is desktop-only`);
  }
  const template = V2_SECTION_TEMPLATES[id];
  if (template === undefined) throw new Error(`Unknown v2 section: ${String(id)}`);
  return template.replace(MARKER, (_match, slot: string) => slots[slot] ?? V2_NEUTRAL_SLOT_DEFAULTS[slot] ?? '').trim();
}

/** The fixed v2 sections a session gets, in order; a cloud host gets only the shared ones. */
export function v2FixedSectionIds(host: V2Host, options: V2CoreOptions = {}): V2SectionId[] {
  const runtime = options.runtime ?? false;
  if (host === 'cloud' && runtime === 'trusted') throw new Error('A cloud host runs brokered TypeScript blocks only');
  const ids: V2SectionId[] = [
    'identity',
    'working-loop',
    'finding-information',
    ...(options.delegation ? (['delegation'] as const) : []),
    ...(runtime === 'trusted' ? (['typescript'] as const) : []),
    ...(runtime === 'brokered' ? (['typescript-brokered'] as const) : []),
    ...(runtime ? (['typescript-rules', 'showing-results'] as const) : []),
    'memory-and-records',
    ...(options.hostTools ? (['requests', 'long-running', 'tools'] as const) : []),
    'communication-and-code',
  ];
  return host === 'cloud' ? ids.filter((id) => !V2_DESKTOP_ONLY_SECTIONS.includes(id)) : ids;
}

/**
 * The fixed v2 sections as prompt sections (`core.v2.<id>`). With the desktop's slot values and host `desktop` their
 * text joined by a blank line is what the desktop's own v2 assembler renders before its session-dependent part.
 */
export function buildV2CoreSections(host: V2Host, options: V2CoreOptions = {}, slots: CoreSlotValues = {}): PromptSection[] {
  const spans = host === 'cloud' && !options.memoryBlock ? { ...V2_NO_MEMORY_BLOCK_SLOT_DEFAULTS, ...slots } : slots;
  return v2FixedSectionIds(host, options)
    .map((id) => ({ id: `${SECTION_PREFIX}${id}`, text: renderV2Section(id, spans, host) }))
    .filter((section) => section.text.length > 0);
}
