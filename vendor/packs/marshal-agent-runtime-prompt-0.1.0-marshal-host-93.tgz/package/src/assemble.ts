import { BEHAVIOR_COMPACT } from './core/compact.js';
import { renderTemplate, templateSlotIds, type CoreSlotValues } from './core/render.js';
import {
  BEHAVIOR_FULL_TEMPLATE,
  BEHAVIOR_LEAN_TEMPLATE,
  CLAUDE_TOOLING_DEEP_TEMPLATE,
  CLAUDE_TOOLING_FULL_TEMPLATE,
  CLAUDE_TOOLING_LEAN_TEMPLATE,
} from './core/templates.js';
import { ROLE_DELTAS } from './roles.js';
import { buildV2CoreSections } from './v2/assemble.js';
import type { V2Host } from './v2/types.js';
import { CLOUD_GITHUB_SURFACE } from './surfaces/cloud-github.js';
import { CLOUD_HEADLESS_SURFACE } from './surfaces/cloud-headless.js';
import { CLOUD_SLACK_SURFACE } from './surfaces/cloud-slack.js';
import {
  AGENT_ROLES,
  CLOUD_SURFACE_IDS,
  type AgentPromptCore,
  type AssembleAgentPromptInput,
  type AssembledAgentPrompt,
  type ClaudeToolingOptions,
  type CloudSurfaceId,
  type PromptSection,
} from './types.js';

const CLOUD_SURFACE_TEXT: Readonly<Record<CloudSurfaceId, string>> = {
  'cloud-slack': CLOUD_SLACK_SURFACE,
  'cloud-github': CLOUD_GITHUB_SURFACE,
  'cloud-headless': CLOUD_HEADLESS_SURFACE,
};

const TOOLING_TEMPLATES = {
  full: CLAUDE_TOOLING_FULL_TEMPLATE,
  lean: CLAUDE_TOOLING_LEAN_TEMPLATE,
  deep: CLAUDE_TOOLING_DEEP_TEMPLATE,
} as const;

/** Every host-dependent span a host may fill, for the core and adapter variants. */
export function coreSlotIds(): string[] {
  return [
    ...new Set(
      [BEHAVIOR_FULL_TEMPLATE, BEHAVIOR_LEAN_TEMPLATE, ...Object.values(TOOLING_TEMPLATES)].flatMap(templateSlotIds),
    ),
  ];
}

function toolingOptions(value: NonNullable<AgentPromptCore['claudeTooling']>): ClaudeToolingOptions {
  return typeof value === 'string' ? { variant: value } : (value as ClaudeToolingOptions);
}

/**
 * The core's pieces; with the desktop's slot values they equal what the desktop emitted before the split. The `v2`
 * core is several pieces (`core.v2.<section>`), chosen by `host` and `core.v2`.
 */
export function buildCoreSections(core: AgentPromptCore, slots?: CoreSlotValues, host: V2Host = 'cloud'): PromptSection[] {
  if (core.behavior === 'v2') {
    const sections = buildV2CoreSections(host, core.v2, slots);
    return core.claudeTooling ? [...sections, toolingSection(core.claudeTooling, slots)] : sections;
  }
  const behavior =
    core.behavior === 'compact'
      ? BEHAVIOR_COMPACT
      : renderTemplate(core.behavior === 'lean' ? BEHAVIOR_LEAN_TEMPLATE : BEHAVIOR_FULL_TEMPLATE, {
          slots,
          variant: core.behavior,
        });
  const sections: PromptSection[] = [{ id: 'core.behavior', text: behavior.trim() }];
  if (core.claudeTooling) sections.push(toolingSection(core.claudeTooling, slots));
  return sections;
}

function toolingSection(value: NonNullable<AgentPromptCore['claudeTooling']>, slots?: CoreSlotValues): PromptSection {
  const options = toolingOptions(value);
  const text = renderTemplate(TOOLING_TEMPLATES[options.variant], {
    slots,
    packs: options.packs,
    variant: options.variant,
  });
  return { id: 'core.adapter.claude', text: text.trim() };
}

function renderTools(tools: NonNullable<AssembleAgentPromptInput['tools']>): string {
  const lines = tools.map((tool) => `- \`${tool.name}\`: ${tool.description.trim()}`);
  return `## Tools on this host\n\nThese are the tools this run can actually call. Do not assume any other tool exists.\n\n${lines.join('\n')}`;
}

const SECTION_ID = /^[a-z0-9][a-z0-9._-]*$/;

/**
 * Deterministic assembly of the shared agent prompt.
 *
 * Ordering contract (a stable prefix first, session-dependent text last):
 *   core.behavior, core.adapter.claude, surface.*, role.<role>, workspace, org, tools, extra.*
 * Empty and whitespace-only pieces are dropped; every piece is trimmed; pieces join with a blank line.
 */
export function assembleAgentPrompt(input: AssembleAgentPromptInput): AssembledAgentPrompt {
  if (!AGENT_ROLES.includes(input.role)) throw new Error(`Unknown agent role: ${String(input.role)}`);
  const surface = input.surface;
  const slots = typeof surface === 'string' ? input.core.slots : (surface.coreSlots ?? input.core.slots);
  const sections: PromptSection[] = buildCoreSections(input.core, slots, typeof surface === 'string' ? 'cloud' : 'desktop');

  let roleText = ROLE_DELTAS[input.role];
  if (typeof surface === 'string') {
    if (!CLOUD_SURFACE_IDS.includes(surface)) {
      throw new Error(`Surface "${String(surface)}" needs an injected layer; only cloud surfaces are built in`);
    }
    sections.push({ id: `surface.${surface}`, text: CLOUD_SURFACE_TEXT[surface].trim() });
  } else {
    if (surface.id !== 'desktop') throw new Error('Injected surface layers must use id "desktop"');
    for (const section of surface.sections) {
      sections.push({ id: `surface.desktop.${section.id}`, text: section.text.trim() });
    }
    if (surface.roleDelta !== undefined) roleText = surface.roleDelta;
  }
  sections.push({ id: `role.${input.role}`, text: roleText.trim() });

  if (input.workspaceDelta !== undefined) sections.push({ id: 'workspace', text: input.workspaceDelta.trim() });
  if (input.orgDelta !== undefined) sections.push({ id: 'org', text: input.orgDelta.trim() });
  if (input.tools && input.tools.length > 0) sections.push({ id: 'tools', text: renderTools(input.tools) });
  for (const section of input.extraSections ?? []) {
    sections.push({ id: `extra.${section.id}`, text: section.text.trim() });
  }

  const kept = sections.filter((section) => section.text.length > 0);
  const seen = new Set<string>();
  for (const section of kept) {
    if (!SECTION_ID.test(section.id)) throw new Error(`Invalid prompt section id: ${section.id}`);
    if (seen.has(section.id)) throw new Error(`Duplicate prompt section id: ${section.id}`);
    seen.add(section.id);
  }
  return { content: kept.map((section) => section.text).join('\n\n'), sections: kept };
}
