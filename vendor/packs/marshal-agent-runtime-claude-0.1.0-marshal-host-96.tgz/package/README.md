# `@marshal/agent-runtime-claude`

Claude Code session files for Marshal hosts, written once for the desktop and the cloud engine:

- `findClaudeSessionFile`, `claudeSessionFilePath`, `writeClaudeSessionFile`: where Claude Code keeps a session, and an atomic write that can be undone.
- `rewriteClaudeSessionId`: points a session file at a new id.
- `forkClaudeJsonl` and `forkClaudeSessionFile`: copy a live session into a child that resumes from the same conversation (so the prompt cache still matches), with the open fork call answered for the child.
- `forkLaunchPrompt`, `forkCallResult`, `FORK_OTHER_CALL_RESULT`: the texts a fork starts from; each host passes its own sibling and closing guidance.

A host names the tool that starts a fork (`toolName`) and, when the call can come through a wrapper tool, the capability it carries and the wrappers (`wrappers`). Marshal's `runtimeInvoke` and `runtimeExecuteTypeScript` are the default.

```ts


const child = await forkClaudeSessionFile(configDir, parentId, cwd, {
  sessionId: childId,
  toolName: 'forkSubagents',
  capability: 'agents.fork.spawn',
  wrappers: [{ tool: 'runtime_exec', field: 'target', match: 'equals' }],
  result: forkCallResult({ index: 1, total: 2, sessionId: childId }),
  otherResult: FORK_OTHER_CALL_RESULT,
});
// resume the child with Options.resume = childId; child.discard() undoes the write
```

The package has no dependencies and no Electron code.
