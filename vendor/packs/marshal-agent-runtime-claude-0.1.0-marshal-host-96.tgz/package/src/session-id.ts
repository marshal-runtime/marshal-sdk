import { decodedLines, Utf8Sink } from "./jsonl.js";

const SESSION_ID_KEY = "sessionId";
/** Room for the longer ids a rewrite can bring before the output has to grow. */
const OUTPUT_HEADROOM_BYTES = 64 * 1024;

/** The ids Claude Code accepts as a session id; a path or anything longer is refused before it reaches the file system. */
export const CLAUDE_SESSION_ID_PATTERN = /^[A-Za-z0-9][A-Za-z0-9_-]{0,127}$/;

/** True when `sessionId` is safe to use as a Claude session file name. */
export function isClaudeSessionId(sessionId: string): boolean {
  return CLAUDE_SESSION_ID_PATTERN.test(sessionId);
}

/** `entry` as a line with the new session id, or undefined when it is not a JSON object that carries one. */
export function entryWithSessionId(entry: unknown, sessionId: string): string | undefined {
  if (
    typeof entry !== "object" ||
    entry === null ||
    Array.isArray(entry) ||
    !(SESSION_ID_KEY in entry) ||
    typeof (entry as Record<string, unknown>)[SESSION_ID_KEY] !== "string"
  ) {
    return undefined;
  }
  return JSON.stringify({ ...entry, [SESSION_ID_KEY]: sessionId });
}

/**
 * Points a Claude session file at a new session id: every line that carries a top-level `sessionId` gets
 * the new one. Lines that are not JSON objects, or carry no session id, are kept byte for byte.
 * The file is read and written one line at a time, so its text is never in memory as a whole.
 */
export function rewriteClaudeSessionId(bytes: Uint8Array, sessionId: string): Uint8Array {
  const out = new Utf8Sink(bytes.byteLength + OUTPUT_HEADROOM_BYTES);
  let rewritten = 0;
  let first = true;
  for (const line of decodedLines(bytes)) {
    if (!first) out.write("\n");
    first = false;
    const replaced =
      line.trim() === "" ? undefined : entryWithSessionId(parseOrUndefined(line), sessionId);
    if (replaced !== undefined) rewritten += 1;
    out.write(replaced ?? line);
  }
  if (rewritten === 0) throw new Error("no-session-id");
  return out.finish();
}

function parseOrUndefined(line: string): unknown {
  try {
    return JSON.parse(line) as unknown;
  } catch {
    return undefined;
  }
}
