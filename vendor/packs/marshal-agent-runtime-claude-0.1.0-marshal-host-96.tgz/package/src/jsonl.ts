const NEWLINE_BYTE = 0x0a;
const MIN_CAPACITY = 1024;

/**
 * The lines `new TextDecoder().decode(bytes).split("\n")` gives, decoded one at a time. A session
 * file runs to hundreds of megabytes; as one string, its lines and the joined copies of them, it
 * took gigabytes of the host's heap for the length of a fork.
 */
export function* decodedLines(bytes: Uint8Array): Generator<string, void, void> {
  // Only the start of the file loses a byte order mark, as it does when the file is decoded whole.
  const first = new TextDecoder();
  const rest = new TextDecoder("utf-8", { ignoreBOM: true });
  let start = 0;
  for (;;) {
    const end = bytes.indexOf(NEWLINE_BYTE, start);
    const line = bytes.subarray(start, end < 0 ? bytes.length : end);
    yield (start === 0 ? first : rest).decode(line);
    if (end < 0) return;
    start = end + 1;
  }
}

/** UTF-8 output written in place, so text is never held as one string before it is encoded. */
export class Utf8Sink {
  readonly #encoder = new TextEncoder();
  #bytes: Uint8Array;
  #length = 0;

  constructor(capacity: number) {
    this.#bytes = new Uint8Array(Math.max(capacity, MIN_CAPACITY));
  }

  write(text: string): void {
    let offset = 0;
    while (offset < text.length) {
      const { read, written } = this.#encoder.encodeInto(
        offset === 0 ? text : text.slice(offset),
        this.#bytes.subarray(this.#length),
      );
      this.#length += written;
      offset += read;
      if (offset < text.length) this.#grow(text.length - offset);
    }
  }

  /** The bytes written so far, in an array of exactly that length. */
  finish(): Uint8Array {
    return this.#length === this.#bytes.length ? this.#bytes : this.#bytes.slice(0, this.#length);
  }

  #grow(pendingChars: number): void {
    const grown = new Uint8Array(
      Math.max(this.#bytes.length + (this.#bytes.length >> 1), this.#length + pendingChars),
    );
    grown.set(this.#bytes.subarray(0, this.#length));
    this.#bytes = grown;
  }
}
