/** One fork of a fork call, as its siblings see it. */
export interface ForkSibling {
  index: number;
  sessionId: string;
  task: string;
}

/** What a fork's first message is built from; `siblingNote` and `closing` are the host's own guidance. */
export interface ForkLaunch {
  parentSessionId: string;
  index: number;
  total: number;
  task: string;
  siblings: readonly ForkSibling[];
  /** Line after the sibling list: how a fork stays out of a sibling's way on this host. */
  siblingNote: string;
  /** Last line: how the fork reports back on this host. */
  closing: string;
}

/** The result a fork sees for the fork call that created it. */
export function forkCallResult(fork: { index: number; total: number; sessionId: string }): string {
  return `Forked. You are fork ${fork.index} of ${fork.total} (session ${fork.sessionId}), created by this call; the parent session continues on its own. Your assignment is in the next message.`;
}

/** The result every other call left open beside the fork call gets in a fork. */
export const FORK_OTHER_CALL_RESULT =
  "Not part of this fork: the parent session handles this call and its result.";

/** A fork's first message: who it is, its task, and its siblings. */
export function forkLaunchPrompt(launch: ForkLaunch): string {
  return [
    `Fork assignment ${launch.index}/${launch.total}`,
    `You are a fork of session ${launch.parentSessionId}: everything above is that session's conversation, and you continue it with the same context. The parent and your sibling forks carry on separately, so do only your part.`,
    "",
    "Your task:",
    launch.task,
    ...(launch.siblings.length > 0
      ? [
          "",
          "Sibling forks working beside you (same workspace):",
          ...launch.siblings.map(
            (other) => `- Fork ${other.index} (${other.sessionId}): ${other.task}`,
          ),
          launch.siblingNote,
        ]
      : []),
    "",
    launch.closing,
  ].join("\n");
}
