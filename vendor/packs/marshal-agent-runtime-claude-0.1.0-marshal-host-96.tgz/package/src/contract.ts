/** One task of a fork call. A model or runtime other than the parent's starts from a transcript instead of the parent's session file. */
export interface ForkSubagentTask {
  task: string;
  name?: string;
  model?: string;
  runtime?: string;
  reasoningEffort?: "low" | "medium" | "high" | "xhigh" | "max";
}

/** One fork a fork call created. */
export interface ForkCreated {
  sessionId: string;
  name: string;
  task: string;
}

/** What a fork call returns at once: the group it made and its forks. */
export interface ForkGroup {
  groupId: string;
  forks: ForkCreated[];
}
