import { randomUUID } from "node:crypto";
import fs from "node:fs";
import path from "node:path";

import { isClaudeSessionId } from "./session-id.js";

/** The format name of a Claude Code session file (one JSON entry per line). */
export const CLAUDE_NATIVE_STATE_FORMAT = "claude-jsonl";
/** A session file above this is refused. */
export const MAX_NATIVE_STATE_BYTES = 256 * 1024 * 1024;
const PROJECTS_DIR = "projects";
const SESSION_FILE_SUFFIX = ".jsonl";
const BACKUP_SUFFIX = ".bak";
const DIR_MODE = 0o700;
const FILE_MODE = 0o600;
/** The longest project directory name Claude Code writes without a hash. */
export const MAX_PROJECT_DIRECTORY_CHARS = 200;
const UNSAFE_NAME_CHARS = /[^A-Za-z0-9]/g;
const NAME_SEPARATOR = "-";
const HASH_RADIX = 36;
const HASH_SHIFT = 5;
const DARWIN = "darwin";
const NFC = "NFC";

function pathHash(text: string): string {
  let hash = 0;
  for (let index = 0; index < text.length; index += 1)
    hash = ((hash << HASH_SHIFT) - hash + text.charCodeAt(index)) | 0;
  return Math.abs(hash).toString(HASH_RADIX);
}

/**
 * The directory under `projects/` Claude Code keeps a working directory's sessions in: every
 * non-alphanumeric character becomes `-` (after NFC normalization on macOS), and a name past 200
 * characters is cut and ends in `-` and a hash of the path.
 */
export function claudeProjectDirectoryName(
  workingDirectory: string,
  platform: string = process.platform,
): string {
  const normalized = platform === DARWIN ? workingDirectory.normalize(NFC) : workingDirectory;
  const name = normalized.replace(UNSAFE_NAME_CHARS, NAME_SEPARATOR);
  return name.length <= MAX_PROJECT_DIRECTORY_CHARS
    ? name
    : `${name.slice(0, MAX_PROJECT_DIRECTORY_CHARS)}${NAME_SEPARATOR}${pathHash(normalized)}`;
}

/** Where Claude Code keeps the session file of `sessionId` for `workingDirectory` under `configDir`. */
export function claudeSessionFilePath(
  configDir: string,
  workingDirectory: string,
  sessionId: string,
): string {
  if (!isClaudeSessionId(sessionId)) throw new Error("Invalid Claude session id");
  return path.join(
    configDir,
    PROJECTS_DIR,
    claudeProjectDirectoryName(workingDirectory),
    `${sessionId}${SESSION_FILE_SUFFIX}`,
  );
}

const isFile = (file: string) =>
  fs.promises.stat(file).then(
    (stat) => stat.isFile(),
    () => false,
  );

/** The session file of `sessionId`: the one of `workingDirectory` first, else the first project directory that has it, else null. */
export async function findClaudeSessionFile(
  configDir: string,
  sessionId: string,
  workingDirectory: string,
): Promise<string | null> {
  const preferred = claudeSessionFilePath(configDir, workingDirectory, sessionId);
  if (await isFile(preferred)) return preferred;
  const projectsDir = path.join(configDir, PROJECTS_DIR);
  const entries = await fs.promises.readdir(projectsDir, { withFileTypes: true }).catch(() => []);
  const candidates = entries
    .filter((entry) => entry.isDirectory())
    .map((entry) => path.join(projectsDir, entry.name, `${sessionId}${SESSION_FILE_SUFFIX}`));
  const found = await Promise.all(candidates.map(isFile));
  const index = found.indexOf(true);
  return index >= 0 ? (candidates[index] ?? null) : null;
}

/** A written session file and how to undo the write. */
export interface WrittenClaudeSession {
  file: string;
  bytes: Uint8Array;
  discard: () => Promise<void>;
}

/** Replaces the session file atomically, keeping the previous one as `.bak` until `discard` restores it. */
export async function writeClaudeSessionFile(
  configDir: string,
  sessionId: string,
  workingDirectory: string,
  bytes: Uint8Array,
): Promise<WrittenClaudeSession> {
  if (bytes.byteLength > MAX_NATIVE_STATE_BYTES) throw new Error("native-state-too-large");
  const existing = await findClaudeSessionFile(configDir, sessionId, workingDirectory);
  const target = existing ?? claudeSessionFilePath(configDir, workingDirectory, sessionId);
  const backup = `${target}${BACKUP_SUFFIX}`;
  await fs.promises.mkdir(path.dirname(target), { recursive: true, mode: DIR_MODE });
  const temp = `${target}.${randomUUID()}.tmp`;
  await fs.promises.writeFile(temp, bytes, { mode: FILE_MODE });
  try {
    if (existing) await fs.promises.copyFile(existing, backup);
    await fs.promises.rename(temp, target);
  } catch (error) {
    await fs.promises.rm(temp, { force: true });
    throw error;
  }
  return {
    file: target,
    bytes,
    discard: async () => {
      if (existing) {
        await fs.promises.copyFile(backup, target);
        await fs.promises.rm(backup, { force: true });
      } else {
        await fs.promises.rm(target, { force: true });
      }
    },
  };
}
