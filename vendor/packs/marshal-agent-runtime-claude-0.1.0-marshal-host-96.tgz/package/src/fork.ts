import { randomUUID } from "node:crypto";
import fs from "node:fs";

import { decodedLines, Utf8Sink } from "./jsonl.js";
import {
  findClaudeSessionFile,
  MAX_NATIVE_STATE_BYTES,
  writeClaudeSessionFile,
  type WrittenClaudeSession,
} from "./session-file.js";
import { entryWithSessionId, isClaudeSessionId } from "./session-id.js";

/** Marshal's own request captures: debugging copies of what was sent, never part of the conversation. */
const CAPTURE_TYPES = new Set(["api-request", "api-request-shape", "api-request-blob"]);
/** Fields copied from the tail entry so the appended entry looks like one the CLI wrote itself. */
const CARRIED_FIELDS = ["userType", "entrypoint", "cwd", "version", "gitBranch"] as const;
const MCP_NAME_SEPARATOR = "__";
const MARSHAL_CAPABILITY_PREFIX = "marshal.tool.";
/** How long a fork waits for the CLI to write the assistant entry that holds the fork call. */
export const FORK_CALL_FLUSH_TIMEOUT_MS = 5_000;
const FORK_CALL_POLL_MS = 100;
/** The error thrown while the session file does not yet hold an open fork call. */
export const FORK_CALL_NOT_FOUND = "fork-call-not-found";
/** Room for the appended entry and a longer session id before the output has to grow. */
const OUTPUT_HEADROOM_BYTES = 64 * 1024;

/** A tool that can carry the fork call inside its input: the call matches when `field` of the input equals (or, for `includes`, contains) the fork capability. */
export interface ForkCallWrapper {
  tool: string;
  field: string;
  match: "equals" | "includes";
}

/** Marshal's wrappers: a capability called through `runtimeInvoke`, or named in a `runtimeExecuteTypeScript` script. */
export const MARSHAL_FORK_WRAPPERS: readonly ForkCallWrapper[] = [
  { tool: "runtimeInvoke", field: "capability", match: "equals" },
  { tool: "runtimeExecuteTypeScript", field: "source", match: "includes" },
];

/** How to find the fork call in a session and what to answer it with. */
export interface ClaudeForkRequest {
  /** The child's session id. */
  sessionId: string;
  /** Tool whose open call started the fork (matched with or without an MCP prefix). */
  toolName: string;
  /** Result of the fork call as the child sees it. */
  result: string;
  /** Result of every other call left open in the same assistant message. */
  otherResult: string;
  /** The capability name a wrapper tool carries for the fork; `marshal.tool.<toolName>` when unset. */
  capability?: string;
  /** Tools that can carry the fork call; Marshal's when unset. */
  wrappers?: readonly ForkCallWrapper[];
}

type Entry = Record<string, unknown>;

/** A tool call of the conversation, reduced to what answering the fork needs. */
interface ForkCall {
  id: string;
  isFork: boolean;
}

function isRecord(value: unknown): value is Entry {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

function contentBlocks(entry: Entry): Entry[] {
  const message = entry["message"];
  if (!isRecord(message) || !Array.isArray(message["content"])) return [];
  return message["content"].filter(isRecord);
}

function isNamed(name: unknown, toolName: string): boolean {
  return (
    typeof name === "string" &&
    (name === toolName || name.endsWith(`${MCP_NAME_SEPARATOR}${toolName}`))
  );
}

function matchesTool(block: Entry, request: ClaudeForkRequest): boolean {
  if (isNamed(block["name"], request.toolName)) return true;
  const input = block["input"];
  if (!isRecord(input)) return false;
  const capability = request.capability ?? `${MARSHAL_CAPABILITY_PREFIX}${request.toolName}`;
  return (request.wrappers ?? MARSHAL_FORK_WRAPPERS).some((wrapper) => {
    if (!isNamed(block["name"], wrapper.tool)) return false;
    const value = input[wrapper.field];
    if (typeof value !== "string") return false;
    return wrapper.match === "equals" ? value === capability : value.includes(capability);
  });
}

/**
 * Copies a Claude session file into a fork that resumes exactly where the source stands: the
 * conversation entries are kept as they are (so the prompt cache still matches), and the fork tool
 * call that is still open at the end gets the child's own result, written as the CLI writes tool
 * results. Calls left open beside it get `otherResult`. Throws when no open fork call exists or
 * the assistant message that made it has no id.
 */
export function forkClaudeJsonl(bytes: Uint8Array, request: ClaudeForkRequest): Uint8Array {
  const out = new Utf8Sink(bytes.byteLength + OUTPUT_HEADROOM_BYTES);
  const callsByMessage = new Map<string, ForkCall[]>();
  const answered = new Set<unknown>();
  let forkAssistant: { uuid: unknown; messageId: unknown } | undefined;
  let tail: { uuid: unknown; carried: [string, unknown][] } | undefined;

  // One line at a time, keeping only these facts: holding every parsed entry and the file as
  // strings took gigabytes for a 100 MB session and ran the host out of heap.
  for (const line of decodedLines(bytes)) {
    if (!line.trim()) continue;
    let parsed: unknown;
    try {
      parsed = JSON.parse(line) as unknown;
    } catch {
      out.write(line);
      out.write("\n");
      continue;
    }
    if (isRecord(parsed)) {
      if (typeof parsed["type"] === "string" && CAPTURE_TYPES.has(parsed["type"])) continue;
      if (typeof parsed["uuid"] === "string" && parsed["isSidechain"] !== true) {
        if (parsed["type"] === "assistant") {
          const message = parsed["message"];
          const messageId = isRecord(message) ? message["id"] : undefined;
          let callsFork = false;
          for (const block of contentBlocks(parsed)) {
            if (block["type"] !== "tool_use") continue;
            const isFork = matchesTool(block, request);
            callsFork ||= isFork;
            const id = block["id"];
            if (typeof id !== "string" || typeof messageId !== "string") continue;
            const calls = callsByMessage.get(messageId);
            if (calls) calls.push({ id, isFork });
            else callsByMessage.set(messageId, [{ id, isFork }]);
          }
          if (callsFork) forkAssistant = { uuid: parsed["uuid"], messageId };
        } else if (parsed["type"] === "user") {
          for (const block of contentBlocks(parsed)) {
            if (block["type"] === "tool_result") answered.add(block["tool_use_id"]);
          }
        }
        const entry = parsed;
        tail = {
          uuid: entry["uuid"],
          carried: CARRIED_FIELDS.filter((field) => field in entry).map((field) => [
            field,
            entry[field],
          ]),
        };
      }
    }
    out.write(entryWithSessionId(parsed, request.sessionId) ?? line);
    out.write("\n");
  }

  if (!forkAssistant || !tail) throw new Error(FORK_CALL_NOT_FOUND);
  const { messageId } = forkAssistant;
  if (typeof messageId !== "string" || !messageId) throw new Error("fork-message-id-missing");
  const open = (callsByMessage.get(messageId) ?? []).filter((call) => !answered.has(call.id));
  if (!open.some((call) => call.isFork)) throw new Error(FORK_CALL_NOT_FOUND);

  const content = open.map((call) => {
    const text = call.isFork ? request.result : request.otherResult;
    return { tool_use_id: call.id, type: "tool_result", content: [{ type: "text", text }] };
  });
  const appended = {
    parentUuid: tail.uuid,
    isSidechain: false,
    type: "user",
    message: { role: "user", content },
    uuid: randomUUID(),
    timestamp: new Date().toISOString(),
    toolUseResult: content.length === 1 ? content[0]?.content : content.map((c) => c.content),
    sourceToolAssistantUUID: forkAssistant.uuid,
    ...Object.fromEntries(tail.carried),
    sessionId: request.sessionId,
  };
  out.write(JSON.stringify(appended));
  out.write("\n");
  return out.finish();
}

/**
 * Writes a fork of a live session as `request.sessionId`: the source file is copied as it is with the
 * open fork call answered for the child. The CLI can run a tool before it has written the assistant
 * entry that called it, so the file is read again until that call is in it or `timeoutMs` passes.
 */
export async function forkClaudeSessionFile(
  configDir: string,
  sourceId: string,
  workingDirectory: string,
  request: ClaudeForkRequest,
  timeoutMs = FORK_CALL_FLUSH_TIMEOUT_MS,
): Promise<WrittenClaudeSession> {
  if (!isClaudeSessionId(sourceId)) throw new Error("Invalid Claude session id");
  const file = await findClaudeSessionFile(configDir, sourceId, workingDirectory);
  if (!file) throw new Error("fork-source-missing");
  const deadline = Date.now() + timeoutMs;
  for (;;) {
    const stat = await fs.promises.stat(file);
    if (stat.size > MAX_NATIVE_STATE_BYTES) throw new Error("native-state-too-large");
    try {
      const bytes = forkClaudeJsonl(await fs.promises.readFile(file), request);
      return await writeClaudeSessionFile(configDir, request.sessionId, workingDirectory, bytes);
    } catch (error) {
      if (!(error instanceof Error) || error.message !== FORK_CALL_NOT_FOUND) throw error;
      if (Date.now() >= deadline) throw error;
      await new Promise((resolve) => setTimeout(resolve, FORK_CALL_POLL_MS));
    }
  }
}
